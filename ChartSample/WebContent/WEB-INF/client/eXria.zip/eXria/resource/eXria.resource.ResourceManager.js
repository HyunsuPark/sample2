/**
 * @fileoverview
 * ResourceManager
 * Resource clear 
 */

/**
 * ResourceManager
 * Resource clear 
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.resource.ResourceManager = {
  clear : function(poCtrl) {
    //TODO 
  }
};