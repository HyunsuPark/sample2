﻿/**
 * @fileoverview
 * Nodeset Data Reference class(노드 데이타 레퍼런스 기본 클래스)
 * @author 조동일
 */

/**
 * @class Nodeset Data Reference class.<br>
 * 노드 데이타 레퍼런스 기본 클래스.
 * @version 1.0
 * @constructor
 * @base eXria.controls.DataRefNode
 * @param {Object} poControl page의 Instance가 참조 가능한 컨트롤 객체  
 * @return 새로운 eXria.controls.DataRefNodeset 객체
 * @type eXria.controls.DataRefNodeset
 */
eXria.controls.DataRefNodeset = function(poControl) {
  eXria.controls.DataRefNode.call(this, poControl);
  /**
   * page의 nodeset instance id
   * @type String
   */
  this.nodesetInstanceId = null;
  /**
   * instance 내부의 nodeset path
   * @type String
   */
  this.nodesetInstancePath = null;
  /**
   * Collection에 반복되는 Tag명
   * @type String
   */
  this.loopTag = "list";
  /**
   * addData 시 Field 스키마를 유지하기 위한 반복 노드 템플릿 객체
   * @type eXria.data.xhtml.Node
   * @private
   */
  this.cloneRefer = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.DataRefNode, eXria.controls.DataRefNodeset);
/**
 * Nodeset reference를 설정한다.
 * @param {String} psNodesetInstanceId Page에서 Unique한 InstanceId
 * @param {String} psNodesetPath 해당 Instance에서의 태그명
 * @param {String} psParentPath control이 repeater나 tree view등
 *   container control안에 포함되어 있는 경우 container control의
 *   node XPath. container control에 포함되지 않을 경우는
 *   넘기지 않는다.
 */
eXria.controls.DataRefNodeset.prototype.setNodesetRef = function(psNodesetInstanceId, psNodesetPath, psParentPath) {
  this.nodesetInstanceId = psNodesetInstanceId;
  if(psNodesetPath == null) return;
  if(psParentPath) {
    this.nodesetInstancePath = psParentPath + "/" + psNodesetPath;
  } else {
    this.nodesetInstancePath = psNodesetPath;
  }    
  var vaPath = psNodesetPath.split("/");
  this.loopTag = vaPath[vaPath.length - 1];
  
  //xhtml autocrud
  var voIns = page.getInstance(this.nodesetInstanceId);
  var voRow = voIns.selectSingleNode(this.nodesetInstancePath);
  if(voRow) {
    this.cloneRefer = voRow.cloneNode(true);
    var voMapNode = new eXria.data.xhtml.MapNode(this.cloneRefer);
    var voKeyCollection = voMapNode.getKeyCollection();
    var vnSize = voKeyCollection.size();
    var vsCol = null;
    for(var i = 0; i < vnSize; i++) {
      vsCol = voKeyCollection.get(i);
      voMapNode.put(vsCol, "");
    }
  }
};
/**
 * page에 접근해서 nodeset의 instance를 찾아서 리턴
 * @return page의 해당 nodeset의 instance
 * @type eXria.data.xhtml.Instance
 */
eXria.controls.DataRefNodeset.prototype.getNodesetInstance = function() {
  return this.control.canvas.page.getInstance(this.nodesetInstanceId);
};
/**
 * page에 접근해서 instance를 찾아서
 * CollectionNode로 instance를 wrapping하여 리턴
 * @param {Number} pnIdx 특별한 인덱스의 값이 필요한 경우 조회 하고자 하는 인덱스 값을 전달한다.
 * @return pnIdx값이 넘어온 경우 eXria.data.xhtml.CollectionNode.<br>
 *         pnIdx값이 넘어오지 않은 경우 eXria.data.xhtml.MapNode.
 * @type Object
 */
eXria.controls.DataRefNodeset.prototype.getNodesetData = function(pnIdx) { /* helper function */
	if(this.nodesetInstanceId == null)
		 return null;
	
	var viInstance = this.getNodesetInstance();
  
 var vaPath = this.nodesetInstancePath.split("/");
 var vsNodesetInstancePath = "";
  for(var i = 0; i < vaPath.length - 1; i++) {
    vsNodesetInstancePath += vaPath[i];
    if(i < vaPath.length - 2) vsNodesetInstancePath += "/";
  }    
  
  var voInstanceNode = null;
  try { voInstanceNode = viInstance.selectSingleNode(vsNodesetInstancePath); } catch(err) {}
  if(voInstanceNode == null) return null;
  if(pnIdx != null) {
    return new eXria.data.xhtml.MapNode(voInstanceNode.getChildNodes().item(pnIdx));
  } else {
    return new eXria.data.xhtml.CollectionNode(voInstanceNode);
  }
};
/**
 * page에 접근해서 instance를 찾아서
 * NodeList로 instance를 wrapping하여 리턴(xpath연산 적용가능)
 * @param {Number} pnIdx 특별한 인덱스의 값이 필요한 경우 조회 하고자 하는 인덱스 값을 전달한다.
 * @return pnIdx값이 넘어온 경우 eXria.data.ListNode.<br>
 *         pnIdx값이 넘어오지 않은 경우 eXria.data.xhtml.MapNode.
 * @type Object
 */
eXria.controls.DataRefNodeset.prototype.getNodesetData2 = function(pnIdx) { /* helper function */
  var viInstance = this.getNodesetInstance();
  
  var vsNodesetInstancePath = this.nodesetInstancePath;
  
  var voInstanceNodes = null;
  try { voInstanceNodes = viInstance.selectNodes(vsNodesetInstancePath); } catch(err) {}
  if(voInstanceNodes == null) return null;
  if(pnIdx != null) {
    return new eXria.data.xhtml.MapNode(voInstanceNodes.item(pnIdx));
  } else {
    return voInstanceNodes;
  }
};
/**
 * page에 접근해서 instance를 찾아서 instance path의 데이타를 json형태의 문자열로 반환해주는 메소드
 * @type String
 */
eXria.controls.DataRefNodeset.prototype.getNodesetStr = function(psInstanceId, psRef) { /* helper function */
  if(psInstanceId == null) psInstanceId = this.nodesetInstanceId;
  if(psRef == null) psRef = this.nodesetInstancePath;
  if(psInstanceId == null) return null;
  var viInstance = this.control.canvas.page.getInstance(psInstanceId);
  var vsNodesetStr = null;
  try { vsNodesetStr = viInstance.selectNodesStr(psRef); } catch(err) {}
  return vsNodesetStr;
};
/**
 * Collection Instance에 MapNode를 추가한다.<br>
 * Select Tag의 경우 Label과 Value
 * <select>
 * <option value="value">label</option>
 * </select>
 * @param {String} label에 해당하는 Value값
 * @param {String} value에 해당하는 Value값
 * @param {Number} pnIdx 데이타를 끼워넣고자 하는 위치(생략가능)
 */
eXria.controls.DataRefNodeset.prototype.addData = function(psLabel, psValue, pnIdx) {
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  //MapNode 생성
  var voMapNode = null;
  if(this.cloneRefer) {
    voMapNode = new eXria.data.xhtml.MapNode(this.cloneRefer.cloneNode(true));
  } else {
    voMapNode = this.getNodesetInstance().createMapNode(this.loopTag);
  }
  //Attribute에서 labalNode로 지정된 Tag명 조회
  var vsLabelNode = this.control.getAttrValue("labelTagName");
  //Attribute에서 valueNode로 지정된 Tag명 조회
  var vsValueNode = this.control.getAttrValue("valueTagName");
  //MapNode에 Label Element추가
  if(psLabel != null) voMapNode.put(vsLabelNode, psLabel);
  //MapNode에 Value Element추가 
  if(psValue != null) voMapNode.put(vsValueNode, psValue);
  if(pnIdx != null) {
    //Control Data에 MapNode를 끼워넣기
    voCollectionNode.insert(pnIdx, voMapNode.node);
  } else {
    //Control Data에 MapNode 추가
    voCollectionNode.add(voMapNode.node);
  }
};
/**
 * Collection Node에 MapNode를 추가한다.<br>
 * Select Tag의 경우 Label과 Value
 * @param {Object} poMap Map 형식의 데이터
 */
eXria.controls.DataRefNodeset.prototype.addMap = function(poMap, pnIndex) {
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  //MapNode 생성
  var voMapNode = this.getNodesetInstance().createMapNode(this.loopTag);
  for(var vsName in poMap) {
    voMapNode.put(vsName, poMap[vsName]);
  }
  //Collection에 추가
  if(pnIndex != null) {
    voCollectionNode.insert(pnIndex, voMapNode.node);
  } else {
    voCollectionNode.add(voMapNode.node);
  }
};
/**
 * 특정 Row를 삭제
 * @param {Number} pnIdx Row 인덱스
 */
eXria.controls.DataRefNodeset.prototype.deleteNode = function(pnIdx) {
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  voCollectionNode.remove(pnIdx);
};
/**
 * 특정 Row의 데이터를 갱신
 * @param {Number} pnIdx Row 인덱스
 * @param {String} psLabel 라벨 데이타
 * @param {String} psValue value 데이타
 */
eXria.controls.DataRefNodeset.prototype.update = function(pnIdx, psLabel, psValue) {
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  //MapNode 생성
  var voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(pnIdx));
  if(voMapNode) {
    //Attribute에서 labalNode로 지정된 Tag명 조회
    var vsLabelNode = this.control.getAttribute("labelTagName");
    //Attribute에서 valueNode로 지정된 Tag명 조회
    var vsValueNode = this.control.getAttribute("valueTagName");
    //Label Element 갱신
    if(psLabel != null) voMapNode.put(vsLabelNode, psLabel);
    //Value Element 갱신
    if(psValue != null) voMapNode.put(vsValueNode, psValue);
  } else {
    //해당 인덱스가 없으면 Insert
    this.addData(psLabel, psValue, pnIdx);
  }
};
/**
 * 특정 Row의 데이터를 갱신
 * @param {Number} pnIdx Row 인덱스
 * @param {String} psNode 노드명
 * @param {String} psValue value 데이타
 */
eXria.controls.DataRefNodeset.prototype.update2 = function(pnIdx, psNode, psValue) {
  psValue = "" + psValue;
  if(psNode == null || psValue == null) return;
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  //MapNode 생성
  var voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(pnIdx));
  if(voMapNode) {
    voMapNode.put(psNode, psValue);      
  }
};  
/**
 * 특정 Row의 모든 데이터 갱신
 * @param {Number} pnIdx Row 인덱스
 * @param {Object} poMap 데이타 저장 Map
 */
eXria.controls.DataRefNodeset.prototype.updateMap = function(pnIdx, poMap) {
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  //MapNode 생성
  var voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(pnIdx));
  if(voMapNode) {
    voMapNode.clear();
    for(var vsName in poMap) {
      voMapNode.put(vsName, poMap[vsName]);
    }
  } else {
    this.addMap(poMap);
  }
};
/**
 * XPath를 이용하여 Instance Source를 Filtering 해서 조회한다.
 * @param {String} psPath DOM Instance를 Filtering하기 위한 XPath 구문 
 * @return CollectionNode
 * @type Object
 */
eXria.controls.DataRefNodeset.prototype.filtering = function(psPath) {
  return this.getNodesetInstance().selectNodes(psPath);
};
/**
 * 정해진 컬럼을 기준으로 Collection을 Sort한다.
 * @param {String} psSortNode Sort할 기준값이 되는 Element Node Name
 * @param {Boolean} pbIsAsc true or null 일경우 Ascending, false일 경우 Descending
 * @return CollectionNode
 * @type Object
 * @ignore
 */
eXria.controls.DataRefNodeset.prototype.sort = function(psSortNode, pbIsAsc) {
  //NodeData 조회
  var voCollectionNode = this.getNodesetData();
  return voCollectionNode.sort(psSortNode);
};
