/**
 * @fileoverview
 * Abstract ObserverHandler(컨트롤이 가지고 있는 속성의 변경을 관찰하여 필요한 경우에 이를 관련 메소드에 통지)
 * @author 김경태
 */ 

/**
 * @class ObserverHandler (추상클래스).<br>
 * 컨트롤이 가지고 있는 속성의 변경을 관찰하여 필요한 경우에 이를 관련 메소드에 통지.
 * @version 1.0
 * @constructor
 * @return 새로운 eXria.controls.ObserverHandler 객체 
 * @type eXria.controls.ObserverHandler
 */
eXria.controls.ObserverHandler = function() {
  
  //////////////////////////////////////////////////////////////////
  // 속성 
  /**
   * 옵저버 객체들에 대한 보관소.
   * @type eXria.data.ArrayMap
   */    
  this.observers = new eXria.data.ArrayMap();
  
  //////////////////////////////////////////////////////////////////
  // 메소드 
  /**
   * 옵저버 객체를 추가한다.
   * @param {String} psKey 옵저버에 매칭되는 키값
   * @param {Object} poObserver 옵저버 객체
   */   
  this.addObserver = function(psKey, poObserver) {
    if(poObserver.update == null || poObserver.update == undefined) {
      throw new Error("옵저버에 적합하지 않은 객체입니다.");
    } else {
      this.observers.put(psKey, poObserver);
    }
  };

  /**
   * 지정된 키에 해당하는 옵저버 객체를 구한다.
   * @param {String} psKey 옵저버에 매칭되는 키값
   * @return 옵저버 객체
   * @type Object
   */     
  this.getObserver = function(psKey) {
    return this.observers.get(psKey);
  };
  
  /**
   * 옵저버 객체를 제거한다.
   * @param {String} psKey 옵저버에 매칭되는 키값
   */   
  this.removeObserver = function(psKey) {
    this.observers.remove(psKey);
  };
  
  /**
   * 옵저버핸들러에 도착한 통지를 처리한다. (옵저버들에게 통지에 따른 처리를 명령한다.)
   * @param {Object} poNotify 통지 객체
   */   
  this.notify = function(poNotify) {
    var voIterator = this.observers.getKeyCollection().iterator();
    while(voIterator.hasNext()) {
      var vsKey = voIterator.next();
      this.observers.get(vsKey).update(poNotify);  
    }
  };
};