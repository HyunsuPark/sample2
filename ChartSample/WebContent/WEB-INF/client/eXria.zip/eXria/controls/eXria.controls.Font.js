﻿/**
 * abstract Font
 * @작성자 : 김경태
 * @version 1.0

/**
 * Font (추상클래스)
 * 텍스트의 폰트 정보를 보관하는 기본 클래스
 * @param poParent : Bound 영역을 가진 객체가 포함된 상위 객체
 */
eXria.controls.Font = function(poControl) {  
  //////////////////////////////////////////////////////////////////
  // 속성   
  // Font의 초기값 설정
  if(poContol == null || poContol == undefined) {
    this.fontFamily = "돋움, Dotum, eXrial, Helvetica, Bitstream Vera Sans, UnDotum, Baekmuk Dotum, AppleGothic, sans-serif";
    this.fontSize = "20px";
    this.fontStyle = "normal";  // normal,italic,oblique
    this.fontWeight = "normal";
  } else {
    this.fontFamily = poContol.getDefaultControl("fontFamily");
    this.fontSize = poContol.getDefaultControl("fontSize");
    this.fontStyle = poContol.getDefaultControl("fontStyle");
    this.fontWeight = poContol.getDefaultControl("fontWeight");
  }
  
  //////////////////////////////////////////////////////////////////
  // 메소드
  cloneFont = function() {
    return new eXria.controls.Font(
      this.fontFamily     != null ? new String(this.fontFamily) : null
      , this.fontSize     != null ? new Number(this.fontSize  ) : null
      , this.fontStyle    != null ? new String(this.fontStyle ) : null
      , this.fontWeight   != null ? new String(this.fontWeight) : null
    );
  };
  
  copyFont = function(poFont) {
    this.fontFamily   = poFont.family != null ? new String(poFont.fontFamily) : null;
    this.fontSize     = poFont.size   != null ? new Number(poFont.fontSize  ) : null;
    this.fontStyle    = poFont.style  != null ? new String(poFont.fontStyle ) : null;
    this.fontWeight   = poFont.weight != null ? new String(poFont.fontWeight) : null;
  };
};