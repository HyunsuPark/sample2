﻿/**
 * @fileoverview
 * Abstract Data Reference(데이타 레퍼런스 기본 클래스).
 * @author 조동일 
 */

/**
 * @class Abstract Data Reference classs<br>
 * 데이타 레퍼런스 기본 클래스
 * @version 1.0
 * @constructor
 * @return 새로운 eXria.controls.DataProxy 객체
 * @type eXria.controls.DataProxy
 * @private
 */
eXria.controls.DataProxy = function(poDataSet, psDataSetId, psRef, pnRow) {
  this.isProxy = true;
  this.dataset = poDataSet;
  this.instancePath = psRef;
  this.rowIndex = pnRow;
  this.instanceId = psDataSetId;
  this.data = null;
  this.nodesetInstanceId = null;
  this.nodesetInstancePath = null;
};
/**
 * Control에 매핑된 Data Instance에 넘겨진 값을 얻어온다.
 * @return Control에 매핑된 Data Instance에 넘겨진 값
 * @type String
 */
eXria.controls.DataProxy.prototype.getData = function() {
  if(this.instanceId == null) return "";
  var vsData = this.dataset.get(this.rowIndex + 1, this.instancePath);
  if(vsData == null) vsData = "";
  
  return vsData;
};
/**
 * Control에 매핑된 Data Instance에 넘겨진 값을 입력한다.
 * @param {String} psData Data Instance에 입력할 String Value
 */
eXria.controls.DataProxy.prototype.setData = function(psData) {
  if(this.instanceId == null) return;
  if(psData == null) psData = "";
  this.dataset.set(this.rowIndex + 1, this.instancePath, psData);
};
/**
 * 컨트롤이 nodeset을 가질 경우 해당 nodeset의 참조 노드 리스트를 반환하는 메소드
 * @private
 */
eXria.controls.DataProxy.prototype.getNodesetData2 = function() {
  var voData = this.data;
  voData.nodesetInstanceId = this.nodesetInstanceId;
  voData.nodesetInstancePath = this.nodesetInstancePath;
  return voData.getNodesetData2();
};
/**
 * page에 접근해서 instance를 찾아서 instance path의 데이타를 json형태의 문자열로 반환해주는 메소드
 * @type String
 */
eXria.controls.DataProxy.prototype.getNodesetStr = function() { /* helper function */
  var voData = this.data;
  return voData.getNodesetStr();
};
/**
 * 인스턴스 패스가 절대 패스 인지 여부 리턴.
 * @return 인스턴스 패스가 절대 패스 인지 여부
 * @type Boolean
 */
eXria.controls.DataProxy.prototype.isRelativeRef = function() {
  return false;
};
/**
 * Nodeset reference를 설정한다.
 * @param {String} psNodesetInstanceId Page에서 Unique한 InstanceId
 * @param {String} psNodesetPath 해당 Instance에서의 태그명
 * @param {String} psParentPath control이 repeater나 tree view등
 *   container control안에 포함되어 있는 경우 container control의
 *   node XPath. container control에 포함되지 않을 경우는
 *   넘기지 않는다.
 */
eXria.controls.DataProxy.prototype.setNodesetRef = function(psNodesetInstanceId, psNodesetPath, psParentPath) {
  this.nodesetInstanceId = psNodesetInstanceId;
  if(psNodesetPath == null) return;
  if(psParentPath) {
    this.nodesetInstancePath = psParentPath + "/" + psNodesetPath;
  } else {
    this.nodesetInstancePath = psNodesetPath;
  }  
  this.data.nodesetInstanceId = this.nodesetInstanceId;
  this.data.nodesetInstancePath = this.nodesetInstancePath;
};

