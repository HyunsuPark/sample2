﻿/**
 * @fileoverview
 * Abstract EditMask Control
 */

/**
 * EditMask Control (추상클래스)
 * @author 김경태
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @constructor
 * @base eXria.controls.UIControl
 */
eXria.controls.EditMask = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  if(pnLeft == null) pnLeft = 20;
  if(pnTop == null) pnTop = 20;
  pnWidth = pnWidth || 100;
  pnHeight = pnHeight || 30;
  
  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  
  /**
   * Data 연동 객체(싱글 노드 연동)
   */
  this.data = new eXria.controls.DataRefNode(this);
  
  /////////////////////////////////////////////////////////////////////////////
  ////속성
  /**
   * 컨트롤에 할당된 문자열 값.
   * mask가 적용되기 이전의 문자열.
   * @type String
   */
  this.value = null;
  
  /**
   * 컨트롤에 표시될 문자열의 최대 길이
   * @type Number
   */
  this.maxLength = null;
  
  /**
   * 읽기만 가능 여부 기능
   * @type Boolean
   */
  this.readOnly = null;
  
  /**
   * 컨트롤 텍스트의 fontFamily값
   * @type String
   */
  this.fontFamily = null;
  
  /**
   * 컨트롤 텍스트의 fontSize값
   * @type Number
   */
  this.fontSize = null;
  
  /**
   * 컨트롤 텍스트의 fontStyle값
   * @type String
   */
  this.fontStyle = null;
  
  /**
   * 컨트롤 텍스트의 fontWeight값
   * @type String
   */
  this.fontWeight = null;
  
  /**
   * 컨트롤 텍스트의 꾸미기 효과 지정
   * @type String
   */
  this.textDecoration = null;
  
  /**
   * 컨트롤 텍스트의 대소문자화 등을 지정
   * @type String
   */
  this.textTransform = null;
  
  /**
   * 컨트롤에 표시될 문자열의 수직정렬 형태 지정
   * @type String
   */
  this.verticalAlign = null;
  
  /**
   * 컨트롤의 표시될 문자열의 데이타 형태 지정.
   * "string" | "date" | "number"  
   * @type String
   */
  this.maskType = null;
  
  /**
   * 컨트롤 텍스트에 적용될 마스크 문자열 지정
   * @type String
   */
  this.maskFormat = null;
  
  /**
   * 마스크 문자열의 프롬프트 캐릭터 지정
   * @type String
   */
  this.maskPrompt = null;
  
  /**
   * 스핀 버튼의 가로 길이 지정
   * @type String
   */
  this.spinWidth = 20;
  
  /**
   * calendar 버튼에 표시될 이미지 URL지정
   * @type String
   * @ignore
   */
  this.calendarImageUrl = null;
  
  /**
   * calendar 컨트롤 저장
   * @type Object
   */
  this.calendar = new eXria.controls.xhtml.Calendar(psId+"calendar",pnWidth,pnHeight,200,200);
  
  /**
   * calendar 컨트롤의 활성화 여부 지정
   * @type Boolean
   */
  this.calendarEnable = null;
  
  /**
   * 스핀 버튼을 클릭시의 증가치 지정
   * @type Number
   */
  this.spinNum = null;
  
  /**
   * 스핀 버튼의 표시 여부
   * @type Boolean
   */
  this.bSpin = null;

  /**
   * 키보드 이벤트 처리 시 사용될 keyCode 상수
   * @type Array(Number)
   */
  this.constKey = {
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    ENTER: 13,
    TAB: 9,
    BACKSPACE: 8,
    DEL: 46,
    HAN_ENG: 21
  };
  
  //////////////////////////////////////////////////////////////////   
  //// 메소드
  /**
   * maskType이 number일 경우의 spin버튼 디스플레이 여부 설정
   * @param {Boolean} pbShow spin버튼 디스플레이 여부
   * @param {Number} pbNum spin버튼에 의한 증가치
   */
  this.showSpin = function(pbShow, pnNum) {};
  
  /**
   * String maskType과 maskFormat에 의한 텍스트 변환값 반환
   * @param {String} psValue 변환할 텍스트
   * @return String maskType과 maskFormat에 의한 텍스트 변환값
   * @type String
   */
  this.toStringFormatValue = function(psValue) {};
  
  /**
   * number maskType과 maskFormat에 의한 텍스트 변환값 반환
   * @param {String} psValue 변환할 텍스트
   * @return String maskType과 maskFormat에 의한 텍스트 변환값
   * @type String
   */
  this.toNumberFormatValue = function(psValue) {};
  
  /**
   * date maskType과 maskFormat에 의한 텍스트 변환값 반환
   * @param {String} psValue 변환할 텍스트
   * @return String maskType과 maskFormat에 의한 텍스트 변환값
   * @type String
   */
  this.toDateFormatValue = function(psValue) {};
  
  /**
   * editmask에 적용될 값 설정
   * @ignore
   */
  this.setValue = function() {};
  
  /**
   * editmask에 적용된 값 반환
   * @ignore
   */
  this.getValue = function() {};
  
  /**
   * 컨트롤에 표시된 값을 date형으로 변환하여 반환
   * @return 컨트롤에 표시된 값을 date형으로 변환한 값
   * @type Date
   */
  this.getDate = function() {};
  
  /**
   * Date형 값을 입력받아 maskFormat형태로 컨트롤에 값 표시
   * @param poData Date형 값
   */
  this.setDate = function(poDate) {};
  
  /**
   * 클래스 명을 반환한다.
   * @return "Label"
   * @type String
   */
  this.toString = function() {
    return "EditMask";
  };
  
};