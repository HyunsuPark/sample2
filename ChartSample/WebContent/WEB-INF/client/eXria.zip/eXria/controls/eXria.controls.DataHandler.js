/**
 * Abstract Control
 * @작성자 : 김경태
 * @version 1.0
 
 
/**
 * DataHandler (추상클래스)
 * Data 처리를 위한 기본 클래스
 */
eXria.controls.DataHandler = function(poControl) {  
  //////////////////////////////////////////////////////////////////
  // 속성   
  /*
   * 컨트롤이 참조하는 Data를 나타내는 XPath 문자열
   */   
  this.ref = null;

  /*
   * 컨트롤이 참조하는 Data를 나타내는 XPath 문자열 (instance 내의 Xpath)
   */   
  this.path = null;
  
  /*
   * 컨트롤의 실체화 컨트롤이 생성되는 시점에 Data를 로딩할지를 지정한다. (true : 생성시 로딩, false : 생성시 로딩안함)
   */ 
  this.initLoad = true;
  
  /*
   * 컨트롤이 참조하는 Data를 가진 instance node의 ID
   */     
  this.instanceId = null;
  
  //////////////////////////////////////////////////////////////////
  // 메소드
  
  this.getInstanceId = function() {
    return this.instanceId();
  };

/* 
  this.getValue = function(psType) {
    if(psType = "value") {
      this.parent.getInstance(this.instanceId).getNodeValue();
    }
    else if(psType = "map") {
      this.parent.getInstance(this.instanceId).getMapValue();
    }
    else if(psType = "collection") {
      this.parent.getInstance(this.instanceId).getCollectionValue();
    }
    else if(psType = "node")  {
      this.parent.getInstance(this.instanceId).getNodeValue(); 
    }
  };
*/
  
  /*
   * ref를 구한다.
   */   
  this.getRef = function() {
    return this.ref;    
  };
  
  /*
   * ref를 설정한다.
   */   
  this.setRef = function(psXpath) {
    this.ref = psXpath;
  };
  
  /*
   * 연결되어 있는 DOM Data를 불러온다.
   */  
  this.getData = function() { throw new Error("메소드가 구현되지 않았습니다."); };
 
  /*
   * 연결되어 있는 Data를 DOM에 저장한다.
   */   
  this.setData = function() { throw new Error("메소드가 구현되지 않았습니다."); };
  
  /*
   * 컨트롤의 Data를 최신정보로 다시 불러온다. 
   */   
  this.refreshData = function() { throw new Error("메소드가 구현되지 않았습니다."); };
};


/**
 * SingleDataHandler
 * 단일 node의 Data 처리를 위한 클래스
 */
eXria.controls.SingleDataHandler = function(poControl) {  
  /*
   * DataHandler를 상속받는다.
   */
  eXria.controls.DataHandler.call(poControl);

  //////////////////////////////////////////////////////////////////
  // 속성   
  /*
   * 컨트롤과 연결된 node에 대한 참조
   */   
  this.node = null;
   
  //////////////////////////////////////////////////////////////////
  // 메소드 
  this.getValue = function() {
    var vValue = String(poControl.canvas.getInstance(this.instanceId).getNodeValue(this.path));
    return vValue;
  };
  
  this.setValue = function(pValue) {
    poControl.canvas.getInstance(this.instanceId).setNodeValue(this.path, pValue);
  };
  
  /*
   * 연결되어 있는 DOM Node를 불러온다.
   */  
  this.getData = function() {
    if(this.node != null) { 
      this.node = poControl.canvas.getInstance(this.instanceId).getNode(this.path);
    }
    return this.node;
  };
  
  /*
   * 컨트롤의 Data를 최신정보로 다시 불러온다. 
   */   
  this.refreshData = function() {
    this.node = poControl.canvas.getInstance(this.instanceId).getNode(this.path);   
    return this.node;
  };
};


/**
 * MultiDataHandler
 * 다중 node의 Data 처리를 위한 클래스
 */
eXria.controls.MultiDataHandler = function(poControl) {  
  /*
   * DataHandler를 상속받는다.
   */
  eXria.controls.DataHandler.call(poControl);

  //////////////////////////////////////////////////////////////////
  // 속성     
  /*
   * 컨트롤과 연결된 nodes에 대한 참조
   */   
  this.nodes = null;
   
  //////////////////////////////////////////////////////////////////
  // 메소드 
  this.getValue = function(pnIndex) {
    var vValue = poControl.canvas.getInstance(this.instanceId).setCollectionValues(this.path, pnIndex);
    return vValue;
  };
  
  this.setValue = function(pnIndex, pValue) {
    poControl.canvas.getInstance(this.instanceId).setCollectionValues(this.path, pnIndex, pValue);
  };
  
  this.getCollectionValues = function() {
    var voCollection = poControl.canvas.getInstance(this.instanceId).getCollectionValues(this.path);
    return voCollection;
  };
  
  this.setCollectionValues = function(poCollection) {
    poControl.canvas.getInstance(this.instanceId).setCollectionValues(this.path, poCollection);
  }
  
  this.getMapValues = function() {
    var voMap = poControl.canvas.getInstance(this.instanceId).getMapValues(this.path);
    return voMap;
  };
  
  this.setMapValues = function(poMap) {
    poControl.canvas.getInstance(this.instanceId).setMapValues(this.path, poMap);
  }
  
  /*
   * 연결되어 있는 DOM Node를 불러온다.
   */  
  this.getData = function() {
    if(this.nodes != null) { 
      this.nodes = poControl.canvas.getInstance(this.instanceId).getNodes(this.path);
    }
    return this.node;
  };
  
  /*
   * 컨트롤의 Data를 최신정보로 다시 불러온다. 
   */   
  this.refreshData = function() {
    this.nodes = poControl.canvas.getInstance(this.instanceId).getNodes(this.path);   
    return this.nodes;
  };
};