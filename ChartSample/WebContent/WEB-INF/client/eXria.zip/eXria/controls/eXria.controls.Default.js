﻿/**
 * Abstract Default
 * @작성자 : 김경태
 * @version 1.0

/**
 * Const (추상클래스)
 * 컨트롤에서 사용하는 기본값에 대한 정의  클래스
 */
eXria.controls.Default = {};

eXria.controls.Default.UIControl.tooltip = {
  arrowImage : "./images/arrow.gif",
  border : "10px solid black",
  style : null,
  color : null,
  backgroundColor : "red",
  fontSize : 12,
  filter : "alpha(opacity:70)",
  opacity : "0.70"
    /**
     * isNull(puValue);
     * Null 여부 체크
     */
//    isNull : function (puValue) {
//        return (eXria.util.StringUtil.fixNull(puValue) == "");
//    },
};

eXria.controls.Default.UIControl = {
  position : "absolute",
  backgroundColor : "white",
  color : "black",
  borderColor :  "silver",
  borderStyle : "inset", 
  borderWidth :  1,
  visible :  true,
  disabled :  false,
  zIndex :  0,
  movable : false,
  cursor : "default",
  tooltip : null,
  tooltipDisplay : true,
  dir : "ltr"
  //tabindex : 0, 
  //accessKey : null,
  //left: 0,
  //top: 0,
  //height: 100,
  //width: 100,
  //className: null,
  //outerClassName: null
};
  
eXria.controls.Default.InputBox = {
  value : null,
  maxLength : null,
  readOnly : false,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none",
  textTransform : "none"
};

eXria.controls.Default.Button = {
  value : "Button",
  imageNormal : null,
  imageFocused : null,
  imagePushed : null,
  imageMouseover : null,
  fontFamily : "eXrial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  borderWidth : 1,
  borderStyle : "inset",
  borderColor : "silver",
  color : "black",
  backgroundRepeat : "no-repeat",
  backgroundPosition : "center center"
};

eXria.controls.Default.SecretBox = {
  maxLength : null,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none"
};

eXria.controls.Default.Label = {
  value : "Label",
  wordWrap : true,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none"
};

eXria.controls.Default.DateInput = {
  value : null,
  calendarEnable : true,
  dateFormat : "YYYY-MM-DD",
  maskPrompt : "_",
  min : "19000101",
  max : "38001231",
  calendarImageUrl : "icon/calendar.jpg",
  readOnly : false,
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textDecoration : "none"
};

eXria.controls.Default.Output = {
  value : "",
  format : null,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none",
  letterSpacing : "normal",
  lineHeight : "normal"
};
  
eXria.controls.xhtml.Default.TextArea = {
  rows : 20,
  cols : 20,
  readOnly : false,
  value : null,
  maxLength : null,
  overflow : null,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none"
};

eXria.controls.xhtml.Default.Image = {
  src : null,
  borderStyle : "ridge"
};

eXria.controls.xhtml.Default.Object = {
  archive : null,
  classid : null,
  codebase : null,
  dataUrl : null,
  declare : null,
  standby : null,
  type : null,
  codetype : null,
  color : "white",
  backgroundColor : "black",
  borderWidth : 3,
  borderStyle : "ridge"
};

eXria.controls.xhtml.Default.ItemGroup_Check_Radio = {
  labelPos : "right", 
  height : 50,
  width : 100, 
  textAlign : "left", 
  verticalAlign : "middle", 
  backgroundColor : "#CCCCFF", 
  borderWidth : 1,
  borderStyle : "solid", 
  borderColor : "#000000"
};

eXria.controls.xhtml.Default.Select = {
  displayMode : "horizontal",
  displayNum : 4,
  value : null,
  horizontalGap : 0,
  verticalGap : 0,
  offsetLeft : 0,
  offsetTop : 0,
  multiple : true,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  itemgroup : eXria.controls.Default.ItemGroup_Check_Radio,
  labelTagName : "labelNode",
  valueTagName : "valueNode"   
};

eXria.controls.xhtml.Default.ItemGroup_List_Combo = {
  className : null,
  optionWidth : 20,
  borderWidth : 1,
  borderStyle : "none",
  borderColor : "black",
  height : 25,
  verticalAlign : "middle"
};

eXria.controls.xhtml.Default.ListArea = {
  className : null,
  appearance : null,
  multiSelect : false,
  size : 5,
  heightBySize : false,
  color : "transparent",
  focusColor : "#FFFFFF",
  backgroundColor : "transparent",
  focusBackgroundColor : "#0000FF",
  borderWidth : "transparent",
  borderStyle : "solid",
  borderColor : "black",
  CellSpacing : 1,
  height : 200
};

eXria.controls.xhtml.Default.ComboBox = {
  value : null,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  btnWidth : 30,
  btnBackgroundColor : null,
  btnColor : "black",
  btnImage : null,
  itemgroup : eXria.controls.Default.ItemGroup_List_Combo,
  listarea : eXria.controls.Default.ListArea,
  labelTagName : "labelNode",
  valueTagName : "valueNode"   
};

eXria.controls.xhtml.Default.ListBox = {
  value : null,
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  appearance : null,
  multiSelect : false,
  size : 5,
  heightBySize : false,
  focusColor : "#FFFFFF",
  focusBackgroundColor : "#0000FF",
  cellSpacing : 1,
  itemgroup : eXria.controls.Default.ItemGroup_List_Combo,
  labelTagName : "labelNode",
  valueTagName : "valueNode"   
};

eXria.controls.xhtml.Default.EditMask = {
  maskType : "string",
  maskFormat : "xxx**",
  maskPrompt : "_",
  value : null,
  spinWidth : 20,
  spinNum : 1,
  bSpin : false,
  readOnly : false,
  maxLength : null,
  calendarImageUrl : "icon/calendar.jpg",
  calendarEnable : "true",
  textDecoration : "none",
  textTransform : "none",
  fontFamily : "serif",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal"
};

eXria.controls.xhtml.Default.Group = {
  overflow : "hidden",
  borderColor : "silver",
  backgroundColor : "transparent"
};

eXria.controls.xhtml.Default.TabButtons = {
  cellSpacing : 1,
  borderWidth : 2,
  borderStyle : "outset",
  borderColor : "#CFCFCF",
  width : 100,
  backgroundColor : "#BBBBBB",
  focusBackground : "#0000FF",
  focusColor : "#FFFFFF"
};

eXria.controls.xhtml.Default.TabPages = {
  className : null,
  outerClassName : null,
  backgroundColor : null,
  borderWidth : 1,
  borderStyle : "solid",
  borderColor : "#000000"
};

eXria.controls.xhtml.Default.Tab = {
  tabHeaderHeight : 50,
  tabHeaderPos : "top",
  borderWidth : 1,
  borderStyle : "solid",
  borderColor : "gray",
  backgroundColor : "#FFFFFF",
  fontFamily : "serif",
  fontSize : 16,
  fontWeight : "normal",
  fontStyle : "normal",
  tabbuttons : eXria.controls.Default.TabButtons,
  tabpages : eXria.controls.Default.TabPages
};

eXria.controls.xhtml.Default.Timer = {
  interval : 1000,
  stopCount : 0
};

eXria.controls.xhtml.Default.Progress = {
  step : 1,
  startPos : 0,
  interval : 100,
  min : 0,
  max : 1000,
  barColor : "#CCFFFF"
};

eXria.controls.xhtml.Default.ItemGroup_Tree = {
  className : null,
  backgroundColor : "white",
  color : "black",
  selectedBackgroundColor : "navy",
  selectedColor : "#FFFFFF",
  cursor : "pointer",
  fontFamily : "serif",
  fontSize : 10,
  fontStyle : "normal",
  fontWeight : "normal",
  textAlign : "left",
  verticalAlign : "middle"
};

eXria.controls.xhtml.Default.TreeView = {
  expandAll : false,
  selectionMode : "single",
  iconDir : "images/treeicon/win2000",
  iconWidth : 19,
  iconHeight : 16,
  overflow : "auto",
  borderStyle : "ridge",
  fontFamily : "serif",
  fontSize : 12,
  fontStyle : "normal",
  fontWeight : "normal",
  itemgroup : eXria.controls.Default.ItemGroup_Tree
};

eXria.controls.xhtml.Default.Calendar = {
  selectedColor : "#0099FF",
  headerBackgroundColor : "#E3E3E3",
  bodyBackgroundColor : "#FCFCFC",
  backgroundColor : "#919191",
  borderWidth : 3,
  borderStyle : "ridge",
  borderColor : "silver",
  fontFamily : "Rockwell",
  fontSize : 12,
  fontWeight : "normal",
  fontStyle : "normal"
};

eXria.controls.xhtml.Default.Import = {
  src : null
};

eXria.controls.xhtml.Default.FreeForm = {
/* TODO 추후예정 */
};

eXria.controls.xhtml.Default.Grid = {
/* TODO 추후예정 */
};

eXria.controls.xhtml.Default.Shape = {
  position : null,
  visible : true,
  movable : false,
  zIndex : 0,
  cursor : "default",
  tooltip : null,
  tooltipDisplay : true,
  penCap : "round",
  penStyle : "solid",
  penWeight :1,
  penColor : "black",
  penOpacity : 100,
  joinType : "round",
  angle : 0
};

eXria.controls.xhtml.Default.Line = {
  startPosition : "top"
};

eXria.controls.xhtml.Default.Rectangle = {
  fillStartColor : "blue",
  fillEndColor : "red",
  fillType : "solid",
  fillAngle : 0,
  fillOpacity : 100
};

eXria.controls.xhtml.Default.Roundrect = {
  round : 20,
  fillStartColor : "blue",
  fillEndColor : "red",
  fillType : "solid",
  fillAngle : 0,
  fillOpacity : 100
};

eXria.controls.xhtml.Default.Ellipse = {
  fillStartColor : "blue",
  fillEndColor : "red",
  fillType : "solid",
  fillAngle : 0,
  fillOpacity : 100
};