/**
 * @fileoverview
 * Abstract Notify(옵저버에 통지되는 데이터 형태 정의)
 * @author 김경태
 */
  
/**
 * @class notify (추상클래스).<br>
 * 옵저버에 통지되는 데이터 형태 정의.
 * @version 1.0
 * @constructor
 * @return 새로운 eXria.controls.Notify 객체 
 * @type eXria.controls.Notify
 */
eXria.controls.Notify = function() {  
  /**
   * 옵저버에 대한 통지 형태(스트링 상수 지정).<br>
   * <a href="../../../eXria.controls.CommonDefine.js">eXria.controls.CommonDefine.Notice를 참조</a>
   * @type String
   */    
  this.type = null;       // eXria.controls.CommonDefine.Notice를 참조
  
  /**
   * 옵저버에 대한 통지 데이터
   * @type eXria.data.ArrayMap
   */
  this.datas = new eXria.data.ArrayMap();
};
