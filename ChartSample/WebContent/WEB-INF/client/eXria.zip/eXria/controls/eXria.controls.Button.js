﻿/**
 * @fileoverview
 * Abstract Button Control
 */

/**
 * Button Control
 * @author 김경태
 * @version 1.0 
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @constructor
 * @base eXria.controls.UIControl
 */
eXria.controls.Button = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  
  if(pnLeft == null)  pnLeft = 20;
  if(pnTop == null)  pnTop = 20;
  pnWidth = pnWidth || 100;
  pnHeight = pnHeight || 30;
  
  /*
   * UIControl을 상속받는다.
   */
  eXria.controls.UIControl.call(this, psId, poCanvas, vnLeft, vnTop, vnWidth, vnHeight);
  
  /**
   * Data 연동 객체(싱글 노드 연동)
   */
  this.data = new eXria.controls.DataRefNode(this);
  
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * Button에 표시될 라벨값
   * 아이콘 정보 포함가능
   * @type String
   */
  this.value = null;
  
  /**
   * Button의 표시될 배경 이미지 지정(url형태)
   * Button의 이벤트 상태에 따라 여러 가지 이미지 지정가능
   * @type String
   */
  this.backgroundImage = null;
  
  /**
   * 배경 이미지 표시방법(반복, 반복없음 등) 지정.
   * @type String
   */
  this.backgroundRepeat = null;
  
  /**
   * 배경 이미지 위치(왼쪽, 가운데, 오른쪽 등) 지정.
   * @type String
   */
  this.backgroundPosition = null;
  
  /**
   * 버튼에 표시될 텍스트의 fontFamily값
   * @type String
   */
  this.fontFamily = null;
  
  /**
   * 버튼에 표시될 텍스트의 fontSize값
   * @type Number
   */
  this.fontSize = null;
  
  /**
   * 버튼에 표시될 텍스트의 fontStyle값
   * @type String
   */
  this.fontStyle = null;
  
  /**
   * 버튼에 표시될 텍스트의 fontWeight값
   * @type String
   */
  this.fontWeight = null;
  
  /**
   * 버튼의 디폴트 배경이미지
   * @type String
   */
  this.imageNormal = null;
  
  /**
   * 버튼이 눌렸을 때의 배경이미지
   * @type String
   */
  this.imagePushed = null;
  
  /**
   * 버튼에 포커스가 위치했을 때의 벼경이미지
   * @type String
   */
  this.imageFocused = null;
  
  /**
   * 버튼 위에 마우스가 위치했을 때의 배경이미지
   * @type String
   */
  this.imageMouseover = null;
  
  /**
   * 버튼의 텍스트(아이콘 정보 포함) 지정
   * @ignore
   */
  this.setValue = function() {};
  
  /**
   * 버튼의 텍스트(아이콘 정보 포함)값 반환
   * @ignore
   */
  this.getValue = function() {};
  
  /**
   * 버튼에 blur이벤트를 발생시킨다
   * @ignore
   */
  this.blur = function() {};
  
  /**
   * 버튼에 click이벤트를 발생시킨다
   * @ignore
   */
  this.click  = function() {};
  
  /**
   * 버튼에 포커스를 준다.
   * @ignore
   */
  this.focus  = function() {};
  
  /**
   * 클래스 명을 반환한다.
   * @return "Button"
   * @type String
   */
  this.toString = function() {
    return "Button";
  };
  
};