/**
 * @fileoverview 
 * controls 패키지의 최상위 Abstract Control을 정의
 * @author 김경태
 */

/**
 * @class 모든 컨트롤에 대한 기본 클래스가 되는 최상위 클래스
 * @version 2.0
 * @constructor
 * @param {String} psId 컨트롤 식별자
 * @return 모든 컨트롤이 상속받게 되는 eXria.controls.Control 객체
 * @type eXria.controls.Control
 */
eXria.controls.Control = function(psId) {
  /**
   * 컨트롤 식별자.
   * @type String
   */
  this.id = psId;
  /**
   * 자기자신을 가지고 있는 부모 객체인 Canvas를 참조.
   * @type Xria.form.xhtml.Canvas
   */
  this.canvas = null;
  /**
   * 자기자신의 실체화 객체를 참조.
   * @type String
   */
  this.ctrl = null;
  /**
   * innerHTML 템플릿.
   * @type Array
   */
  this.template = null;
  /**
   * 사용자 정의 값을 저장하기 위한 속성.
   * @type String
   */
  this.userAttr = null;
}; // End of Control

/**
 * Ctrl(실체화 컨트롤)을 생성한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치할 Doucment에 대한 참조
 * @return 실체화 컨트롤에 대한 참조
 * @type object
 */   
eXria.controls.Control.prototype.create = function(poDocument) {
  if(poDocument == null) poDocument = this.document;
  var voCtrl = null;
  
  if(this.createCtrl) {                                                                               // 1. Main Ctrl 생성 후 추가
    voCtrl = this.createCtrl(poDocument); 
    if(voCtrl) this.canvas.getCtrl().appendChild(voCtrl);  
    else new Error("create main ctrl error");
  };                                      

  if(this.createSubCtrl && voCtrl) { this.createSubCtrl(voCtrl, poDocument); };                       // 2. Composite Child Ctrl 생성
  
  if(this.setTemplate && voCtrl) { this.setTemplate(voCtrl, poDocument); };                           // 13. innerHTML 방식으로 생성하는 컨트롤인 경우 Template 생성
  if(this.setMainCtrlStyles && voCtrl) { this.setMainCtrlStyles(voCtrl, poDocument); };               // 3. Main Style 적용
  if(this.setSubCtrlStyles && voCtrl) { this.setSubCtrlStyles(voCtrl, poDocument); };                 // 4. Composite Child Style 적용
  
  if(this.setFormDefaults && voCtrl) { this.setFormDefaults(voCtrl, poDocument); };
  if(this.setUIGeneralDefaults && voCtrl) { this.setUIGeneralDefaults(voCtrl, poDocument); };         // 5. 공통 초기값 설정
  if(this.setSpecificDefaults && voCtrl) { this.setSpecificDefaults(voCtrl, poDocument); };           // 6. 개별 초기값 설정
  
  //if(this.setFormAttrs && voCtrl) { this.setFormAttrs(voCtrl, poDocument); };
  //if(this.setGeneralAttrs && voCtrl) { this.setGeneralAttrs(voCtrl, poDocument); };                   // 7. 공통 Attrs 적용
  //if(this.setUIGeneralAttrs && voCtrl) { this.setUIGeneralAttrs(voCtrl, poDocument); }                // 8. UI 공통 Attrs 적용 
  if(this.setSpecificAttrs && voCtrl) { this.setSpecificAttrs(voCtrl, poDocument); }                  // 9. 개별 Attrs 적용
    
  if(!this.printMode) {
    if(this.setGeneralEvents && voCtrl) { this.setGeneralEvents(voCtrl); }                            // 10. 공통 Events 적용  
    if(this.setUIGeneralEvents && voCtrl) { this.setUIGeneralEvents(voCtrl); }                        // 11. UI 공통 Events 적용  
    if(this.setSpecificEvents && voCtrl) { this.setSpecificEvents(voCtrl); }                          // 12. 개별 Events 적용
  }
  
  return voCtrl;
}; 
/**
 * 속성 값을 설정한다.
 * 그러나 값만 설정할 뿐 해당 속성의 관련된 UI 갱신작업까지 수행하지는 않음.
 * @ignore
 */       
eXria.controls.Control.prototype.setAttr = null;
/**
 * 속성 값을 구한다.
 * @ignore
 */ 
eXria.controls.Control.prototype.getAttrValue = null;
/**
 * 속성을 제거한다.
 * @ignore
 */ 
eXria.controls.Control.prototype.removeAttr = null;
 /**
  * 속성 값을 설정하고 바로 적용한다. (설정된 속성을 실체화 컨트롤에 바로 적용)
  * @ignore
  */
eXria.controls.Control.prototype.applyAttr = null;
/**
 * canvas에 컨트롤이 로딩되어 있는지의 여부를 구한다.
 * @return 컨트롤의 로딩 여부
 * @type Boolean
 */
eXria.controls.Control.prototype.isLoaded = function() {
  if(this.canvas == null || this.canvas == undefined)
    return false;
  else
    return true;
};
/**
 * 컨트롤의 정보를 문자열로 구한다.
 * @ignore
 */  
eXria.controls.Control.prototype.toString = null; 
/**
 * 실체화 컨트롤을 구한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document에 대한 참조
 * @return 실체화 컨트롤
 * @type Object
 */ 
eXria.controls.Control.prototype.getCtrl = function(poDocument) {
  if(this.ctrl == null) this.ctrl = this.lookup(this.id, poDocument);
  return this.ctrl;
};
/**
 * 컨트롤이 속한 canvas를 구한다.
 * @return 컨트롤이 속한 eXria.form.Canvas에 대한 참조
 * @type eXria.form.Canvas
 */   
eXria.controls.Control.prototype.getCanvas = function() {
  if(this.canvas) { return this.canvas; }
};
/**
 * 브라우저에서 발생한 이벤트를 전달받아 자바스크립트 컨트롤 이벤트로 처리한다.
 * @param {HTMLEvent} e 브라우저 이벤트
 * @param {eXria.controls.Control} poControl 이벤트를 실행할 컨트롤 객체에 대한 참조
 * @private
 */ 
eXria.controls.Control.prototype.runEvent = function(e, poControl) {
  if(!!this.skipEvent) return;
  var voCanvas = this.canvas;
  var voEvent = new eXria.event.Event(e, this.window);
	var vsType = voEvent.type;
  if(voCanvas.page.waitingSend && vsType == "blur") {
    voEvent.stopEvent();
    return;
  }
  
  if(this.disabled || this.isEditing) { //input 계열 컨트롤에서 MaxByteLength를 넘어가는 keyup을 구분하기 위해 isEditing속성 사용
    voEvent.stopPropagation();
    if(vsType == "focus") this.isEditing = false;
    return;
  }

  voEvent.object = poControl;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;

  switch(vsType) {
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
  	break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {      
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
  	if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
  		vbSkip = true;
  	}
  	break;
  case "change" :
    if(this.isComboMousedown) vbSkip = true;
    break;
  }
  
  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
    	try {
    		poControl[vsOnEvent](voEvent);
    	} catch(err) {
  			alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
    	}
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
  
  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  case "focus" :
    if(voCanvas.page.metadata.browser.gecko) {
      var voTarget = voEvent.target;
      if(voTarget == null) return;
      
      var vsNodeName = voTarget.nodeName.toUpperCase();
      var vsType = voTarget.type.toUpperCase();

      if(vsNodeName == "INPUT") {
        if(vsType == "TEXT" || vsType == "PASSWORD") break;
      } else if(vsNodeName == "TEXTAREA") {
        break;
      }
    } 
  default :
    voEvent.stopPropagation();
    break;
  }
};  
/**
 * 자바스크립트 컨트롤에서 일차적으로 처리한 이벤트를 전달받아 자바스크립트 컨트롤 이벤트로 실행한다.
 * @param {eXria.event.Event} poEvent 자바스크립트 이벤트
 * @param {eXria.controls.Control} poControl 이벤트를 실행할 컨트롤 객체에 대한 참조
 * @private   
 */ 
eXria.controls.Control.prototype.runControlEvent = function(poEvent, poControl) {
  var vsType = poEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  
  if (poControl[vsAtEvent]) { poControl[vsAtEvent](poEvent); }    
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](poEvent); }
  if (poControl[vsOnEvent]) { poControl[vsOnEvent](poEvent); }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](poEvent); }
};
/**
 * 컨트롤(Control)에 설정된 최신 정보로 실체화 컨트롤(Ctrl)을 새로고침한다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */   
eXria.controls.Control.prototype.refresh = function(poDocument) {  
  if(poDocument == null) poDocument = this.document;
//  voCtrl = this.getCtrl(poDocument);
  
  if(this.removeUIGeneralDefaults) { this.removeUIGeneralDefaults(this.ctrl, poDocument); };           // 공통 초기값으로 지정된 속성값을 제거
  if(this.removeSpecificDefaults) { this.removeSpecificDefaults(this.ctrl, poDocument); };             // 개별 초기값으로 지정된 속성값을 제거
  
  if(this.refreshTemplate) { this.refreshTemplate(this.ctrl, poDocument); };                       		
  if(this.refreshMainStyles) { this.refreshMainStyles(this.ctrl, poDocument); };                       // Main Style 새로고침
  if(this.refreshSubStyles) { this.refreshSubStyles(this.ctrl, poDocument); };                         // Composite Child Style 새로고침
  
  if(this.refreshUIGeneralDefaults) { this.refreshUIGeneralDefaults(this.ctrl, poDocument); };         // 공통 초기값으로 새로고침
  if(this.refreshSpecificDefaults) { this.refreshSpecificDefaults(this.ctrl, poDocument); };           // 개별 초기값으로 새로고침
  
  //if(this.refreshGeneralAttrs) { this.refreshGeneralAttrs(voCtrl, poDocument); };                 // 공통 속성으로 새로고침
  //if(this.refreshUIGeneralAttrs) { this.refreshUIGeneralAttrs(voCtrl, poDocument); };             // UI 공통 속성으로 새로고침
  if(this.refreshSpecificAttrs) { this.refreshSpecificAttrs(this.ctrl, poDocument); };                 // 개별 속성으로 새로고침
   
  //if(this.refhresGeneralEvents) { this.refhresGeneralEvents(voCtrl); };                           // 공통 Events로 새로고침
  //if(this.refreshUIGeneralEvents) { this.refreshUIGeneralEvents(voCtrl); };                       // UI 공통 Events로 새로고침
  if(this.refreshSpecificEvents) { this.refreshSpecificEvents(this.ctrl); };                         	// 개별 Events로 새로고침

  if(this.reloadData) { this.reloadData(this.ctrl, poDocument); };                                   // Data 새로고침
  //if(voCtrl != this.getCtrl(poDocument)) voCtrl = this.getCtrl(poDocument);	//20090621 dhkim
  if(this.refreshComplete) {this.refreshComplete(this.ctrl, poDocument); };														// 새로고침 최종 처리
}; 
/**
 * 컨트롤과 실체화컨트롤을 모두 제거한다.
 */ 
eXria.controls.Control.prototype.clear = function() {        
   if(this.clearCtrl) { this.clearCtrl(); };                        // 1. Ctrl 제거
   if(this.clearControl) { this.clearControl(); };                  // 2. Control을 제거
};  
/**
 * 컨트롤을 제거한다.
 * @private
 */ 
eXria.controls.Control.prototype.clearControl = function() {
  for (member in this) {
    this[member] = null;
    delete this[member];
  }
};
/**
 * 공통 초기화 수행
 * @ignore
 */ 
eXria.controls.Control.prototype.initGeneral = null;   