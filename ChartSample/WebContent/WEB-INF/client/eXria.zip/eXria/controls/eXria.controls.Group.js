/**
 * @fileoverview
 * Abstract Group(UI 컨트롤들을 그룹짓는 클래스)
 * @author 김경태
 */

/**
 * @class Group (추상클래스).<br>
 * UI 컨트롤들을 그룹짓는 클래스.
 * @version 1.0 
 * @constructor
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.Group 객체 
 * @type eXria.controls.Group
 */
eXria.controls.Group = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 컨트롤 식별자
   * @type String
   */
  this.id = psId;
  /**
   * 컨트롤의 left 좌표
   * @type Number
   */
  this.left = pnLeft || 0;
  /**
   * 컨트롤의 top 좌표
   * @type Number
   */
  this.top = pnTop || 0;
  /**
   * 컨트롤의 가로길이
   * @type Number
   */
  this.width = pnWidth || 200;
  /**
   * 컨트롤의 세로길이
   * @type Number
   */
  this.height = pnHeight || 200;
  /**
   * 하위 구성요소(컨트롤)를 담고 있는 컬렉션 배열
   * @type eXria.data.ArrayCollection
   */    
  this.controls = new eXria.data.ArrayCollection();
};  
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * 하위 구성요소(컨트롤)를 추가한다.
 * @param {Object} poItem 추가될 구성요소(컨트롤)
 * @private
 */        
eXria.controls.Group.prototype.addItem = function(poItem) {
  this.controls.add(poItem);   
};
/**
 * 하위 구성요소(컨트롤)들에 대한 참조를 반환합니다.
 * @return 구성요소(컨트롤)들에 대한 참조로 구성된 ArrayCollection
 * @type eXria.data.ArrayCollection
 */  
eXria.controls.Group.prototype.getControls = function() {
  return this.controls;
};
/**
 * 하위 구성요소(컨트롤)를 반환합니다.
 * @param {pnIndex} 반환할 구성요소(컨트롤) 인덱스
 * @return 지정된 구성요소(컨트롤)
 * @private
 */  
eXria.controls.Group.prototype.getItem = function(pnIndex) {
  return this.controls.get(pnIndex);
};
/**
 * 하위 구성요소(컨트롤)를 삭제 시킵니다.
 * @param {pnIndex} 삭제될 구성요소(컨트롤) 인덱스
 * @private
 */  
eXria.controls.Group.prototype.removeItem = function(pnIndex) {
  this.controls.remove(pnIndex);
};
