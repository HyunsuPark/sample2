/**
 * @fileoverview
 * Abstract MenuItem(메뉴형 컨트롤에서 사용될 아이템의 추상 클래스)
 * @author 김경태
 */
 
/**
 * @class eXria.controls.MenuItem.<br>
 * 메뉴형 컨트롤에서 사용될 아이템의 추상 클래스
 * @version 1.0 
 * @constructor
 * @param {String} psId 아이템 식별자
 * @param {Object} poParent 상위컨트롤
 * @param {String} psLabelText 아이템에 표시될 문자열
 * @param {String} psValue 아이템에 할당될 값
 * @param {Number} pnLeft 아이템 좌상단 점 x좌표
 * @param {Number} pnTop 아이템 좌상단 점 y좌표
 * @param {Number} pnWidth 아이템의 가로 길이
 * @param {Number} pnHeight 아이템의 세로 길이
 * @return 새로운 eXria.controls.MenuItem 객체 
 * @type eXria.controls.MenuItem
 */
eXria.controls.MenuItem = function(psId, poControl, psLabel, psValue, psImage, psHotKey, pnLeft, pnTop, pnWidth, pnHeight) {  
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 컨트롤 식별자.
   * @type String
   */
  this.id = psId;
  /**
   * 상위 컨트롤 객체.<br>
   * 읽기 전용 속성.
   * @type Object
   */
  this.parentControl = poControl;
  /**
   * 상위 아이템에 객체.<br>
   * @type eXria.controls.MenuItem
   */
  this.parent = null;          
  /**
   * label 텍스트.
   * @type String
   */
  this.label = psLabel;              
  /**
   * 아이템에 할당된 String value값.
   * @type String
   */
  this.value = psValue;
  /**
   * 아이템에 할당된 아이콘 이미지의 경로.
   * @type String
   */
  this.image = psImage;
  /**
   * 아이템에 할당된 HotKey(단축키).
   * @type String
   */
  this.hotKey = psHotKey;
  /**
   * 상위 컨트롤에서 option들 상호간에 식별자 역할 속성.<br>
   * 읽기 전용 속성.
   * @type Number
   */
  this.index = null;                  // readonly number
  /**
   * 아이템의 활성화 여부 지정.
   * @type Boolean
   */
  this.disabled = null;              // boolean
  /**
   * 아이템이 선택되었는지 여부 지정.
   * @type Boolean
   */
  this.selected = false;               // boolean
  /**
   * 아이템의 텍스트 가로 정렬.<br>
   * left/center/right
   * @type String
   */
  this.textAlign = null;          // 옵션의 가로 정렬 left/center/right
  /**
   * 아이템의 세로 정렬.<br>
   * top/middle/bottom
   * @type String
   */
  this.verticalAlign = null;        // 옵션의 세로 정렬 top/middle/bottom
  /**
   * 아이템의 좌측 시작 x좌표.
   * @type Number
   */
  this.left = pnLeft || 0;            // 옵션의 좌측 시작 x좌표
  /**
   * 아이템의 상단 시작 y좌표.
   * @type Number
   */
  this.top = pnTop || 0;              // 옵션의 상단 시작 y좌표
  /**
   * 아이템의 가로길이
   * @type Number
   */
  this.width = pnWidth || 200;        // 옵션의 넓이 - number
  /**
   * 아이템의 세로길이
   * @type Number
   */
  this.height = pnHeight || 20;       // 옵션의 높이 - number
  /**
   * 글자색.
   * @type String
   */
  this.color = null;                  // 글자색
  /**
   * 글자 크기(단위:pt).
   * @type Number
   */
  this.fontSize = null;                // 글자 크기
  /**
   * 아이템의 배경색.
   * @type String
   */
  this.backgroundColor = null;        // 옵션의 배경색
  /**
   * 보더 두께.
   * @type Number
   */
  this.borderWidth = null;            // border의 폭 - number
  /**
   * border 스타일.<br>
   * none/hidden/dotted/dashed/solid/double/groove/ridge/inset/outset
   * @type String
   */
  this.borderStyle = null;            // none/hidden/dotted/dashed/solid/double/groove/ridge/inset/outset
  /**
   * 보더 색상.
   * @type String
   */
  this.borderColor = null;            // border색  
};

//////////////////////////////////////////////////////////////////
// 메소드 
/**
 * 아이템의 실체화 컨트롤 생성.
 * @ignore
 */
eXria.controls.MenuItem.prototype.createCtrl = function() {};
/**
 * 아이템의 실체화 컨트롤 하위 요소 생성.
 * @ignore
 */
eXria.controls.MenuItem.prototype.createSubCtrl = function() {};
/**
 * 하위 아이템에서 발생한 이벤트를 컨트롤에 전달한다. (하위 아이템의 이벤트가 컨트롤에 버블링되지 않을 경우 사용)
 * @param {HTMLEvent} e 브라우저 이벤트
 * @param {eXria.controls.Control} poControl 이벤트를 실행할 컨트롤 객체에 대한 참조   
 */ 
eXria.controls.MenuItem.prototype.notifyEvent = function(e, poItem, poControl) {
  var voEvent = new eXria.event.Event(e, poControl.window);
  voEvent.object = this;
  voEvent.objectType = "item";   
  voEvent.baseControlId = poControl.baseControlId;
  poControl.runControlEvent(voEvent, poControl); 
};
