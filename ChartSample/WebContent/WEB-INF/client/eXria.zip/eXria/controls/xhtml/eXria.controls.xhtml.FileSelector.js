﻿/**
 * @fileoverview
 * Concreate xhtml FileSelector(XHTML FileSelector 컨트롤)
 * @author 고정원
 */

/**
 * @class 원하는 파일을 업로드 할 수있는 컨트롤을 생성하는 class입니다.<br />
 * XHTML FileSelector Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.FileSelector 객체
 * @type eXria.controls.xhtml.FileSelector
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */ 
eXria.controls.xhtml.FileSelector = function(psId, pnLeft, pnTop, pnWidth, pnHeight){
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 150 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */  
  this.data = new eXria.controls.DataRefNode(this);
  /////////////////////////////////////////////////////////////////////////////
  ////속성
  /**
   * 컨트롤에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 컨트롤의 보더 두께.
   * @type Number
   */  
  this.borderWidth = null;
  /**
   * 컨트롤의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 컨트롤의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 컨트롤의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * css를 통해 지정된 컨트롤의 배경 색상.
   * @type String
   */
  this.cssBackgroundColor = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = null;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */  
  this.fontSize = null;
  /**
   * css를 통해 지정된 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */  
  this.cssFontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트 박스를 둘러싼 보더의 두께.
   * @type Number
   * @private
   */
  this.subBorderWidth = 1;
  /**
   * 컨트롤의 안쪽 여백(단위 px).
   * @type Number
   * @private
   */
  this.padding = null;
  /**
   * 컨트롤의 안쪽 상단여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingTop = null;
  /**
   * 컨트롤의 안쪽 우측여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingRight = null;
  /**
   * 컨트롤의 안쪽 하단여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingBottom = null;
  /**
   * 컨트롤의 안쪽 좌측여백(단위 px).
   * @type Number
   * @private
   */
  this.paddingLeft = null;
  /**
   * 텍스트 박스의 좌우 여백(단위 px).
   * @private
   * @type Number
   */
  this.hPadding = 2;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
  /**
   * 파일첨부 버튼의 속성을 저장하기 위한 오브젝트.
   */
  this.browseBtn = new eXria.controls.xhtml.FileSelector_browseBtn(this);
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.FileSelector);

//////////////////////////////////////////////////////////////////   
//// 메소드 

eXria.controls.xhtml.FileSelector.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");  
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.ctrl = voCtrl;
  return voCtrl;
};

eXria.controls.xhtml.FileSelector.prototype.setTemplate = function(poCtrl, poDocument){ 
  this.template = [];
  var vaTemplate = this.template;
  var vfcGetEHandler = this.getEHandler;							// 추가
  var vaStrBuf = null;
	var vsClass = this.getCSSClass(this, 1);
	var vsBtnClass = this.getCSSClass(this, 1, "BrowseButton");
  vaTemplate.push("<table cellPadding=0px cellSpacing=0px ");
  vaTemplate.push("style='border-style:solid;border-color:#CCCCCC;left:0px;top:0px;");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("'>");

  vaTemplate.push("<tbody>");
  vaTemplate.push("<tr>");
  vaTemplate.push("<td valign='middle' style='");
  vaTemplate.push("@cssStrBuf");	//7
  vaTemplate.push("'>");
  
  vaTemplate.push("<input class='" + vsClass + "' type='text' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_text' readOnly='true' ");
  vaTemplate.push("style='");
  vaTemplate.push("border-style:none;border-width:0px;");
  vaTemplate.push("@cssStrBuf");	//14
  vaTemplate.push("'/></td></tr></tbody></table>");

  vaTemplate.push("<div class='" + vsBtnClass + "' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_btn' ");
  vaTemplate.push("style=\"position:absolute;overflow:hidden;margin:0px;padding:0px;");
  vaTemplate.push("top:0px;right:0px;text-align:center;vertical-align:middle;cursor:pointer;");
  vaTemplate.push("@cssStrBuf");	//21
  vaTemplate.push("\">");
  
  vaTemplate.push("<span id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_label' ");
  vaTemplate.push("style='position:absolute;width:100%;margin:0px;padding:0px;cursor:pointer;left:0px;'>");
  vaTemplate.push("@innStrBuf"); //27
  vaTemplate.push("</span>")
  
  vaTemplate.push("<input type='file' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_file' name='");
  vaTemplate.push(this.id);
  vaTemplate.push("_file' ");
  vaTemplate.push("style='position:absolute;top:0px;right:0px;margin:0px;padding:0px;cursor:pointer;");
  
  vaStrBuf = [];
  if(this.canvas.page.metadata.browser.ie > 0) {
    vaStrBuf.push("filter:alpha(opacity:0);");
  } else {
    vaStrBuf.push("opacity:0.0;");
  }
  vaStrBuf.push("cursor:pointer;")
  vaTemplate.push(vaStrBuf.join(""));
  
  vaTemplate.push("@cssStrBuf");	//36
  //vaTemplate.push("' onchange=\"");										// 추가
  //vaTemplate.push(vfcGetEHandler(this.id, "changeValue"));				// 추가
  vaTemplate.push("' /></div>");
  
//  vaTemplate.push("<span style='visibility:hidden;");
//  vaTemplate.push("@cssStrBuf");	//41
//  vaTemplate.push("'/>");
  
  vaStrBuf = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.getFileFontSize = function(pnBtnWidth) {
  return Math.round(pnBtnWidth/4);
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.refreshSubStyle = function(poCtrl, poDocument) {
  this.setSubCtrlStyles(poCtrl);  
};

eXria.controls.xhtml.FileSelector.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
	this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  var voBtnDf = this.browseBtn;
  voBtnDf.width = this.getAttrValue("browseBtn.width",this.browseBtn.width);
  var vsValue = voBtnDf.value;
  var voData = voBtnDf.data;
  if(voData.instanceId && voData.instancePath) vsValue = voData.getData();
  voBtnDf.value = this.getAttrValue("browseBtn.value", vsValue);
};

eXria.controls.xhtml.FileSelector.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voBtnDf = this.browseBtn;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  // voTable
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", this.subBorderWidth, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - 5, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vaTemplate[2] = vaCssStrBuf.join("");
  
  // voTd
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight - (2 * this.subBorderWidth) - this.paddingTop - this.paddingBottom - 5, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
	vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vaTemplate[7] = vaCssStrBuf.join("");
  
  // voText
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSiz, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - this.paddingLeft - this.paddingRight - 5, "px");
  //vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight - (2 * this.subBorderWidth) - this.paddingTop - this.paddingBottom - 5, "px");
  vaTemplate[14] = vaCssStrBuf.join("");
  
  // voBtn
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "color", voBtnDf.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voBtnDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-image", voBtnDf.backgroundImage);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", voBtnDf.backgroundPosition);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", voBtnDf.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", voBtnDf.borderWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", voBtnDf.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", voBtnDf.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", voBtnDf.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", voBtnDf.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", voBtnDf.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", voBtnDf.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", voBtnDf.borderWidth, "px");
	var vnWidth = voBtnDf.width;
	if(voBtnDf.borderWidth) vnWidth = vnWidth - 2 * voBtnDf.borderWidth;
	var vnHeight = this.innerHeight;
	if(voBtnDf.borderWidth) vnHeight = vnHeight - 2 * voBtnDf.borderWidth; 
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  
  vaTemplate[21] = vaCssStrBuf.join("");
  
  vaTemplate[27] = this.getLabelText(voBtnDf.value);
    
  // voFile
//  var vnFontSize = this.getFileFontSize(voBtnDf.width);
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight - 2 * voBtnDf.borderWidth, "px");
//  vfcSetCssStrBuf(vaCssStrBuf, "font-size", vnFontSize, "px");
  vaTemplate[36] = vaCssStrBuf.join("");
  
//  vaCssStrBuf = [];
//  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
//  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
//  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
//  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
//  vaTemplate[39] = vaCssStrBuf.join("");

  poCtrl.innerHTML = vaTemplate.join("");
  
  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
  
  this.setSubElement(poDocument);
}; 
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.setSubElement = function(poDocument) {
	var voCtrl = this.ctrl;
	var voSubElement = this.subElement;
	
	voSubElement.table = voCtrl.childNodes[0];
	voSubElement.td = voSubElement.table.rows[0].cells[0];
	voSubElement.text = this.getSubCtrl("input", voCtrl, null, 0);
	voSubElement.btn = voCtrl.childNodes[1];
	voSubElement.file = this.getSubCtrl("input", voCtrl, null, 1);
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.loadComplete = function(poDocument) {
	var voCtrl = this.getCtrl(poDocument);
  var voBtn = this.subElement.btn;
	var voTxt = this.subElement.text;
  var voLabel = this.getSubCtrl("span");
	this.setbrowseBtnSize();
  this.setVerticalAlign(voLabel, voBtn, "middle");
	this.setVerticalAlign(voTxt, voCtrl, "middle");
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.setbrowseBtnSize = function(){
	var voSubElements = this.subElement;
	var vnBtnWidth = this.getStyleCurrentValue(voSubElements.btn, "width", "width");
	//var vnBtnWidth = this.getAttrValue("browseBtn.width",this.browseBtn.width);	
	var vnBtnBorderLeftWidth = this.getStyleCurrentValue(voSubElements.btn, "border-left-width", "borderLeftWidth");
	var vnBtnBorderRightWidth = this.getStyleCurrentValue(voSubElements.btn, "border-right-width", "borderRightWidth");
	var vnBtnBorderTopWidth = this.getStyleCurrentValue(voSubElements.btn, "border-top-width", "borderTopWidth");
	var vnBtnBorderBottomWidth = this.getStyleCurrentValue(voSubElements.btn, "border-bottom-width", "borderBottomWidth");
	var voBtnStyle = voSubElements.btn.style;
	voBtnStyle.width = parseInt(vnBtnWidth, 10) - parseInt(vnBtnBorderLeftWidth, 10) - parseInt(vnBtnBorderRightWidth, 10) + "px";
	voBtnStyle.height = this.innerHeight - parseInt(vnBtnBorderTopWidth, 10) - parseInt(vnBtnBorderBottomWidth, 10) + "px";
	
	var vnWidthTemp = this.innerWidth - parseInt(vnBtnWidth, 10) - (2 * this.subBorderWidth) - 5;
	
	var vsWidth = this.innerWidth - parseInt(vnBtnWidth, 10) - (2 * this.subBorderWidth) - 5 + "px";
	
	if(vnWidthTemp <= 0)
	  vsWidth = this.innerWidth + "px"; 
	    
	voSubElements.table.style.width = vsWidth;
	voSubElements.text.style.width = parseInt(vsWidth, 10) - (2 * this.subBorderWidth) + "px";
	
	var voFileStyle = voSubElements.file.style;
	var vnFontSize = this.getFileFontSize(parseInt(vnBtnWidth, 10));
	voFileStyle.fontSize = vnFontSize + "px";
};

eXria.controls.xhtml.FileSelector.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadComplete(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  
  var voTable = this.subElement.table;
  var voTd = this.subElement.td;
  var voText = this.subElement.text;
  var voBtn = this.subElement.btn;
  var voFile = this.getSubCtrl("input", poCtrl, null, 1);
  var voBtnDf = this.browseBtn;
  
  switch(psAttrName) { 
    case "width" :
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - 5, voTable);
      break;
    case "height" :
      this.setAttrCtrl("height", this.innerHeight, voTable);
      break;
//    case "borderWidth" :
//    case "borderLeftWidth" :
//    case "borderRightWidth" :
//    case "borderTopWidth" :
//    case "borderBottomWidth" :
//      this.setAttrCtrl("width", this.innerWidth, voText);
//      this.setAttrCtrl("height", this.innerHeight, voText);
//      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.setSpecificEvents = function(poCtrl) {
  var voTable = this.subElement.table;
  var voTd = this.subElement.td;
  var voText = this.subElement.text;
  var voFile = this.subElement.file
  
  this.eventManager.addListener(voFile, "onchange", this.mediateEvent);

  voFile.control = this;
  voText.control = this;
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.atchange = function(e) {
	var voCtrl = this.ctrl;
  var voTable = this.subElement.table;
  var voTd = this.subElement.td;
  var voText = this.subElement.text;
  var voFile = this.getSubCtrl("input", voCtrl, null, 1);
  
//  var vsFileValue = voFile.value.substring(voFile.value.lastIndexOf("\\")+1);
  var vsFileValue = voFile.value;
  voText.value = vsFileValue;
};

eXria.controls.xhtml.FileSelector.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
//  this.browseBtn.df = {};
  
  var voFile = this.getSubCtrl("input", poCtrl, null, 1);
  this.eventManager.removeListener(voFile, "onchange", this.mediateEvent);
};

eXria.controls.xhtml.FileSelector.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  this.setSpecificAttrs(poCtrl);  
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.refreshSpecificEvents = function(poCtrl) {
	this.setSpecificEvents(poCtrl);
};
/**
 * @ignore
 */
eXria.controls.xhtml.FileSelector.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voTable = this.subElement.table;
  var voTd = this.subElement.td;
  var voText = this.subElement.text;
  var voBtn = this.subElement.btn;
  var voFile = this.getSubCtrl("input", voCtrl, null, 1);
	var voDf = this.df;
  var vaAttrName = psAttrName.split(".");
  var voBtnDf = this.browseBtn;
  
  this.setAttr(psAttrName, psAttrValue);
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  
  switch(psAttrName) {
    case "visible" :
      this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
      break;
    case "disabled" :
      this.setDisable(voCtrl, psAttrValue);
      break;
    case "backgroundColor" :
    case "color" :
      this.setAttrCtrl(psAttrName, psAttrValue, voText);
      break;      
    case "fontFamily" :
    case "fontSize" :
    case "fontStyle" :
    case "fontWeight" :
      this.setAttrCtrl(psAttrName, psAttrValue, voText);
      break;      
    case "borderColor" :
    case "borderStyle" :
    case "outerClassName":
    case "className":
      this.refresh(poDocument);
      break;
    case "width" :
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - 5, voTable);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - this.paddingLeft - this.paddingRight - 5, voText);
      var voLabel = this.getSubCtrl("span");
      this.setVerticalAlign(voLabel, voBtn, this.verticalAlign);
      break;
    case "height" :
      this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setAttrCtrl("height", this.innerHeight-(parseInt(voBtn.style.borderBottomWidth) + parseInt(voBtn.style.borderTopWidth)), voBtn);
      this.setAttrCtrl("height", this.innerHeight, voFile);
      //this.setVerticalAlign(voCtrl);
      this.setVerticalAlign(voFile, voCtrl, this.verticalAlign);
      var voLabel = this.getSubCtrl("span");
      this.setVerticalAlign(voLabel, voBtn, this.verticalAlign);
      break;
    case "borderWidth" :
      this.borderLeftWidth = this.borderWidth;
      this.borderRightWidth = this.borderWidth;
      this.borderTopWidth = this.borderWidth;
      this.borderBottomWidth = this.borderWidth;
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
      this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
      this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
      this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - 5, voTable);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - this.paddingLeft - this.paddingRight - 5, voText);
      //this.setAttrCtrl("width", this.innerWidth-(parseInt(voText.style.borderBottomWidth) + parseInt(voText.style.borderTopWidth) + this.paddingLeft + this.paddingRight+5), voText);
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setAttrCtrl("height", this.innerHeight- (4 * this.subBorderWidth), voTd);
      this.setAttrCtrl("height", this.innerHeight- (4 * this.subBorderWidth), voText);
      this.setAttrCtrl("height", this.innerHeight-(parseInt(voBtn.style.borderBottomWidth) + parseInt(voBtn.style.borderTopWidth)), voBtn);
      this.setAttrCtrl("height", this.innerHeight, voFile);
      
      this.setVerticalAlign(voTable, voCtrl, this.verticalAlign);
      var voLabel = this.getSubCtrl("span");
      this.setVerticalAlign(voLabel, voBtn, this.verticalAlign);
      
      break;
   case "borderLeftWidth" :
   case "borderRightWidth" :
      this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
      if(this.innerWidth < 0) this.innerWidth = 0;
      this.setAttrCtrl("width", this.innerWidth, voCtrl);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - 5, voTable);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - this.paddingLeft - this.paddingRight - 5, voText);
      this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
      break;
   case "borderTopWidth" :
   case "borderBottomWidth" :
      this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
      if(this.innerHeight < 0) this.innerHeight = 0;
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      this.setAttrCtrl("height", this.innerHeight-(parseInt(voBtn.style.borderBottomWidth) + parseInt(voBtn.style.borderTopWidth)), voBtn);
      this.setAttrCtrl("height", this.innerHeight, voFile);
      this.setAttrCtrl(psAttrName, voDf[psAttrName] + "px", voCtrl);
      
      this.setVerticalAlign(voText, voCtrl, this.verticalAlign);
      var voLabel = this.getSubCtrl("span");
      this.setVerticalAlign(voLabel, voBtn, this.verticalAlign);
      break;
   case "padding" :
      this.paddingTop = this.padding;
      this.paddingRight = this.padding;
      this.paddingBottom = this.padding;
      this.paddingLeft = this.padding;
      this.setAttrCtrl("paddingTop", this.paddingTop + "px", voTd);
      this.setAttrCtrl("paddingRight", this.paddingRight + "px", voTd);
      this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voTd);
      this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voTd);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - this.paddingLeft - this.paddingRight - 5, voText);
      break;
    case "paddingTop" :
    case "paddingRight" :
    case "paddingBottom" :
    case "paddingLeft" :
      this.setAttrCtrl(psAttrName, psAttrValue + "px", voTd);
      this.setAttrCtrl("width", this.innerWidth - voBtnDf.width - (2 * this.subBorderWidth) - this.paddingLeft - this.paddingRight - 5, voText);
      break;
    default :
      this.refresh(poDocument);
      break;
  }
};
/**
 * 컨트롤에 할당된 값을 반환
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 텍스트 박스의 입력 값
 * @type String
 */
eXria.controls.xhtml.FileSelector.prototype.getValue = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voFile = this.getSubCtrl("input", voCtrl, null, 1);
  return voFile.value;
};

eXria.controls.xhtml.FileSelector.prototype.getSpecificDefaultValue = function(psAttrName){
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.FileSelector[psAttrName];      
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.FileSelector[vaAttrName[0]][vaAttrName[1]] != null ? eXria.controls.xhtml.Default.FileSelector[vaAttrName[0]][vaAttrName[1]] : vsDefaultValue;
  }
  if( vsDefaultValue == undefined) { 
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
///**
// * 컨트롤에 값 설정.
// * @param {String} psLabel 컨트롤에 설정할 라벨 값
// * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능.
// * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
// */
//eXria.controls.xhtml.FileSelector.prototype.setValue = function(psLabel, poCtrl, poDocument) {
//  if(poDocument == null) poDocument = document;    
//  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
//  var voCtrl = poCtrl.getCtrl();
//  var voLabel = this.getSubCtrl("div", voCtrl, null, 1);
//  
//  //this.browseBtn.value = psLabel;
//  this.browseBtn.df.value = psLabel;
//  
//  this.setText(voLabel, eXria.controls.xhtml.Util.parseLang(psLabel));
//};
/**
 * 버튼에 라벨(아이콘 이미지 포함) 값에 줄발꿈을 값을 적용하여 반환하는 메소드.
 * @param {String} psLabel 라벨명
 * @return 버튼에 라벨(아이콘 이미지 포함) 값에 줄발꿈이 적용된 값
 * @type String
 * @private
 */
eXria.controls.xhtml.FileSelector.prototype.getLabelText = function(psLabel) {
  var vsStr = eXria.controls.xhtml.Util.parseLang(psLabel);
  if(vsStr == null) return "";
  vsStr = vsStr.replace("\n", "<br>");
  return vsStr;
};
/**
 * 클래스 명을 반환.
 * @return "FileSelector"
 * @type String
 */
eXria.controls.xhtml.FileSelector.prototype.toString = function() {
  return "FileSelector";
};

/**
 * 파일첨부 버튼의 속성을 저장하기 위한 오브젝트.
 */
eXria.controls.xhtml.FileSelector_browseBtn = function(poParent){
  /**
  * FileSelector Control 참조 변수.
  * @type eXria.controls.xhtml.FileSelector
  */
  this.parent = poParent;
  /**
   * 파일첨부 버튼에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 파일첨부 버튼의 보더 두께.
   * @type Number
   */  
  this.borderWidth = null;
  /**
   * CSS를 통해 지정된 파일첨부 버튼의 보더 두께.
   * @type Number
   */  
  this.cssBorderWidth = null;
  /**
   * 파일첨부 버튼의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 파일첨부 버튼의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 파일첨부 버튼의 가로 길이.
   * @type Number
   */
  this.width = null;
  /**
   * 파일첨부 버튼의 세로 길이.
   * @type Number
   */
  this.height = null;
  /**
   * 파일첨부 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;  
  /**
   * 파일첨부 버튼 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * 파일첨부 버튼 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;
  /**
   * 파일첨부 버튼의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 파일첨부 버튼의 텍스트 색상.
   * @type String
   */
  this.color = null;
  /**
   * 파일첨부 버튼에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 파일첨부 버튼에 표시될 텍스트 폰트사이즈.
   * @type Number
   */    
  this.fontSize = null;
  /**
   * CSS를 통해 지정된 파일첨부 버튼에 표시될 텍스트 폰트사이즈.
   * @type Number
   */    
  this.cssFontSize = null;
  /**
   * 파일첨부 버튼에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 파일첨부 버튼에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 파일첨부 버튼에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 파일첨부 버튼에 설정된 값.
   * @type String
   */
  this.value = null;
  /**
   * 파일첨부 버튼 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */  
  this.data = new eXria.controls.DataRefNode(this.parent);
};