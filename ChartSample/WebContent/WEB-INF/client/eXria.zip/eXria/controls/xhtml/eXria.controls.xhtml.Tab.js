/**
 * @fileoverview
 * Concreate xhtml TabHeader, TabButton, TabPage, Tab
 * @author 조영진
 */

/**
 * 탭 컨트롤 헤더의 탭 버튼 공통 속성을 저장하기 위한 클래스.
 * @version 2.0
 * @type eXria.controls.xhtml.TabHeader_tabbuttons
 * @constructor
 */
eXria.controls.xhtml.TabHeader_tabbuttons = function() {
  /**
   * 탭 버튼의 보더 색상.
   * @type String
   */
  this.borderColor = null;  
  /**
   * 탭 버튼의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;  
  /**
   * 탭 버튼의 보더 두께.
   * @type Number
   */ 
  this.borderWidth = null;  
  /**
   * 탭 버튼의 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;  
  /**
   * 탭 버튼의 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;  
  /**
   * 탭 버튼의 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;  
  /**
   * 탭 버튼의 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 탭 버튼에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;    
  /**
   * 탭 버튼에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;  
  /**
   * 탭 버튼에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;  
  /**
   * 탭 버튼에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;  
  /**
   * 탭 버튼에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 탭 버튼간 간격(px).
   * @type Number
   */
  this.cellSpacing = null;  
  /**
   * 탭 버튼의 가로 길이.
   * @type Number
   */
  this.width = null;  
  /**
   * 탭 버튼의 세로 길이.
   * readOnly 속성.
   * @type Number
   * @private
   */
  this.height = null;  
  /**
   * 탭 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;    
  /**
   * 선택된 탭 버튼의 배경이미지 url.
   * @type String
   */
  this.imageFocused = null;      
  /**
   * 탭 버튼 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;  
  /**
   * 탭 버튼 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;  
  /**
   * 탭 버튼의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;  
  /**
   * 탭 버튼이 선택되었을 때의 배경 색상.
   * @type String
   */
  this.focusBackgroundColor = null;  
  /**
   * 탭 버튼의 텍스트 색상.
   * @type String
   */
  this.color = null;    
  /**
   * 탭 버튼이 선택되었을 때의 텍스트 색상.
   * @type String
   */
  this.focusColor = null;  
  /**
   * 탭 버튼에 표시될 텍스트의 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 탭 버튼에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;  
  /**
   * 탭 버튼에 표시될 텍스트 폰트사이즈.
   * @type Number
   */    
  this.fontSize = null;  
  /**
   * 탭 버튼에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;  
  /**
   * 탭 버튼에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;  
  /**
   * 텍스트 밑줄 적용 속성.
   * @type String
   */
  this.textDecoration = null;
  /**
   * 탭 버튼에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;  
  /**
   * 탭 버튼에 외곽에 적용될 css 클래스 명.
   * @type String
   */
  this.outerClassName = null;
  /**
   * 탭 컨트롤 헤더의 탭 버튼 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  /**
   * 탭 컨트롤 헤더의 탭 버튼 cursor값
   * @type String
   * @private
   */
  this.cursor = null;
  
  this.df = {};
};


/**
 * @class Concreate xhtml TabButton
 * XHTML Tab 컨트롤 헤더에 포함되는 탭 버튼 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.TabButton 객체
 * @type eXria.controls.xhtml.TabButton
 * @constructor
 * @base eXria.controls.xhtml.Button
 */
eXria.controls.xhtml.TabButton = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  
  eXria.controls.xhtml.Button.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 탭 헤더 참조
   * @type eXria.controls.xhtml.TabHeader
   * @private
   */
  this.parent = null;
  /**
   * Button의 subId 참조(탭 컨트롤 id가 제외된 값)
   * @private
   */
  this.subId = null;
  /**
   * 링크된 페이지 아이디(탭 컨트롤 id와 조합된 값) 참조
   * @type String
   * @private
   */
  this.pageId = null;
  /**
   * 링크된 페이지 아이디 참조(탭 컨트롤 id가 제외된 값)
   * @type String
   * @private
   */
  this.pageSubId = null;
  /**
   * @ignore
   */    
  this.position = "relative";
  
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Button, eXria.controls.xhtml.TabButton);
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<button hidefocus='true' type='button' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_btn' style=\"");
  vaTemplate.push("@cssStrbuf"); //setSpecificAttrs메소드에서  스타일 속성이 대체될  부분은 @cssStrBuf로 마크(Element 속성의 경우엔 @attStrBuf로 마크)
  vaTemplate.push("\" class='" + vsClass + "'>");
  vaTemplate.push("@innStrBuf"); //setSpecificAttrs메소드에서 innerHTML이 대체될 부분은 @innStrBuf로 마크
  vaTemplate.push("</button>");
//  vaTemplate.push("<div style=\"");
//  vaTemplate.push("@cssStrBuf");
//  vaTemplate.push("\"><table style=\"position:absolute;left:0px;top:0px;width:100%;height:100%;font-family:Arial;font-weight:bold;\">");
//  vaTemplate.push("<tr><td align=\"center\" vAlign=\"middle\">x</td></tr></table></div>");
  var vcTab = this.parent.parent;
    if(vcTab.type == "minimizedWindow") {
    vaTemplate.push("<input type=\"button\" value=\"x\" HIDEFOCUS=\"true\" style=\"");
    vaTemplate.push("@cssStrBuf");
    vaTemplate.push("\" onclick=\"");
    vaTemplate.push(this.getEHandler2(this.pageId));
    vaTemplate.push("\"/>");
  }
  vaTemplate.push("<span style=\"");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("\"/>");
  this.templateIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaTemplate);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  ///////////////////////////////////////////////////////////////////////////////////
  // 블럭 A
  // 이 블럭의 코드는 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  ///////////////////////////////////////////////////////////////////////////////  
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  var voIndexMap = this.templateIndexMap;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.09.21 기존에 이와같은 코드가 있었는데 아예 동작을 안했는데 여기서는 동작이 되서 side effect 생김
  //if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  //////////////////////////////////////////////////////////////////////////////////////////
  // 블럭 A 끝
  //////////////////////////////////////////////////////////////////////////////////////////

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;left:0px;top:0px;border-style:none;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
  
  // AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
  // backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.
  if(this.backgroundImage) {
    if(this.backgroundImage.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
      var vsSplit = this.backgroundImage.split("\'");
      if(vsSplit[0] == "url(") 
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[2] + "')");
      else
        vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[1] + "')");   
    } else {
      vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
      if(poCtrl.style["filter"]) poCtrl.style["filter"] = "";
    }
  }

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else if(this.wordWrap == true) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  
  vaTemplate[voIndexMap.get(0)] = vaCssStrBuf.join("");
  vaTemplate[voIndexMap.get(1)] = this.getLabelText(this.value);
  
  var vnIndex = 2;
  var vcTab = this.parent.parent;
  if(vcTab.type == "minimizedWindow") {
    vaCssStrBuf = [];
    vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;border-width:0px;left:" + (this.innerWidth - 20) + "px;top:0px;");
    vaCssStrBuf.push("border-style:none;font-family:Arial;font-weight:bold;text-align:center;outline-style:none;");
    vfcSetCssStrBuf(vaCssStrBuf, "width", 20, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
    vaTemplate[voIndexMap.get(vnIndex++)] = vaCssStrBuf.join("");
  }
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[voIndexMap.get(vnIndex)] = vaCssStrBuf.join("");
  poCtrl.innerHTML = vaTemplate.join("");
  
  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
  
  this.setSubElement(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  voEvent.object = poControl;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  
  if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if (poControl[vsOnEvent]) { 
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
};
eXria.controls.xhtml.TabButton.prototype.setSpecificEvents = function(poCtrl) {
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.atmouseover = function(poEvent) {
}
/**
* @ignore
*/
eXria.controls.xhtml.TabButton.prototype.atmouseout = function(poEvent) {
}
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.atclick = function(poEvent) {
  // 조영진 선임 추가 코드
  var voTabHeader = this.parent;
  var voTab = voTabHeader.parent;
  var voButton = poEvent.object;
  var vnIndex = voTab.getIndexById(voButton.pageId);
  if(vnIndex != voTab.selectedIndex) voTabHeader.select(vnIndex);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voBtn = voCtrl.childNodes[0];
  var voDf = this.df;
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
//    if(this.borderLeftWidth == null) this.borderLeftWidth = this.borderWidth;
//    if(this.borderRightWidth == null) this.borderRightWidth = this.borderWidth;
//    if(this.borderTopWidth == null) this.borderTopWidth = this.borderWidth;
//    if(this.borderBottomWidth == null) this.borderBottomWidth = this.borderWidth;
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;

    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  //case "borderTopHeight" :
  case "borderBottomWidth" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "value" :
    this.setValue(psAttrValue, voBtn, poDocument);
    break;
  case "backgroundImage" :
  case "imageFocused" :
    if(this.focused) this.setAttrCtrl("backgroundImage", this.imageFocused, voBtn);
    else this.setAttrCtrl("backgroundImage", this.backgroundImage, voBtn);
    break;
  case "backgroundPosition":
  case "backgroundRepeat":
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "outerClassName" :
  case "className" :
  case "borderWidth" :
    this.refresh(poDocument);
    break;
  default :
    this.refresh(poDocument);
    break;
  } 
};  
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  if(eXria.controls.xhtml.Default.Tab.TabHeader.tabbuttons) vsDefaultValue = eXria.controls.xhtml.Default.Tab.TabHeader.tabbuttons[psAttrName];
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabButton.prototype.getEHandler2 = function(psPageId) {
  var voTabHeader = this.parent;
  var voTab = voTabHeader.parent;
  var vnIndex = voTab.getIndexById(psPageId);
  var vaStrBuf = [];
  vaStrBuf.push("var voControl=page.getControl('");
  vaStrBuf.push(voTab.id);
  vaStrBuf.push("');");
  vaStrBuf.push("voControl.")
  vaStrBuf.push("removeMinimizedWindowTab(" + vnIndex + ");");
  vaStrBuf.push("var voEvent = new eXria.event.Event(event);");
  vaStrBuf.push("voEvent.stopEvent();");
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * 클래스 명을 반환.
 * @return "TabButton"
 * @type String
 */
eXria.controls.xhtml.TabButton.prototype.toString = function() {
  return "Tab_TabHeader_TabButtons";
};


/**
 * @class Concreate xhtml TabHeader.<br>
 * XHTML Tab 컨트롤의 헤더부분 구성.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.TabHeader 객체
 * @type eXria.controls.xhtml.TabHeader
 * @constructor
 * @base eXria.controls.xhtml.Group
 */ 
eXria.controls.xhtml.TabHeader = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  eXria.controls.xhtml.Group.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  // 데이타 연동 관련
  /**
   * Data 연동 객체(노드 셋 연동).
   * @type eXria.controls.DataRefNodeset
   */  
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * 인스턴스로 부터 라벨 데이타를 가져올 때 사용될 DOM Element 명
   * @type String
   */
  this.labelTagName = "label";
  /**
   * 인스턴스로 부터 button id를 가져올 때 사용될 DOM Element 명
   * @type String
   */
  this.bidTagName = "buttonid";
  /**
   * 인스턴스로 부터 page id를 가져올 때 사용될 DOM Element 명
   * @type String
   */
  this.pidTagName = "pageid";
  /**
   * 탭 버튼 이동에 이용되는 인덱스 번호.
   * @type Number
   * @private
   */      
  this.scrollIndex = 0;
  /**
   * 탭 버튼의 공통적인 속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.TabHeader_tabbuttons
   */
  this.tabbuttons = new eXria.controls.xhtml.TabHeader_tabbuttons();
  /**
   * 탭 이동 버튼의 가로 길이.
   * @type Number
   * @private
   */
  this.scrollBtnWidth = 30;
  /**
   * 보더를 제외한 Tab Header의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 Tab Header의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 스크롤 버튼 영역의 가로 길이(컨트롤 내부 위치 계산에 이용).
   * @type Number
   * @private
   */
  this.scrollAreaWidth = 0;
  /**
   * 상위 탭 컨트롤 참조.
   * @type eXria.controls.xhtml.Tab
   * @private
   */
  this.parent = null;   //@private
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 왼쪽 탭스핀 버튼 비활성화 이미지
   * @type String
   * 
   */
  this.tabSpinLeftDisabledImg = null;
  /**
   * 왼쪽 탭스핀 버튼 활성화 이미지
   * @type String
   * 
   */
  this.tabSpinLeftImg = null;
  /**
   * 오른쪽 탭스핀 버튼 비활성화 이미지
   * @type String
   * 
   */
  this.tabSpinRightDisabledImg = null;
  /**
   * 오른쪽 탭스핀 버튼 활성화 이미지
   * @type String
   * 
   */
  this.cursor = null;
  
  this.tabSpinRightImg = null;
  
  /**
   * 왼쪽 탭스핀 버튼 width
   * @type Number
   */
  this.tabSpinLeftWidth = null;
  /**
   * 오른쪽 탭스핀 버튼 width
   * @type Number
   */
  this.tabSpinRightWidth = null; 
  
};  
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Group, eXria.controls.xhtml.TabHeader);
//////////////////////////////////////////////////////////////////
// 메소드   
eXria.controls.xhtml.TabHeader.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
eXria.controls.xhtml.TabHeader.prototype.createSubCtrl = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voTabbuttonsDf = this.tabbuttons;
  this.scrollBtnWidth = this.getAttrValue("scrollBtnWidth", this.scrollBtnWidth);
  this.tabSpinLeftWidth = this.getAttrValue("tabSpinLeftWidth", this.tabSpinLeftWidth);
  this.tabSpinLeftWidth = this.tabSpinLeftWidth == null ? 23 : this.tabSpinLeftWidth;   // default image가 23사이즈
  this.tabSpinRightWidth = this.getAttrValue("tabSpinRightWidth", this.tabSpinRightWidth);
  this.tabSpinRightWidth = this.tabSpinRightWidth == null ? 23 : this.tabSpinRightWidth;  // default image가 23사이즈
  
  voTabbuttonsDf.cellSpacing = this.getAttrValue("tabbuttons.cellSpacing", this.tabbuttons.cellSpacing);
  var voCssStyle = this.canvas.getCssStyle(this.outerClassName, poDocument);
  this.borderWidth = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderWidth");
  
  this.tabSpinLeftImg = this.getAttrValue("tabSpinLeftImg", this.tabSpinLeftImg);
  this.tabSpinRightImg = this.getAttrValue("tabSpinRightImg", this.tabSpinRightImg);
  this.tabSpinLeftDisabledImg = this.getAttrValue("tabSpinLeftDisabledImg", this.tabSpinLeftDisabledImg);
  this.tabSpinRightDisabledImg = this.getAttrValue("tabSpinRightDisabledImg", this.tabSpinRightDisabledImg);
  
  var vnBorderWidth = this.borderWidth;
  if(vnBorderWidth == null) vnBorderWidth = 0;
  this.innerWidth = this.width - 2 * vnBorderWidth;
  this.innerHeight = this.height - 2 * vnBorderWidth;
  this.tabbuttons.height = this.innerHeight - 2 * voTabbuttonsDf.cellSpacing;

  //if(this.tabSpinLeftImg || this.tabSpinRightImg || this.tabSpinLeftDisabledImg || this.tabSpinRightDisabledImg){
  if(this.tabSpinLeftWidth || this.tabSpinRightWidth){
    this.scrollAreaWidth = this.tabSpinLeftWidth + this.tabSpinRightWidth + voTabbuttonsDf.cellSpacing * 3;
  }else{
    this.scrollAreaWidth = this.scrollBtnWidth * 2 + voTabbuttonsDf.cellSpacing * 3;
  }
};
eXria.controls.xhtml.TabHeader.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabHeader.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  voEvent.object = poControl;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  
  if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if (poControl[vsOnEvent]) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
};  
/**
 * @ignore
 */
eXria.controls.xhtml.TabHeader.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voBtnDf = this.tabbuttons;
  
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.scrollBtnWidth = this.getAttrValue("scrollBtnWidth", this.scrollBtnWidth);
  
  /*this.tabSpinLeftImg = eXria.controls.xhtml.Util.getBackgroundImagePath(this.getAttrValue("tabSpinLeftImg", this.tabSpinLeftImg), this.window);
  this.tabSpinRightImg = eXria.controls.xhtml.Util.getBackgroundImagePath(this.getAttrValue("tabSpinRightImg", this.tabSpinRightImg), this.window);
  this.tabSpinLeftDisabledImg = eXria.controls.xhtml.Util.getBackgroundImagePath(this.getAttrValue("tabSpinLeftDisabledImg", this.tabSpinLeftDisabledImg), this.window);
  this.tabSpinRightDisabledImg = eXria.controls.xhtml.Util.getBackgroundImagePath(this.getAttrValue("tabSpinRightDisabledImg", this.tabSpinRightDisabledImg), this.window);*/
  /*this.tabSpinLeftImg = this.getAttrValue("tabSpinLeftImg", this.tabSpinLeftImg);
  this.tabSpinRightImg = this.getAttrValue("tabSpinRightImg", this.tabSpinRightImg);
  this.tabSpinLeftDisabledImg = this.getAttrValue("tabSpinLeftDisabledImg", this.tabSpinLeftDisabledImg);
  this.tabSpinRightDisabledImg = this.getAttrValue("tabSpinRightDisabledImg", this.tabSpinRightDisabledImg);*/
  
  voBtnDf.cellSpacing = this.getAttrValue("tabbuttons.cellSpacing",this.tabbuttons.cellSpacing);
  if(voBtnDf.cellSpacing != null) voBtnDf.cellSpacing = parseInt(voBtnDf.cellSpacing);
  this.tabbuttons.height = this.innerHeight - 2 * voBtnDf.cellSpacing;
  voBtnDf.width = this.getAttrValue("tabbuttons.width",this.tabbuttons.width);
  if(voBtnDf.width != null) voBtnDf.width = parseInt(voBtnDf.width);
  voBtnDf.focusBackgroundColor = this.getAttrValue("tabbuttons.focusBackgroundColor",this.tabbuttons.focusBackgroundColor);
  voBtnDf.imageFocused = this.getAttrValue("tabbuttons.imageFocused",this.tabbuttons.imageFocused);
  voBtnDf.backgroundImageFocused = this.getAttrValue("tabbuttons.imageFocused",this.tabbuttons.backgroundImageFocused);
  //if(voBtnDf.imageFocused != null) {
  //  voBtnDf.imageFocused = eXria.controls.xhtml.Util.getBackgroundImagePath(voBtnDf.imageFocused, this.window);
  //}
  voBtnDf.focusColor = this.getAttrValue("tabbuttons.focusColor",this.tabbuttons.focusColor);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabHeader.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voBtnDf = this.tabbuttons;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  var voIndexMap = null;
  var vaInnerDiv = this.createInnerDiv();
  var vaOuterDiv = this.createOuterDiv();
  var vaScrollDiv = this.createScrollDiv();
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  //var vsClass = this.getCSSClass(this.parent, 1, "tabHeader");
  var vsClass= "Default_Tab_TabHeader_Class " + this.className;
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  //vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  // OuterDiv
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", (this.innerWidth - this.scrollAreaWidth), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");
  
  vaOuterDiv[3] = vaCssStrBuf.join("");
  
  // ScrollDiv
  voIndexMap = eXria.controls.xhtml.Util.getTemplateIndexMap(vaScrollDiv);
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "left", (this.innerWidth - this.scrollAreaWidth), "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.scrollAreaWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");  
  vfcSetCssStrBuf(vaCssStrBuf, "display", this.isScroll()?"block":"none");
  
  vaScrollDiv[voIndexMap.get(0)] = vaCssStrBuf.join("");
  
  // voTable
  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "cellSpacing", voBtnDf.cellSpacing, "px");
  
  vaScrollDiv[voIndexMap.get(1)] = vaAttStrBuf.join("");
  //  voScrollBtn
  vaScrollDiv[voIndexMap.get(2)] = this.makeSpinButtonStyle("left");
  vaScrollDiv[voIndexMap.get(3)] = this.makeSpinButtonStyle("right");
  voIndexMap.clear()

  // voInnerDiv
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vaInnerDiv[3] = vaCssStrBuf.join("");
  
  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "cellSpacing", voBtnDf.cellSpacing, "px");
  
  vaInnerDiv[6] = vaAttStrBuf.join("");
  
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vaInnerDiv[8] = vaCssStrBuf.join("");
  
  
  vaOuterDiv[5] = vaInnerDiv.join("");
  
  vaTemplate.push(vaOuterDiv.join(""));
  vaTemplate.push(vaScrollDiv.join(""));
  
  poCtrl.innerHTML = vaTemplate.join("");
  
  vaInnerDiv = null;
  vaOuterDiv = null;
  vaScrollDiv = null;
  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  voIndexMap = null;
  this.template = null;
  
  var voOuterDiv = poCtrl.childNodes[0];
  var voInnerDiv = voOuterDiv.childNodes[0];
  var voTable = voInnerDiv.childNodes[0];
  
  var voTabButton = null;
  var voTr = voTable.rows[0];
  var voTd = null;

  for(var i = 0; i < this.controls.size(); i++) {
    voTabButton = this.controls.get(i);
    voTabButton.canvas = this.canvas;
    voTabButton.window = this.window;
    voTabButton.document = this.document;
    voTabButton.className = voBtnDf.className;
    voTabButton.outerClassName = voBtnDf.outerClassName;
    voTabButton.width = voBtnDf.width;
    voTabButton.height = this.tabbuttons.height;
    voTabButton.backgroundColor = voBtnDf.backgroundColor;
    voTabButton.backgroundImage = voBtnDf.backgroundImage;
    voTabButton.backgroundPosition = voBtnDf.backgroundPosition;
    voTabButton.backgroundRepeat = voBtnDf.backgroundRepeat;
    voTabButton.imageFocused = voBtnDf.imageFocused;
    voTabButton.backgroundImageFocused = voBtnDf.backgroundImageFocused;
    voTabButton.color = voBtnDf.color;
    voTabButton.textAlign = voBtnDf.textAlign
    voTabButton.textDirection = voBtnDf.textDirection;
    voTabButton.fontFamily = voBtnDf.fontFamily;
    voTabButton.fontSize = voBtnDf.fontSize; 
    voTabButton.fontWeight = voBtnDf.fontWeight; 
    voTabButton.fontStyle = voBtnDf.fontStyle;     
    voTabButton.borderColor = voBtnDf.borderColor;
    voTabButton.borderStyle = voBtnDf.borderStyle;
    voTabButton.borderWidth = voBtnDf.borderWidth;
    voTabButton.borderLeftWidth = voBtnDf.borderLeftWidth;
    voTabButton.borderRightWidth = voBtnDf.borderRightWidth;
    voTabButton.borderTopWidth = voBtnDf.borderTopWidth;
    voTabButton.borderBottomWidth = voBtnDf.borderBottomWidth;
    voTabButton.padding = voBtnDf.padding;
    voTabButton.paddingLeft = voBtnDf.paddingLeft;
    voTabButton.paddingRight = voBtnDf.paddingRight;
    voTabButton.paddingTop = voBtnDf.paddingTop;
    voTabButton.paddingBottom = voBtnDf.paddingBottom;    
    // yhkim tabbuttons의 속성을 button 에 전달
    voTabButton.cursor = voBtnDf.cursor;
    if(voTabButton.visible == false) continue;
    voTd = this.document.createElement("td");
    voTd.appendChild(voTabButton.create(poDocument));
    voTr.appendChild(voTd);
    voTabButton.load();
  }
};

eXria.controls.xhtml.TabHeader.prototype.loadComplete = function(poDocument) {
  var voCtrl = this.ctrl;
  var voStyle = voCtrl.style;
  voStyle.backgroundColor = this.backgroundColor;
};
/**
 * yhkim 2009.11.25 tabheader의 spinbutton의 button style을 만드는 함수
 * @ignore
 */
eXria.controls.xhtml.TabHeader.prototype.makeSpinButtonStyle = function(poParam) {
  var vfcSetCssStrBuf = this.setCssStrBuf;
  vaCssStrBuf = [];
  var vbImageExist = false;
  if(this.tabSpinLeftDisabledImg || this.tabSpinRightDisabledImg)
    vbImageExist = true;

  if(vbImageExist == true) {
    vfcSetCssStrBuf(vaCssStrBuf, "border-width", 0, "px");  // image 있을 경우만
    vfcSetCssStrBuf(vaCssStrBuf, "border-style", "none"); // image 있을 경우만
    if(poParam == "left") vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.tabSpinLeftDisabledImg);
    else if(poParam == "right") vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.tabSpinRightDisabledImg);
  }
  
  if(poParam == "left") 
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.tabSpinLeftWidth, "px");
  else if(poParam == "right") 
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.tabSpinRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.tabbuttons.height, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", "no-repeat");
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", "center center");
  
  return vaCssStrBuf.join("");
};
eXria.controls.xhtml.TabHeader.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.tabbuttons.df = {};
  this.df = {};
};
eXria.controls.xhtml.TabHeader.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voOuterDiv = poCtrl.childNodes[0];
  var voInnerDiv = voOuterDiv.childNodes[0];
  var voTable = voInnerDiv.childNodes[0];
  var voTBody = voTable.childNodes[0];
  var voTr = voTBody.childNodes[0];
  
  var vnSize = this.controls.size();
  for(var i = 0; i < vnSize; i++) {
    this.controls.get(i).clearEvents(poDocument);
  }
  vnSize = voTr.childNodes.length;
  var voChild = null;
  for(var i = 0; i < vnSize; i++) {
    voChild = voTr.childNodes[0];
    //this.clearCtrlNode(voChild);
    voTr.removeChild(voChild);
  }

  this.setSpecificAttrs(poCtrl);
   
  if(this.controls.size() == 0) {
    this.applyAttr("visible", false);
  }
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  
  switch(psAttrName) {
  case "disabled" :
    //this.setDisable(poCtrl, psAttrValue);
    break;
  }
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(); 
  var voOuterDiv = voCtrl.childNodes[0];
  var voScrollDiv = voCtrl.childNodes[1];
  var voInnerDiv = voOuterDiv.childNodes[0];
  var voScrollTable = voScrollDiv.childNodes[0];
  var voTabTable = voInnerDiv.childNodes[0];    
  var vsSubAttrName = null;
  var voDf = this.df;
  var voBtnDf = this.tabbuttons;
  var voTab = this.parent;
      
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
  case "disabled" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "color" :
  case "fontFamily" :
  case "fontSize" :
  case "fontWeight" :
    var voScrollBtn = voScrollTable.rows[0].cells[0].childNodes[0];
    this.setAttrCtrl(psAttrName, psAttrValue, voScrollBtn);
    
    voScrollBtn = voScrollTable.rows[0].cells[1].childNodes[0];
    this.setAttrCtrl(psAttrName, psAttrValue, voScrollBtn);
    
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      var vnIndex = voTab.getIndex(voTabButton.value);
      if(psAttrName != "color" || vnIndex != this.selectedIndex) {
        voTabButton.applyAttr(psAttrName, psAttrValue);
      }
    }
    break;
  case "backgroundColor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    
    var vnWidth = this.innerWidth - this.scrollAreaWidth;
    if(vnWidth < 0) vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voOuterDiv);
    this.setAttrCtrl("left", vnWidth, voScrollDiv);
    
    this.tabbuttons.height = this.innerHeight - 2 * voBtnDf.cellSpacing;
    this.setAttrCtrl("height", this.innerHeight, voOuterDiv);
    this.setAttrCtrl("height", this.innerHeight, voScrollDiv);
    this.setAttrCtrl("height", this.innerHeight, voScrollTable);
    var voScrollBtn = voScrollTable.rows[0].cells[0].childNodes[0];
    this.setAttrCtrl("height", this.tabbuttons.height, voScrollBtn);
    voScrollBtn = voScrollTable.rows[0].cells[1].childNodes[0];
    this.setAttrCtrl("height", this.tabbuttons.height, voScrollBtn);
    this.setAttrCtrl("height", this.innerHeight, voInnerDiv);
    this.setAttrCtrl("height", this.innerHeight, voTabTable);
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      voTabButton.applyAttr("height", this.tabbuttons.height);
    }
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    var vnWidth = this.innerWidth - this.scrollAreaWidth;
    if(vnWidth < 0) vnWidth = 0;
    this.setAttrCtrl("width", vnWidth, voOuterDiv);
    this.setAttrCtrl("left", vnWidth, voScrollDiv);
    break;
  case "borderTopWidth" :
  case "borderTopHeight" :
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.tabbuttons.height = this.innerHeight - 2 * voBtnDf.cellSpacing;
    this.setAttrCtrl("height", this.innerHeight, voOuterDiv);
    this.setAttrCtrl("height", this.innerHeight, voScrollDiv);
    this.setAttrCtrl("height", this.innerHeight, voScrollTable);
    var voScrollBtn = voScrollTable.rows[0].cells[0].childNodes[0];
    this.setAttrCtrl("height", this.tabbuttons.height, voScrollBtn);
    voScrollBtn = voScrollTable.rows[0].cells[1].childNodes[0];
    this.setAttrCtrl("height", this.tabbuttons.height, voScrollBtn);      
    this.setAttrCtrl("height", this.innerHeight, voInnerDiv);
    this.setAttrCtrl("height", this.innerHeight, voTabTable);
    
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      voTabButton.applyAttr("height", this.tabbuttons.height);     
    }
    break;     
  case "tabbuttons.textAlign" :
  case "tabbuttons.backgroundImage" :
  case "tabbuttons.backgroundPosition" :
  case "tabbuttons.backgroundRepeat" :
  case "tabbuttons.focusImage" :
  case "tabbuttons.borderColor" :
  case "tabbuttons.borderStyle" :
  case "tabbuttons.borderWidth" :
  case "tabbuttons.borderBottomWidth" :
  case "tabbuttons.borderLeftWidth" :
  case "tabbuttons.borderRightWidth" :
  case "tabbuttons.borderTopWidth" :
  case "tabbuttons.backgroundColor" :
  case "tabbuttons.color" :
  case "tabbuttons.focusBackgroundColor" :
  case "tabbuttons.focusColor" :
  case "tabbuttons.textDecoration" :
  case "tabbuttons.fontFamily" :
  case "tabbuttons.fontSize" :
  case "tabbuttons.fontStyle" :
  case "tabbuttons.fontWeight" :
  case "tabbuttons.padding" :
  case "tabbuttons.paddingBottom" :
  case "tabbuttons.paddingLeft" :
  case "tabbuttons.paddingRight" :
  case "tabbuttons.paddingTop" :
  case "tabbuttons.cellSpacing" :
  case "tabbuttons.width" :
  case "tabbuttons.className" :
  case "tabbuttons.outerClassName" :
  // yhkim tabbuttons의 속성을 button 에 전달
  case "tabbuttons.cursor" :
    vsSubAttrName = psAttrName.split(".")[1];
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      voTabButton.applyAttr(vsSubAttrName, psAttrValue);
    }      
    break;      
  case "scrollBtnWidth" :
    this.scrollAreaWidth = this.scrollBtnWidth * 2 + voBtnDf.cellSpacing * 3;
    this.setAttrCtrl("width", (this.innerWidth - this.scrollAreaWidth), voOuterDiv);
    this.setAttrCtrl("left", (this.innerWidth - this.scrollAreaWidth), voScrollDiv);
    this.setAttrCtrl("width", this.scrollAreaWidth, voScrollDiv);
    this.setAttrCtrl("width", this.scrollAreaWidth, voScrollTable);
    var voScrollBtn = voScrollTable.rows[0].cells[0].childNodes[0];
    this.setAttrCtrl("width", this.scrollBtnWidth, voScrollBtn);
    voScrollBtn = voScrollTable.rows[0].cells[1].childNodes[0];
    this.setAttrCtrl("width", this.scrollBtnWidth, voScrollBtn);
    break;
  case "tabbuttons.cellSpacing" :
    this.tabbuttons.height = this.innerHeight - 2 * voBtnDf.cellSpacing;
    this.scrollAreaWidth = this.scrollBtnWidth * 2 + voBtnDf.cellSpacing * 3;
    
    this.setAttrCtrl("width", (this.innerWidth - this.scrollAreaWidth), voOuterDiv);
    this.setAttrCtrl("left", (this.innerWidth - this.scrollAreaWidth), voScrollDiv);
    this.setAttrCtrl("width", this.scrollAreaWidth, voScrollDiv);
    voScrollTable.setAttribute("cellSpacing", voBtnDf.cellSpacing + "px");
    this.setAttrCtrl("width", this.scrollAreaWidth, voScrollTable);      
    
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      voTabButton.applyAttr("height", this.tabbuttons.height);
    }             
    break;      
  case "tabbuttons.width" :
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      voTabButton.applyAttrRebuild("width", voBtnDf.width);
    }                   
    break;        
  case "tabbuttons.backgroundColor" :
    var voIterator = this.controls.iterator();
    var voTabButton = null;
    var vnIndex = -1;
    while(voIterator.hasNext()) {
      voTabButton = voIterator.next();
      vnIndex = voTab.getIndex(voTabButton.value);
      if(vnIndex != this.selectedIndex) {
        voTabButton.applyAttr("backgroundColor", this.tabbuttons.backgroundColor);
      }
    }    
    break;
  case "tabbuttons.focusBackgroundColor" :
    this.controls.get(this.selectedIndex).applyAttrRebuild("backgroundColor", voBtnDf.focusBackgroundColor);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * 실체화 컨트롤 비활성화.
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {String} psValue 컨트롤 disabled설정
 */
eXria.controls.xhtml.TabHeader.prototype.setDisable = function(poCtrl, psValue) {
  if(poCtrl.disabled != undefined)  poCtrl.disabled = psValue;
  
  if(poCtrl.childNodes) {
    var voChild = null;
    for(var i = 0; i < poCtrl.childNodes.length; i++) {
      voChild = poCtrl.childNodes[i];
      this.setDisable(voChild, psValue);
    }
  }  
};
/** 
 * 오버플로우 타입이 hidden인 탭 버튼을 감싸는 div 생성.
 * @return div 객체
 * @type HTMLDiv
 * @private
 */             
eXria.controls.xhtml.TabHeader.prototype.createOuterDiv = function() {
  var vaOuterDiv = [];
  vaOuterDiv.push("<div id='");
  vaOuterDiv.push(this.id);
  vaOuterDiv.push("_outerdiv' style='position:absolute; overflow:hidden; padding:0px; margin:0px; border-width:0px; left:0px; top:0px; ");
  vaOuterDiv.push("@cssStrbuf"); // 3
  vaOuterDiv.push("'>");
  vaOuterDiv.push("@innerDiv"); // 5
  vaOuterDiv.push("</div>");
  return vaOuterDiv;
};
/** 
 * 탭 이동 버튼을 감싸는 영역 생성.
 * @return 탭 이동 버튼을 감싸는 div
 * @type HTMLDiv
 * @private
 */ 
eXria.controls.xhtml.TabHeader.prototype.createScrollDiv = function() {
  var voDf = this.df;
  var vaScrollDiv = [];
  
  vaScrollDiv.push("<div id='");
  vaScrollDiv.push(this.id);
  vaScrollDiv.push("_scrolldiv' style='position:absolute; padding:0px; margin:0px; border-width:0px; top:0px; ");
  vaScrollDiv.push("@cssStrbuf"); // 0
  vaScrollDiv.push("'>");
  
  vaScrollDiv.push("<table cellpadding='0px' ");
  vaScrollDiv.push("@attStrbuf"); // 1
  vaScrollDiv.push("style='position:absolute; left:0px; top:0px; ");
  vaScrollDiv.push("width:");
  vaScrollDiv.push(this.scrollAreaWidth + "px; ");
  vaScrollDiv.push("height:");
  vaScrollDiv.push(this.innerHeight + "px;");
  vaScrollDiv.push("'>");
  vaScrollDiv.push("<tbody><tr>");
  
  vaScrollDiv.push("<td>");
  vaScrollDiv.push("<input id='");
  vaScrollDiv.push(this.id + "_scrollleft' type='button' ");
  if(this.tabSpinLeftImg) {
    vaScrollDiv.push("value='' disabled='true' ");
  } else {
    vaScrollDiv.push("value='◀' disabled='true' ");
  }
  vaScrollDiv.push("onclick=\"");
  vaScrollDiv.push(this.getEHandler(this.parent.id, "tabSpinLeft"));
  vaScrollDiv.push("\" style=\"");
  vaScrollDiv.push("@cssStrbuf"); // 2
  vaScrollDiv.push("\"/>");
  vaScrollDiv.push("</td>");
  
  vaScrollDiv.push("<td>");
  vaScrollDiv.push("<input id='");
  vaScrollDiv.push(this.id + "_scrollright' type='button' ");
  if(this.tabSpinRightImg) {
    vaScrollDiv.push("value='' disabled='true' ");
  } else {
    vaScrollDiv.push("value='▶' disabled='true' ");
  }
  vaScrollDiv.push("onclick=\"");
  vaScrollDiv.push(this.getEHandler(this.parent.id, "tabSpinRight"));
  vaScrollDiv.push("\" style=\"");
  vaScrollDiv.push("@cssStrbuf"); // 3
  vaScrollDiv.push("\"/>");
  vaScrollDiv.push("</td>");
  
  vaScrollDiv.push("</tr></tbody>");
  vaScrollDiv.push("</table>");
  
  return vaScrollDiv;
};
/** 
 * 탭 버튼을 감싸는 가로 길이가 한정되지 않은 영역 생성.
 * @return 탭 버튼을 감싸는 가로 길이가 한정되지 않은 div
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.createInnerDiv = function() {
  var vaInnerDiv = [];
  //var vsClass = this.getCSSClass(this.parent, 1, "TabHeader");
  var vsClass= "Default_Tab_TabHeader_Class";
  if(this.className) vsClass += " " + this.className
  vaInnerDiv.push("<div id='");
  vaInnerDiv.push(this.id + "_innerdiv' ");
  vaInnerDiv.push("class='" + vsClass + "' " + "style='position:absolute; padding:0px; margin:0px; border-width:0px; left:0px; top:0px; ");
  vaInnerDiv.push("@cssStrbuf"); // 3 - innerDiv 추가 스타일
  vaInnerDiv.push("'>");
  
  vaInnerDiv.push("<table cellPadding='0px' ");
  vaInnerDiv.push("@attStrbuf"); // 6 - innerDiv.table.cellSpacing
  vaInnerDiv.push("style='position:absolute; left:0px; top:0px; ");
  vaInnerDiv.push("@cssStrbuf"); // 8 - innerDiv.table.style
  vaInnerDiv.push("'>");
  
  vaInnerDiv.push("<tbody>");
  
  vaInnerDiv.push("<tr id=\"");
  vaInnerDiv.push(this.id + "_tab_tr");
  vaInnerDiv.push("\">");
  
  vaInnerDiv.push("</tr>");
  vaInnerDiv.push("</tbody>");
  vaInnerDiv.push("</table>");
  vaInnerDiv.push("</div>");
  
  return vaInnerDiv;
};
/** 
 * 한 탭 버튼의 가로길이 만큼 탭 버튼 영역을 좌측으로 이동시킴.
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.tabSpinLeft = function() {
  var voInnerDiv = this.lookup(this.id + "_innerdiv");
  this.scrollIndex++;
  voInnerDiv.style.left = ((this.tabbuttons.width + this.tabbuttons.cellSpacing) * this.scrollIndex) + "px";
  this.checkScroll();
};
/**
 * 탭 한 탭 버튼의 가로길이 만큼 탭 버튼 영역을 우측으로 이동시킴.
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.tabSpinRight = function() {
  var voInnerDiv = this.lookup(this.id + "_innerdiv");
  this.scrollIndex--;
  voInnerDiv.style.left = ((this.tabbuttons.width + this.tabbuttons.cellSpacing) * this.scrollIndex) + "px";
  this.checkScroll();
};
/**
 * 탭 해더에 탭 버튼을 추가
 * @param {eXria.controls.xhtml.TabButton} poTabButton 탭 버튼
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.addTabButton = function(poTabButton) {
  var voCtrl = this.getCtrl();
  var voBtnDf = this.tabbuttons;
  if(this.visible == false) {
    this.visible = true;
  }
  
  poTabButton.parent = this;
  this.addItem(poTabButton);

  if(this.parent.loaded) { 
    poTabButton.canvas = this.canvas;
    poTabButton.window = this.window;
    poTabButton.document = this.document;
    poTabButton.className = voBtnDf.className;
    poTabButton.outerClassName = voBtnDf.outerClassName;
    poTabButton.backgroundColor = voBtnDf.backgroundColor;
    poTabButton.backgroundImage = voBtnDf.backgroundImage;
    poTabButton.imageFocused = voBtnDf.imageFocused;
    poTabButton.backgroundPosition = voBtnDf.backgroundPosition;
    poTabButton.backgroundRepeat = voBtnDf.backgroundRepeat;
    poTabButton.color = voBtnDf.color;
    poTabButton.fontFamily = voBtnDf.fontFamily;
    poTabButton.fontSize = voBtnDf.fontSize; 
    poTabButton.fontWeight = voBtnDf.fontWeight; 
    poTabButton.fontStyle = voBtnDf.fontStyle;
    poTabButton.textDecoration = voBtnDf.textDecoration;    
    poTabButton.borderColor = voBtnDf.borderColor;
    poTabButton.borderStyle = voBtnDf.borderStyle;
    poTabButton.borderWidth = voBtnDf.borderWidth;
    poTabButton.borderLeftWidth = voBtnDf.borderLeftWidth;
    poTabButton.borderRightWidth = voBtnDf.borderRightWidth;
    poTabButton.borderTopWidth = voBtnDf.borderTopWidth;
    poTabButton.borderBottomWidth = voBtnDf.borderBottomWidth;
    poTabButton.padding = voBtnDf.padding;
    poTabButton.paddingLeft = voBtnDf.paddingLeft;
    poTabButton.paddingRight = voBtnDf.paddingRight;
    poTabButton.paddingTop = voBtnDf.paddingTop;
    poTabButton.paddingBottom = voBtnDf.paddingBottom;
  poTabButton.position = "relative";
  // yhkim tabbuttons의 속성을 button 에 전달
  poTabButton.cursor = voBtnDf.cursor;
    if(poTabButton.visible != false) {
      var voTd =  this.document.createElement("td");
      voTd.appendChild(poTabButton.create());
      
      this.checkScroll();
    
      var voTr = this.lookup(this.id+"_tab_tr");
      voTr.appendChild(voTd);
      poTabButton.load();
    }
  }
};
/**
 * 지정된 인덱스의 탭을 선택
 * @param {Number} pnIndex 탭인덱스
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.select = function(pnIndex) {
  var voTab = this.parent;
  var voEvent = new eXria.event.Event(null);
  voEvent.object = voTab;
  var vbChangePage = true;
  if(voTab.onPreChange && voTab.loaded) vbChangePage = voTab.onPreChange(voEvent);
  if(vbChangePage == false) {
    var voBtn = this.controls.get(pnIndex);
    if(voBtn) voBtn.atblur();
    return;
  }
  
  var voCtrl = this.getCtrl(this.document);
  var voBtnDf = this.tabbuttons;
  if(voCtrl == null) {
  voTab.selectedIndex = pnIndex;
    return;
  }
  var voSelectedTab = null;
  var voTabCtrl = null;
  var voPage = null;
  
  if(voTab.selectedIndex != -1) {
    voSelectedTab = this.controls.get(voTab.selectedIndex);
    if(voSelectedTab.visible != false) {
      voTabCtrl = voSelectedTab.getSubCtrl("button");
      if(voSelectedTab != null) {
        if(voBtnDf.backgroundColor) voSelectedTab.setAttrCtrl("backgroundColor", voBtnDf.backgroundColor, voTabCtrl);
        else voSelectedTab.setAttrCtrl("backgroundColor", "", voTabCtrl);
        if(voBtnDf.color) voSelectedTab.setAttrCtrl("color", voBtnDf.color, voTabCtrl);
        else voSelectedTab.setAttrCtrl("color", "", voTabCtrl);
        if(voBtnDf.backgroundImage) voSelectedTab.setAttrCtrl("backgroundImage", voBtnDf.backgroundImage, voTabCtrl);
        else voSelectedTab.setAttrCtrl("backgroundImage", "", voTabCtrl);
        if(voBtnDf.backgroundImageFocused) voSelectedTab.setAttrCtrl("backgroundImage", "", voSelectedTab.ctrl);
      }
      voPage = voTab.tabPageSet.get(voTab.selectedIndex);

      if(voTab.canvas.page.metadata.browser.ie) {
        var voChild = null;
        var voIterator = voPage.controls.iterator();
        while(voIterator.hasNext()) {
          voChild = voIterator.next();
          if(voChild.toString() == "GridEx") {
            voChild.scrollLeft = 0;
            voChild.scrollTop = 0;
            try { voChild.scrollLeft = voChild.grid.GetScrollLeft(); } catch(err) {}
            try { voChild.scrollTop = voChild.grid.GetScrollTop(); } catch(err) {}
          }
        }
      }
      
      if(voPage) voPage.applyAttr("visible", false);
    }
  }

  voSelectedTab = this.controls.get(pnIndex);
  
  if(voSelectedTab.visible == false) {
  //tabHeader visible false 일경우 tabPage도 false 처리되게 수정
  //2010.04.08
  voTab.tabPageSet.get(pnIndex).applyAttr("visible", false);
  return;
  }
  
  voTabCtrl = voSelectedTab.getSubCtrl("button");
  if(voSelectedTab) {
    if(voBtnDf.focusBackgroundColor) voSelectedTab.setAttrCtrl("backgroundColor", voBtnDf.focusBackgroundColor, voTabCtrl);
    else voSelectedTab.setAttrCtrl("backgroundColor", "", voTabCtrl);
    if(voBtnDf.focusColor) voSelectedTab.setAttrCtrl("color", voBtnDf.focusColor, voTabCtrl);
    else voSelectedTab.setAttrCtrl("color", "", voTabCtrl);
    if(voBtnDf.imageFocused) {
      var voIterator = this.controls.iterator();
      while(voIterator.hasNext()) {
        voTabButton = voIterator.next();
        voTabButton.focused = false;
      }
      voSelectedTab.setAttrCtrl("backgroundImage", voBtnDf.imageFocused, voTabCtrl);
    }
    else voSelectedTab.setAttrCtrl("backgroundImage", "", voTabCtrl);
    if(voBtnDf.backgroundImageFocused) voSelectedTab.setAttrCtrl("backgroundImage", voBtnDf.backgroundImageFocused, voSelectedTab.ctrl);
    voSelectedTab.oldImage = voBtnDf.imageFocused;
  }
  var voPage = voTab.tabPageSet.get(pnIndex);  
  if(voPage) {
    voPage.applyAttr("visible", true);
    if(voPage.rendered == false) {
      voPage.createChildren();
      voPage.rendered = true;
    } else {

      if(voTab.canvas.page.metadata.browser.ie) {
        var voChild = null;
        var voFunc = null;
        var voIterator = voPage.controls.iterator();
        while(voIterator.hasNext()) {
          voChild = voIterator.next();
          if(voChild.toString() == "GridEx") {
            voFunc = function() {
              if(voChild.scrollLeft) voChild.grid.SetScrollLeft(voChild.scrollLeft);
              if(voChild.scrollTop) voChild.grid.SetScrollTop(voChild.scrollTop);
              voChild.scrollLeft = null;
              voChild.scrollTop = null;
            };
            setTimeout(voFunc, 100);
          }
        }
      }
      
    }
  }

  voTab.selectedIndex = pnIndex;
  if(voTab.onPostChange && voTab.loaded) voTab.onPostChange(voEvent);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TabHeader.prototype.isScroll = function() {
  var vbScroll = false;
  var vnLen = this.innerWidth;
  var vnChilds = this.getVisibleCount();
  var voBtnDf = this.tabbuttons;
  if(vnLen < (voBtnDf.width + voBtnDf.cellSpacing) * vnChilds) {
    vbScroll = true;
    vnLen = this.innerWidth - this.scrollAreaWidth;
  }
  return vbScroll;
}
/**
 * 탭 이동 버튼 활성화 상태 지정 메소드.
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.checkScroll = function() {
  var voDf = this.df;
  var vbScroll = false;
  var voOuterDiv = this.lookup(this.id + "_outerdiv");
  var voScrollDiv = this.lookup(this.id + "_scrolldiv");
  var vnLen = this.innerWidth;
  var vnChilds = this.getVisibleCount();
  var voBtnDf = this.tabbuttons;
  if(vnLen < (voBtnDf.width + voBtnDf.cellSpacing) * vnChilds) {
    vbScroll = true;
    vnLen = this.innerWidth - this.scrollAreaWidth;
  }
  voOuterDiv.style.width = vnLen + "px";
  if(vbScroll) {
    voScrollDiv.style.display = "block";
  } else {
    voScrollDiv.style.display = "none";
    return;
  }
  
  var voScrollLeft = this.lookup(this.id + "_scrollleft");
  var voScrollRight = this.lookup(this.id + "_scrollright");
  
  voScrollLeft.disabled = true;
  voScrollRight.disabled = true;
  
  if(this.scrollIndex < 0) {
    voScrollLeft.disabled = false;
    if(this.tabSpinLeftImg) {
      voScrollLeft.value = "";
      voScrollLeft.style.backgroundImage = this.tabSpinLeftImg;
    } else {
      voScrollLeft.value = "◀";
      voScrollLeft.style.backgroundImage = "";
    }
  } else {
    if(this.tabSpinLeftDisabledImg) {
      voScrollLeft.value = "";
      voScrollLeft.style.backgroundImage = this.tabSpinLeftDisabledImg;
    } else {
      voScrollLeft.value = "◀";
      voScrollLeft.style.backgroundImage = ""
    }
  }

  var vnLeft = this.scrollIndex * (voBtnDf.width + voBtnDf.cellSpacing);
  if(vnLeft + (voBtnDf.width + voBtnDf.cellSpacing) * vnChilds > vnLen) {
    voScrollRight.disabled = false;
    if(this.tabSpinRightImg) {
      voScrollRight.value = "";
      voScrollRight.style.backgroundImage = this.tabSpinRightImg;
    } else {
      voScrollRight.value = "▶";
      voScrollRight.style.backgroundImage = "";
    }
  } else {
    if(this.tabSpinRightDisabledImg) {
      voScrollRight.value = "";
      voScrollRight.style.backgroundImage = this.tabSpinRightDisabledImg;
    } else {
      voScrollRight.value = "▶";
      voScrollRight.style.backgroundImage = ""
    }
  }
  
  var voCtrl = this.lookup(this.id);
  var voStyle = null;
  if(this.controls.size() == 0) {
    this.applyAttr("visible", false);
  }
};
/**
 * 활성화 된 탭 버튼 개수를 반환.
 * @return 활성화 된 탭 버튼 갯수
 * @type Number
 * @private
 */
eXria.controls.xhtml.TabHeader.prototype.getVisibleCount = function() {
  var vnCnt = 0;
  var voControls = this.controls;
  var vnSize = voControls.size();
  var voTabButton = null;
  for(var i = 0; i < vnSize; i++) {
    voTabButton = voControls.get(i);
    if(voTabButton.visible != false) {
      vnCnt++;
    }
  }
  return vnCnt;
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type String|Number
 * @ignore
 */
eXria.controls.xhtml.TabHeader.prototype.getSpecificDefaultValue = function(psAttrName){
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.Tab.TabHeader[psAttrName] == null ? vsDefaultValue : eXria.controls.xhtml.Default.Tab.TabHeader[psAttrName];      
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.Tab.TabHeader[vaAttrName[0]][vaAttrName[1]] == null ? vsDefaultValue : eXria.controls.xhtml.Default.Tab.TabHeader[vaAttrName[0]][vaAttrName[1]];    
  }
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환.
 * @return "TabHeader"
 * @type String
 */
eXria.controls.xhtml.TabHeader.prototype.toString = function() {
  return "Tab_TabHeader";
};


/**
 * 탭 바디의 공통속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.Tab_tabpages = function() {
  /**
   * 탭 바디의 보더 색상.
   * @type String
   */
  this.borderColor = null;  
  /**
   * 탭 바디의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;  
  /**
   * 탭 바디의 보더 두께.
   * @type Number
   */ 
  this.borderWidth = null;  
  /**
   * 탭 바디의 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;  
  /**
   * 탭 바디의 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;  
  /**
   * 탭 바디의 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;  
  /**
   * 탭 바디의 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 탭 바디에 담긴 컨트롤이 영역을 벗어날때 스크롤 처리.
   * @type String
   */  
  this.overflow = null;  
  /**
   * 탭 바디에 담긴 컨트롤이 영역을 벗어날때 횡 스크롤 처리.
   * @type String
   */  
  this.overflowX = null;  
  /**
   * 탭 바디에 담긴 컨트롤이 영역을 벗어날때 종 스크롤 처리.
   * @type String
   */  
  this.overflowY = null; 
  /**
   * 탭 바디의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;  
  /**
   * 탭 바디의 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;  
  /**
   * 탭 바디의 외곽 div에 적용될 css 클래스 명.
   * @type String
   */
  this.outerClassName = null;
  /**
   * 탭 바디의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};  
};
/**
 * @class Concreate xhtml TabPage.<br>
 * 탭의 컨텐츠 패널 영역 담당 클래스.
 * @author 조영진
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.TabPage 객체
 * @type eXria.controls.xhtml.TabPage
 * @constructor
 * @base eXria.controls.xhtml.Group
 */
eXria.controls.xhtml.TabPage = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  eXria.controls.xhtml.Group.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * 상위 Tab컨트롤 참조변수
   * @type eXria.controls.xhtml.Tab
   */
  this.parent = null;
  /**
   * TabPage의 sub Id참조
   * @type String
   */
  this.subId = null;
  /**
   * TabPage가 렌더링 되었는지 여부
   * @type Boolean
   * @private
   */
  this.rendered = false;
  
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Group, eXria.controls.xhtml.TabPage);
/**
 * @ignore
 */
eXria.controls.xhtml.TabPage.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  
  if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if (poControl[vsOnEvent]) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @ignore
 */
eXria.controls.xhtml.TabPage.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  if(eXria.controls.xhtml.Default.Tab.tabpages) vsDefaultValue = eXria.controls.xhtml.Default.Tab.tabpages[psAttrName];
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환.
 * @return "TabPage"
 * @type String
 */
eXria.controls.xhtml.TabPage.prototype.toString = function() {
  return "Tab_TabPages";
};


/**
 * @class Concreate xhtml Tab.<br>
 * XHTML Tab 컨트롤.
 * @author 조영진
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Tab 객체
 * @type eXria.controls.xhtml.Tab
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Tab = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight = pnHeight == null ? 300 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * @private
   */
  this.position = "absolute";
  /**
   * 선택된 탭 페이지의 인덱스 번호.
   * @type Number
    */
  this.selectedIndex = 0;
  /**
   * 선택된 탭 페이지의 ID.
   * @type String
   * @ignore
   */
  this.selectedPageId = null;  
  /**
   * 탭 헤더 영역의 가로 길이.
   * @type Number
   */
  this.headerHeight = null;
  /**
   * 탭 헤더 객체.<br>
   * 탭 버튼을 관리하는 오브젝트.
   * readOnly
   * @type eXria.controls.xhtml.TabHeader
   */
  this.tabHeader = new eXria.controls.xhtml.TabHeader(this.id + "_tabheader", 0, 0, this.width, this.headerHeight);;
  this.tabHeader.parent = this;
  /**
   * 탭 바디(탭의 컨텐츠 패널 영역)을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   */
  this.tabPageSet = new eXria.data.ArrayCollection();
  /**
   * 탭 아이디 생성에 이용되는 순차적인 번호.
   * @type Number
   * @private
   */
  this.tabSeqNum = 0;  
  /**
   * @type Number
   * @ignore
   */
  this.tabPageZindex = null;
  /**
   * 탭 헤더의 위치 지정.
   * "top" | "bottom"
   * @type String
   */
  this.headerPos = null;
  /**
   * 탭 바디의 공통속성을 저장하기 위한 오브젝트.
   * @type Object
   */
  this.tabpages = new eXria.controls.xhtml.Tab_tabpages();
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 초기에 모든 페이지를 렌더링할지 여부.
   * @type Boolean
   */
  this.renderAll = null;
  /**
   * data연동을 통해 생성된 탭 페이지 아이디 저장.
   * @type eXria.data.ArrayMap
   * @private
   */
  this.pageIdsInData = new eXria.data.ArrayMap();
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트.
   * @type Object
   * @private
   */
  this.df = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Tab);
//////////////////////////////////////////////////////////////////
// 메소드   
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;
//if(vsType == "change")debugger  
  switch(vsType) {
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {      
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }
  
  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
  
  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
eXria.controls.xhtml.Tab.prototype.setSubCtrlStyles = function(poCtrl) {
  //var voTabPage = null;
  //var voIterator = this.tabPageSet.iterator();
  //while(voIterator.hasNext()) {
  //  voTabPage = voIterator.next();
  //  voTabPage.className = this.tabpages.className;
  //  voTabPage.outerClassName = this.tabpages.outerClassName;
  //}
};
eXria.controls.xhtml.Tab.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voUserAttr = null;
  this.type = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
  }
  if(voUserAttr) {
    this.type = voUserAttr.type;
    this.maxTabCount = voUserAttr.maxTabCount;
    if(!this.maxTabCount)
      this.maxTabCount = 5;
      
    this.impPosGap = voUserAttr.impPosGap;
    if(null === this.impPosGap || undefined === this.impPosGap)
      this.impPosGap = 5;

    this.impBorderWidth = voUserAttr.impBorderWidth;
    if(null === this.impBorderWidth 
       || undefined === this.impBorderWidth
       || ''=== this.impBorderWidth)
      this.impBorderWidth = 1;
    
    if('minimizedWindow' === this.type)
      this.headerPos = "bottom";
    if(voUserAttr.tabbuttons) {
      if(voUserAttr.tabbuttons.backgroundImageFocused) this.tabHeader.tabbuttons.backgroundImageFocused = voUserAttr.tabbuttons.backgroundImageFocused;
    }
  }
  
  
  var voDf = this.df;
  var voPageDf = this.tabpages;

  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
  this.headerHeight = this.getAttrValue("headerHeight",this.headerHeight);
  this.tabPageZindex = this.getAttrValue("tabPageZindex",this.tabPageZindex);
  this.headerPos = this.getAttrValue("headerPos",this.headerPos);
};
eXria.controls.xhtml.Tab.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voPageDf = this.tabpages;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
//  if(this.disabled) poCtrl["disabled"] = true;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  this.tabHeader.width = this.innerWidth;
  this.tabHeader.height = this.headerHeight;
  this.tabHeader.canvas = this.canvas;
  this.tabHeader.window = this.window;
  this.tabHeader.document = this.document;
  var vnTop = 0;
  if(this.headerPos == "bottom") {
    vnTop = this.innerHeight - this.headerHeight;
  }
  this.tabHeader.top = vnTop;
  this.tabHeader.parent = this;
  this.tabHeader.clearCtrl();
  poCtrl.appendChild(this.tabHeader.create());
  var voTabPage = null; 
  for(var i = 0; i < this.tabPageSet.size(); i++) {
    voTabPage = this.tabPageSet.get(i);
    voTabPage.canvas = this.canvas;
    voTabPage.window = this.window;
    voTabPage.document = this.document;
    voTabPage.className = this.tabpages.className;
    voTabPage.outerClassName = this.tabpages.outerClassName;
    if(this.headerPos == "bottom") {
      voTabPage.top = 0;
    }
    voTabPage.width = this.innerWidth;
    voTabPage.height = this.innerHeight - this.headerHeight;
    voTabPage.backgroundColor = voPageDf.backgroundColor;
    voTabPage.borderStyle = voPageDf.borderStyle;
    voTabPage.borderColor = voPageDf.borderColor;
    voTabPage.borderWidth = voPageDf.borderWidth;
    voTabPage.borderLeftWidth = voPageDf.borderLeftWidth;
    voTabPage.borderRightWidth = voPageDf.borderRightWidth;
    voTabPage.borderTopWidth = voPageDf.borderTopWidth;
    voTabPage.borderBottomWidth = voPageDf.borderBottomWidth;
    voTabPage.overflow = voPageDf.overflow;
    voTabPage.overflowX = voPageDf.overflowX;
    voTabPage.overflowY = voPageDf.overflowY;
    voTabPage.visible = false;
    voTabPage.clearCtrl();
    poCtrl.appendChild(voTabPage.create(poDocument));
  }
  
  if(this.disabled) this.setDisable(poCtrl, this.disabled);
  
  vaCssStrBuf = null;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.tabpages.df = {};
  this.df = {};
  
  var vnSelectedIndex = this.selectedIndex;
  this.selectedIndex = -1;
  var voPageIdsInData = this.pageIdsInData;
  var vnSize = voPageIdsInData.size();
  var voPageIds = voPageIdsInData.getKeyCollection();
  var vsPageId = null;
  var vnIndex = null;
  for(var i = 0; i < vnSize; i++) {
    vsPageId = voPageIds.get(i);
    if(vnIndex) this.removeTab(vnIndex);
  }
  voPageIdsInData.clear();
  this.selectedIndex = vnSelectedIndex;
};
/**
 * @ignore
 */
//eXria.controls.xhtml.Tab.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
//  var voDf = this.df;
//  var voPageDf = this.tabpages.df;
//  this.setAttrCtrl("top", this.top, poCtrl);
//  this.setAttrCtrl("left", this.left, poCtrl);
//  this.setAttrCtrl("width", this.innerWidth, poCtrl);
//  this.setAttrCtrl("height", this.innerHeight, poCtrl);
//  this.setAttrCtrl("borderColor", this.borderColor, poCtrl);
//  this.setAttrCtrl("borderStyle", this.borderStyle, poCtrl);
//  this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", poCtrl);
//  this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", poCtrl);
//  this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", poCtrl);
//  this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", poCtrl);
//  
//  this.tabHeader.width = this.innerWidth;    
//  if(this.headerPos == "top") {
//    this.tabHeader.top = 0;
//  } else {
//    this.tabHeader.top = this.height - this.headerHeight;
//  } 
//  this.tabHeader.refresh();
//  
//  var voTabPage = null;
//  var voIterator = this.tabPageSet.iterator();
//  while(voIterator.hasNext()) {
//    voTabPage = voIterator.next();
//    if(this.headerPos == "top") {
//      voTabPage.top = this.headerHeight;
//    } else {
//      voTabPage.top = 0;
//    }
//    voTabPage.width = this.innerWidth;
//    voTabPage.height = this.innerHeight - this.headerHeight;
//    voTabPage.backgroundColor = this.backgroundColor;
//    voTabPage.borderStyle = voPageDf.borderStyle;
//    voTabPage.borderColor = voPageDf.borderColor;
//    voTabPage.borderWidth = voPageDf.borderWidth;
//    voTabPage.borderLeftWidth = voPageDf.borderLeftWidth;
//    voTabPage.borderRightWidth = voPageDf.borderRightWidth;
//    voTabPage.borderTopWidth = voPageDf.borderTopWidth;
//    voTabPage.borderBottomWidth = voPageDf.borderBottomWidth;
//    voTabPage.overflow = voPageDf.overflow;
//    voTabPage.overflowX = voPageDf.overflowX;
//    voTabPage.overflowY = voPageDf.overflowY;
//    voTabPage.refresh();
//  }     
//  
//  if(this.disabled) this.setDisable(this.disabled);
//  
//  var voCover = this.lookup(this.id + "_cover");
//  if(voCover != null) {
//    if(this.visible == false) {
//      this.setAttrCtrl("display", "none", voCover);
//    } else {
//      this.setAttrCtrl("display", "", voCover);
//    }
//  }
//  
//  this.loadComplete(poDocument); 
//};
eXria.controls.xhtml.Tab.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voPageDf = this.tabpages;
  
  this.setAttrCtrl("top", this.top, poCtrl);
  this.setAttrCtrl("left", this.left, poCtrl);
  this.setAttrCtrl("width", this.innerWidth, poCtrl);
  this.setAttrCtrl("height", this.innerHeight, poCtrl);
  this.setAttrCtrl("borderColor", this.borderColor, poCtrl);
  this.setAttrCtrl("borderStyle", this.borderStyle, poCtrl);
  this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", poCtrl);
  this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", poCtrl);
  this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", poCtrl);
  this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", poCtrl);
  this.setAttrCtrl("cursor", this.cursor, poCtrl);
  
  this.tabHeader.width = this.innerWidth;
  if(this.headerPos == "top") {
    this.tabHeader.top = 0;
  } else {
    this.tabHeader.top = this.height - this.headerHeight;
  } 
  this.tabHeader.refresh();
  
  var voTabPage = null;
  var voIterator = this.tabPageSet.iterator();
  while(voIterator.hasNext()) {
    voTabPage = voIterator.next();
    if(voTabPage.rendered == false) continue;
    if(this.headerPos == "top") {
      voTabPage.top = this.headerHeight;
    } else {
      voTabPage.top = 0;
    }
    voTabPage.width = this.innerWidth;
    voTabPage.height = this.innerHeight - this.headerHeight;
    voTabPage.backgroundColor = voPageDf.backgroundColor;
    voTabPage.borderStyle = voPageDf.borderStyle;
    voTabPage.borderColor = voPageDf.borderColor;
    voTabPage.borderWidth = voPageDf.borderWidth;
    voTabPage.borderLeftWidth = voPageDf.borderLeftWidth;
    voTabPage.borderRightWidth = voPageDf.borderRightWidth;
    voTabPage.borderTopWidth = voPageDf.borderTopWidth;
    voTabPage.borderBottomWidth = voPageDf.borderBottomWidth;
    voTabPage.overflow = voPageDf.overflow;
    voTabPage.overflowX = voPageDf.overflowX;
    voTabPage.overflowY = voPageDf.overflowY;
    voTabPage.refresh();
  }     
  
  if(this.disabled) this.setDisable(this.ctrl, this.disabled);
  
  var voCover = this.lookup(this.id + "_cover");
  if(voCover != null) {
    if(this.visible == false) {
      this.setAttrCtrl("display", "none", voCover);
    } else {
      this.setAttrCtrl("display", "", voCover);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
    
  switch(psAttrName) {
  case "width" : 
    break;
  case "height" : 
    break;
  case "borderWidth" :
    break;
  }
};  
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voDf = this.df;
  var voCtrl = this.getCtrl();
  var vaAttrName = null;
  var vsSubAttrName = null;
  this.setAttr(psAttrName, psAttrValue);
  
  //this.tabHeader.applyAttrRebuild(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "backgroundColor" :
//    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    this.tabpages[psAttrName] = psAttrValue;
    
    var voTabPage = null;
    var voIterator = this.tabPageSet.iterator();
    while(voIterator.hasNext()) {
      voTabPage = voIterator.next();        
      voTabPage.applyAttrRebuild(psAttrName, psAttrValue);
    }      
    break;    
  case "headerPos" :
    if(this.headerPos == "top") {
      this.tabHeader.top = 0;
    } else {
      this.tabHeader.top = this.height - this.headerHeight;
    }    
    this.tabHeader.refresh();
    
    var voTabPage = null;
    var voIterator = this.tabPageSet.iterator();
    while(voIterator.hasNext()) {
      voTabPage = voIterator.next();
      if(this.headerPos == "top") {
        voTabPage.top = this.headerHeight;
      } else {
        voTabPage.top = 0;
      }
      voTabPage.refresh();
    }    
    break;
  case "tabpages.backgroundColor" :
  case "tabpages.borderStyle" :
  case "tabpages.borderColor" :
  case "tabpages.borderWidth" :
  case "tabpages.borderLeftWidth" :
  case "tabpages.borderRightWidth" :
  case "tabpages.borderTopWidth" :
  case "tabpages.borderBottomWidth" :
  case "tabpages.className" :
  case "tabpages.outerClassName" :
    vaAttrName = psAttrName.split(".");
    vsSubAttrName = vaAttrName[vaAttrName.length - 1];
    var voTabPage = null;
    var voIterator = this.tabPageSet.iterator();
    while(voIterator.hasNext()) {
      voTabPage = voIterator.next();
      voTabPage.applyAttrRebuild(psAttrName.replace(/tabpages./gi,""), psAttrValue, poDocument);
    }
    break;
  case "tabpages.overflow" :
  case "tabpages.overflowX" :
  case "tabpages.overflowY" :
    var voDf = voObj;
    //var voCssStyle = this.canvas.getCssStyle(this.className, this.document);
    if(this.overflow == null) this.overflow = "hidden";
    var vsOverflowX = this.makeSpecificAttrValue(voCtrl, voCssStyle, "tabpages.overflowX");
    var vsOverflowY = this.makeSpecificAttrValue(voCtrl, voCssStyle, "tabpages.overflowY");
    if(voObj.overflowX == null) this.overflowX = vsOverflowX ? vsOverflowX : this.overflow;
    if(voObj.overflowY == null) this.overflowY = vsOverflowY ? vsOverflowY : this.overflow;
    
    vaAttrName = psAttrName.split(".");   
    vsSubAttrName = vaAttrName[vaAttrName.length - 1];
    var voTabPage = null;
    var voIterator = this.tabPageSet.iterator();
    while(voIterator.hasNext()) {
      voTabPage = voIterator.next();
      voTabPage.overflowX = this.overflowX;
      voTabPage.overflowY = this.overflowY;
      var voStyle = voTabPage.ctrl.style;
      voStyle.overflowX = this.overflowX;
      voStyle.overflowY = this.overflowY;
  //      voContentPane.applyAttrRebuild(vsSubAttrName, psAttrValue, poDocument);        
    }
    break;
  case "tabHeader.tabbuttons.textAlign" :
  case "tabHeader.tabbuttons.backgroundImage" :
  case "tabHeader.tabbuttons.backgroundPosition" :
  case "tabHeader.tabbuttons.backgroundRepeat" :
  case "tabHeader.tabbuttons.focusImage" :
  case "tabHeader.tabbuttons.borderColor" :
  case "tabHeader.tabbuttons.borderStyle" :
  case "tabHeader.tabbuttons.borderWidth" :
  case "tabHeader.tabbuttons.borderBottomWidth" :
  case "tabHeader.tabbuttons.borderLeftWidth" :
  case "tabHeader.tabbuttons.borderRightWidth" :
  case "tabHeader.tabbuttons.borderTopWidth" :
  case "tabHeader.tabbuttons.backgroundColor" :
  case "tabHeader.tabbuttons.color" :
  case "tabHeader.tabbuttons.focusBackgroundColor" :
  case "tabHeader.tabbuttons.focusColor" :
  case "tabHeader.tabbuttons.textDecoration" :
  case "tabHeader.tabbuttons.fontFamily" :
  case "tabHeader.tabbuttons.fontSize" :
  case "tabHeader.tabbuttons.fontStyle" :
  case "tabHeader.tabbuttons.fontWeight" :
  case "tabHeader.tabbuttons.padding" :
  case "tabHeader.tabbuttons.paddingBottom" :
  case "tabHeader.tabbuttons.paddingLeft" :
  case "tabHeader.tabbuttons.paddingRight" :
  case "tabHeader.tabbuttons.paddingTop" :
  case "tabHeader.tabbuttons.cellSpacing" :
  case "tabHeader.tabbuttons.width" :
  case "tabHeader.tabbuttons.className" :
  case "tabHeader.tabbuttons.outerClassName" :
  // yhkim tabbuttons의 속성을 button 에 전달
  case "tabHeader.tabbuttons.cursor" :
  case "tabHeader.borderColor" :
  case "tabHeader.borderStyle" :
  case "tabHeader.borderWidth" :
  case "tabHeader.borderBottomWidth" :
  case "tabHeader.borderLeftWidth" :
  case "tabHeader.borderRightWidth" :
  case "tabHeader.borderTopWidth" :
  case "tabHeader.backgroundColor" :
  case "tabHeader.tabSpinLeftDisabledImg" :
  case "tabHeader.tabSpinLeftImg" :
  case "tabHeader.tabSpinRightDisabledImg" :
  case "tabHeader.tabSpinRightImg" :
    this.tabHeader.applyAttrRebuild(psAttrName.replace(/tabHeader./gi,""), psAttrValue, poDocument);
    
  break;
  default :
    this.refresh(poDocument);
    break;
  }

};
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.loadData = function(poDocument) {
  if(this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null) return;
  
  var voCollectionNode = this.data.getNodesetData2();
  if(voCollectionNode == null) return;
  var vnLoop = voCollectionNode.getLength();
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vsParentNode = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  var vaNodes = [];
  var voTreeNode = null;
  var voPage = null;
  for(var i = 0; i < vnLoop; i++) {
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
    vsLabelNode = voMapNode.get(this.labelTagName);
    vsBidNode = voMapNode.get(this.bidTagName);
    vsPidNode = voMapNode.get(this.pidTagName);
    
    voPage = this.addTab(vsLabelNode, vsBidNode, vsPidNode);
    voPageIdsInData.put(voPage.id, "");
  }
};
eXria.controls.xhtml.Tab.prototype.reloadData = function(poCtrl, poDocument) {
  if(this.renderAll) {
    var voIterator = this.tabPageSet.iterator();
    var voPage = null;
    var voSelectedPage = this.getPage(this.selectedIndex);
    while(voIterator.hasNext()) {
      voPage = voIterator.next();
      if(voPage != voSelectedPage) voPage.applyAttr("visible", true);
      voPage.reloadData(voPage.ctrl, voPage.document);
      if(voPage != voSelectedPage) voPage.applyAttr("visible", false);
    }
  }  
};
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.loadComplete = function(poDocument) {
  this.tabHeader.loadComplete(poDocument);
  this.tabHeader.checkScroll();
  if(this.renderAll) {
    var voIterator = this.tabPageSet.iterator();
    var voPage = null;
    var vnIE = this.canvas.page.metadata.browser.id;
    while(voIterator.hasNext()) {
      voPage = voIterator.next();
      if(vnIE < 8.0) voPage.setAttrCtrl("visibility", "hidden");
      voPage.applyAttr("visible", true);
      if(voPage.rendered){
        //voPage.refresh();
      } else {
        voPage.createChildren();
        voPage.rendered = true;
      }
      if(vnIE < 8.0) voPage.setAttrCtrl("visibility", "visible");
      voPage.applyAttr("visible", false);
    }
  }
  this.loaded = true;
  
  if(this.tabPageSet.iterator().hasNext())
    this.selectTab(this.selectedIndex);
  
};

eXria.controls.xhtml.Tab.prototype.refreshComplete = function(poCtrl, poDocument) {
  this.tabHeader.checkScroll();
  if(this.renderAll) {
    var voIterator = this.tabPageSet.iterator();
    var voPage = null;
    var vnIE = page.metadata.browser.id;
    
    while(voIterator.hasNext()) {
      voPage = voIterator.next();
      if(vnIE < 8.0) voPage.setAttrCtrl("visibility", "hidden");
      voPage.applyAttr("visible", true);
      voPage.refreshComplete(voPage.ctrl, poDocument);
      if(vnIE < 8.0) voPage.setAttrCtrl("visibility", "visible");
      voPage.applyAttr("visible", false);
    }
  }

  if(0 === this.tabPageSet.cnt) return;
  
  this.selectTab(this.selectedIndex);
};

/**
 * 내부의 포함된 컨트롤을 순환적으로 참조하기 위해 사용되는 메소드
 * @return tabPageSet
 * @type eXria.data.ArrayCollection
 * @ignore 
 */
eXria.controls.xhtml.Tab.prototype.getControls = function() {
  return this.tabPageSet;
};

/**
 * type 이 minimizedWindow 인 경우 사용될 탭 추가 메소드
 * 탭 버튼 및 그에 따른 탭 바디 추가 메소드.
 * @param {String} psTabName 탭 버튼 라벨
 * @param {String} psButtonId 탭 버튼 아이디
 * @param {String} psPageId 탭 페이지 아이디
 * @param {Boolean} pbVisible Visible 여부
 * @param {String} psSrc 불러오는 화면에 대한 URL 및 파일 경로.
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 추가된 탭의 인덱스
 * @type Number
 */
eXria.controls.xhtml.Tab.prototype.addMinimizedWindowTab = function(psTabName, psButtonId, psPageId, pbVisible, psSrc, pnLeft, pnTop, pnWidth, pnHeight) {
  if(!this.type || this.type !== 'minimizedWindow') {
    var voErrMsg;
    voErrMsg.name = "eXria.controls.xhtml.Tab.prototype.addMinimizedWindowTab";
    voErrMsg.message = "type 이  minimizedWindow 인 경우에만 사용이 가능 합니다.";
    throw voErrMsg;
  }
  
  var voIterator = this.tabPageSet.iterator();
  while(voIterator.hasNext()){       
   var voTabPage = voIterator.next();
   var voCtlIterator = voTabPage.controls.iterator();
   while(voCtlIterator.hasNext()){
     var vcSbp = voCtlIterator.next()
     if(vcSbp.src === psSrc) {     
      var vnTabIndex = this.getIndexBySubId(voTabPage.subId);        
      this.selectTab(vnTabIndex);          
      return vnTabIndex; 
     }
   }
  }    

    
  var vnMaxTabCount = this.maxTabCount;
  var vnSize = this.tabPageSet.size();
  
  if(vnSize >= vnMaxTabCount){
   this.selectTab(0);
   this.removeMinimizedWindowTab(0);    
  }  
  
  var vnPosGap = this.impPosGap;
  var vnBorderWidth = this.impBorderWidth;
  var vnIdx = this.addTab(psTabName, psButtonId, psPageId, pbVisible, pnLeft, pnTop, pnWidth, pnHeight);
  
  if(!!psSrc){    
    var voPage = this.getPage(vnIdx);
    var vnWidth = this.innerWidth;
    var vnHeight = this.innerHeight- this.tabHeader.innerHeight; 
    var voSbp = new eXria.controls.xhtml.SubPage("sbpMinimizedWindowTab"+this.tabSeqNum, vnPosGap, vnPosGap, vnWidth, vnHeight);
    voSbp.src = psSrc;
    voSbp.borderWidth = vnBorderWidth;
    voSbp.zIndex = 0;
    voPage.addChild(voSbp);
  }
  
  this.selectTab(vnIdx);
  
  return this.tabPageSet.size() - 1;
};
/**
 * type 이 minimizedWindow 인 경우 현재 활성화된 Tab 하위의 SubPage url을 지정된 url로 변경해주는 메소드.
 * @param {String} psSrc 변경 URL
 * @param {String} psLabel 변경 탭 버튼 라벨(생략가능).
 */
eXria.controls.xhtml.Tab.prototype.setCurrentMinimizedWindowSrc = function(psSrc, psLabel) {
  if(!this.type || this.type !== 'minimizedWindow') {
    var voErrMsg;
    voErrMsg.name = "eXria.controls.xhtml.Tab.prototype.addMinimizedWindowTab";
    voErrMsg.message = "type 이  minimizedWindow 인 경우에만 사용이 가능 합니다.";
    throw voErrMsg;
  }
  
  var vnIdx = this.selectedIndex;
  var voTabPage = this.getPage(vnIdx);
  var vcSbp = voTabPage.getItem(0);
  vcSbp.setSrc(psSrc);
  if(psLabel) {
    var voTabBtn = this.getButton(vnIdx);
    voTabBtn.setValue(psLabel);
  }
};
/**
 * 탭 버튼 및 그에 따른 탭 바디 추가 메소드.
 * @param {String} psTabName 탭 버튼 라벨
 * @param {String} psButtonId 탭 버튼 아이디
 * @param {String} psPageId 탭 페이지 아이디
 * @param {Boolean} pbVisible Visible 여부
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 추가된 탭의 인덱스
 * @type Number
 */
eXria.controls.xhtml.Tab.prototype.addTab = function(psTabName, psButtonId, psPageId, pbVisible, pnLeft, pnTop, pnWidth, pnHeight) {
  var voCtrl = this.getCtrl();
  var voDf = this.df;
  var voPageDf = this.tabpages;
  var voHeader = this.tabHeader;
  var vsButtonId = null;
  var vsPageId = null;
  
  if(this.headerHeight == null) this.headerHeight = this.getAttrValue("headerHeight", this.headerHeight);
  if(psButtonId == null) vsButtonId = this.id + "_button_" + this.tabSeqNum;
  else vsButtonId = this.id + "_page_" + psButtonId;
  if(psPageId == null) vsPageId = this.id + "_page_" + this.tabSeqNum;
  else vsPageId = this.id + "_page_" + psPageId;
  if(pnLeft == null) {
    pnLeft = 0;
    pnTop = this.headerHeight;
    if(this.headerPos == "bottom") pnTop = 0;
    pnWidth = this.innerWidth;
    pnHeight = this.innerHeight - this.headerHeight;
  }
  var voTabPage = new eXria.controls.xhtml.TabPage(vsPageId, pnLeft, pnTop, pnWidth, pnHeight);
  voTabPage.subId = psPageId;
  voTabPage.parent = this;
  //voCtrl.appendChild(voTabPage.create());
  //voTabPage.getCtrl().style.zIndex = this.tabSeqNum;
  if(pbVisible) voTabPage.visible = pbVisible;
  voTabPage.zIndex = this.tabSeqNum;
  this.tabPageZindex = this.tabSeqNum;
  this.tabPageSet.add(voTabPage);
  if(voCtrl) {
   voTabPage.canvas = this.canvas;
   voTabPage.window = this.window;
   voTabPage.document = this.document;
   voTabPage.backgroundColor = this.tabpages.backgroundColor;
   voTabPage.className = voPageDf.className;
   voTabPage.outerClassName = voPageDf.outerClassName;
   voTabPage.borderStyle = voPageDf.borderStyle;
   voTabPage.borderColor = voPageDf.borderColor;
   voTabPage.borderWidth = voPageDf.borderWidth;
   voTabPage.borderLeftWidth = voPageDf.borderLeftWidth;
   voTabPage.borderRightWidth = voPageDf.borderRightWidth;
   voTabPage.borderTopWidth = voPageDf.borderTopWidth;
   voTabPage.borderBottomWidth = voPageDf.borderWidth;
   voTabPage.overflow = voPageDf.overflow;
   voTabPage.overflowX = voPageDf.overflowX;
   voTabPage.overflowY = voPageDf.overflowY;
    voTabPage.visible = false;
    voCtrl.appendChild(voTabPage.create());
    voTabPage.getCtrl().style.zIndex = this.tabSeqNum;
  }
  var voTabButton = new eXria.controls.xhtml.TabButton(vsButtonId, 0, 0, voHeader.tabbuttons.width, voHeader.tabbuttons.height);
  voTabButton.subId = psButtonId;
  voTabButton.value = psTabName;
  voTabButton.pageId = vsPageId;
  voTabButton.pageSubId = psPageId;
  voTabPage.btn = voTabButton;
  if(pbVisible != null) voTabButton.visible = pbVisible;
  voHeader.addTabButton(voTabButton);
  this.tabSeqNum++;
  
  var vnIndex = this.tabPageSet.size() - 1;
  if(vnIndex == this.selectedIndex) this.selectTab(vnIndex);
  
  return this.tabPageSet.size() - 1;
};
/**
 * 미리 생성된 탭 바디를 탭에 추가하기 위한 메소드
 * @param {String} psTabName 탭 버튼 라벨
 * @param {String} psButtonId 생성할 버튼의 아이디
 * @param {eXria.controls.xhtml.TabPage} poTabPage 탭 바디
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.addTabPage = function(psTabName, psButtonId, poTabPage) {
  var voCanvas = this.canvas;
  var voHeader = this.tabHeader;
  var vsButtonId = null;
  
  poTabPage.canvas = voCanvas;
  poTabPage.window = this.window;
  poTabPage.document = this.document;
  poTabPage.getCtrl().style.zIndex = this.tabSeqNum;
  this.tabPageZindex = this.tabSeqNum;
  this.tabPageSet.add(poTabPage);
  if(psButtonId == null) vsButtonId = this.id + "_button_" + tabSeqNum++;
  else vsButtonId = this.id + "_button_" + psButtonId;
  var voTabButton = new eXria.controls.xhtml.TabButton(vsButtonId, 0, 0, voHeader.tabbuttons.width, voHeader.tabbuttons.height);
  voTabButton.subId = psButtonId;
  voTabButton.value = psTabName;
  voTabButton.pageId = poTabPage.id;
  voTabButton.pageSubId = poTabPage.subId;
  voHeader.addTabButton(voTabButton);
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 인덱스 번호 반환.
 * @param {String} psLabel 탭 버튼 라벨
 * @return 라벨에 해당하는 탭 버튼 인덱스
 * @type Number
 */
eXria.controls.xhtml.Tab.prototype.getIndex = function(psLabel) {
  var voHeader = this.tabHeader;
  var voIterator = voHeader.controls.iterator();
  var voTabButton = null;
  var i = 0;
  while(voIterator.hasNext()) {
    voTabButton = voIterator.next();
    if (voTabButton.value.indexOf(psLabel) == 0) { return i; }
    i++;
  }
  return -1;
};
/**
 * 지정된 pageId에 해당하는 탭 인덱스 반환.
 * @param {String} psPageId 지정된 페이지 아이디.
 * @return pageId에 해당하는 탭 인덱스
 * @type Number
 */  
eXria.controls.xhtml.Tab.prototype.getIndexById = function(psPageId) {
  var vnIndex = -1;
  var voIterator = this.tabPageSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == psPageId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};
/**
 * 지정된 subId에 해당하는 탭 인덱스 반환.
 * @param {String} pspageSubId 지정된 서브 아이디.
 * @return subId에 해당하는 탭 인덱스
 * @type Number
 */  
eXria.controls.xhtml.Tab.prototype.getIndexBySubId = function(psPageSubId) {
  var vnIndex = -1;
  var voIterator = this.tabPageSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.subId == psPageSubId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};
/**
 * 모든 탭 제거.
 */
eXria.controls.xhtml.Tab.prototype.removeAll = function() {
  var voTabHeader = this.tabHeader;
  var voTabPageSet = this.tabPageSet;
  voTabHeader.controls.clear();
  voTabHeader.refresh();
  var vnSize = this.tabPageSet.size();
  for(var i = 0; i < vnSize; i++) {
    this.removeTabPage(0);
  };
};
/**
 * type 이 minimizedWindow 인 경우 사용될 탭 제거 메소드
 * @param {Number} pnIndex 탭의 인덱스
 */
eXria.controls.xhtml.Tab.prototype.removeMinimizedWindowTab = function(pnIndex) {
  if(!this.type || this.type !== 'minimizedWindow'){
    var voErrMsg;
    voErrMsg.name = "eXria.controls.xhtml.Tab.prototype."
    voErrMsg.message = "type 이  minimizedWindow 인 경우에만 사용이 가능 합니다."
    throw voErrMsg;
  };
  this.removeTab(pnIndex);
};
/**
 * 지정된 인덱스에 해당하는 탭 제거.
 * @param {Number} pnIndex 탭의 인덱스
 */
eXria.controls.xhtml.Tab.prototype.removeTab = function(pnIndex) {
  var voHeader = this.tabHeader;
  var voTabButton = voHeader.controls.remove(pnIndex);
  var voTd = voTabButton.getCtrl().parentNode;
  voTabButton.clear();
  
  var voTr = this.lookup(voHeader.id + "_tab_tr");
  voTr.removeChild(voTd);
  
  voHeader.checkScroll();
  this.removeTabPage(pnIndex);
  if(pnIndex == this.selectedIndex && voHeader.controls.size() > 0) {
    this.selectedIndex = -1;
    if(pnIndex >= voHeader.controls.size()) --pnIndex;
    this.selectTab(pnIndex);
  }
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 제거.
 * @param {String} psLabel 라벨명
 */
eXria.controls.xhtml.Tab.prototype.removeTabByLabel = function(psLabel) {
  var vnIndex = this.getIndex(psLabel);
  if(vnIndex != -1) this.removeTab(vnIndex);
};
/**
 * 지정된 페이지 subId에 해당하는 탭 제거.
 * @param {String} psPageSubId 페이지 서브 아이디
 */
eXria.controls.xhtml.Tab.prototype.removeTabById = function(psPageSubId) {
  var vnIndex = this.getIndexBySubId(psPageSubId);
  if(vnIndex != -1) this.removeTab(vnIndex);
};
/**
 * 지정된 인덱스의 탭 바디 제거.
 * @param {Number} pnIndex 탭 바디 인덱스
 * @private
 */
eXria.controls.xhtml.Tab.prototype.removeTabPage = function(pnIndex) {
  var voControl = this.tabPageSet.remove(pnIndex);
  voControl.clear();
};
/**
 * 지정된 인덱스의 탭 활성화.
 * @param {Number} pnIndex 탭 바디 인덱스
 */
eXria.controls.xhtml.Tab.prototype.selectTab = function(pnIndex) {
  this.tabHeader.select(pnIndex);
};
/**
 * 지정된 pageId에 해당하는 탭 활성화
 * @param {String} psPageId 페이지 아이디
 */  
eXria.controls.xhtml.Tab.prototype.selectById = function(psPageId) {
  var vnIndex = -1;
  var vsId = this.id + "_page_" + psPageId;
  var voIterator = this.tabPageSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == vsId) {
      vnIndex = cnt;
      break;
    }
  }
  
  if(vnIndex != -1) this.selectTab(vnIndex);
};
/**
 * 지정된 인덱스에 해당하는 탭 버튼 반환.
 * @param {Number} pnIndex 탭 인덱스
 * @return 지정된 인덱스에 해당하는 탭 버튼
 * @type eXria.controls.xhtml.TabButton  
 */   
eXria.controls.xhtml.Tab.prototype.getButton = function(pnIndex) {
  var voHeader = this.tabHeader;
  var voTabButton = null;
  voTabButton = voHeader.controls.get(pnIndex);
  return voTabButton;
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 반환.
 * @param {String} psLabel 탭 버튼 라벨
 * @return 지정된 라벨에 해당하는 탭 버튼 객체
 * @type eXria.controls.xhtml.TabButton
 */
eXria.controls.xhtml.Tab.prototype.getButtonByLabel = function(psLabel) {
  var voHeader = this.tabHeader;
  var voIterator = voHeader.controls.iterator();
  var voTabButton = null;
  var i = 0;
  while(voIterator.hasNext()) {
    voTabButton = voIterator.next();
    if (voTabButton.value == psLabel) { return voTabButton; }
  }
  return null;
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 반환.
 * @param {String} psButtonSubId 탭 버튼 아이디
 * @return 지정된 아이디에 해당하는 탭 버튼 객체
 * @type eXria.controls.xhtml.TabButton
 */
eXria.controls.xhtml.Tab.prototype.getButtonById = function(psButtonSubId) {
  var voHeader = this.tabHeader;
  var voIterator = voHeader.controls.iterator();
  var voTabButton = null;
  var i = 0;
  while(voIterator.hasNext()) {
    voTabButton = voIterator.next();
    if (voTabButton.subId == psButtonSubId) { return voTabButton; }
  }
  return null;
};
/**
 * 지정된 인덱스에 해당하는 탭 페이지 반환.
 * @param {Number} pnIndex 탭 인덱스
 * @return 지정된 인덱스에 해당하는 탭 페이지
 * @type eXria.controls.xhtml.TabPage  
 */   
eXria.controls.xhtml.Tab.prototype.getPage = function(pnIndex) {
  var voPage = null;
  try {
    voPage = this.tabPageSet.get(pnIndex);
  } catch(err) {}
  return voPage;
};
/**
 * 지정된 페이지 ID에 해당하는 탭 페이지 반환.
 * @param {String} psPageSubId 탭 페이지 id
 * @return 지정된 페이지 ID에 해당하는 탭 페이지
 * @type eXria.controls.xhtml.TabPage  
 */  
eXria.controls.xhtml.Tab.prototype.getPageById = function(psPageSubId) {
  var vnIndex = this.getIndexBySubId(psPageSubId);
  
  var voPage = null;
  voPage = this.tabPageSet.get(vnIndex);
  return voPage;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.clear = function() {
  this.tabHeader.clear();
  var voTabPage = null;
  var voIterator = this.tabPageSet.iterator();
  while(voIterator.hasNext()) {
    voTabPage = voIterator.next();
    voTabPage.clear();
  }
  this.clearCtrl();
  this.clearControl();
};
/**
 * getCtrlClassName
 * @param {String} psClassName 참조 대상 클래스명
 * @param {String} psOuterClassName
 * @return vsClassName
 * @type String
 */
eXria.controls.xhtml.Tab.prototype.getCtrlClassName = function(psClassName, psOuterClassName) {
  var vsClassName = "";
  if(psClassName == null) psClassName = "";
  if(psOuterClassName == null) psOuterClassName = "";
  vsClassName = psClassName + " " + psOuterClassName;
  vsClassName = eXria.util.StringUtil.trim(vsClassName);
  
  return vsClassName;
};  
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.getSpecificDefaultValue = function(psAttrName){
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.Tab[psAttrName];      
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.Tab[vaAttrName[0]][vaAttrName[1]] || vsDefaultValue;    
  }
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
}; 
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.tabSpinLeft = function(e){
  this.tabHeader.tabSpinLeft(e);
}
/**
 * @ignore
 */
eXria.controls.xhtml.Tab.prototype.tabSpinRight = function(e){
  this.tabHeader.tabSpinRight(e);
}
/**
 * 클래스 명을 반환.
 * @return "Tab"
 * @type String
 */
eXria.controls.xhtml.Tab.prototype.toString = function() {
  return "Tab";
};

/**
 * 지정됨 탭을 숨기거나 보임
 * @param  {Number} pnIndex 숨기거나 보이려고 하는 탭 인덱스
 * @param  {Boolean} pbShow true 이면 지정된 탭을 보이고 false 이면 탭을 숨김 
 */
eXria.controls.xhtml.Tab.prototype.showTab = function(pnIndex, pbShow){
  var that = this;
  
  //내부함수 선언
  var showNextTab = function(pnIdx){
    var voControls = that.tabHeader.controls;
    var vnSize = voControls.size();
    var voTabButton = null;            
    voTabButton = voControls.get(pnIdx);
    
    //가장 마자믹 tab 일경우 처음 부터 
    if(pnIdx-1 >= vnSize-1){
      for(var i = 0; i < vnSize; i++) {
        voTabButton = voControls.get(i);
        if(voTabButton.visible != false) {
          that.selectTab(i);
          break;
        }
      }      
    }else{
      if(voTabButton.visible != false) {
        that.selectTab(pnIdx);
      }    
    }            
  };
  
  if(typeof(pnIndex) === 'number'){
    if(!!pbShow){
      this.getButton(pnIndex).visible = true;
      this.refresh();            
    }else{
      this.getButton(pnIndex).visible = false;
      this.refresh();
      
      //현재 보여지는 tab이 숨겨질 경우 다음탭을 활성화
      if(this.selectedIndex === pnIndex)
        showNextTab(pnIndex+1);        
    }  
  }
};