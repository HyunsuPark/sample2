/**
 * @fileoverview
 * XHTML Util
 * @author Youngjin Cho
 */
 
/**
 * XHTML Util
 * @version 2.0
 * @type eXria.controls.xhtml.Util
 * @constructor
 */
eXria.controls.xhtml.Util = {
  createInheritance : function(parentClass, childClass) {
    var parentProto = parentClass.prototype;
    var childProto = childClass.prototype;
    var psAttr = null;
    for(psAttr in parentProto) {
      childProto[psAttr] = parentProto[psAttr];
    }
  },
  // 조영진선임 전달받은 내용 : map에 $로 시작되는 keycode를 정의해서 그 값을 eval처리하여 
	// 다국어 지원하기로 되어있었는데 현재 그렇게 처리할 경우는 없는 걸로 결론 지었음.
	// TODO : 향후 컨트롤별 사용되는 곳을 찾아서 지워줘야 함
  parseLang : function(psStr) {
    var vsRet = psStr;
    if(vsRet != null) {
      vsRet = "" + vsRet;
      if(vsRet.indexOf('$') == 0) {
        vsRet = vsRet.substring(1);
        try { vsRet = eval(vsRet); } catch(err) { return psStr; }
      }      
    }
    if(vsRet == null) vsRet = psStr;
    return vsRet; 
  },
  
  /**
   * 웹 페이지에 로딩된 지정된 클래스명을 포함한 css 파일의 경로 반환
   * @param {String} psClassName 지정된 클래스명
   * @param {HTMLDocument} poDocument css 파일을 로딩 한 Document
   * @return css 파일의 경로
   * @type String
   */
  getCssRef : function(psClassName, poDocument) {
    if(psClassName == null) return null;
    var vsCssRef = null;
    var bBreak = false;
    var vaClassName = psClassName.split(" ");
    for (var s = 0; s < poDocument.styleSheets.length; s++) {
      if (vaClassName.length >= 2) {
        for(var i = 1; i < vaClassName.length; i++) {
          if(vaClassName[i].substring(0, 1) != ".") vaClassName[i] = vaClassName[i].toUpperCase();
        }
        psClassName = vaClassName.join(" ");        
      }
      try {
        if(poDocument.styleSheets[s].rules) {                       // IE와 Safari
          for(var r = 0; r < poDocument.styleSheets[s].rules.length; r++) {
            if (poDocument.styleSheets[s].rules[r].selectorText == '.' + psClassName) {
              vsCssRef = poDocument.styleSheets[s].href
              bBreak = true;
              break;
            }
          }
        }
        else if(poDocument.styleSheets[s].cssRules) {               // FireFox와 Opera
          if(vaClassName.length >= 2) {
            for(var i = 1; i < vaClassName.length; i++) {
              if(vaClassName[i].substring(0, 1) != ".") vaClassName[i] = vaClassName[i].toLowerCase();
            }
            psClassName = vaClassName.join(" ");
          }          
          for (var r = 0; r < poDocument.styleSheets[s].cssRules.length; r++) {
            if (poDocument.styleSheets[s].cssRules[r].selectorText == '.' + psClassName) {
              vsCssRef = poDocument.styleSheets[s].href;
              bBreak = true;
              break;
            }
          }
        }
      } catch(err) {}
      if(bBreak) break;
    }
    return vsCssRef;
  },
  /**
	 * @private
	 */
  convertImagePathToXrf : function(psClassName, psCssImage, poDocument) {
    if(psCssImage == null || psCssImage == "") return psCssImage;
    var vsPath = psCssImage.replace(/(url\()/, "");
    vsPath = vsPath.replace(/\"/gi, "");
    //vsPath = this.df.backgroundImage.replace(/(\)$)/, "");
    if(vsPath.indexOf("http://") == 0) return psCssImage;
    if(vsPath.indexOf("/") == 0) return psCssImage;
    var vaRef = this.getCssRef(psClassName, poDocument).split("/");
    vaRef.splice(vaRef.length - 1, 1);
    var vsParentPath = vaRef.join("/");    
    if(vsParentPath != "") vsParentPath += "/";
    vsPath = vsParentPath + vsPath;
    vsPath = "url(" + vsPath;
    return vsPath;
  },
  
	/**
	 * @ignore
	 */
  getBackgroundImagePath : function(psPath, poWindow) {
    if(psPath == null || psPath == "" || psPath == "none") return "";
    psPath = psPath.replace(/\'/gi, "");
    var vsGlobalContextPath = page.globalContextPath;
    if(vsGlobalContextPath) {
      psPath = psPath.replace(new RegExp("^" + vsGlobalContextPath), "/");
    }
    var vsBaseUrl = poWindow.page.metadata.resourceBaseUrl;
    if((psPath.indexOf("/") == 0 && psPath.indexOf(vsBaseUrl) != 0) || psPath.indexOf(".") == -1) psPath = vsBaseUrl + psPath.substring(1);
    if(psPath.indexOf("url(") == -1) psPath = "url(" + psPath + ")";
    
    return psPath;
  },
	
  /**
	 * @ignore
	 */
  getImagePath : function(psPath, poWindow) {
    if(psPath == null || psPath == "") return "";
    else if(psPath == "none") return psPath;
    var vsGlobalContextPath = page.globalContextPath;
    if(vsGlobalContextPath) {
      psPath = psPath.replace(new RegExp("^" + vsGlobalContextPath), "/");
    }
    psPath = psPath.replace(/\'/gi, "");
    if(psPath.indexOf("http://") == 0 || psPath.indexOf(".") == 0) return psPath;
    var vsBaseUrl = poWindow.page.metadata.resourceBaseUrl;
    if(psPath.indexOf("/") == 0 && psPath.indexOf(vsBaseUrl) != 0) psPath = vsBaseUrl + psPath.substring(1);
    
    return psPath;
  },
  
	/**
	 * @ignore
	 */
  getAttrToApply : function(psAttrName, poObject, poCssStyle) {
    var vsAttrValue = null;
    var vaAttrName = psAttrName.split(".");
    var voAttr = poObject;
    for(var i = 0; i < vaAttrName.length; i++) {
      voAttr = voAttr[vaAttrName[i]];
    }
    vsAttrValue = voAttr;
    if(vsAttrValue != null) return vsAttrValue;
    
    if(vsAttrValue == null) {
      if(poCssStyle) vsAttrValue = poCssStyle[vaAttrName[vaAttrName.length - 1]];
    }
    if(vsAttrValue == null || vsAttrValue == "") {
      if(poObject.getSpecificDefaultValue) vsAttrValue = poObject.getSpecificDefaultValue(psAttrName);
    }
    return vsAttrValue;
  },
  
	/**
	 * @ignore
	 */
  getTemplateIndexMap : function(paTemplate) {
    var voArrayMap = new eXria.data.ArrayMap();
    var vnIndex = 0;
    for(var i = 0; i < paTemplate.length; i++) {
      if(typeof paTemplate[i] == "string") {
        var t = paTemplate[i].indexOf("@");
        if(paTemplate[i].indexOf("@") == 0) voArrayMap.put(vnIndex++, i);
      }
    }
    return voArrayMap;
  },
  
	/**
	 * @ignore
	 */
  getXmlString : function(psStr) {
    if(psStr == null) return null;
    var vsStr = psStr.replace(/\&/g,"&amp;").replace(/\</g,"&lt;").replace(/"/g,"&quot;").replace(/\n/g,"&#x0A;");
    return vsStr;
  },
  /*
  //IE 6.0 이하 투명 png 처리 Method
  //template_xhtml.xml 에 이하 스타일 추가 필요
  <style>
	.png24 { 
  	tmp:expression(eXria.controls.xhtml.Util.setPng(this)); 
	}
	</style>
  
  setPng : function(poImg) {
  	poImg.width=poImg.height=1; 
  	poImg.className=poImg.className.replace(/\bpng24\b/i,''); 
  	poImg.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + poImg.src + "',sizingMethod='image');"; 
    poImg.src='';  
    return '';
  }
  */
  
  
  //2009-04-06 ehj
  colorNames : {
	    ALICEBLUE            : "#F0F8FF"
  	  , ANTIQUEWHITE         : "#FAEBD7"
  	  , AQUA                 : "#00FFFF"
  	  , AQUAMARINE           : "#7FFFD4"
  	  , AZURE                : "#F0FFFF"
  	  , BEIGE                : "#F5F5DC"
  	  , BISQUE               : "#FFE4C4"
  	  , BLACK                : "#000000"
  	  , BLANCHEDALMOND       : "#FFEBCD"
  	  , BLUE                 : "#0000FF"
  	  , BLUEVIOLET           : "#8A2BE2"
  	  , BROWN                : "#A52A2A"
  	  , BURLYWOOD            : "#DEB887"
  	  , CADETBLUE            : "#5F9EA0"
  	  , CHARTREUSE           : "#7FFF00"
  	  , CHOCOLATE            : "#D2691E"
  	  , CORAL                : "#FF7F50"
  	  , CORNFLOWERBLUE       : "#6495ED"
  	  , CORNSILK             : "#FFF8DC"
  	  , CRIMSON              : "#DC143C"
  	  , CYAN                 : "#00FFFF"
  	  , DARKBLUE             : "#00008B"
  	  , DARKCYAN             : "#008B8B"
  	  , DARKGOLDENROD        : "#B8860B"
  	  , DARKGRAY             : "#A9A9A9"
  	  , DARKGREEN            : "#006400"
  	  , DARKKHAKI            : "#BDB76B"
  	  , DARKMAGENTA          : "#8B008B"
  	  , DARKOLIVEGREEN       : "#556B2F"
  	  , DARKORANGE           : "#FF8C00"
  	  , DARKORCHID           : "#9932CC"
  	  , DARKRED              : "#8B0000"
  	  , DARKSALMON           : "#E9967A"
  	  , DARKSEAGREEN         : "#8FBC8F"
  	  , DARKSLATEBLUE        : "#483D8B"
  	  , DARKSLATEGRAY        : "#2F4F4F"
  	  , DARKTURQUOISE        : "#00CED1"
  	  , DARKVIOLET           : "#9400D3"
  	  , DEEPPINK             : "#FF1493"
  	  , DEEPSKYBLUE          : "#00BFFF"
  	  , DIMGRAY              : "#696969"
  	  , DODGERBLUE           : "#1E90FF"
  	  , FIREBRICK            : "#B22222"
  	  , FLORALWHITE          : "#FFFAF0"
  	  , FORESTGREEN          : "#228B22"
  	  , FUCHSIA              : "#FF00FF"
  	  , GAINSBORO            : "#DCDCDC"
  	  , GHOSTWHITE           : "#F8F8FF"
  	  , GOLD                 : "#FFD700"
  	  , GOLDENROD            : "#DAA520"
  	  , GRAY                 : "#808080"
  	  , GREEN                : "#008000"
  	  , GREENYELLOW	         : "#ADFF2F"
  	  , HONEYDEW             : "#F0FFF0"
  	  , HOTPINK              : "#FF69B4"
  	  , INDIANRED            : "#CD5C5C"
  	  , INDIGO               : "#4B0082"
  	  , IVORY                : "#FFFFF0"
  	  , KHAKI                : "#F0E68C"
  	  , LAVENDER             : "#E6E6FA"
  	  , LAVENDERBLUSH        : "#FFF0F5"
  	  , LAWNGREEN            : "#7CFC00"
  	  , LEMONCHIFFON         : "#FFFACD"
  	  , LIGHTBLUE            : "#ADD8E6"
  	  , LIGHTCORAL           : "#F08080"
  	  , LIGHTCYAN            : "#E0FFFF"
  	  , LIGHTGOLDENRODYELLOW : "#FAFAD2"
  	  , LIGHTGREY            : "#D3D3D3"
  	  , LIGHTGREEN           : "#90EE90"
  	  , LIGHTPINK            : "#FFB6C1"
  	  , LIGHTSALMON          : "#FFA07A"
  	  , LIGHTSEAGREEN        : "#20B2AA"
  	  , LIGHTSKYBLUE         : "#87CEFA"
  	  , LIGHTSLATEGRAY       : "#778899"
  	  , LIGHTSTEELBLUE       : "#B0C4DE"
  	  , LIGHTYELLOW          : "#FFFFE0"
  	  , LIME                 : "#00FF00"
  	  , LIMEGREEN            : "#32CD32"
  	  , LINEN                : "#FAF0E6"
  	  , MAGENTA              : "#FF00FF"
  	  , MAROON               : "#800000"
  	  , MEDIUMAQUAMARINE     : "#66CDAA"
  	  , MEDIUMBLUE           : "#0000CD"
  	  , MEDIUMORCHID         : "#BA55D3"
  	  , MEDIUMPURPLE         : "#9370D8"
  	  , MEDIUMSEAGREEN       : "#3CB371"
  	  , MEDIUMSLATEBLUE      : "#7B68EE"
  	  , MEDIUMSPRINGGREEN    : "#00FA9A"
  	  , MEDIUMTURQUOISE      : "#48D1CC"
  	  , MEDIUMVIOLETRED      : "#C71585"
  	  , MIDNIGHTBLUE         : "#191970"
  	  , MINTCREAM            : "#F5FFFA"
  	  , MISTYROSE            : "#FFE4E1"
  	  , MOCCASIN             : "#FFE4B5"
  	  , NAVAJOWHITE          : "#FFDEAD"
  	  , NAVY                 : "#000080"
  	  , OLDLACE              : "#FDF5E6"
  	  , OLIVE                : "#808000"
  	  , OLIVEDRAB            : "#6B8E23"
  	  , ORANGE               : "#FFA500"
  	  , ORANGERED            : "#FF4500"
  	  , ORCHID               : "#DA70D6"
  	  , PALEGOLDENROD        : "#EEE8AA"
  	  , PALEGREEN            : "#98FB98"
  	  , PALETURQUOISE        : "#AFEEEE"
  	  , PALEVIOLETRED        : "#D87093"
  	  , PAPAYAWHIP           : "#FFEFD5"
  	  , PEACHPUFF            : "#FFDAB9"
  	  , PERU                 : "#CD853F"
  	  , PINK                 : "#FFC0CB"
  	  , PLUM                 : "#DDA0DD"
  	  , POWDERBLUE           : "#B0E0E6"
  	  , PURPLE               : "#800080"
  	  , RED                  : "#FF0000"
  	  , ROSYBROWN            : "#BC8F8F"
  	  , ROYALBLUE            : "#4169E1"
  	  , SADDLEBROWN          : "#8B4513"
  	  , SALMON               : "#FA8072"
  	  , SANDYBROWN           : "#F4A460"
  	  , SEAGREEN             : "#2E8B57"
  	  , SEASHELL             : "#FFF5EE"
  	  , SIENNA               : "#A0522D"
  	  , SILVER               : "#C0C0C0"
  	  , SKYBLUE              : "#87CEEB"
  	  , SLATEBLUE            : "#6A5ACD"
  	  , SLATEGRAY            : "#708090"
  	  , SNOW                 : "#FFFAFA"
  	  , SPRINGGREEN          : "#00FF7F"
  	  , STEELBLUE            : "#4682B4"
  	  , TAN                  : "#D2B48C"
  	  , TEAL                 : "#008080"
  	  , THISTLE              : "#D8BFD8"
  	  , TOMATO               : "#FF6347"
  	  , TURQUOISE            : "#40E0D0"
  	  , VIOLET               : "#EE82EE"
  	  , WHEAT                : "#F5DEB3"
  	  , WHITE                : "#FFFFFF"
  	  , WHITESMOKE           : "#F5F5F5"
  	  , YELLOW               : "#FFFF00"
  	  , YELLOWGREEN          : "#9ACD32"

  },
  
   /**
   * getColor(psColorName);
   * ex) eXria.controls.xhtml.Util.getColor("Red"); -> "#FF0000"
   */
  getColor : function(psColorName) {
	var vsColorName = psColorName.toUpperCase();
	var vsColor = (this.colorNames[vsColorName] == undefined) ? psColorName : this.colorNames[vsColorName];
  	return vsColor;
  },
  
 /**
  * 색상정보 조회(16진수)
  * @param {Number,Number,Number} 16진수로 변환될 10진수
  * @return {String}
  */	
  getRGBToHex : function(psRed, psGreen, psBlue) {
		var vsR = (psRed < 0 || isNaN(psRed)) ? 0 : ((psRed > 255) ? 255 : psRed);
		var vsB = (psBlue < 0 || isNaN(psBlue)) ? 0 : ((psBlue > 255) ? 255 : psBlue);
		var vsG = (psGreen < 0 || isNaN(psGreen)) ? 0 : ((psGreen > 255) ? 255 : psGreen);
		
		vsR = vsR.toString(16);
		vsG = vsG.toString(16);
		vsB = vsB.toString(16);
		
		if (vsR.length == 1) vsR = '0' + vsR;
		if (vsG.length == 1) vsG = '0' + vsG;
		if (vsB.length == 1) vsB = '0' + vsB;
		
		return '#' + vsR + vsG + vsB;		
  },
  
  /**
   * getPage(psId)
   */
  getPage : function(psId, poWindow) {
    if(poWindow == null) poWindow = window.top;
    var voDocument = poWindow.document;
    var voFrames = voDocument.getElementsByTagName("frame");
    var vnLen = voFrames.length;
    var voFrame = null;
    var voWindow = null;
    var voPage =  null;
    for(var i = 0; i < vnLen; i++) {
      voFrame = voFrames[i];
      voWindow = voFrame.contentWindow;
      if(voWindow) {
        voPage = voWindow.page;
        if(voPage) {
          if(voPage.id == psId) return voPage;
          voPage = null;
        } else {
          voPage = this.getPage(psId, voWindow);
        }
        if(voPage) return voPage;
      }
    }    
    voFrames = voDocument.getElementsByTagName("iframe");
    vnLen = voFrames.length;
    for(var i = 0; i < vnLen; i++) {
      voFrame = voFrames[i];
      voWindow = voFrame.contentWindow;
      if(voWindow) {
        voPage = voWindow.page;
        if(voPage) {
          if(voPage.id == psId) return voPage;
          voPage = null;
        } else {
          voPage = this.getPage(psId, voWindow)
        }
        if(voPage) return voPage;
      }
    }    
    return null;
  },
  
    /**
     * css를 동적으로 로드한다.
     * @param {String} psCSSFilePath 경로가 포함된 로딩될 CSS
     * @return {boolean}
     * @type String
     */
    loadCSSFile: function(psCSSFilePath){
        var voRtnVal = false
        var poWindow = window;
        var voDocument = poWindow.document;
        var voDocumentElement = voDocument.documentElement;
        var voLink = voDocument.documentElement.getElementsByTagName("link");
        
        if (!!psCSSFilePath) {
            for (var i = 0; i < voLink.length; i++) {
                if (voLink[i].rel.toLowerCase() == "stylesheet" && voLink[i].href && voLink[i].href.indexOf(psCSSFilePath) >= 0) 
                    break;
            }
            
            //TODO : CSS 파일 존재 여부 확인 로직추가
            if (true) {
                var voCreateElement = voDocument.createElement("link");
                voCreateElement.href = psCSSFilePath;
                voCreateElement.rel = "Stylesheet";
                voCreateElement.type = "text/css"
                
                var voHead = voDocumentElement.getElementsByTagName("head")[0];
                if (!voHead) {
                    voHead = voDocument.createElement("head");
                    voDocumentElement.insertBefore(voHead, voDocument.body);
                }
                voHead.insertBefore(voCreateElement, voHead.firstChild);
                voRtnVal = true;
            }
            
        }
        return voRtnVal;
    },
    
    /**
     * XML 로딩
     * @param {String} psXML 경로가 포함된 로딩될 xml
     * @return {XML DOM object}
     * @type String
     */
    loadXML: function(psXML){
        var voRtnVal = {
            xmlDox: null,
            success: false
        };
        
        var voXHTTP = eXria.form.xhtml.HttpRequestFactory.create();
        
        //TODO : XML파일 존재 여부 확인 로직 추가 및 String 형태의 XML을 받을수 있게 수정
        if (psXML) {
            voXHTTP.open("GET", psXML, false);
            voXHTTP.send(null);
            voRtnVal.xmlDox = voXHTTP.responseXML;
            voRtnVal.success = true;
        }
        else {
            voRtnVal.success = false;
        }
        
        return voRtnVal;
    },
    
    /**
     * DEFALUT LOCALE 정보 로딩
     */
    getDefaultLocale: function(){
    
        var poWindow = window;
        var vsLocale = "kor";
        
        if (poWindow.page.metadata.useMultilingual != null && poWindow.page.metadata.language != null) {
            if (poWindow.page.metadata.useMultilingual == true) {
                var vsDefaultLocale = poWindow.page.metadata.eXriaLocale.toUpperCase();
                if (vsDefaultLocale == "KO_KR") 
                    vsLocale = "kor";
                else 
                    if (vsDefaultLocale == "JA_JP") 
                        vsLocale = "jpn";
                    else 
                        if (vsDefaultLocale.search(/ZH/) != -1) 
                            vsLocale = "chn";
                        else 
                            vsLocale = "eng";
            }
            else {
                if (poWindow.page.metadata.language.toUpperCase() == "KO") 
                    vsLocale = "kor";
                else 
                    vsLocale = "eng";
            }
        }
        return vsLocale;
    },
	
	/**
	 * 
	 * @param {String, String} 
	 * @return {String}
	 * @type String
	 */	
	getValueFromInputMode : function(psData, psInputMode) {
		if (!psData) return psData;
		if (!psInputMode) return psData;
		var vsReturnValue = "";
		var vsRegType = "";
		
		switch (psInputMode) {
			case "uppercase" :
			vsReturnValue = psData.toUpperCase();
			break;
			case "lowercase" :
			vsReturnValue = psData.toLowerCase();
			break;
			case "number" :
			vsRegType = /[^0-9]/gi;
			vsReturnValue = psData.replace(vsRegType, '');
			break;
			case "alpha" :
			vsRegType = /[^\sA-Za-z._$-]/gi;
			vsReturnValue = psData.replace(vsRegType, '');
			break;
			case "alphanumeric" :
			vsRegType = /[^\sA-Za-z0-9._$-]/gi;
			vsReturnValue = psData.replace(vsRegType, '');
			break;
		}
		
		return vsReturnValue;
	}	
  
};

function getScrollBarWidth() {
  var inner = document.createElement('p');
  inner.style.width = "100%";
  inner.style.height = "200px";

  var outer = document.createElement('div');
  outer.style.position = "absolute";
  outer.style.top = "0px";
  outer.style.left = "0px";
  outer.style.visibility = "hidden";
  outer.style.width = "200px";
  outer.style.height = "150px";
  outer.style.overflow = "hidden";
  outer.appendChild (inner);

  document.body.appendChild (outer);
  var w1 = inner.offsetWidth;
  outer.style.overflow = 'scroll';
  var w2 = inner.offsetWidth;
  if (w1 == w2) w2 = outer.clientWidth;

  document.body.removeChild (outer);

  return (w1 - w2);
};

/**
* 폼엘리먼트의 value 가 변화되면 keyup 이벤트 발생시키기
* [출처] 모질라계열(파이어폭스 등)에서 한글 입력시에 onKeyUp 이벤트 잡기 흉내|작성자 지멋대루
* @author hooriza at nhncorp.com 
* @version 0.1
*
* @created Nov.8.2007.
*/
 
var Observe = function(oEl) {
  this._o = oEl;
  this._value = oEl.value;
  this._bindEvents();

};
 
Observe.prototype._bindEvents = function() {
  var cnt = 0;
  var cnt2 = 0;
  var self = this;
  var bind = function(oEl, sEvent, pHandler) {
    if (oEl.attachEvent) oEl.attachEvent('on' + sEvent, pHandler);
    else oEl.addEventListener(sEvent, pHandler, false);
  };
 
  bind(this._o, 'focus', function() {
    if(this.id == "txt1_textarea"){
      var voCtl = page.getControl("txt2");
      var vnCnt = cnt2++;
      var vsValue = "focus : " + vnCnt;
      vsValue = voCtl.getValue() + "\n"+ vsValue;
      voCtl.setValue(vsValue);
    }
    if (self._timer) clearInterval(self._timer);
    self._timer = setInterval(function() {
     
      // window.console.debug('compare : ' + self._value + ' == ' + self._o.value);
      if (self._o.getAttribute("trimValue") != self._o.value) {
        self._fireEvent();
      }
     
    }, 50);
   
  });
 
  bind(this._o, 'blur', function() {
    if (self._timer) clearInterval(self._timer);
    self._timer = null;
    if(this.id == "txt1_textarea"){
      var voCtl = page.getControl("txt2");
      var vnCnt = cnt++;
      var vsValue = "blur : " + vnCnt;
      vsValue = voCtl.getValue() + "\n"+ vsValue;
      voCtl.setValue(vsValue);
    }
  });
           
};
 
Observe.prototype._fireEvent = function() {
  if (document.createEvent) {
    var e;
    if (window.KeyEvent) {
      e = document.createEvent('KeyEvents');
      e.initKeyEvent('keyup', true, true, window, false, false, false, false, 65, 0);
    } else {
      e = document.createEvent('UIEvents');
      e.initUIEvent('keyup', true, true, window, 1);
      e.keyCode = 65;
    }
    this._o.dispatchEvent(e);
   
  } else {
    var e = document.createEventObject();
    e.keyCode = 65;
    this._o.fireEvent('onkeyup', e);
   
  }
 
};
