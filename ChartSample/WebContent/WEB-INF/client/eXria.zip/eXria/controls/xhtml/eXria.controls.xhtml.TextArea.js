﻿/**
 * @fileoverview
 * Concreate xhtml TextArea(XHTML TextArea 컨트롤)
 * @author 조동일 , 이종녕
 */
 
/**
 * @class 텍스트 입력필드를 여러줄 만들어주는 컨트롤을 생성하는 class입니다.<br />
 * XHTML TextArea Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.TextArea 객체
 * @type eXria.controls.xhtml.TextArea
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.TextArea = function(psId,pnLeft, pnTop, pnWidth, pnHeight) {
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 100 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */      
  this.data = new eXria.controls.DataRefNode(this);
  /////////////////////////////////////////////////////////////////////////////
  ////속성
  /**
   * 최대 표현 가능한 문자열의 줄 수.
   * @type Number
   */
  this.rows = null;
  /**
   * 한 줄에 최대 표현 가능한 문자열의 길이.
   * @type Number
   */
  this.cols = null;
  /**
   * 한 줄에 최대 표현 가능한 문자열의 길이, -1일 경우 제한없음.
   * @type Number
   */
  this.maxLength = null;
  /**
   * 텍스트 오버플로우 속성.<br>
   * "visible" | "scroll" | "hidden" | "auto"
   * @type String
   */
  this.overflow = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */ 
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트 가로 정렬 방식.<br>
   * "left" | "center" | "right"
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트에 밑줄을 넣을때.<br>
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */    
  this.textDecoration = null;
  /**
   * 읽기 전용 여부.
   * @type String
   */
  this.readOnly = null;
  /**
   * 컨트롤의 설정된 값.
   * @type String
   */       
  this.value = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;  
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
  /**
   * 텍스트 오버플로우
   */
  this.inputOverFlow = false;
	/**
   * 한 줄에 최소 표현 가능한 문자열의 길이
   * @type Number
   */
  this.minLength = null;
	/**
	 * 사용자 정의 nullable 속성
	 * @type Boolean
	 */
  this.nullable = true;
  /**
   * 사용자정의 Max Byte 길이
   * @type Number
   */
  this.maxByteLenth = null;
  /**
   * 사용자정의 Min Byte 길이
   * @type Number
   */
  this.minByteLenth = null;
  /**
   * input element ime-mode 설정 속성
   * @type String
   */
  this.imeMode = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.TextArea);
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.createCtrl = function(poDocument){
	var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.setTemplate = function(poCtrl, poDocument){
  this.template = [];
  var vaTemplate = this.template;
	var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<textarea id='" + this.id + "_textarea' class='" + vsClass + "' ");
  vaTemplate.push("@attStrBuf");
  vaTemplate.push(" style=\"");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("\">");
  vaTemplate.push("@innStrBuf");
  vaTemplate.push("</textarea>")
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.refreshTemplate = null;
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
	this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;

  this.maxLength = this.getAttrValue("maxLength",this.maxLength);
	this.minLength = this.getAttrValue("minLength",this.minLength);
  this.value = this.getAttrValue("value",this.value);
  this.readOnly = this.getAttrValue("readonly",this.readOnly);
  this.cols = this.getAttrValue("cols", this.cols);
  this.rows = this.getAttrValue("rows", this.rows);
};
eXria.controls.xhtml.TextArea.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  vaAttStrBuf = [];
  if(this.readOnly)	vfcSetAttStrBuf(vaAttStrBuf, "readOnly", this.readOnly);
  if(this.maxLength != null) {
  	vfcSetAttStrBuf(vaAttStrBuf, "maxLength", this.maxLength);
    this.textLengthCheck(poCtrl);
  }
	 if(this.minLength != null) {
  	vfcSetAttStrBuf(vaAttStrBuf, "minLength", this.minLength);
  }
	
  vfcSetAttStrBuf(vaAttStrBuf, "cols", this.cols);
  vfcSetAttStrBuf(vaAttStrBuf, "rows", this.rows); 
  if(this.overflowX == "scroll") {
    vfcSetAttStrBuf(vaAttStrBuf, "wrap", "off");
  }
  //vaAttStrBuf.push("on")
  vaTemplate[1] = vaAttStrBuf.join("");
  
  var vnWidth = this.innerWidth - this.paddingLeft - this.paddingRight;
  if(vnWidth < 0) vnWidth = 0;
  
  var vnHeight = this.innerHeight - this.paddingTop - this.paddingBottom;
  if(vnHeight < 0) vnHeight = 0;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;padding:0px;border-style:none;top:0px;left:0px;");//overflow:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  //vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  // yhkim 2009.09.15 outer색깔에 적용
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  if(this.canvas.page.metadata.browser.ie <= 0) {     // ie가 아닌 브라우저에서 나타나는 resize 표시를 막음
    vfcSetCssStrBuf(vaCssStrBuf, "resize", "none");
  }
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);
  vaTemplate[3] = vaCssStrBuf.join("");
  
  vaTemplate[5] = this.value;
  poCtrl.innerHTML = vaTemplate.join("");
  
  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  this.template = null;
  
  this.setSubElement(poDocument);
  if(this.canvas.page.metadata.browser.gecko != 0){
    new Observe(this.subElement.textarea);
  }
}; 
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.setSubElement = function(poDocument) {
	var voCtrl = this.ctrl;
	var voSubElement = this.subElement;
	voSubElement.textarea = this.getSubCtrl("textarea", voCtrl, poDocument);
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
  
  var voTextarea = this.subElement.textarea;
  switch(psAttrName) {
    case "disabled" :
      this.setDisable(voTextarea, psAttrValue);
      break;
    case "backgroundColor" :
    case "color" :
      this.setAttrCtrl(psAttrName, psAttrValue, voTextarea);
      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.setSpecificEvents = function(poCtrl) { 
  var voTextarea = this.subElement.textarea;
  voTextarea.control = this;
  
//  this.eventManager.addListener(voTextarea, "onchange", this.mediateEvent);
  this.eventManager.addListener(voTextarea, "onblur", this.mediateEvent);
  voTextarea.onfocus = function(event) {
    if(this.control == null) return;
    var voControl = this.control;
    voControl.runEvent(event, voControl);
    voControl.checkSkipEvent(event);
  }
  this.eventManager.addListener(voTextarea, "onselect", this.mediateEvent); 
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.atkeydown = function(e) {
//  var voDf = this.df;
//  var voCtrl = this.ctrl;
//	if(this.maxLength != null) {
//    if(this.inputOverFlow) {
//      var vnKeyCode = e.keyCode; //IE
//      if(vnKeyCode == null) {
//        e.charCode; //Mozilla
//      }
//      // BackSpace, Tab, Delete Key
//      if(vnKeyCode != 8 && vnKeyCode != 9 && vnKeyCode != 46) {
//        var voText = this.subElement.textarea;
//        voText.value = this.textBuffer;
//        e.returnValue = false; //IE;
//      } else {
//        e.returnValue = true; //IE;
//      }
//    }
//  }
}; 
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.atkeyup = function(e) {
  this.textLengthCheck();
  this.textByteLengthCheck();
  if(this.inputOverFlow) {
    this.inputOverFlow = false;
    this.skipEvent = true;
    var voCtrl = this.subElement.textarea;
    this.cursorPos = this.getCursorPosition(); 
    voCtrl.blur();
    voCtrl.value = this.textBuffer;
    voCtrl.setAttribute("trimValue",this.textBuffer);
    
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.finalkeyup = function(e) {
  if(this.skipEvent) {
    var voCtrl = this.subElement.textarea;
    voCtrl.focus();
    this.setCursorPos(this.cursorPos);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.atclick = function(e) { /* 입력 length 체크 */
  var voDf = this.df;
  //if(this.maxLength != -1) {
	if(this.maxLength != null) {
    var voCtrl = this.ctrl;
    var voText = this.subElement.textarea;
    var vsText = voCtrl.value;
    if(this.inputOverFlow) {
      voText.value = this.textBuffer;
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.dofocus = function() {
  var voText = this.subElement.textarea;
  voText.focus();
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.atfocus = function(e) {
//	if(this.focused == false) this.selectText();
  this.focused = true;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.atblur = function(e) { /* 입력 length 체크 */
  var voCtrl = this.ctrl;
  var voText = this.subElement.textarea;
  this.textLengthCheck();
  this.textByteLengthCheck();
  if(this.inputOverFlow) {
    voText.value = this.textBuffer;
    this.inputOverFlow = false;
  }

  this.value = voText.value;
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != voText.value) {
    vbChanged = true;
  }
  this.onchangeInitValue = voText.value;
  if(vbChanged) {
    this.data.setData(voText.value);
    var voEvent = new eXria.event.Event(null);
    voEvent.object = this;
    if(this.onchange) this.onchange(voEvent);
  }

  this.focused = false;
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.doblur = function() {
	var voText = this.subElement.textarea;
	voText.blur();
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.checkSkipEvent = function(poEvent) {
  if(this.skipEvent) {
    this.skipEvent = false;
  }
};
///**
// * @ignore
// */
//eXria.controls.xhtml.TextArea.prototype.atchange = function(e) {
//  var voCtrl = this.ctrl;
//  var voText = this.subElement.textarea;
//  var vsRefData = voText.value;
//  this.setValue(vsRefData, voCtrl);
//};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
  var voTextarea = this.subElement.textarea;
  var voStyle = voTextarea.style;
  voStyle.cssText = "";
  
//  this.eventManager.removeListener(voTextarea, "onchange", this.mediateEvent);
  this.eventManager.removeListener(voTextarea, "onblur", this.mediateEvent);
  voTextarea.onblur = null;
  this.eventManager.removeListener(voTextarea, "onselect", this.mediateEvent); 
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  var voDf = this.df;
  var voTextareaCtrl = this.subElement.textarea;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", this.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", this.overflowX);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", this.overflowY);  
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  
  poCtrl.style.cssText = vaCssStrBuf.join("");
    
  if(this.readOnly) voTextareaCtrl["readOnly"] = this.readOnly;
  if(this.maxLength != null) {
    voTextareaCtrl["maxLength"] = this.maxLength;
    this.textLengthCheck(poCtrl);
  }
	if(voDf.minLength != null) {
    voTextareaCtrl["minLength"] = voDf.minLength;
  }
	if(this.overflowX == "scroll") voTextareaCtrl["wrap"] = "off";
	else voTextareaCtrl["wrap"] = "soft";
	if(this.className != null) voTextareaCtrl.className = this.getCSSClass(this, 1);
	
  voTextareaCtrl["cols"] = this.cols;
  voTextareaCtrl["rows"] = this.rows;

  // 2009. 09.24 리프레쉬시 textarea 영역이 넘치는 현상 방지    
  var vnWidth = this.innerWidth - this.paddingLeft - this.paddingRight;
  if(vnWidth < 0) vnWidth = 0;
  
  var vnHeight = this.innerHeight - this.paddingTop - this.paddingBottom;
  if(vnHeight < 0) vnHeight = 0;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;padding:0px;border-style:none;top:0px;left:0px;");//overflow:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  //vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "ime-mode", this.imeMode);
  if(this.canvas.page.metadata.browser.ie <= 0) {   // ie가 아닌 브라우저에서 나타나는 resize 표시를 막음
    vfcSetCssStrBuf(vaCssStrBuf, "resize", "none");
  } 
  voTextareaCtrl.style.cssText = vaCssStrBuf.join("");
  var vsValue = this.value;
  if(vsValue == null) vsValue = "";

}; 

// innerHtml로 넣을 경우 필요하다.
eXria.controls.xhtml.TextArea.prototype.getHtmlText = function(psValue) {
  if(psValue) {
	  psValue = psValue.replace(/</g, "&lt;");
	  psValue = psValue.replace(/>/g, "&gt;");
	  psValue = psValue.replace(/\n/g, "<br/>");
  }
  return psValue;
};
	
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.refreshSpecificEvents = function(poCtrl) {
	this.setSpecificEvents(poCtrl);
}
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voTextarea = this.subElement.textarea;
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
    case "visible" :
      this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
      break;
    case "disabled" :
	    this.setDisable(voCtrl, psAttrValue);
	    break;
    case "outerClassName":
    case "className":
    case "borderWidth":
    case "borderLeftWidth":
    case "borderRightWidth":
    case "borderTopWidth":
    case "borderBottomWidth":
    case "padding":
    case "paddingLeft":
    case "paddingRight":
    case "paddingTop":
    case "paddingBottom":
      this.refresh(poDocument);
      break;      
    case "maxLength":
      this.setAttrCtrl(psAttrName, psAttrValue, voTextarea);
      this.textLengthCheck(voCtrl, poDocument);
      break;
		case "minLength":
      this.setAttrCtrl(psAttrName, psAttrValue, voTextarea);
      break;
    case "value":
      this.setValue(psAttrValue, voCtrl);
      break;
    case "readOnly":
    case "textAlign":
    case "textDecoration":
    case "cols":
    case "rows":
      this.setAttrCtrl(psAttrName, psAttrValue, voTextarea);
      break;
    case "overflow":
    case "overflowX":
    case "overflowY":
      this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
      break;
    default: {
      this.refresh(poDocument);
      break;
    }
  }
};
/**
 * loadData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
//  if(this.data.instanceId == null || this.data.isRelativeRef()) return;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;
  var vsRefData = this.data.getData();
  var voTextAreaCtrl = this.subElement.textarea;
  voTextAreaCtrl.value = vsRefData;
  vsRefData = voTextAreaCtrl.value;
  voTextAreaCtrl.setAttribute("trimValue", vsRefData);
  this.setValue(vsRefData, voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
};  
/**
 * 최대 입력가능 길이를 체크합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.textLengthCheck = function(poCtrl, poDocument) {
  var voDf = this.df
  if(this.maxLength == null) return;
  var voCtrl = this.getSubCtrl("textarea", poCtrl, poDocument);
  if(voCtrl == null) return;
  var vsText = voCtrl.value;
  var vnSize = vsText.length;
  if(vnSize <= this.maxLength) return;
  var vsSubText = vsText.substr(0, this.maxLength);
  this.textBuffer = vsSubText;
  this.inputOverFlow = true;
};
/**
 * 최대 입력가능 Byte길이를 체크합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.textByteLengthCheck = function(poCtrl, poDocument) {
  var voDf = this.df
  if(this.maxByteLength == null) return;
  var voCtrl = this.getSubCtrl("textarea", poCtrl, poDocument);
  if(voCtrl == null) return;
  var vsText = voCtrl.value;
  if(this.inputOverFlow) vsText = this.textBuffer;
  var vnMultiCharLength = 0;
  if(!vsText) return;
  var vsByte = (escape(vsText)).match(/%u/g);
  if(!vsByte) vsByte = ""; 
  vnMultiCharLength = vsByte.length;
  var vnSize = (vsText.length - vnMultiCharLength) + (vnMultiCharLength*2);
  if(vnSize <= this.maxByteLength) return;
  var vnSubLength = 0;
  vnSize = vsText.length;
  var vsChar =null;
  var i = null;
  for(i = 0; i < vnSize; i++) {
    vsChar = escape(vsText.charAt(i));
    if (vsChar.length == 1) {
      vnSubLength++;
    } else if (vsChar.indexOf("%u") != -1)  {
      vnSubLength += 2;
    } else if (vsChar.indexOf("%") != -1)  {
      vnSubLength += vsChar.length/3;
    }
    if(vnSubLength > this.maxByteLength) {
      break;
    }
  }
  var vsSubText = vsText.substring(0, i);
  this.textBuffer = vsSubText;
  this.inputOverFlow = true;
};
/**
 * 텍스트를 선택상태로 만들어 줍니다.
 */
eXria.controls.xhtml.TextArea.prototype.selectText = function() {
  var voCtrl = this.ctrl;
  var voTextarea = this.subElement.textarea;
  var vnPos = voTextarea.value.length;
  if(vnPos == 0) {
  	voTextarea.focus();
  }else {
	  if (voTextarea.createTextRange) {
	    var range = voTextarea.createTextRange();
	    range.collapse(true);
	    range.moveEnd('character', vnPos);
	    range.moveStart('character', 0);
	    range.select();
	  } else if (voTextarea.selectionEnd) {
	  	voTextarea.selectionStart = 0;
	  	voTextarea.selectionEnd = vnPos;
	  }
  }
};
/**
 * 커서 위치를 지정해주는 메소드.
 * @param {Number} pnPos 커서 위치
 * @private
 */
eXria.controls.xhtml.TextArea.prototype.setCursorPos = function(pnPos) {
  var voCtrl = this.ctrl;
  var voTextarea = this.subElement.textarea;
    if (voTextarea.createTextRange) {
      var range = voTextarea.createTextRange();
      range.collapse(true);
      range.moveEnd('character', pnPos);
      range.moveStart('character', pnPos);
      range.select();
    } else if (voTextarea.selectionEnd) {
      voTextarea.selectionStart = pnPos;
      voTextarea.selectionEnd = pnPos;
    }
};
/**
 * 현재 커서 위치를 반환해주는 메소드
 * @return 현재 커서 위치
 * @type Number
 */
eXria.controls.xhtml.TextArea.prototype.getCursorPosition = function() {
  var voDocument = this.document;
  var vnCaretPos = 0; 
  var voCtrl = this.subElement.textarea; 
  // IE Support
  if (voDocument.selection) {
    var voSel = voDocument.selection.createRange ();
    voSel.moveStart ('character', -voCtrl.value.length);
    vnCaretPos = voSel.text.length;
  }
  // Firefox support
  else if (voCtrl.selectionStart || voCtrl.selectionStart == '0')
    vnCaretPos = voCtrl.selectionStart;
  return (vnCaretPos);
};
/**
 * 컨트롤에 지정된 값을 설정합니다.
 * @param {String} psText 설정 값.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.TextArea.prototype.setValue = function(psText, poCtrl, poDocument) {
  if(poCtrl == null) poCtrl = this.ctrl;
  var voCurrentCtrl = this.getSubCtrl("textarea", poCtrl, poDocument);
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psText) {
    vbChanged = true;
  }
  this.onchangeInitValue = psText;
  this.value = psText;
  voCurrentCtrl.value = psText; //eXria.controls.xhtml.Util.parseLang(psText);
  if(vbChanged) {
    this.data.setData(this.value);
    var voEvent = new eXria.event.Event(null);
    voEvent.object = this;
    if(this.onchange) this.onchange(voEvent);
  }
};
/**
 * 컨트롤에 설정된 값을 반환합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 컨트롤의 할당된 값
 * @type String
 */
eXria.controls.xhtml.TextArea.prototype.getValue = function(poDocument) {
  return this.value;
};

/**
 * 입력필드에 보여지는 텍스트값을 반환합니다.
 * @return 입력필드에 보여지는값
 * @type String
 */
eXria.controls.xhtml.TextArea.prototype.getText = function() {
  var voCurrentCtrl = this.getSubCtrl("textarea");
  return voCurrentCtrl.value;
};

/**
 * 각 속성에 따른 디폴트 값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.TextArea.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.TextArea[psAttrName];
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환합니다.
 * @return "TextArea"
 * @type String
 */
eXria.controls.xhtml.TextArea.prototype.toString = function() {
  return "TextArea";
};
