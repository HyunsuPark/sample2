/**
 * @fileoverview
 * Concreate xhtml ListBox(XHTML ListBox 컨트롤)
 * @author 조영진
 */

/**
 * Concreate xhtml ListBox
 * @author : 조영진
 * @version 2.0
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {eXria.controls.xhtml.ListBox} poControl
 * @constructor
 */
eXria.controls.xhtml.ListItem = function(psName, poValue, poControl) {
  /**
   * 아이템 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 아이템 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 아이템 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 아이템 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 아이템 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 아이템 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 아이템 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * @type Number
   * @private
   */
  this.cellSpacing = 0;
  /**
   * @type Number
   * @private
   */
  this.cellPadding = 0;
  /**
   * 아이템 배경 색상.
   * @type String
   * @private
   */
  this.backgroundColor = poControl.itemgroup.backgroundColor;
  /**
   * 아이템 텍스트 색상.
   * @type String
   * @private
   */
  this.color = poControl.color;
  /**
   * 아이템 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 아이템 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 아이템 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 아이템 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 아이템 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 아이템 라벨 명.
   * @type String
   */
  this.name = psName;
  /**
   * 아이템 설정 값.
   * @type String
   */
  this.value = poValue;
  /**
   * ListBox Control 참조 변수.
   * @type eXria.controls.xhtml.ListBox
   */
  this.parent = poControl;
  /**
   * 아이템 선택 여부.
   * @type Boolean
   */
  this.selected = false;
  /**
   * 아이템 생성 innerHTML 템플릿 저장.
   */
  this.template = null;
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   * @private
   */
  this.data = new eXria.controls.DataRefNode(this.parent);
};
/**
 * 실체화 컨트롤 생성.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListItem.prototype.create = function(poDocument) {
  var voParent = this.parent;

  if (poDocument == null)
    poDocument = this.document;
  var voCtrl = voParent.getCtrl(poDocument);

  var voTable = voCtrl.childNodes[0];
  var voTbody = voTable.childNodes[0];
  var voTr = null;
  var voTd = null;
  var voDiv = null;
  var voInput = null;
  var vsType = null;
  var vsInputId = null;
  var voText = null;
  var vsKey = null;

  if (voParent.appearance == "radio") {
    vsType = "radio";
    vsInputId = voParent.id + "_radio_";

  } else if (voParent.appearance == "checkbox") {
    vsType = "checkbox";
    vsInputId = voParent.id + "_checkbox_";
  }

  voTr = poDocument.createElement("tr");
  voTr.style.backgroundColor = this.backgroundColor;
  voTr.style.color = this.color;
  voTd = poDocument.createElement("td");
  voDiv = poDocument.createElement("div");
  voDiv.name = voParent.id + "_option";
  this.id = voParent.id + "_option_" + voParent.seqNum++;
  voDiv.setAttribute("id", this.id);

  this.setDefault(voDiv, poDocument);

  voParent.setAttrCtrl("overflow", "hidden", voDiv);
  var voInnerTable = poDocument.createElement("table");
  voParent.setAttrCtrl("cellSpacing", 0, voInnerTable);
  voParent.setAttrCtrl("cellPadding", 0, voInnerTable);
  voParent.setAttrCtrl("backgroundColor", this.backgroundColor, voDiv);
  voParent.setAttrCtrl("color", this.color, voInnerTable);
  var voInnerTbody = poDocument.createElement("tbody");
  var voInnerTr = poDocument.createElement("tr");
  var voInnerTd = poDocument.createElement("td");
  var vnWidth = voParent.innerWidth - this.borderLeftWidth - this.borderRightWidth - 2 * voParent.cellSpacing;
  if (vnWidth < 0) vnWidth = 0;
  var vnHeight = voParent.itemgroup.height - this.borderTopWidth - this.borderBottomWidth;
  if (vnHeight < 0) vnHeight = 0;
  var voOption = null;
  
//   if(voParent.isScrolled()) { vnWidth -= voParent.scrollbarWidth;
//   if(voParent.bScrolled == false) { for(var i = 0; i < voTable.rows.length;
//   i++) { voOption = voTable.rows[i].cells[0].childNodes[0];
//   voParent.setAttrCtrl("width", vnWidth, voOption); }
//   voParent.setAttrCtrl("width", voParent.innerWidth, voTable);
//   voParent.bScrolled = true; } }
  
  voParent.setAttrCtrl("width", vnWidth, voDiv);
  voParent.setAttrCtrl("height", vnHeight, voInnerTd);
  voParent.setAttrCtrl("height", vnHeight, voDiv);
  voParent.setAttrCtrl("width", voParent.innerWidth, voTd);
  voParent.setAttrCtrl("height", voParent.itemgroup.height, voTd);
  if (voParent.appearance != "normal") {
    voInput = poDocument.createElement("input");
    voInput.setAttribute("type", vsType);
    if (voParent.appearance == "radio")
      voInput.setAttribute("name", vsInputId);
    var vnIndex = voTable.rows.length;
    voInput.setAttribute("id", vsInputId + vnIndex);
    voParent.setAttrCtrl("width", voParent.itemgroup.selectorWidth, voInput);
    voInnerTd.appendChild(voInput);
  }
  voText = poDocument.createTextNode(this.name);
  voInnerTd.appendChild(voText);
  voInnerTr.appendChild(voInnerTd);
  voInnerTbody.appendChild(voInnerTr);
  voInnerTable.appendChild(voInnerTbody);
  voDiv.appendChild(voInnerTable);
//  if (this.disabled) voDiv.disabled = true;
  voTd.appendChild(voDiv);

  // [Set page context unselective]
  if (typeof voTd.onselectstart != "undefined") {
    voTr.onselectstart = function(e) {
      return false;
    };
  } else {
    voTr.onmousedown = function(e) {
      return false;
    };
  }
  // end of [Set page context unselectable]
  voTr.control = voParent;
  if (this.disabled != true)
    voTr.onclick = function(e) {
      this.control.selectList(e);
    }

  voTr.appendChild(voTd);
  voTbody.appendChild(voTr);

  var vnSize = voParent.getVisibleItemCount();
  var vnHeight = parseInt(voParent.itemgroup.height);
  vnHeight = vnSize * (vnHeight + voParent.cellSpacing)
      + voParent.cellSpacing;
  voParent.setAttrCtrl("height", vnHeight, voTable);
  if (voParent.heightBySize && vnSize > 0) {
    voParent.setAttrCtrl("height", vnHeight, voCtrl);
  }

  if (voParent.isScrolled())
    voParent.setAttrCtrl("overflowY", "scroll", voCtrl);
  else
    voParent.setAttrCtrl("overflowY", "hidden", voCtrl);

  this.setAttrs(voDiv, poDocument);

};
/**
 * 실체화 컨트롤 생성 innerHTML
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 실체화 컨트롤 생성 innerHTML
 * @type String
 * @ignore
 */
eXria.controls.xhtml.ListItem.prototype.getInnerHTML = function(poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var voParent = this.parent;
  var vaStrBuf = null;
  var vsType = null;
  var vsInputId = null;

  if (voParent.appearance == "radio") {
    vsType = "radio";
    vsInputId = voParent.id + "_radio_";

  } else if (voParent.appearance == "checkbox") {
    vsType = "checkbox";
    vsInputId = voParent.id + "_checkbox_";
  }


  var vsName = voParent.id + "_option";
  var vnSeqNum = voParent.seqNum++;
  this["id"] = vsName + "_" + vnSeqNum;

  vaTemplate.push("<tr onselectstart=\"return false;\" onmousedown=\"return false;\"><td><div id=");
  vaTemplate.push(this["id"]);
  vaTemplate.push(" name=");
  vaTemplate.push(vsName);
  vaTemplate.push(" style='overflow:hidden;");
  vaTemplate.push("@cssStrBuf"); // 5
  vaTemplate.push("'");

  vaStrBuf = [];
  if (this.disabled != true) {
    vaStrBuf.push(" onclick=\"")
    vaStrBuf.push(voParent.getEHandler(voParent.id, "selectEventList"));
    vaStrBuf.push("\"");

    vaStrBuf.push(" onmouseover=\"");
    vaStrBuf.push(voParent.getEItemHandler(voParent.id, this.id, "mouseOver"));
    vaStrBuf.push("\"");

//    vaStrBuf.push(" onkeydown=\"");
//    vaStrBuf.push(voParent.getEItemHandler(voParent.id, this.id, "keyDown"));
//    vaStrBuf.push("\"");
  }
  
  vaTemplate.push(vaStrBuf.join(""));
	var vsClass = this.parent.getCSSClass(this.parent, 1, "itemgroup");
	if(voParent.getItemClassName) {
    var vsItemClassName = voParent.getItemClassName(vnSeqNum);
    if(vsItemClassName != null) vsClass = vsClass + " " + vsItemClassName;
  } else if(voParent.itemgroup.className) {
    vsClass = vsClass + " " + voParent.itemgroup.className;
  }
  vaTemplate.push("/><table cellSpacing=0 cellPadding=0 class='" + vsClass + "' style='");
  vaTemplate.push("@cssStrBuf"); // 9
  vaTemplate.push("'><tbody><tr><td style='");
  vaTemplate.push("@cssStrBuf"); // 11
  vaTemplate.push("'>");

  vaStrBuf = [];
  if (voParent.appearance != "normal") {
    vaStrBuf.push("<input ");
    vaStrBuf.push("type=");
    vaStrBuf.push(vsType);
    if (voParent.appearance == "radio") {
      vaStrBuf.push(" name=");
      vaStrBuf.push(vsInputId);
    }
    vaStrBuf.push(" style='width:" + voParent.itemgroup.selectorWidth + "px' />");
//    voParent.setCssStrBuf(vaStrBuf, "width",
//        voParent.itemgroup.selectorWidth, "px");
  }
  
  vaTemplate.push(vaStrBuf.join(""));
  vaTemplate.push("@innStrBuf"); // 14
  vaTemplate.push("</td></tr></tbody></table></div></td></tr>");

  this.setDefault(null, voParent.document);
  this.setAttrsInn(null, null);

  var vsRet = vaTemplate.join("");
  vaStrBuf = null;
  vaTemplate = null;
  this.template = null;  
  return vsRet;
};
/**
 * setDefault
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListItem.prototype.setDefault = function(poCtrl, poDocument) {
	this.className = this.makeSpecificAttrValue(poCtrl, null, "className");
  var voData = this.data;
  if(voData.instanceId && voData.instancePath) {
    this.name = voData.getData();
  }
};
/**
 * setAttrs
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListItem.prototype.setAttrs = function(poCtrl, poDocument) {
  var voDiv = poCtrl;
  var voParent = this.parent;
  if (voDiv == null)
    voDiv = this.getCtrl(poDocument);
  voParent.setAttrCtrl("color", this.color, voDiv);
  voParent.setAttrCtrl("borderStyle", this.borderStyle, voDiv);
  voParent.setAttrCtrl("borderColor", this.borderColor, voDiv);
  voParent.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voDiv);
  voParent.setAttrCtrl("borderRightWidth", this.borderRightWidth, voDiv);
  voParent.setAttrCtrl("borderTopWidth", this.borderTopWidth, voDiv);
  voParent.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voDiv);
  var voInnerTable = voDiv.childNodes[0];
  voParent.setAttrCtrl("fontFamily", this.fontFamily, voInnerTable);
  voParent.setAttrCtrl("fontSize", this.fontSize, voInnerTable);
  voParent.setAttrCtrl("fontStyle", this.fontStyle, voInnerTable);
  voParent.setAttrCtrl("fontWeight", this.fontWeight, voInnerTable);
  var voInnerTd = voInnerTable.rows[0].cells[0];
  voParent.setAttrCtrl("verticalAlign", this.verticalAlign, voInnerTd);
  voParent.setAttrCtrl("paddingLeft", this.paddingLeft, voInnerTd);
  voParent.setAttrCtrl("paddingRight", this.paddingRight, voInnerTd);
  voParent.setAttrCtrl("paddingTop", this.paddingTop, voInnerTd);
  voParent.setAttrCtrl("paddingBottom", this.paddingBottom, voInnerTd);
};
/**
 * 실체화 부분에 속성 값 설정
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListItem.prototype.setAttrsInn = function(poCtrl,
    poDocument) {
  var voParent = this.parent;
  var vaTemplate = this.template;
  var vaAttStrBuf = null;
  var vaCssStrBuf = null;
  var vaInnStrBuf = null;
  var vfcSetAttStrBuf = voParent.setAttStrBuf;
  var vfcSetCssStrBuf = voParent.setCssStrBuf;

  var vnWidth = voParent.innerWidth - this.borderLeftWidth - this.borderRightWidth - 2 * voParent.cellSpacing;
  if (vnWidth < 0)
    vnWidth = 0;
  var vnHeight = voParent.itemgroup.height - this.borderTopWidth - this.borderBottomWidth;
  if (vnHeight < 0)
    vnHeight = 0;
  if (voParent.isScrolled()) {
    vnWidth -= voParent.scrollbarWidth;
  }
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  // vfcSetCssStrBuf(vaCssStrBuf, "width", "100%");
  // vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", voParent.itemgroup.color);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", voParent.itemgroup.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", voParent.itemgroup.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", voParent.itemgroup.borderWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", voParent.itemgroup.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", voParent.itemgroup.borderRightWidth, 
    "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", voParent.itemgroup.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", voParent.itemgroup.borderBottomWidth, 
    "px");
  vaTemplate[5] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", voParent.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", voParent.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", voParent.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", voParent.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voParent.itemgroup.backgroundColor);
  vaTemplate[9] = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  // vfcSetCssStrBuf(vaCssStrBuf, "width", "100%");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "min-height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", voParent.itemgroup.verticalAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voParent.itemgroup.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "padding", voParent.itemgroup.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", voParent.itemgroup.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", voParent.itemgroup.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", voParent.itemgroup.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", voParent.itemgroup.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
  vfcSetCssStrBuf(vaCssStrBuf, "word-break", "break-all");
  vfcSetCssStrBuf(vaCssStrBuf, "word-wrap", "break-word");

  vaTemplate[11] = vaCssStrBuf.join("");

  vaInnStrBuf = [];
  vaInnStrBuf.push(this.name);

  vaTemplate[14] = vaInnStrBuf.join("");

  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaInnStrBuf = null;
  vaTemplate = null;
};
/**
 * 아이템 새로고침 수행.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListItem.prototype.refresh = function(poDocument) {
  var voCtrl = this.parent.getCtrl(poDocument);
  if (voCtrl == null)
    return;
  this.removeAttrDefault(voCtrl, poDocument);
  this.setAttrs(voCtrl, poDocument);
};
/**
 * removeAttrDefault
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListItem.prototype.removeAttrDefault = function(poCtrl,
    poDocument) {
  this.df = {};
  var voParent = this.parent;

  // var voDiv = this.getCtrl(poDocument);
  // var voInnerTable = voDiv.childNodes[0];
  // var voInnerTd = voInnerTable.rows[0].cells[0];
  //
  // this.setAttrCtrl("verticalAlign", this.verticalAlign, voInnerTd);
};
/**
 * 아이템의 실체화 객체 반환.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return 실체화 객체
 * @type HTMLDiv
 */
eXria.controls.xhtml.ListItem.prototype.getCtrl = function(poDocument) {
  var voParent = this.parent;
  var voCtrl = voParent.lookup(this.id);

  return voCtrl;
};
/**
 * 아이템 실체화 컨트롤에 적용될 세부 속성 값을 반환하는 메소드
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListItem.prototype.makeSpecificAttrValue = function(
    poCtrl, poCssStyle, psAttrName, psCtrlAttrName) {
  var vaAttrName = psAttrName.split(".");
  
   //var voAttr = this; for(var i = 0; i < vaAttrName.length; i++) { voAttr =
   //voAttr[vaAttrName[i]]; if(voAttr == null) { break; } }
   
  var voAttr = null;
  if (voAttr != null) { // 사용자 지정 속성값이 있을 경우
    return voAttr;
  } else { // 사용자 지정 속성값이 없을 경우
    if (poCssStyle != null) { // 지정된 CSS가 있을 경우
      if (psCtrlAttrName == null)
        psCtrlAttrName = vaAttrName[vaAttrName.length - 1];
      if (poCssStyle[psCtrlAttrName] != null
          && poCssStyle[psCtrlAttrName] != "") {
        return poCssStyle[psCtrlAttrName];
      } else { // CSS에 해당 속성 값이 없을 경우
        return this.getSpecificDefaultValue(psAttrName);
      }
    } else { // 지정된 CSS가 없을 경우
      return this.getSpecificDefaultValue(psAttrName);
    }
  }
};
/**
 * @param {String} psAttrName 속성명
 * @return 지정된 속성에 대한 디폴트 값
 * @type String|Number|Object
 * @private
 */
eXria.controls.xhtml.ListItem.prototype.getSpecificDefaultValue = function(
    psAttrName) {
  var voRet = null;
  if (this.parent.itemgroup[psAttrName] != null) {
    voRet = this.parent.itemgroup[psAttrName];
  }
  return voRet;
};
/**
 * 아이템의 스타일 속성값을 일괄적으로 변경하기 위한 메소드.
 * @param {Object} poStyleObject 변경될 속성값을 담은 오브젝트
 * @return void
 * @type void
 * @example
 * var data = new eXria.data.Map();<br/>
	 data.put("name","newName");<br/>
	 data.put("fontSize","10");<br/><br/>
	 
	 var item = page.getControl("listbox").getItem(0);<br/>
	 item.poStyleObject(data.getEntries());<br/>
 */
eXria.controls.xhtml.ListItem.prototype.setItemStyle = function(poStyleObject) {
  var vsAttr = null;
  for (vsAttr in poStyleObject) {
    this[vsAttr] = poStyleObject[vsAttr];
  }
};

/**
 * ListBox 컨트롤 아이템의 공통 속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.ListBox_itemgroup = function() {
  /**
   * 아이템의 보더 두께.
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 아이템 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 아이템 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 아이템 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 아이템 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 아이템의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 아이템의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 아이템의 세로 길이.
   * @type Number
   */
  this.height = null;
  /**
   * 선택 버튼의 가로 길이.
   * @type Number
   */
  this.selectorWidth = null;
  /**
   * 아이템에 표시될 텍스트의 오버플오루 속성.
   * @type String
   */
  this.overflow = null;
  /**
   * 아이템에 표시될 텍스트의 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 아이템에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * css를 통해 지정된 텍스트 컨텐츠 오버플로우 속성.
   * @private
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 아이템에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  
  this.df = {};
};

/**
 * @class Concreate xhtml ListBox.<br>
 *        XHTML ListBox 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.ListBox 객체
 * @type eXria.controls.xhtml.ListBox
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.ListBox = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 200 : pnWidth;
  pnHeight = pnHeight == null ? 100 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth,
      pnHeight);
  // 데이타 연동 관련
  /**
   * Data 연동 객체(노드 셋 연동).
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * 인스턴스로 부터 라벨 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.labelTagName = "label";
  /**
   * 인스턴스로 부터 value 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.valueTagName = "value";
  // 데이타 연동 관련 End

  // ////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 컨트롤에 설정된 값.
   * @type String
   */
  this.value = null;
  /**
   * 선택 버튼 형태. normal, radio, checkbox (보여지는 option의 형태 : 라디오, 리스트, 콤보)
   * @type String
   */
  this.appearance = null;
  /**
   * 이전까지의 컨트롤의 선택 버튼 형태.
   * @type Boolean
   * @private
   */
  this.oldAppearance = null;
  /**
   * 아이템 다중선택 여부.
   * @type Boolean
   */
  this.multiSelect = null;
  /**
   * 이전까지 컨트롤의 다중선택 여부.
   * @type Boolean
   * @private
   */
  this.oldMultiselect = false;
  /**
   * 선택된 아이템의 인덱스.
   * @type Number
   */
  this.selectedIndex = null;
  /**
   * 앞쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.frontItems = new eXria.data.ArrayMap();
  /**
   * 인스턴스로 부터 가져올 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.itemset = new eXria.data.ArrayMap();
  /**
   * 뒤쪽에 위치할 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.backItems = new eXria.data.ArrayMap();
  /**
   * 선택된 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.selectedItems = new eXria.data.ArrayMap();
  /**
   * 리스트에 보여지는 아이템 개수.
   * @type Number
   */
  this.size = null;
  /**
   * 아이템에 포커스 위치시에 아이템 배경색상.
   * @type String
   */
  this.focusBackgroundColor = null;
  /**
   * 아이템에 마우스오버 위치시에 아이템 배경색상.
   * @type String
   */
  this.hoverBackgroundColor = null;
  /**
   * 아이템에 포커스 위치시에 아이템 텍스트색상.
   * @type String
   */
  this.focusColor = null;
  /**
   * 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트의 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;
  /**
   * 리스트 아이템 사이의 간격.
   * @type Number
   */
  this.cellSpacing = null;
  /**
   * 컨트롤의 크기를 아이템 개수를 기준으로 할지 여부.
   * @type Boolean
   */
  this.heightBySize = null;
  /**
   * 리스트 영역 계산 시 사용될 스크롤 버튼의 가로 길이.
   * @private
   * @type Number
   */
  this.scrollbarWidth = 19;
  /**
   * 리스트 영역의 오버플로우 타입('scroll' | 'hidden' | 'auto').
   * @type String
   */
  this.overflow = null;
  /**
   * 현재 리스트의 스크롤바가 표시되어 있는지 여부 체크.
   * @type Boolean
   * @private
   */
  this.bScrolled = false;
  /**
   * 아이템의 공통 속성을 저장하기 위한 오브젝트.
   * @type Object
   * @private
   */
  this.itemgroup = new eXria.controls.xhtml.ListBox_itemgroup();
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 선택된 아이템이 변경 되었는지 여부(change이벤트 발생에 이용).
   * @private
   * @type Boolean
   */
  this.bRowChanged = false;
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type Object
   * @private
   */
  this.document = null;
  /**
   * @private
   */
  this.seqNum = 0;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */  
  this.df = {};
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl,
    eXria.controls.xhtml.ListBox);
/**
 * 컨트롤 클릭 이벤트 발생 메소드. click
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.click = function() {
  this.getCtrl().click();
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  voCtrl["tabIndex"] = 0;
	if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.setTemplate = function(poCtrl,
    poDocument) {
  if (this.appearance == null)
    this.appearance = "normal";

  this.template = [];
	var vsClass = this.getCSSClass(this, 1);
  var vaTemplate = this.template;
  vaTemplate.push("<table class='" + vsClass + "' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_list_table' cellpadding=0 ");
  vaTemplate.push("@attStrBuf"); // 3
  vaTemplate.push("style='position:absolute;left:0px;top:0px;background-color:transparent;");
  vaTemplate.push("@cssStrBuf"); // 5
  vaTemplate.push("'>");
  vaTemplate.push("<tbody>");
  vaTemplate.push("@listareaStrBuf"); // 8
  vaTemplate.push("</tbody>");
  vaTemplate.push("</table>");
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.refreshSubStyle = function(poCtrl,
    poDocument) {
  this.setSubCtrlStyles(poCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.seqNum = 0;
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if (this.innerWidth < 0)
    this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if (this.innerHeight < 0)
    this.innerHeight = 0;
	this.setStyleCurrentBorderValue(this);

  if (this.value == null) this.value = [];
	
  this.selectedIndex = this.getAttrValue("selectedIndex", this.selectedIndex);
  this.multiSelect = this.getAttrValue("multiSelect", this.multiSelect);
  this.size = this.getAttrValue("size", this.size);
  this.heightBySize = this.getAttrValue("heightBySize", this.heightBySize);
  this.focusColor = this.getAttrValue("focusColor", this.focusColor);
  this.focusBackgroundColor = this.getAttrValue("focusBackgroundColor", this.focusBackgroundColor);
  var voHoverColor = this.getAttrValue("hoverBackgroundColor", this.hoverBackgroundColor);
  this.hoverBackgroundColor = ( voHoverColor == null || voHoverColor == "undefine")?"#F0F0F0":voHoverColor;
  this.cellSpacing = this.getAttrValue("cellSpacing", this.cellSpacing);
	
	var voItemgroupDf = this.itemgroup;
  voItemgroupDf.verticalAlign = this.getAttrValue("itemgroup.verticalAlign",this.itemgroup.verticalAlign);
  var voUserAttr = null;
  if(this.userAttr == "") this.userAttr = null;
  this.userAttr = this.getAttrValue("userAttr", this.userAttr);
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.labelName = voUserAttr.labelName;
    if(voUserAttr.getItemClassName) this.getItemClassName = voUserAttr.getItemClassName;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.setSpecificAttrs = function(poCtrl,
    poDocument) {
  var voTable = poCtrl.childNodes[0];
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
//  if (this.disabled)
//    poCtrl["disabled"] = true;

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if (this.visible == false)vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth,"px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth,"px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", "hidden");
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaAttStrBuf = [];
  vfcSetAttStrBuf(vaAttStrBuf, "cellSpacing", this.cellSpacing);
  vaTemplate[3] = vaAttStrBuf.join("");

  vaCssStrBuf = null;
  vaAttSTrBuf = null;
};

/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.atclick = function(e) {
  var voDiv = e.target;
  while (voDiv.nodeName != "DIV") {
    voDiv = voDiv.parentNode;
  }
  if (voDiv == null) return;
  var vsDivId = voDiv.id;
  var vsId = this.id + "_option";
  if(vsDivId.indexOf(vsId) == -1) return;

  this.document.getElementById(this.id).focus();
  
  if (this.bRowChanged
      || (this.appearance == "checkbox" && this.multiSelect == true)) {
    this.dochange(e, this);
  }
};

/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.atkeydown = function(e) {
  this.keyDown(e);
  
  var voDiv = e.target;
  while (voDiv.nodeName != "DIV") {
    voDiv = voDiv.parentNode;
  }
  if (voDiv == null || voDiv.name != this.id + "_option")
    return;

  if (this.bRowChanged
      || (this.appearance == "checkbox" && this.multiSelect == true)) {
    this.dochange(e, this);
  }  
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.finalkeydown = function(e) {
	this.doFinalKey(e);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.finalkeypress = function(e) {
	this.doFinalKey(e);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.doFinalKey = function(e){
  var voEvent = new eXria.event.Event(e, this.window);
  var vnKeyCode = e.keyCode;

  if(vnKeyCode == '38' || vnKeyCode == '40' ||vnKeyCode == '16' || vnKeyCode == '17'){//화살표 위, 아래, shift, ctrl
    voEvent.stopEvent();
  }	
};

/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.atmouseover = function(e) {
  if (this.eventType == "item" && this.eventObject != null) {
    var voDocument = this.document;
    var voItem = this.eventObject;

    voItemCtrl = voDocument.getElementById(voItem.id);

    var voStyle;
    
    if(!!voItemCtrl)
     voStyle = voItemCtrl.style;

    var voCollection = this.selectedItems.getKeyCollection().iterator();
    var voData = null;
    var vbSelected = false;

    while (voCollection.hasNext()) {
      var vnIndex = voCollection.next();
      var voData = this.getItem(vnIndex);

      if (voData.id == voItem.id)
        vbSelected = true;
    }

    if (!vbSelected)
      voStyle.backgroundColor = this.hoverBackgroundColor;// eXria.controls.xhtml.Default.ListBox.focusBackgroundColor;//"#F1F1EB";//this.df.focusBackgroundColor;
  }
};

/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.dochange = function(poEvent, poControl) {
  if (poControl.atchange) {
    poControl.atchange(poEvent);
  }
  if (poControl.cochange) {
    poControl.cochange(poEvent);
  }
  if (poControl.onchange) {
    poControl.onchange(poEvent);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.doitemchange = function(poEvent, poControl) {
	if (poControl.atitemchange) {
		poControl.atitemchange(poEvent);
	}
	if (poControl.coitemchange) {
		poControl.coitemchange(poEvent);
	}
	if (poControl.onitemchange) {
		poControl.onitemchange(poEvent);
	}
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.atchange = function(poEvent) {
  // if(this.data.instanceId) this.data.setData(this.getSelectedValue());
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.removeSpecificDefaults = function(
    poCtrl, poDocument) {
//  this.df = {};
//  this.itemgroup.df = {};
//  this.template = null;
  // var voTable = this.lookup(this.id + "_list_table");
  // var voDiv = null;
  // for(var i = 0; i < voTable.rows.length; i++) {
  // voDiv = voTable.rows[i].cells[0].firstChild;
  // voDiv.onclick = null;
  // }
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.refreshSpecificAttrs = function(poCtrl,
    poDocument) {
  this.setSpecificAttrs(poCtrl, poDocument);
  // this.refreshList(poCtrl, poDocument);
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.setAttrSubCtrl = function(psAttrName,
    psAttrValue, poCtrl) {
  if (poCtrl.id != this.id)
    return;

  var voTable = poCtrl.childNodes[0];

  switch (psAttrName) {
  case "disabled":
    this.setDisable(poCtrl, psAttrValue);
    break;
  case "width":
    this.setAttrCtrl("width", psAttrValue, voTable);
    break;
  case "height":
    this.setAttrCtrl("height", psAttrValue, voTable);
    break;
  // case "borderWidth" :
  // this.setAttrCtrl("width", this.innerWidth, voTable);
  // this.setAttrCtrl("height", this.innerHeight, voTable);
  // break;
  }
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.applyAttrRebuild = function(psAttrName,
    psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voTable = voCtrl.childNodes[0];
  var voStyle = null;
  var vsSubAttrName = null;
  var voDf = this.df;
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for ( var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }

  switch (psAttrName) {
//  case "disabled":
//    this.setDisable(voCtrl, psAttrValue);
//    break;
  case "backgroundColor":
  case "color":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    var voDiv = null;
    for ( var i = 0; i < voTable.rows.length; i++) {
      voDiv = voTable.rows[i].cells[0].childNodes[0];
      if (this.selectedItems.get(i) == null) {
        this.restoreRowColor(voDiv);
      }
    }
    break;
  case "visible":
  case "borderStyle":
  case "borderColor":
  case "fontFamily":
  case "fontSize":
  case "fontStyle":
  case "fontWeight":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "left":
  case "top":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "borderLeftWidth":
  case "borderRightWidth":
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voCtrl);
    // this.setListWidth();
  case "width":
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if (this.innerWidth < 0)
      this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.refreshList(voCtrl, poDocument);
    break;
  case "borderTopWidth":
  case "borderBottomWidth":
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voCtrl);
  case "height":
    this.innerHeight = this.height - this.borderTopWidth
        - this.borderBottomWidth;
    if (this.innerHeight < 0)
      this.innerHeight = 0;
    if (!this.heightBySize) {
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      // this.refreshList(voCtrl, poDocument);
    }
    this.refreshList(voCtrl, poDocument);
    break;
  case "borderWidth":
  	this.borderLeftWidth = this.borderWidth;
  	this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if (this.innerWidth < 0)
      this.innerWidth = 0;
    this.innerHeight = this.height - this.borderTopWidth
        - this.borderBottomWidth;
    if (this.innerHeight < 0)
      this.innerHeight = 0;
    // border
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this
        .setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    // width
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    // height
    if (!this.heightBySize) {
      this.setAttrCtrl("height", this.innerHeight, voCtrl);
      // this.refreshList(voCtrl, poDocument);
    }
    this.setListWidth();
    break;
  case "size":
    if (this.heightBySize && this.size > 0) {
      var vnHeight = this.itemgroup.height;
      vnHeight = this.size * (vnHeight + this.cellSpacing) + this.cellSpacing;
      this.setAttrCtrl("height", vnHeight, voCtrl);
    }
    break;
  case "cellSpacing" :
    if (psAttrName == "cellSpacing") {
      voTable.setAttribute("cellSpacing", this.cellSpacing);
    }
    break;
  case "focusBackgroundColor":
  case "focusColor":
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    var voDiv = null;
    for ( var i = 0; i < voTable.rows.length; i++) {
      voDiv = voTable.rows[i].cells[0].childNodes;
      if (this.selectedItems.get(i) == null) {
        this.restoreRowColor(voDiv);
      }
    }
    break;
  case "multiSelect":
    if (this.appearance == "radio") {
      this.multiSelect = false;
      this.multiSelect = false;
    }
    if (this.multiSelect != this.oldMultiselect) {
      this.refreshList(voCtrl, poDocument);
    }
    break;
  case "appearance":
    if (this.appearance == "radio") {
      this.multiSelect = false;
      this.multiSelect = false;
    }
    if (this.appearance != this.oldAppearance) {
      this.refreshList(voCtrl, poDocument);
    }
    break;
  case "itemgroup.borderWidth":
  case "itemgroup.borderLeftWidth":
  case "itemgroup.borderRightWidth":
  case "itemgroup.borderTopWidth":
  case "itemgroup.borderBottomWidth":
  case "itemgroup.height":
  case "itemgroup.padding":
  case "itemgroup.paddingLeft":
  case "itemgroup.paddingRight":
  case "itemgroup.paddingTop":
  case "itemgroup.paddingBottom":
  case "itemgroup.selectorWidth":
  case "itemgroup.verticalAlign":
    this.refreshList(voCtrl, poDocument);
    break;
  default:
    this.refresh(poDocument);
    break;
  }
};
/**
 * loadData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.loadData = function(poDocument) {
  if(this.canvas.page.metadata.modelType == eXria.form.ModelType.JRE) {
    this.loadDataFromPluginInstance(poDocument);
    return;
  }
  
  if (poDocument == null)
    poDocument = this.document;
  var voCtrl = this.getCtrl(poDocument);
  this.itemset.clear();

  var vsRefValue = this.value;
  var vaValue = [];
  if (this.data.instanceId != null && this.data.instancePath != null)
    vsRefValue = this.data.getData();
  if (vsRefValue != null) {
    this.selectedIndex = -1;
    this.selectedIndex = -1;
    if (vsRefValue instanceof Array)
      vaValue = vsRefValue;
    else
      vaValue.push(vsRefValue);
  }
  this.value = vaValue;
  this.value = vaValue;
  if (this.data.nodesetInstanceId == null
      || this.data.nodesetInstancePath == null)
    return;
  var voCollectionNode = this.data.getNodesetData2();
  if (voCollectionNode == null)
    return;
  var vnLoop = voCollectionNode.getLength();
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  for ( var i = 0; i < vnLoop; i++) {
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
    vsLabelNode = voMapNode.get(this.labelTagName);
    vsValueNode = voMapNode.get(this.valueTagName);
    voItem = this.addToItemset(vsLabelNode, vsValueNode, poDocument);

    for ( var j = 0; j < vaValue.length; j++) {
      if (vaValue[j] == vsValueNode) {
        voItem.selected = true;
        break;
      }
    }
  }
};
/**
 * loadDataFromPluginInstance
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.loadDataFromPluginInstance = function(poDocument) {
  if (poDocument == null)
    poDocument = this.document;
  var voCtrl = this.getCtrl(poDocument);
  this.itemset.clear();

  var vsRefValue = this.value;
  var vaValue = [];
  if (this.data.instanceId != null && this.data.instancePath != null)
    vsRefValue = this.data.getData();
  if (vsRefValue != null) {
    this.selectedIndex = -1;
    this.selectedIndex = -1;
    if (vsRefValue instanceof Array)
      vaValue = vsRefValue;
    else
      vaValue.push(vsRefValue);
  }
  this.value = vaValue;
  this.value = vaValue;
  if (this.data.nodesetInstanceId == null
      || this.data.nodesetInstancePath == null)
    return;
  var voCollectionNode = this.data.getNodesetStr();
  if (voCollectionNode == null)
    return;
  voCollectionNode = eval(voCollectionNode);
  var vnLoop = voCollectionNode.length;
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  for ( var i = 0; i < vnLoop; i++) {
    voMapNode = voCollectionNode[i];
    vsLabelNode = voMapNode[this.labelTagName];
    vsValueNode = voMapNode[this.valueTagName];
    voItem = this.addToItemset(vsLabelNode, vsValueNode, poDocument);

    for ( var j = 0; j < vaValue.length; j++) {
      if (vaValue[j] == vsValueNode) {
        voItem.selected = true;
        break;
      }
    }
  }
};
/**
 * loadComplete
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.loadComplete = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  var voDf = this.df;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vaStrbuf = null;

  if (this.value.length > 0)
    this.clearSelected();

  
//   var vnSize = this.getVisibleItemCount(); var vnHeight =
//   parseInt(this.itemgroup.df.height); vnHeight = vnSize * (vnHeight +
//   this.df.cellSpacing) + this.df.cellSpacing; if(this.df.heightBySize &&
//   vnSize > 0) { this.setAttrCtrl("height", vnHeight, voCtrl); }
   
  vaStrBuf = [];
  // vfcSetCssStrBuf(vaStrBuf, "height", this.height, "px");
  vfcSetCssStrBuf(vaStrBuf, "width", this.innerWidth, "px");
  vaTemplate[5] = vaStrBuf.join("");

  vaTemplate[8] = this.getListInnerHTML();

  voCtrl.innerHTML = vaTemplate.join("");

  vaStrBuf = null;
  // vaTemplate = null;
  // this.template = null;

  var vnListHeight = this.getListScrollHeight(poDocument);
  if (this.heightBySize && vnListHeight > 0)
    this.setAttrCtrl("height", vnListHeight, voCtrl);
  if (this.isScrolled()) {
    this.setAttrCtrl("overflowY", "scroll", voCtrl);
  } else {
    this.setAttrCtrl("overflowY", "hidden", voCtrl);
  }
  this.setListWidth();

  this.checkSelected(voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
  this.loadComplete(poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.getListScrollHeight = function(
    poDocument) {
  if (poDocument == null)
    poDocument = this.document;
  var voCtrl = this.getCtrl(poDocument);
  var voTable = this.lookup(this.id + "_list_table");
  return voTable.scrollHeight;
};
/**
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.setListWidth = function() {
  var voTable = this.lookup(this.id + "_list_table");
  if (this.isScrolled()) {
    voTable.style.width = (this.innerWidth - this.scrollbarWidth) + "px";
  } else {
    voTable.style.width = this.innerWidth + "px";
  }
};
/**
 * 로딩된 아이템을 새로고침하기 위한 메소드(아이템들을 리로딩 하지 않는다는 점에서 refresh메소드와 구별됨).
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 * @ignore
 */
eXria.controls.xhtml.ListBox.prototype.repaint = function(poDocument) {
  if (poDocument == null)
    poDocument = this.document;
  var voCtrl = this.getCtrl(poDocument);
  this.removeUIGeneralDefaults(voCtrl, poDocument);
  this.removeSpecificDefaults(voCtrl, poDocument);
  this.refreshTemplate(voCtrl, poDocument);
  this.refreshUIGeneralDefaults(voCtrl, poDocument);
  this.refreshSpecificDefaults(voCtrl, poDocument);
  
  this.refreshSpecificAttrs(voCtrl, poDocument);
  
  this.loadComplete(poDocument);
};
/**
 * itemset에 아이템 추가 메소드
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ListItem
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.addToItemset = function(psName, poValue,
    poDocument) {
  var voListItem = new eXria.controls.xhtml.ListItem(psName, poValue, this);
  this.itemset.put(poValue, voListItem);
  return voListItem;
};
/**
 * frontItems혹은 backItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psType 아이템 타입("front|back")
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ListItem
 * @example addItem("front", "라벨명", "value", 3);
 */
eXria.controls.xhtml.ListBox.prototype.addItem = function(psType, psName, poValue, pnIndex, poDocument) {
  var voListItem = new eXria.controls.xhtml.ListItem(psName, poValue, this);
  var voItems = null;
  if (psType == "front") voItems = this.frontItems;
  else voItems = this.backItems;

  if (pnIndex == null) {
    voItems.put(poValue, voListItem);
  } else {
    var voNewItems = new eXria.data.ArrayMap();
    var vnIndex = 0;
    var voIterator = voItems.getKeyCollection().iterator();
    var vsKey = null;
    while (voIterator.hasNext()) {
      if (vnIndex == pnIndex)
        voNewItems.put(poValue, voListItem);
      vsKey = voIterator.next();
      voNewItems.put(vsKey, voItems.get(vsKey));
      vnIndex++;
    }
    if (psType == "front")
      this.frontItems = voNewItems;
    else
      this.backItems = voNewItems;
  }

  // var voCtrl = this.getCtrl(poDocument);
  // if(voCtrl != null) {
  // voListItem.create(poDocument);
  // }

  return voListItem;
};
/**
 * frontItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ListItem
 * @example addItemFront("라벨명", "value", 3);
 */
eXria.controls.xhtml.ListBox.prototype.addItemFront = function(psName, poValue,
    pnIndex, poDocument) {
  var voItem = this.addItem("front", psName, poValue, pnIndex, poDocument);
  return voItem;
};
/**
 * backItems에 아이템을 추가하기 위한 메소드.
 * @param {String} psName 아이템 라벨 명
 * @param {String} poValue 아이템 설정 값
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 리스트 아이템
 * @type eXria.controls.xhtml.ListItem
 * @example addItemBack("라벨명", "value", 3);
 */
eXria.controls.xhtml.ListBox.prototype.addItemBack = function(psName, poValue,
    pnIndex, poDocument) {
  var voItem = this.addItem("back", psName, poValue, pnIndex, poDocument);
  return voItem;
};
/**
 * 지정된 인덱스에 해당하는 아이템 반환.
 * @param {Number} pnIndex 전체 리스트에서의 인덱스
 * @return 인덱스로 지정된 객체
 * @type eXria.controls.xhtml.ListItem
 */
eXria.controls.xhtml.ListBox.prototype.getItem = function(pnIndex) {
  var voIterator = null;
  var vnIndex = 0;
  var voItem = null;

  voIterator = this.frontItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (pnIndex == vnIndex)
      return voItem;
    vnIndex++;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (pnIndex == vnIndex)
      return voItem;
    vnIndex++;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (pnIndex == vnIndex)
      return voItem;
    vnIndex++;
  }

  return null;
};
/**
 * 지정된 라벨명에 해당하는 아이템을 반환하는 메소드.
 * @param {String} psName 아이템 라벨 값
 * @return 인덱스로 지정된 eXria.controls.xhtml.ListItem 객체
 * @type eXria.controls.xhtml.ListItem
 */
eXria.controls.xhtml.ListBox.prototype.getItemByName = function(psName) {
  var voItems = null;
  var voItem = null;
  var voRet = null;
  var vbBreak = false;
  var vaItems = [ this.frontItems, this.itemset, this.backItems ];
  for ( var i = 0; i < vaItems.length; i++) {
    voItems = vaItems[i].getValueCollection().iterator();
    while(voItems.hasNext()){
      voItem = voItems.next();
      if (voItem.name == psName) {
        voRet = voItem;
        vbBreak = true;
        break;
      }
    }
    if (vbBreak)
      break;
  }

  return voRet;
};

/**
 * 지정된 값을 포함한 아이템 얻어오기 위한 메소드.
 * @param {String} psId 검색할 아이디
 * @return 지정된 값을 포함한 아이템
 * @type eXria.controls.xhtml.ListItem
 */
eXria.controls.xhtml.ListBox.prototype.getItemById = function(psId) {
  var voItem = null;
  var voIterator = this.frontItems.getValueCollection().iterator();

  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.id == psId)
      return voItem;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.id == psId)
      return voItem;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.id == psId)
      return voItem;
  }
  return null;
};

/**
 * 지정된 값을 포함한 아이템 얻어오기 위한 메소드.
 * @param {String} psValue 검색할 값
 * @return 지정된 값을 포함한 아이템
 * @type eXria.controls.xhtml.ListItem
 */
eXria.controls.xhtml.ListBox.prototype.getItemByVal = function(psValue) {
  var voItem = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.value == psValue)
      return voItem;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.value == psValue)
      return voItem;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.value == psValue)
      return voItem;
  }
  return null;
};
/**
 * 아이템의 selected속성을 체크하여 컨트롤의 아이템 선택 작업 수행.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 선택된 값이 있는지 여부
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.checkSelected = function(poCtrl,
    poDocument) {
  var voCtrl = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  var vaIndex = [];
  var i = -1;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    i++;
    if (voItem.visible == false)
      continue;
    if (voItem.selected == true)
      vaIndex.push(i);
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    i++;
    if (voItem.visible == false)
      continue;
    if (voItem.selected == true)
      vaIndex.push(i);
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    i++;
    if (voItem.visible == false)
      continue;
    if (voItem.selected == true)
      vaIndex.push(i);
  }
  if (vaIndex.length == 0 && this.selectedIndex != -1)
    vaIndex.push(this.selectedIndex);
  this.select(vaIndex, poCtrl, poDocument, true);

  if (vaIndex.length > 0)
    return true;
  return false;
};
/**
 * 리스트 영역의 스크롤 버튼이 표시되었는지 여부 반환.
 * @return 스크롤 버튼의 유무
 * @type Boolean
 */
eXria.controls.xhtml.ListBox.prototype.isScrolled = function() {
  var vbScrolled = false;
  var voDf = this.df;
  if (this.overflow == "scroll")
    return true;
  if (this.overflow == "hidden")
    return false;
  /*
   * var vnSize = this.getVisibleItemCount(); if(this.heightBySize) {
   * if(this.size < vnSize) vbScrolled = true; } else { var vnHeight =
   * this.itemgroup.df.height; vnHeight = vnSize * (vnHeight + this.cellSpacing) +
   * this.cellSpacing; if(this.innerHeight < vnHeight) vbScrolled = true; }
   */
  if (this.ctrl.clientHeight < this.ctrl.scrollHeight)
    vbScrolled = true;

  return vbScrolled;
};
/**
 * 리스트 아이템 제거.
 * @param {String} psName 아이템 라벨명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListBox.prototype.removeItem = function(psName, poDocument) {
  this.frontItems.remove(psName);
  this.itemset.remove(psName);
  this.backItems.remove(psName);
  var vnIndex = this.getIndex(psName);
  this.selectedItems.remove(vnIndex);
  // var voCtrl = this.getCtrl(poDocument);
  // this.refreshList(voCtrl, poDocument);
};
/**
 * 모든 리스트 아이템 제거.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListBox.prototype.removeAll = function(poDocument) {
  this.frontItems.clear();
  this.itemset.clear();
  this.backItems.clear();
  this.selectedItems.clear();
  var voCtrl = this.getCtrl(poDocument);
  this.refreshList(voCtrl, poDocument);
};
/**
 * 모든 컨트롤의 selected속성을 초기화(false값 설정).
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListBox.prototype.clearSelected = function() {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voComboItem = null;
  while (voIterator.hasNext()) {
    voComboItem = voIterator.next();
    voComboItem.selected = false;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voComboItem = voIterator.next();
    voComboItem.selected = false;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voComboItem = voIterator.next();
    voComboItem.selected = false;
  }
  this.selectedIndex = -1;
};

// eXria.controls.xhtml.ListBox.prototype.refreshList = function(poCtrl,
// poDocument) {
// var voDf = this.df;
// this.bScrolled = false;
// //this.selectedItems.clear();
// //this.selectedIndex = -1;
// this.oldMultiselect = this.multiSelect;
// this.oldAppearance = this.appearance;
//  
// if(this.appearance == "radio") {
// this.multiSelect = false;
// this.multiSelect = false;
// }
//  
// if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
// var voTable = poCtrl.childNodes[0];
// var voTbody = voTable.childNodes[0];
// this.clearCtrlNode(voTbody);
// for(var i = 0; i < voTbody.childNodes.length;) {
// voTbody.removeChild(voTbody.childNodes[i]);
// }
//  
// voTable.setAttribute("cellSpacing", this.cellSpacing + "px");
//
// var vsKey = null;
// var voIterator = this.frontItems.getValueCollection().iterator();
// var voListItem = null;
// var vaIndex = new Array();
// while(voIterator.hasNext()) {
// voListItem = voIterator.next();
// if(voListItem.visible == false) continue;
// voListItem.create(poDocument);
// for(var j = 0; j < this.value.length; j++) {
// if(this.value[j] == voListItem.value) {
// voListItem.selected = true;
// break;
// }
// }
// }
// voIterator = this.itemset.getValueCollection().iterator();
// while(voIterator.hasNext()) {
// voListItem = voIterator.next();
// if(voListItem.visible == false) continue;
// voListItem.create(poDocument);
// for(var j = 0; j < this.value.length; j++) {
// if(this.value[j] == voListItem.value) {
// voListItem.selected = true;
// break;
// }
// }
// }
// voIterator = this.backItems.getValueCollection().iterator();
// while(voIterator.hasNext()) {
// voListItem = voIterator.next();
// if(voListItem.visible == false) continue;
// voListItem.create(poDocument);
// for(var j = 0; j < this.value.length; j++) {
// if(this.value[j] == voListItem.value) {
// voListItem.selected = true;
// break;
// }
// }
// }
//  
// if(this.isScrolled()) this.setAttrCtrl("overflowY", "scroll", poCtrl);
// else this.setAttrCtrl("overflowY", "hidden", poCtrl);
// };
/**
 * 리스트 영역 새로 고침.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListBox.prototype.refreshList = function(poDocument) {
  this.repaint(poDocument);
};
/**
 * 리스트 영역 innerHTML 반환.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 리스트 영역 innerHTML
 * @type String
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.getListInnerHTML = function(poCtrl,
    poDocument) {
  var voDf = this.df;
  this.bScrolled = false;
  // this.selectedItems.clear();
  // this.selectedIndex = -1;
  this.oldMultiselect = this.multiSelect;
  this.oldAppearance = this.appearance;

  if (this.appearance == "radio") {
    this.multiSelect = false;
    this.multiSelect = false;
  }

  var vaStrBuf = [];
  var vsKey = null;
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voListItem = null;
  var vaIndex = new Array();
  while (voIterator.hasNext()) {
    voListItem = voIterator.next();
    if (voListItem.visible == false)
      continue;
    vaStrBuf.push(voListItem.getInnerHTML());
    for ( var j = 0; j < this.value.length; j++) {
      if (this.value[j] == voListItem.value) {
        voListItem.selected = true;
        break;
      }
    }
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voListItem = voIterator.next();
    if (voListItem.visible == false)
      continue;
    vaStrBuf.push(voListItem.getInnerHTML());
    for ( var j = 0; j < this.value.length; j++) {
      if (this.value[j] == voListItem.value) {
        voListItem.selected = true;
        break;
      }
    }
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voListItem = voIterator.next();
    if (voListItem.visible == false)
      continue;
    vaStrBuf.push(voListItem.getInnerHTML());
    for ( var j = 0; j < this.value.length; j++) {
      if (this.value[j] == voListItem.value) {
        voListItem.selected = true;
        break;
      }
    }
  }

  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * 선택된 아이템의 배경 색상 변경.
 * @param {HTMLDiv} poDiv 아이템의 실체화 객체
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.changeRowColor = function(poDiv) {
  var voTable = poDiv.childNodes[0];
  this.setAttrCtrl("backgroundColor", this.focusBackgroundColor, poDiv);
  this.setAttrCtrl("color", this.focusColor, voTable);
};
/**
 * 변경된 아이템의 색상을 원래대로 되돌림.
 * @param {HTMLDiv} poDiv 아이템의 실체화 객체
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.restoreRowColor = function(poDiv) {
  var voTable = poDiv.childNodes[0];
  if(this.backgroundColor) this.setAttrCtrl("backgroundColor", this.backgroundColor, poDiv);
	else this.setAttrCtrl("backgroundColor", "", poDiv);
  if(this.color) this.setAttrCtrl("color", this.color, voTable);
	else this.setAttrCtrl("color", "", voTable);
};

/**
 * selectEventList
 * @param event
 * @return void
 * @type void
 * @private
 **/
eXria.controls.xhtml.ListBox.prototype.selectEventList = function(event) {
  var voEvent = null;

  if (event.type == "click") {
    voEvent = new eXria.event.Event(event, this.window);
    this.selectList(voEvent);
  } else {
    voEvent = event;
    this.selectListKeyDown(voEvent);
  }
};
/**
 * 아이템 선택 시 호출된는 메소드.
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.selectList = function(poEvent) {
  // var voEvent = new eXria.event.Event(e, this.window);
  poEvent.object = this.control;
  var voTr = null;
  var voDiv = null;
  var voInput = null;
  
  this.unselectListItem(poEvent, poEvent.ctrlKey || poEvent.shiftKey);

  voDiv = poEvent.target;
  while (voDiv.nodeName.toUpperCase() != "DIV") {
    voDiv = voDiv.parentNode;
  }
  if (voDiv == null || voDiv["id"].indexOf(this.id + "_option") == -1)
    return;

  voTr = voDiv.parentNode.parentNode;
  
  var vnCurrentIdx = voTr.rowIndex;
	var vnLastIdx = this.selectedIndex;
	var vnFirstIdx = this.getFirstItemIndex();
	
  if (this.selectedIndex != voTr.rowIndex){//선택된 아이템이 마지막에 선택되었던 아이템과 같은지 체크
    this.bRowChanged = true;
    this.doitemchange(poEvent, this);
  }
  else
    this.bRowChanged = false;
  
  var voItem = this.getItem(vnCurrentIdx);
  if (this.appearance != "normal")
    voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;

  if(poEvent.shiftKey && this.selectedItems.size() != 0){
  	if(!this.bRowChanged)return;	//마지막에 선택한 아이템과 동일한 아이템을 선택했을 때 리턴
  	
  		this.clearSelected();
  		var vnTemp = vnFirstIdx;
  		var vbChk = false;
  		
  		while(vnCurrentIdx != vnTemp){
  			if(vbChk){
	  			if(vnCurrentIdx > vnTemp)++vnTemp;
	  	    else --vnTemp;
  			}
  			
				if (voInput != null)
  	      voInput.checked = true;
				if(this.selectedItems.get(vnTemp) == undefined){
	  	    this.selectedItems.put(vnTemp, "");
				}
				
				this.getItem(vnTemp).selected = true;
				
  	    this.selectedIndex = vnTemp;
  	    this.selectedIndex = vnTemp;
  	    
  	    vbChk = true;
  		}
  		
  		if(vnFirstIdx == vnCurrentIdx){
  			if (voInput != null)
  	      voInput.checked = true;
				
				this.getItem(vnFirstIdx).selected = true;
				
  	    this.selectedIndex = vnFirstIdx;
  	    this.selectedIndex = vnFirstIdx;
  		}
  }else{
  	if (this.selectedItems.get(vnCurrentIdx) == undefined) {//이전에 선택이 안되어 있는 아이템일 경우
      if (voInput != null)
        voInput.checked = true;
      this.selectedItems.put(voTr.rowIndex, "");
      voItem.selected = true;
      this.selectedIndex = vnCurrentIdx;
      this.selectedIndex = vnCurrentIdx;

    } else {//이전에 선택이 되어 있는 아이템 선택 해제
      if (voInput != null)
        voInput.checked = false;
      this.selectedItems.remove(vnCurrentIdx);
      voItem.selected = false;
    }
  }

	this.checkSelected();
	// this.value = this.getSelectedValue(true);
	// this.data.setData(this.value);
	if (this.bRowChanged)
	  this.dochange(poEvent, this);
};

/**
 * shift로 다중선택된 아이탬중 기준이 되는 처음 선택된 아이템 index 리턴
 * @return 아이템 index
 * @type Number
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.getFirstItemIndex = function(){
	var voIterator = this.selectedItems.getKeyCollection().iterator();
	var vnIdx = null;
	
	if(voIterator.hasNext()){
		vnIdx = voIterator.next();
		
		if(vnIdx == this.selectedIndex)
			vnIdx = voIterator.collection[voIterator.collection.length-1];
	}
	
	return vnIdx;
};


/**
 * 기존선택 되어있던 아이템 선택 해제
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.unselectListItem = function(poEvent, pbMultiSelectKey){
	var voTr = null;
  var voDiv = null;
  var voInput = null;
  
  if (this.multiSelect == false || this.appearance != "normal"
    || (this.appearance == "normal" && pbMultiSelectKey == false)
    || this.selectedItems.size() == 0) {
	  var voTable = this.lookup(this.id + "_list_table");
	  var vnTableLen = voTable.rows.length;
	  
	  if (this.multiSelect == false
	      || (this.appearance == "normal" && pbMultiSelectKey == false)
	      || this.selectedItems.size() == 0) {
	    this.selectedItems.clear();
	    if (this.appearance != "normal") {// 체크박스, 라디오 타입일 경우
	      for ( var i = 0; i < vnTableLen; i++) {
	        voDiv = voTable.rows[i].cells[0].childNodes[0];
	        voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
	        voInput.checked = false;
	      }
	    }
	  }
	  this.clearSelected();
	  for ( var i = 0; i < vnTableLen; i++) {
	    voDiv = voTable.rows[i].cells[0].childNodes[0];
	    this.restoreRowColor(voDiv);
	  }
  }
};

/**
 * 아이템 선택 시 호출된는 메소드.(key event)
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.selectListKeyDown = function(poEvent) {
  // var voEvent = new eXria.event.Event(e, this.window);
  poEvent.object = this.control;
  var voTr = null;
  var voDiv = null;
  var voInput = null;
  
  this.unselectListItem(poEvent, poEvent.shiftKey);

  voDiv = poEvent.target;
  while (voDiv.nodeName.toUpperCase() != "DIV") {
    voDiv = voDiv.parentNode;
  }
  if (voDiv == null || voDiv["id"].indexOf(this.id + "_option") == -1)
    return;

  voTr = voDiv.parentNode.parentNode;
  if (this.selectedIndex != voTr.rowIndex){
    this.bRowChanged = true;
    this.doitemchange(poEvent, this);
  }
  else
    this.bRowChanged = false;
  var voItem = this.getItem(voTr.rowIndex);
  if (this.appearance != "normal")
    voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
  if (this.selectedItems.get(voTr.rowIndex) == undefined) {
    if (voInput != null)
      voInput.checked = true;
    this.selectedItems.put(voTr.rowIndex, "");
    this.changeRowColor(voDiv);
    voItem.selected = true;

  } else {
    if (voInput != null)
      voInput.checked = false;
    
    if(poEvent.shiftKey == true ){
      this.getItem(this.selectedIndex).selected = false;
      this.selectedItems.remove(this.selectedIndex);
    }else{
      this.selectedItems.remove(voTr.rowIndex);
      //this.restoreRowColor(voDiv);
      voItem.selected = false;
    }
  }
  this.selectedIndex = voTr.rowIndex;
  this.selectedIndex = voTr.rowIndex;

  this.checkSelected();
  // this.value = this.getSelectedValue(true);
  // this.data.setData(this.value);
  if (this.bRowChanged)
    this.dochange(poEvent, this);
};
/**
 * 마우스 오버시 호출된는 메소드.
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.mouseOver = function(e, psItemId) {
  this.eventType = "item";
  this.eventObject = this.getItemById(psItemId);

  var voDiv = null;
  var voInput = null;

  var voTable = this.lookup(this.id + "_list_table");

  var voData = null;

  for ( var i = 0; i < voTable.rows.length; i++) {
    voDiv = voTable.rows[i].cells[0].childNodes[0];

    var voCollection = this.selectedItems.getKeyCollection().iterator();
    var vbSelected = false;

    while (voCollection.hasNext()) {
      var vnIndex = voCollection.next();
      var voData = this.getItem(vnIndex);

      if (voData.id == voDiv.id)
        vbSelected = true;
    }

    if (!vbSelected) {
      this.restoreRowColor(voDiv);
    }
  }
};
/**
 * 이전에 선택된 Tr 정보 얻기
 * @param pnIndex 선택된 인덱스
 * @return void
 * @type voTr
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.getSelectedTr = function(pnIndex) {
  // 이전에 선택된 아이템 정보 얻기
	var voTable = this.lookup(this.id+"_list_table");
	var voTr = voTable.rows[pnIndex];
	return voTr;
};
/**
 * 키다운 이벤트시 호출된는 메소드.
 * @param {HTMLEvent} e 윈도우이벤트
 * @return void
 * @type void
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.keyDown = function(e) {
  // 기존 선택된 아이템이 있어야 함
  // 선택된게 한개 일 때와 여러개 일때 화살표 키다운시 처리
  var vnKeyCode = e.keyCode;

  var voEvent = new eXria.event.Event(e, this.window);

  if (vnKeyCode == 38 || vnKeyCode == 40) {
    // 이전에 선택된 아이템 정보 얻기
    var voTr = this.getSelectedTr(this.selectedIndex);

    var voNextTarget = null;

    if (vnKeyCode == 38) { // ↑ key
      voNextTarget = voTr.previousSibling;
    } else if (vnKeyCode == 40) { // ↓ key
      voNextTarget = voTr.nextSibling;
    }

    if (voNextTarget != null) {
      voEvent.target = voNextTarget.cells[0].childNodes[0].childNodes[0].rows[0].cells[0];

      this.selectEventList(voEvent);
    }
  }
};
/**
 * 선택된 리스트 아이템의 값 반환.
 * @return 선택된 아이템의 값
 * @type String|Array(String)
 */
eXria.controls.xhtml.ListBox.prototype.getSelectedValue = function() {
  var vnIndex = null;
  var vaValue = [];

  var voIterator = this.selectedItems.getKeyCollection().iterator();
  var voListItem = null;
  while (voIterator.hasNext()) {
    vnIndex = voIterator.next();
    voListItem = this.getItem(vnIndex);
    vaValue.push(voListItem.value);
  }

  if (vaValue.length > 1)
    return vaValue;
  else
    return vaValue[0];
};
/**
 * 선택된 리스트 아이템들을 반환.
 * @return 선택된 리스트 아이템 배열
 * @type Array
 */
eXria.controls.xhtml.ListBox.prototype.getSelectedItems = function() {
  var vnIndex = null;
  var vaItem = [];

  var voIterator = this.selectedItems.getKeyCollection().iterator();
  var voListItem = null;
  while (voIterator.hasNext()) {
    vnIndex = voIterator.next();
    voListItem = this.getItem(vnIndex);
    vaItem.push(voListItem);
  }

  return vaItem;
};
/**
 * 지정된 라벨과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스 반환.
 * @param {String} psName 아이템 라벨 명
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.ListBox.prototype.getIndex = function(psName) {
  var voIterator = this.frontItems.getKeyCollection().iterator();
  var vsKey = null;
  var i = -1;
  while (voIterator.hasNext()) {
    i++;
    vsKey = voIterator.next();
    if (vsKey == psName) {
      return i;
    }
  }
  voIterator = this.itemset.getKeyCollection().iterator();
  while (voIterator.hasNext()) {
    i++;
    vsKey = voIterator.next();
    if (vsKey == psName) {
      return i;
    }
  }
  voIterator = this.backItems.getKeyCollection().iterator();
  while (voIterator.hasNext()) {
    i++;
    vsKey = voIterator.next();
    if (vsKey == psName) {
      return i;
    }
  }
  return -1;
};
/**
 * 지정된 값과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스 반환.
 * @param {String} psValue 아이템 값
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.ListBox.prototype.getIndexByVal = function(psValue) {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  var i = 0;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.value == psValue)
      return i;
    i++;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.value == psValue)
      return i;
    i++;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.value == psValue)
      return i;
    i++;
  }
  return -1;
};
/**
 * 지정된 ID과 일치되는 리스트 아이템의 전체 리스트에서의 인덱스 반환.
 * @param {String} psId 아이템 아이디
 * @return 해당 아이템의 전체 리스트에서의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.ListBox.prototype.getIndexById = function(psId) {
  var voIterator = this.frontItems.getValueCollection().iterator();
  var voItem = null;
  var i = 0;
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.id == psId)
      return i;
    i++;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.id == psId)
      return i;
    i++;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    if (voItem.id == psId)
      return i;
    i++;
  }
  return -1;
};
/**
 * 지정된 index를 통해 아이템을 선택하기 위한 메소드.
 * @param {Array(Number)} paIndex 선택될 아이템들의 인덱스를 저장하는 배열
 * @param {HTMLDiv} poCtrl 실체화 컨트롤. 생략가능
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @param {Boolean} pbLoad 로드시에 불려지는지의 여부. 생략가능
 * @return void
 * @type void
 * @example 
 * var index = new Array(2);<br/>
 * index[0] = 1;<br/>
 * index[1] = 3;<br/>
 * page.getControl("listbox").select(index);
 */
eXria.controls.xhtml.ListBox.prototype.select = function(paIndex, poCtrl, poDocument, pbLoad) {
  if (paIndex == null || paIndex.length == 0)
    return;
  if (poCtrl == null)
    poCtrl = this.getCtrl(poDocument);
  var voTable = poCtrl.childNodes[0];
  var voDiv = null;
  var voInput = null;
  var vnIndex = null;

  // TODO : this.showList(true);

  this.selectedItems.clear();
  for ( var i = 0; i < voTable.rows.length; i++) {
    voDiv = voTable.rows[i].cells[0].childNodes[0];
    if (this.appearance != "normal") {
      voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
      voInput.checked = false;
    }
    this.restoreRowColor(voDiv);
  }

  var vbSelected = false;
  for ( var i = 0; i < paIndex.length; i++) {
    vnIndex = paIndex[i];
    if (vnIndex == this.selectedIndex)
      vbSelected = true;
    voDiv = voTable.rows[vnIndex].cells[0].childNodes[0];
    this.selectedItems.put(vnIndex, "");
    if (this.appearance == "normal") {
      this.changeRowColor(voDiv);
    } else {
      voInput = voDiv.childNodes[0].rows[0].cells[0].firstChild;
      voInput.checked = true;
    }
    if (this.multiSelect == false)
      break;
  }
  if (voDiv != null && this.appearance != "normal")
    this.changeRowColor(voDiv);
  if (vbSelected == false) {
    // this.selectedIndex = vnIndex; //ctrl 키보드클릭시 오류때문에 주석처리 2009-03-26 hajubal
    // this.df.selectedIndex = vnIndex;
  }
  var vsSelectedValue = this.getSelectedValue();
  if(this.getItemByVal(vsSelectedValue) && pbLoad != true){
		if(this.getItemByVal(this.value) != this.getItemByVal(vsSelectedValue)) this.doitemchange(null, this);
	}
  
  var vsOldVal = this.value;
  if(vsOldVal instanceof Array) vsOldVal = vsOldVal.join();
  var vsNewVal = vsSelectedValue;
  if(vsNewVal instanceof Array) vsNewVal = vsNewVal.join();
  if(vsOldVal != vsNewVal) {
    this.value = vsSelectedValue;
    if(pbLoad != true) this.data.setData(this.value);
  }
};
/**
 * 컨트롤에 값을 설정.
 * @param {String|Array(String)} psValue 설정될 값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능
 * @return void
 * @type void
 */
eXria.controls.xhtml.ListBox.prototype.setValue = function(psValue, poDocument) {
  var voDf = this.df;
  var vaValue = [];
  this.selectedIndex = -1;
	if(this.getItemByVal(psValue)){
		if(this.getItemByVal(this.value) != this.getItemByVal(psValue)) this.doitemchange(null, this);
	}
  if (psValue instanceof Array) {
    vaValue = psValue
  } else {
    if (psValue != null)
      vaValue.push(psValue);
  }
  this.value = vaValue;
  this.data.setData(psValue);
  this.reloadData(null, poDocument);
};
/**
 * 컨트롤에 설정된 값을 반환.
 * @return 컨트롤 value 속성 값
 * @type String
 */
eXria.controls.xhtml.ListBox.prototype.getValue = function() {
  // var voDiv = voTable.rows[pnIndex].cells[0].childNodes[0];
  // var vsKey = voDiv.childNodes[0].rows[0].cells[0].lastChild.data;
  // var voValue = this.frontItems.get(vsKey) || this.itemset.get(vsKey) ||
  // this.backItems.get(vsKey);
  return this.value;
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 해당 속성명의 디폴트 속성 값
 * @type String
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.getSpecificDefaultValue = function(
    psAttrName) {
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if (vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.ListBox[psAttrName];
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.ListBox[vaAttrName[0]][vaAttrName[1]];
  }
  if (vsDefaultValue === undefined) {
    // alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 보여지는 아이템 개수를 반환
 * @return 보여지는 아이템 개수
 * @type Number
 * @private
 */
eXria.controls.xhtml.ListBox.prototype.getVisibleItemCount = function() {
  var vnCnt = 0;
  var voIterator = null;
  var voItem = null;
  voIterator = this.frontItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    vnCnt++;
  }
  voIterator = this.itemset.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    vnCnt++;
  }
  voIterator = this.backItems.getValueCollection().iterator();
  while (voIterator.hasNext()) {
    voItem = voIterator.next();
    if (voItem.visible == false)
      continue;
    vnCnt++;
  }
  return vnCnt;
};

//Ctrl을 제거.
//@param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.

// eXria.controls.xhtml.ListBox.prototype.clearCtrl = function(poDocument) {
// this.clearEvents(poDocument);
// var voCtrl = this.getCtrl(poDocument);
// var vsId = this.id;
// var voTable = this.lookup(vsId + "_listarea_table");
// var voTr = null;
// for(var i = 0; i < voTable.rows.length; i++) {
// voTr = voTable.rows[i];
// voTr.onclick = null;
// }
//  
// if (voCtrl != null) {
// if(voCtrl.parentNode) voCtrl.parentNode.removeChild(voCtrl);
// }
// };
/**
 * 클래스 명을 반환.
 * @return "ListBox"
 * @type String
 */
eXria.controls.xhtml.ListBox.prototype.toString = function() {
  return "ListBox";
};
