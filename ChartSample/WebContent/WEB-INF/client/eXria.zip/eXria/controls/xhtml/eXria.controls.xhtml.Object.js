/**
 * @fileoverview
 * Concreate xhtml Object(XHTML Object 컨트롤)
 * @author 이종녕
 */

/**
 * @class images, audio, videos, Java applets, ActiveX, <br />
 * PDF, flash 등의 객체를 포함하는 컨트롤을 생성하는 class입니다.<br />
 * XHTML Object Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Object 객체
 * @type eXria.controls.xhtml.Object
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */ 
eXria.controls.xhtml.Object = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 300 : pnWidth;
  pnHeight = pnHeight == null ? 300 : pnHeight;

  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  
  //////////////////////////////////////////////////////////////////
  //  속성
  /**
   * 여백 문자로 분리된 URI들의 목록.
   * @type String
   */
  this.archive = null;
  /**
   * 오브젝트 클래스 아이디.
   * @type String
   */
  this.classid = null;
  /**
   * classid, data, archive의 기준 URI.
   * @type String
   */
  this.codebase = null;
  /**
   * 오브젝트  데이터 참조.
   * @type String
   */
  this.dataUrl = null;
  /**
   * 선언되나 즉시화가 되지 않음.
   * @type String
   */ 
  this.declare = null;
  /**
   * 로딩 중 보이는 메세지.
   * @type String
   */
  this.standby = null;
  /**
   * 데이터 컨텐트 타입.
   * @type String
   */
  this.type = null;
  /**
   * 코드(code) 컨텐트 타입.
   * @type String
   */  
  this.codetype = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */ 
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 파라미터의 리스트.
   * @type eXria.data.ArrayMap
   */
  this.params = new eXria.data.ArrayMap();
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type HTMLDocument
   * @private
   */ 
  this.document = null;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Object);
/////////////////////////////////////////////////////////////////////////////////
///  메소드    

/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");  
  voCtrl["id"] = this.id;
	if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.template = [];
  this.document = poDocument;
  this.ctrl = voCtrl;
  var vaTemplate = this.template;

  vaTemplate.push("<object id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_object' ");
  vaTemplate.push("@attrStrBuf");   //3
  vaTemplate.push(" style='");
  vaTemplate.push("position:absolute;padding:0px;margin:0px;border-style:none;");
  vaTemplate.push("border-width:0px;top:0px;left:0px;");
  vaTemplate.push("@cssStrBuf");    //7
  vaTemplate.push("'>");
  
  //if(navigator.appName != "Microsoft Internet Explorer") {
  //  vaTemplate.push("Sorry, if this text is displayed, your browser does not support Type and Error!!");
  //}
  
  return voCtrl;
};

/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
	var vsClass = this.getCSSClass(this, 1);

  vaTemplate.push("<object class='" + vsClass + "' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_object' ");
  vaTemplate.push("@attrStrBuf");   //3
  vaTemplate.push(" style='");
  vaTemplate.push("position:absolute;padding:0px;margin:0px;border-style:none;");
  vaTemplate.push("border-width:0px;top:0px;left:0px;");
  vaTemplate.push("@cssStrBuf");    //7
  vaTemplate.push("'>");
  vaTemplate.push("@attrStrBuf");   //9

//  vaTemplate.push(this.getParamTemplate("wmode","transparent"));
//  vaTemplate.push(this.getParamTemplate("AutoSize","true"));
//  vaTemplate.push(this.getParamTemplate("autostart","true"));
//  vaTemplate.push(this.getParamTemplate("controller","true"));
};

/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.getInnerHTML = function(){
	var vaTemplate = [];
  if(this.params.get("wmode") == null) vaTemplate.push(this.getParamTemplate("wmode","transparent"));
  if(this.params.get("AutoSize") == null) vaTemplate.push(this.getParamTemplate("AutoSize","true"));
  if(this.params.get("autostart") == null) vaTemplate.push(this.getParamTemplate("autostart","true"));
  if(this.params.get("controller") == null) vaTemplate.push(this.getParamTemplate("controller","true"));
  
  var voIterator = this.params.getKeyCollection().iterator();
  var vsParamValue = null;
  var vsParamName = null;
  while (voIterator.hasNext()) {
    vsParamName = voIterator.next();
    vsParamValue = this.params.get(vsParamName);
    vaTemplate.push(this.getParamTemplate(vsParamName, vsParamValue));
  }
  
  return vaTemplate.join(""); 
}
/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.setSpecificDefaults = function(poCtrl,poDocument) {
	this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
  
  this.archive = this.getAttrValue("archive",this.archive);
  this.classid = this.getAttrValue("classid",this.classid);
  this.codebase = this.getAttrValue("codebase",this.codebase);
  this.dataUrl = this.getAttrValue("dataUrl",this.dataUrl);
  this.declare = this.getAttrValue("declare",this.declare);
  this.standby = this.getAttrValue("standby",this.standby);
  this.type = this.getAttrValue("type",this.type);
  this.codetype =  this.getAttrValue("codetype",this.codetype);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.setSpecificAttrs = function(poCtrl,poDocument) {
  var voBtn = poCtrl.childNodes[0];
  //var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  if(this.disabled) poCtrl["disabled"] = true;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
//  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  vaAttrStrBuf = [];
  if(this.classid && this.canvas.page.metadata.browser.ie > 0) vfcSetAttStrBuf(vaAttrStrBuf, "classid", this.classid);
  vfcSetAttStrBuf(vaAttrStrBuf, "type", this.type);
  vfcSetAttStrBuf(vaAttrStrBuf, "codeBase", this.codebase);
  vfcSetAttStrBuf(vaAttrStrBuf, "codeType", this.codetype);
  vfcSetAttStrBuf(vaAttrStrBuf, "data", this.dataUrl);
  vfcSetAttStrBuf(vaAttrStrBuf, "archive", this.archive);
  vfcSetAttStrBuf(vaAttrStrBuf, "declare", this.declare);
  vfcSetAttStrBuf(vaAttrStrBuf, "standby", this.standby);
  vfcSetAttStrBuf(vaAttrStrBuf, "usemap", this.usemap);
  vaTemplate[3] = vaAttrStrBuf.join("");
  
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vaTemplate[7] = vaCssStrBuf.join("");
  
  vaTemplate[9] = this.getInnerHTML();
  
  vaTemplate.push(this.getParamTemplate("FileName", this.dataUrl));
  vaTemplate.push(this.getParamTemplate("src", this.dataUrl));
  vaTemplate.push(this.getParamTemplate("movie", this.dataUrl));
  
  vaTemplate.push("</object>");
  poCtrl.innerHTML = vaTemplate.join("");
  
  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Object.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;  
  var voObject = this.getSubCtrl("object",poCtrl);
  switch(psAttrName) {
    case "width" :
      this.setAttrCtrl("width", this.innerWidth, voObject);
      break;
    case "height" :
      this.setAttrCtrl("height", this.innerHeight, voObject);
      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.setSpecificEvents = null;
/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};
/**
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl, poDocument);
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Object.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl();
  var voObject = this.getSubCtrl("object");
  //var voDf = this.df;
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "outerClassName":
  case "className":
    this.refresh(poDocument);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth, voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth, voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth, voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth, voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderTopWidth" :
  case "borderTopHeight" :
    this.innerHeight = this.width - this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
    break;
  case "borderStyle" : 
  case "borderColor" :
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  default:
    this.refresh(poDocument);
    break;
  }
}; 
/**
 * 파라미터를 설정합니다.
 * @param {String} psName 새로운 값이 설정될 파라미터 명
 * @param {String} psValue 설정될 새로운 파라미터 값
 */
eXria.controls.xhtml.Object.prototype.setParam = function(psName, psValue) {
  var vsParamName = this.params.get(psName);  
  if (!vsParamName) {
    this.params.put(psName, psValue);
  } else {
    this.params.remove(psName);
    this.params.put(psName, psValue);
  }
};

/**
 * 새로운 파라미터를 추가합니다.
 * @param {String} psName 추가될 파라미터 명
 * @param {String} psValue 추가될 파라미터 값
 * @param {HTMLObject} poCtrl 실체화 컨트롤. 생략가능.
 */
eXria.controls.xhtml.Object.prototype.createParam = function(psName, psValue, poCtrl) {
  if (psName == null || psValue == null) {
    //  ERROR 처리   alert("정확한 값을 입력해주세요...");
    return false;
  }
  var voCtrl = this.getCtrl();
  if(poCtrl == null || poCtrl == "undefined")  poCtrl = this.getSubCtrl("object",voCtrl); 
  var voParam = this.document.createElement("param");
  voParam.setAttribute("id", this.id + "_" + psName);
  voParam.setAttribute("name",psName);
  voParam.setAttribute("value",psValue);
  poCtrl.appendChild(voParam);
};
/**
 * 파라미터 HTML 코드를 반환합니다.
 * @param {String} psName 추가될 파라미터 명
 * @param {String} psValue 추가될 파라미터 값
 * @return HTML코드
 * @type String
 * @private
 */
eXria.controls.xhtml.Object.prototype.getParamTemplate = function(psName, psValue) {
  if (psName == null || psValue == null) {
    //  ERROR 처리   alert("정확한 값을 입력해주세요...");
    return;
  }
  return "<param id='" + this.id + "_" + psName + "' name='" + psName + "' value='" + psValue + "'/>";
};
///**
// * Embed 객체 생성 메소드.
// * @param {String} psSrc Embed src경로
// * @param {HTMLDiv} poCtrl 실체화 컨트롤 
// */
//eXria.controls.xhtml.Object.prototype.createEmbed = function(poCtrl) {
//	if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(this.document); }
//  if (psSrc == null || psType == null) {
//    alert("정확한 값을 입력해주세요...");
//    return false;
//  } 
//  var voEmbed = this.document.createElement("embed");
//  voEmbed.setAttribute("src",psSrc);
//  voEmbed.setAttribute("pluginspage","http://www.macromedia.com/go/getflashplayer");
//  voEmbed.setAttribute("top",this.top);
//  voEmbed.setAttribute("left",this.left);
//  voEmbed.setAttribute("width",this.width);
//  voEmbed.setAttribute("height",this.height);
//  voEmbed.setAttribute("type",psType);
//  poCtrl.appendChild(voEmbed);
//};
/**
*  실체화 Object 객체를 반환합니다.
* @return 실체화 Object 객체
* @type HTMLObject
*/
eXria.controls.xhtml.Object.prototype.getObject = function(){
	var voCtrl = this.getCtrl();
	var voObject = voCtrl.getElementsByTagName("object")[0];
	// firefox에서 object가 exria plugin인지를 체크하여 plugin인 접근 object를 반환하도록 처리
	if(this.canvas.page.metadata.browser.gecko > 0) {
	  var vsType = this.type;
	  if(vsType == null) vsType = "";
	  if(vsType.indexOf("application/npETBClient") != -1) voObject = voObject.nsIETBClientFox;
	}
	return voObject;
}
/**
* 서브 컨트롤 실체화 객체를 반환합니다.
* @param {String} psTagName
* @return 서브 컨트롤 실체화 객체
* @type HTMLObject
* @private
*/
eXria.controls.xhtml.Object.prototype.getSubCtrl = function(psTagName,poCtrl,poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  var subCtrl = poCtrl.getElementsByTagName(psTagName)[0];
  return subCtrl;
};
/**
 * getCtrlClassName
 * @param {String} psClassName 참조 대상 클래스명
 * @param {String} psOuterClassName
 * @return vsClassName
 * @type String
 * @ignore
 */
eXria.controls.xhtml.Object.prototype.getCtrlClassName = function(psClassName, psOuterClassName) {
  var vsClassName = "";
  if(psClassName == null) psClassName = "";
  if(psOuterClassName == null) psOuterClassName = "";
  vsClassName = psClassName + " " + psOuterClassName;
  vsClassName = eXria.util.StringUtil.trim(vsClassName);
  
  return vsClassName;
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore 
 */
eXria.controls.xhtml.Object.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Object[psAttrName];
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};

/**
 * 클래스 명을 반환합니다.
 * @return "Object"
 * @type String
 */
eXria.controls.xhtml.Object.prototype.toString = function() {
  return "Object";
};
