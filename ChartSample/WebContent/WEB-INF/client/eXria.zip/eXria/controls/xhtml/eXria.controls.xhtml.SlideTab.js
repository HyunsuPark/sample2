/**
 * @fileoverview
 * Concreate xhtml SlideTab_slideButtons, SlideButton, SlideTab_slidePages, SlidePage, SlideTab
 * @author 조영진
 */

/**
 * 슬라이드 탭 컨트롤의 슬라이드 버튼 공통 속성을 저장하기 위한 클래스.
 * @version 2.0
 * @type eXria.controls.xhtml.SlideTab_slideButtons
 * @constructor
 */
eXria.controls.xhtml.SlideTab_slideButtons = function() {
  /**
   * 버튼의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 버튼의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 버튼의 보더 두께.
   * @type Number
   */ 
  this.borderWidth = null;
  /**
   * 버튼의 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 버튼의 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 버튼의 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 버튼의 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 버튼에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 버튼에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 버튼에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 버튼에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 버튼에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;
  /**
   * 버튼의 세로 길이.
   * @type String
   */  
  this.height = null;
  /**
   * 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 선택된 버튼의 배경이미지 url.
   * @type String
   */
  this.imageFocused = null;
  /**
   * 버튼 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * 버튼 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;
  /**
   * 버튼의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 버튼이 선택되었을 때의 배경 색상.
   * @type String
   */
  this.focusBackgroundColor = null;
  /**
   * 버튼의 텍스트 색상.
   * @type String
   */
  this.color = null;
  /**
   * 버튼이 선택되었을 때의 텍스트 색상.
   * @type String
   */
  this.focusColor = null;
  /**
   * 버튼에 표시될 텍스트의 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;
  /**
   * 버튼에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 버튼에 표시될 텍스트 폰트사이즈.
   * @type Number
   */    
  this.fontSize = null; 
  /**
   * 버튼에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 버튼에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 텍스트 밑줄 적용 속성.
   * @type String
   */
  this.textDecoration = null;
  /**
   * 버튼에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 버튼에 외곽에 적용될 css 클래스 명.
   * @type String
   */
  this.outerClassName = null;
  /**
   * 슬라이드 버튼의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.cursor = null;
  
  this.df = {};
};


/**
 * @class Concreate xhtml SlideButton
 * XHTML SlideTab 컨트롤에 포함되는 슬라이드 버튼 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.SlideButton 객체
 * @type eXria.controls.xhtml.SlideButton
 * @constructor
 * @base eXria.controls.xhtml.Button
 */
eXria.controls.xhtml.SlideButton = function(psId, pnLeft, pnTop, pnWidth, pnHeight, poSlide) {
  
  eXria.controls.xhtml.Button.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * 슬라이드 탭 참조
   * @type eXria.controls.xhtml.SlideTab
   * @private
   */
  this.parent = poSlide;
  /**
   * 슬라아드 버튼의 subId 참조(슬라이드 탭 컨트롤 id가 제외된 값)
   * @type String
   * @private
   */
  this.subId = null;
  /**
   * 링크된 페이지 아이디(슬라이드 탭 컨트롤 id와 조합된 값) 참조
   * @type String
   * @private
   */
  this.pageId = null;
  /**
   * 링크된 페이지 아이디 참조(슬라이드 탭 컨트롤 id가 제외된 값)
   * @type String
   * @private
   */
  this.pageSubId = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Button, eXria.controls.xhtml.SlideButton);
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type String|Number
 * @private
 */
eXria.controls.xhtml.SlideButton.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  if(eXria.controls.xhtml.Default.SlideTab.slideButtons) vsDefaultValue = eXria.controls.xhtml.Default.SlideTab.slideButtons[psAttrName];
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * @ignore
 */
eXria.controls.xhtml.SlideButton.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  voEvent.object = poControl;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  
  if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if (poControl[vsOnEvent]) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
};
/**
 * @ignore
 */
eXria.controls.xhtml.SlideButton.prototype.atblur = null;
/**
 * @ignore
 */
eXria.controls.xhtml.SlideButton.prototype.atmouseover = null;
/**
 * @ignore
 */
eXria.controls.xhtml.SlideButton.prototype.atmouseout = null;

eXria.controls.xhtml.SlideButton.prototype.toString = function(){
	return "SlideButton";
}

/**
 * 슬라이드 탭 컨트롤의 슬라이드 페이지 공통 속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.SlideTab_slidePages = function() {
  /**
   * 슬라이드 페이지의 보더 스타일.
   * @type String
   */
  this.borderStyle = null;
  /**
   * 슬라이드 페이지의 보더 색상.
   * @type String
   */
  this.borderColor = null;
  /**
   * 슬라이드 페이지 보더 두께.
   * @type Number
   */ 
  this.borderWidth = null;
  /**
   * 슬라이드 페이지 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 슬라이드 페이지 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 슬라이드 페이지 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 슬라이드 페이지 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 슬라이드 페이지에 담긴 컨트롤이 영역을 벗어날때 스크롤 처리.
   * @type String
   */  
  this.overflow = null;
  /**
   * 슬라이드 페이지에 담긴 컨트롤이 영역을 벗어날때 횡 스크롤 처리.
   * @type String
   */  
  this.overflowX = null;
  /**
   * 슬라이드 페이지에 담긴 컨트롤이 영역을 벗어날때 종 스크롤 처리.
   * @type String
   */  
  this.overflowY = null;
  /**
   * 슬라이드 바디의 배경 색상.
   * @type String
   */
  this.backgroundColor = null;
  /**
   * 슬라이드 페이지의 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 슬라이드 페이지의 외곽 div에 적용될 css 클래스 명.
   * @type String
   */
  this.outerClassName = null;
  /**
   * 슬라이드 페이지의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};


/**
 * 슬라이드 탭 페이지
 * @type eXria.controls.xhtml.SlidePage
 * @constructor
 * @base eXria.controls.xhtml.Group
 */
eXria.controls.xhtml.SlidePage = function(psId, pnLeft, pnTop, pnWidth, pnHeight, poSlide) {
  eXria.controls.xhtml.Group.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * 상위 SlideTab컨트롤 참조변수
   * @type eXria.controls.xhtml.SlideTab
   */
  this.parent = poSlide;
	/**
   * 상위 SlideTab컨트롤 참조변수
   * @type eXria.controls.xhtml.SlideTab
   */
  this.control = poSlide;
  /**
   * SlidePage의 sub Id참조
   * @type String
   */
  this.subId = null;
  /**
   * SlidePage가 렌더링 되었는지 여부
   * @type Boolean
   * @private
   */
  this.rendered = false;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Group, eXria.controls.xhtml.SlidePage);
/**
 * @ignore
 */
eXria.controls.xhtml.SlidePage.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  
  if (poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if (poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if (poControl[vsOnEvent]) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type String|Number
 * @private
 */
eXria.controls.xhtml.SlidePage.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = null;
  if(eXria.controls.xhtml.Default.SlideTab.slidePages) vsDefaultValue = eXria.controls.xhtml.Default.SlideTab.slidePages[psAttrName];
  if(vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
}; 
/**
 * 클래스 명을 반환.
 * @return "TabPage"
 * @type String
 */
eXria.controls.xhtml.SlidePage.prototype.toString = function() {
  return "SlidePage";
};


/**
 * @class Concreate xhtml SlideTab.<br>
 * XHTML SlideTab 컨트롤.
 * @author 조영진
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.SlideTab 객체
 * @type eXria.controls.xhtml.SlideTab
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.SlideTab = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {

  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 200 : pnWidth;
  pnHeight = pnHeight == null ? 350 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //////////////////////////////////////////////////////////////////
  // 속성
  // 데이타 연동 관련
  /**
   * Data 연동 객체(노드 셋 연동).
   * @type eXria.controls.DataRefNodeset
   */  
  this.data = new eXria.controls.DataRefNodeset(this);
  /**
   * 인스턴스로 부터 라벨 데이타를 가져올 때 사용될 DOM Element 명
   * @type String
   */
  this.labelTagName = "label";
  /**
   * 인스턴스로 부터 button id를 가져올 때 사용될 DOM Element 명
   * @type String
   */
  this.bidTagName = "buttonid";
  /**
   * 인스턴스로 부터 page id를 가져올 때 사용될 DOM Element 명
   * @type String
   */
  this.pidTagName = "pageid";
  /**
   * 슬라이드 버튼과 페이지 생성 시 이용되는 순차적인 번호
   * @type Number
   * @private
   */  
  this.seqNum = 0;
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type Object
   * @private
   */
  this.document = null;
  /**
   * 버튼 선택 시 버튼이 움직이는 방향 지정('top'|'bottom')
   * @type String
   */
  this.expandDirection = "bottom"; //'top'|'bottom'
  /**
   * 선택된 슬라이드 버튼의 인덱스.
   * @type Number
   */
  this.selectedIndex = null;
  /**
   * 선택된 슬라이드 페이지의 ID.
   * @type Number
   */
  this.selectedPageId = null;
  /**
   * 버튼들을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   * @private
   */  
  this.buttonSet = new eXria.data.ArrayCollection();
  
  /**
   * 보여지는 버튼들만을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   * @ignore
   */  
  this.buttonVisibleSet = new eXria.data.ArrayCollection();
  
  /**
   * 버튼에 종속된 컨텐츠 패널들을 저장하기 위한 eXria.data.ArrayCollection.
   * @type eXria.data.ArrayCollection
   * @private
   */
  this.contentPaneSet = new eXria.data.ArrayCollection();
  /**
   * 버튼들의 공통속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.SlideTab_slideButtons
   */
  this.slideButtons = new eXria.controls.xhtml.SlideTab_slideButtons();
  /**
   * 컨텐츠 패널들의 공통속성을 저장하기 위한 오브젝트.
   * @type eXria.controls.xhtml.SlideTab_slidePages
   */  
  this.slidePages = new eXria.controls.xhtml.SlideTab_slidePages();
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 초기에 모든 페이지를 렌더링할지 여부
   */
  this.renderAll = null;
  /**
   * data연동을 통해 생성된 탭 페이지 아이디 저장
   * @type eXria.data.ArrayMap
   * @private
   */
  this.pageIdsInData = new eXria.data.ArrayMap();
  /**
   * 모든 탭이 닫힐수 있는지 여부
   * @type Boolean
   * @private
   */
  this.closable = false;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */

  this.cursor = null;   

  this.df = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.SlideTab);
//////////////////////////////////////////////////////////////////   
// 메소드    
/**
 * @ignore
 */
eXria.controls.xhtml.SlideTab.prototype.runEvent = function(e, poControl) {
  if(this.disabled) return;
  var voEvent = new eXria.event.Event(e, this.window);
  if(voEvent.target && voEvent.target.id == "GridEx") return;
  voEvent.object = poControl;
  var voCanvas = this.canvas;
  var vsType = voEvent.type;
  var vsAtEvent = "at" + vsType;        // 컨트롤별 이벤트 처리    
  var vsCoEvent = "co" + vsType;        // 공통 이벤트 처리    
  var vsOnEvent = "on" + vsType;        // 사용자 지정 이벤트 처리
  var vsFinalEvent = "final" + vsType;  // 최종 이벤트 처리
  var vbSkip = false;

  switch(vsType) {
  case "mouseover" :
    if(voCanvas.mouseoverObj == poControl) {
      vbSkip = true;
    } else {
      voCanvas.mouseoverObj = poControl;
      this.mouseoutFired = false;
    }
    break;
  case "mouseout" :
    var vnX = this.borderLeftWidth;
    var vnY = this.borderTopWidth;
    if(voCanvas.page.metadata.browser.ie) {
      vnX = voEvent.e.offsetX;
      vnY = voEvent.e.offsetY;
      var voElement = voEvent.target;
      while(voElement.offsetParent) {      
        vnX += voElement.offsetLeft;
        vnY += voElement.offsetTop;
        voElement = voElement.offsetParent ;
      };
    } else {
      vnX = voEvent.e.pageX;
      vnY = voEvent.e.pageY;
    }
    if(this.isContain(this.ctrl, vnX, vnY) || this.mouseoutFired) {
      vbSkip = true;
    } else {
      this.mouseoutFired = true;
    }
    break;
  case "keyup" :
    if(voEvent.keyCode == 229 && voCanvas.page.metadata.browser.gecko) {
      vbSkip = true;
    }
    break;
  }
  
  if(poControl[vsAtEvent]) { poControl[vsAtEvent](voEvent); }
  if(poControl[vsCoEvent]) { poControl[vsCoEvent](voEvent); }
  if(poControl[vsOnEvent] && vbSkip == false) {
    if(this.debug) {
      poControl[vsOnEvent](voEvent);
    } else {
      try {
        poControl[vsOnEvent](voEvent);
      } catch(err) {
        alert(vsOnEvent + "_" + poControl.id + " 사용자 정의 스크립트 오류\n\nname : " + err.name + "\nmessage : " + err.message);
      }
    }
  }
  if (poControl[vsFinalEvent]) { poControl[vsFinalEvent](voEvent); }
  
  switch(vsType) {
  case "keydown" :
  case "keyup" :
    break;
  case "contextmenu" :
    voEvent.stopEvent();
    break;
  default :
    voEvent.stopPropagation();
    break;
  }
};

eXria.controls.xhtml.SlideTab.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  
  this.document = poDocument;
  this.ctrl = voCtrl;
  
  return voCtrl;
};
eXria.controls.xhtml.SlideTab.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
	var voBtnDf = this.slideButtons;
	var voPageDf = this.slidePages;

	this.setStyleCurrentBorderValue(this);
	
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
	
  this.selectedIndex = this.getAttrValue("selectedIndex", this.selectedIndex);
  if(this.selectedIndex == null){
  	this.selectedIndex = -1; 
  }
  
  this.renderAll = this.getAttrValue("renderAll", this.renderAll);  
  voBtnDf.height = this.getAttrValue("slideButtons.height",this.slideButtons.height);
  voBtnDf.focusBackgroundColor = this.getAttrValue("slideButtons.focusBackgroundColor",this.slideButtons.focusBackgroundColor);
  voBtnDf.focusColor = this.getAttrValue("slideButtons.focusColor",this.slideButtons.focusColor);
  voBtnDf.imageFocused = this.getAttrValue("slideButtons.imageFocused",this.slideButtons.imageFocused);
};

eXria.controls.xhtml.SlideTab.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voBtnDf = this.slideButtons;
  var vaCssStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;

  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  vaCssStrBuf = null;
   
  var vnSize = this.buttonSet.size();
  var voIterator = this.buttonSet.iterator();
  while(voIterator.hasNext()) {
    voButton = voIterator.next();        
    if(voButton.visible != false) this.buttonVisibleSet.add(voButton);        
  }  
  var voButton = null;
  var voContentPane = null;
  var voButtonCtrl = null;
  var voContentPaneCtrl = null;
  for(var i = 0; i < vnSize; i++) {
    voButton = this.buttonSet.get(i);
    voButton.canvas = this.canvas;
    voButton.window = this.window;
    voButton.document = this.document;
    voButton.top = voBtnDf.height * (i);
    voButton.width = this.innerWidth;
    voContentPane = this.contentPaneSet.get(i);
    voContentPane.canvas = this.canvas;
    voContentPane.window = this.window;
    voContentPane.document = this.document;
    if(this.expandDirection == "top") voContentPane.top = voBtnDf.height * (i);
    else voContentPane.top = voBtnDf.height * (i + 1);
    voContentPane.width = this.innerWidth;
    voContentPane.height = this.innerHeight - voBtnDf.height * vnSize;
    
    this.createItemCtrl(i, poCtrl, poDocument);
  }
};

eXria.controls.xhtml.SlideTab.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
  this.slideButtons.df = {};
  this.slidePages.df = {};
  
  var voPageIdsInData = this.pageIdsInData;
  var vnSize = voPageIdsInData.size();
  var voPageIds = voPageIdsInData.getKeyCollection();
  var vsPageId = null;
  var vnIndex = null;
  for(var i = 0; i < vnSize; i++) {
    vsPageId = voPageIds.get(i);
    if(vnIndex) {
      var voButton = this.buttonSet.remove(pnIndex);
      voButton.clear();
      var voContentPane = this.contentPaneSet.remove(pnIndex);
      voContentPane.clear();
    }
  }
  voPageIdsInData.clear();
};

eXria.controls.xhtml.SlideTab.prototype.refreshSubStyles = function(poCtrl, poDocument) {
  this.setSubCtrlStyles(poCtrl, poDocument);
};

eXria.controls.xhtml.SlideTab.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
	var voBtnDf = this.slideButtons;
	var voPageDf = this.slidePages;
	this.setAttrCtrl("top", this.top, poCtrl);
	this.setAttrCtrl("left", this.left, poCtrl);
  this.setAttrCtrl("width", this.innerWidth, poCtrl);
  this.setAttrCtrl("height", this.innerHeight, poCtrl);
  this.setAttrCtrl("borderColor", this.borderColor, poCtrl);
  this.setAttrCtrl("borderStyle", this.borderStyle, poCtrl);
  this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", poCtrl);
  this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", poCtrl);
  this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", poCtrl);
  this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", poCtrl);
  this.setAttrCtrl("cursor", this.cursor, poCtrl);
  this.setAttrCtrl("visible", this.visible, poCtrl);
      
  var vnSize = this.buttonSet.size();
  this.buttonVisibleSet.clear();
  var voIterator = this.buttonSet.iterator();
  while(voIterator.hasNext()) {
    voButton = voIterator.next();        
    if(voButton.visible != false) this.buttonVisibleSet.add(voButton);        
  }    
  var vnVisibleSize = this.buttonVisibleSet.size();
  var voButton = null;
  var voContentPane = null;
  var voButtonCtrl = null;
  var voContentPaneCtrl = null;
  var vnVisible = 0;
  for(var i = 0; i < vnSize; i++) {
    voButton = this.buttonSet.get(i);
    voContentPane = this.contentPaneSet.get(i);    
    if(voButton.visible != false) {
      voButton.top = voBtnDf.height * (vnVisible);
      voButton.width = this.innerWidth;
      voButton.height = voBtnDf.height;
  		voButton.borderStyle = voBtnDf.borderStyle;
  		voButton.borderColor = voBtnDf.borderColor;
      voButton.borderWidth = voBtnDf.borderWidth;
      voButton.borderLeftWidth = voBtnDf.borderLeftWidth;
      voButton.borderRightWidth = voBtnDf.borderRightWidth;
      voButton.borderTopWidth = voBtnDf.borderTopWidth;
      voButton.borderBottomWidth = voBtnDf.borderBottomWidth;
      voButton.padding = voBtnDf.padding;
      voButton.paddingLeft = voBtnDf.paddingLeft;
      voButton.paddingRight = voBtnDf.paddingRight;
      voButton.paddingTop = voBtnDf.paddingTop;
      voButton.paddingBottom = voBtnDf.paddingBottom;
  		voButton.backgroundColor = voBtnDf.backgroundColor;
      voButton.backgroundImage = voBtnDf.backgroundImage;
      voButton.backgroundPosition = voBtnDf.backgroundPosition;
      voButton.backgroundRepeat = voBtnDf.backgroundRepeat;
      voButton.color = voBtnDf.color;
      voButton.fontFamily = voBtnDf.fontFamily;
      voButton.fontSize = voBtnDf.fontSize;
      voButton.fontStyle = voBtnDf.fontStyle;
      voButton.fontWeight = voBtnDf.fontWeight;
      voButton.textAlign = voBtnDf.textAlign;
      voButton.textDecoration = voBtnDf.textDecoration;
      voButton.cursor = voBtnDf.cursor;
      
      if(this.expandDirection == "top") voContentPane.top = voBtnDf.height * (vnVisible);
      else voContentPane.top = voBtnDf.height * (vnVisible + 1);
      voContentPane.width = this.innerWidth;
      voContentPane.height = this.innerHeight - voBtnDf.height * vnVisibleSize;
  		voContentPane.borderStyle = voPageDf.borderStyle;
  		voContentPane.borderColor = voPageDf.borderColor;
      voContentPane.borderWidth = voPageDf.borderWidth;
      voContentPane.borderLeftWidth = voPageDf.borderLeftWidth;
      voContentPane.borderRightWidth = voPageDf.borderRightWidth;
      voContentPane.borderTopWidth = voPageDf.borderTopWidth;
      voContentPane.borderBottomWidth = voPageDf.borderBottomWidth;
      voContentPane.overflow = voPageDf.overflow;
      voContentPane.overflowX = voPageDf.overflowX;
      voContentPane.overflowY = voPageDf.overflowY;
      voContentPane.cursor = this.cursor;
      voContentPane.backgroundColor = voPageDf.backgroundColor;
  
      voButtonCtrl = voButton.getCtrl(poDocument);
      if(voButtonCtrl) {
        voButton.refresh(poDocument);
        if(voContentPane.rendered) {
          voContentPane.refresh(poDocument);
        }
      } else {
        this.createItemCtrl(i, poCtrl, poDocument);
      }
      vnVisible = vnVisible + 1;
    }
  }
  this.expandButton(this.selectedIndex);
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.SlideTab.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
    
  switch(psAttrName) {
  case "width" : 
    break;
  case "height" : 
    break;
  case "borderWidth" :
    break;
  }
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치할 Doucment에 대한 참조
 */
eXria.controls.xhtml.SlideTab.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl();
  var vaAttrName = null;
  var vsSubAttrName = null;
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
//  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  case "backgroundColor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);   
    break;
  case "slideButtons.backgroundColor" :
  case "slideButtons.color" :
  case "slideButtons.borderStyle" :
  case "slideButtons.borderColor" :
  case "slideButtons.borderWidth" :
  case "slideButtons.borderLeftWidth" :
  case "slideButtons.borderRightWidth" :
  case "slideButtons.borderTopWidth" :
  case "slideButtons.borderBottomWidth" :
  case "slideButtons.padding" :
  case "slideButtons.paddingLeft" :
  case "slideButtons.paddingRight" :
  case "slideButtons.paddingTop" :
  case "slideButtons.paddingBottom" :
  case "slideButtons.fontFamily" :
  case "slideButtons.fontSize" :
  case "slideButtons.fontStyle" :
  case "slideButtons.fontWeight" :
  case "slideButtons.textAlign" :
  case "slideButtons.textDecoration" :
    vaAttrName = psAttrName.split(".");      
    vsSubAttrName = vaAttrName[vaAttrName.length - 1];
    var voButton = null;
    var voIterator = this.buttonSet.iterator();
    while(voIterator.hasNext()) {
      voButton = voIterator.next();        
      voButton.applyAttrRebuild(vsSubAttrName, psAttrValue, poDocument);        
    }
    break;      
  case "slidePages.backgroundColor" :
  case "slidePages.borderStyle" :
  case "slidePages.borderColor" :
  case "slidePages.borderWidth" :
  case "slidePages.borderLeftWidth" :
  case "slidePages.borderRightWidth" :
  case "slidePages.borderTopWidth" :
  case "slidePages.borderBottomWidth" :
    vaAttrName = psAttrName.split(".");   
    vsSubAttrName = vaAttrName[vaAttrName.length - 1];
    var voContentPane = null;
    var voIterator = this.contentPaneSet.iterator();
    while(voIterator.hasNext()) {
      voContentPane = voIterator.next();
      voContentPane.applyAttrRebuild(vsSubAttrName, psAttrValue, poDocument);        
    }
    break;  	
  case "slidePages.overflow" :
  case "slidePages.overflowX" :
  case "slidePages.overflowY" : 
  	var voCssStyle = this.canvas.getCssStyle(this.className, this.document);
    if(this.overflow == null) this.overflow = "hidden";
    var vsOverflowX = this.makeSpecificAttrValue(voCtrl, voCssStyle, "slidePages.overflowX");
    var vsOverflowY = this.makeSpecificAttrValue(voCtrl, voCssStyle, "slidePages.overflowY");
    if(voObj.overflowX == null) this.overflowX = vsOverflowX ? vsOverflowX : this.overflow;
    if(voObj.overflowY == null) this.overflowY = vsOverflowY ? vsOverflowY : this.overflow;
    
    vaAttrName = psAttrName.split(".");   
    vsSubAttrName = vaAttrName[vaAttrName.length - 1];
    var voContentPane = null;
    var voIterator = this.contentPaneSet.iterator();
    while(voIterator.hasNext()) {
      voContentPane = voIterator.next();
      voContentPane.overflowX = this.overflowX;
      voContentPane.overflowY = this.overflowY;
      var voStyle = voContentPane.ctrl.style;
      voStyle.overflowX = this.overflowX;
      voStyle.overflowY = this.overflowY;
//      voContentPane.applyAttrRebuild(vsSubAttrName, psAttrValue, poDocument);        
    }
    break;
  default :
    this.refresh(poDocument);
    break;
  }

};

eXria.controls.xhtml.SlideTab.prototype.loadData = function(poDocument) {
  if(this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null) return;
    
  var voCollectionNode = this.data.getNodesetData2();
  if(voCollectionNode == null) return;
  var vnLoop = voCollectionNode.getLength();
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vsParentNode = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  var vaNodes = [];
  var voTreeNode = null;
  var voButton = null;
  for(var i = 0; i < vnLoop; i++) {
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.item(i));
    vsLabelNode = voMapNode.get(this.labelTagName);
    vsBidNode = voMapNode.get(this.bidTagName);
    vsPidNode = voMapNode.get(this.pidTagName);
    
    voButton = this.addTab(vsLabelNode, vsBidNode, vsPidNode);
    voPageIdsInData.put(voButton.pageId, "");
  }
};
eXria.controls.xhtml.SlideTab.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
  
  var voSelectedPage = this.getPage(this.selectedIndex);
  if(this.renderAll) {
    var voIterator = this.contentPaneSet.iterator();
    var voContentPane = null;
    while(voIterator.hasNext()) {
      voContentPane = voIterator.next();
      if(voContentPane != voSelectedPage) {
	      voContentPane.setAttrCtrl("visibility", "hidden");
	      voContentPane.applyAttr("visible", true);
      }
      if(voContentPane.rendered){
        voContentPane.refresh(poDocument);
      } else {
        voContentPane.createChildren();
        voContentPane.rendered = true;
      }
      if(voContentPane != voSelectedPage) {
	      voContentPane.setAttrCtrl("visibility", "visible");
	      voContentPane.applyAttr("visible", false);
      }
    }
  } else {
    if(voSelectedPage) {
      voSelectedPage.refresh(poDocument);
    }
  }
  
  // yhkim  2009.07.07 : detail view에서 default값 설정
  if(this.selectedPageId)
  	this.selectById(this.selectedPageId)
  else {
  	if(this.selectedIndex != -1) this.expandButton(this.selectedIndex);
    else if(this.selectedIndex == -1 && this.selectedPageId != null) this.selectById(this.selectedPageId);
  }
};
/**
 * loadComplete
 * @ignore
 */
eXria.controls.xhtml.SlideTab.prototype.loadComplete = function(poDocument) {
  if(this.renderAll) {
    var voIterator = this.contentPaneSet.iterator();
    var voContentPane = null;
    var vnIE = this.canvas.page.metadata.browser.id;
    while(voIterator.hasNext()) {
      voContentPane = voIterator.next();
      if(vnIE < 8.0) voContentPane.setAttrCtrl("visibility", "hidden");
      voContentPane.setAttrCtrl("visible", true);
      if(voContentPane.rendered){
        voContentPane.refresh();
      } else {
        voContentPane.createChildren();
        voContentPane.rendered = true;
      }
      if(vnIE < 8.0) voContentPane.setAttrCtrl("visibility", "visible");
      voContentPane.setAttrCtrl("visible", false);
    }
  }
  
  // yhkim  2009.07.07 : detail view에서 default값 설정
  if(this.selectedPageId)
  	this.selectById(this.selectedPageId)
  else {
	  if(this.selectedIndex != -1) this.expandButton(this.selectedIndex);
	  else if(this.selectedIndex == -1 && this.selectedPageId != null) this.selectById(this.selectedPageId);
  }

};
/**
 * 내부의 포함된 컨트롤을 순환적으로 참조하기 위해 사용되는 메소드
 * @return 버튼에 종속된 컨텐츠 패널들을 저장하기 위한 eXria.data.ArrayCollection
 * @type eXria.data.ArrayCollection
 * @private
 */
eXria.controls.xhtml.SlideTab.prototype.getControls = function() {
  return this.contentPaneSet;
};
/**
 * 탭 버튼 및 그에 따른 탭 바디 추가 메소드.
 * @param {String} psButtonName 탭 버튼 라벨
 * @param {String} psButtonId 탭 버튼 아이디
 * @param {String} psPageId 탭 페이지 아이디
 * @return 추가된 탭 인덱스
 * @type Number
 */
eXria.controls.xhtml.SlideTab.prototype.addTab = function(psButtonName, psButtonId, psPageId) {
  var vsButtonId = null;
  var vsPageId = null;
  if(psButtonId == null) vsButtonId = this.id + "_button_" + this.seqNum;
  else vsButtonId = this.id + "_button_" + psButtonId;
  if(psPageId == null) vsPageId = this.id + "_page_" + this.seqNum;
  else vsPageId = this.id + "_page_" + psPageId;
  this.seqNum++;
  var voButton = new eXria.controls.xhtml.SlideButton(vsButtonId, 0, 0, this.width, this.slideButtons.height, this);
  voButton.subId = psButtonId;
  voButton.pageId = vsPageId;
  voButton.pageSubId = psPageId;
  voButton.value = psButtonName
  var voContentPane = new eXria.controls.xhtml.SlidePage(vsPageId, 0, 0, this.width, this.height, this);
  voContentPane.subId = psPageId;
  voContentPane.parent = this;
  this.buttonSet.add(voButton);
  this.contentPaneSet.add(voContentPane);
  
  var voCtrl = this.getCtrl();
  if(voCtrl) {
    voButton.canvas = this.canvas;
    voButton.window = this.window;
    voButton.document = this.document;
    voContentPane.canvas = this.canvas;
    voContentPane.window = this.window;
    voContentPane.document = this.document;
    var vnSize = this.buttonSet.size();
    this.createItemCtrl((vnSize - 1), voCtrl, this.document);
    for(var i = 0; i < vnSize - 1; i++) {
      voContentPane = this.contentPaneSet.get(i);
      voContentPane.applyAttrRebuild("height", (this.innerHeight - this.slideButtons.height * vnSize));
    }
  }
  
  return this.buttonSet.size() - 1;
};
/**
 * 슬라이드 버튼과 페이지의 실체화 객체 생성
 * @param {Number} pnIndex 슬라이드 버튼/탭의 인덱스
 * @param {HTMLDiv} poCtrl 슬라이드 탭 실체화 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 생성될 document
 * @private
 */
eXria.controls.xhtml.SlideTab.prototype.createItemCtrl = function(pnIndex, poCtrl, poDocument) {
  var vnSize = this.buttonSet.size();
  var voButton = this.buttonSet.get(pnIndex);
	var voBtnDf = this.slideButtons;
	var voPageDf = this.slidePages;
  voButton.top = voBtnDf.height * (pnIndex)
  voButton.width = this.innerWidth;
  voButton.height = voBtnDf.height;
  voButton.atclick = this.click;
  voButton.borderStyle = voBtnDf.borderStyle;
  voButton.borderColor = voBtnDf.borderColor;
  voButton.borderWidth = voBtnDf.borderWidth;
  voButton.borderLeftWidth = voBtnDf.borderLeftWidth;
  voButton.borderRightWidth = voBtnDf.borderRightWidth;
  voButton.borderTopWidth = voBtnDf.borderTopWidth;
  voButton.borderBottomWidth = voBtnDf.borderBottomWidth;
  voButton.padding = voBtnDf.padding;
  //voButton.paddingLeft = voBtnDf.paddingLeft;
  //voButton.paddingRight = voBtnDf.paddingRight;
  //voButton.paddingTop = voBtnDf.paddingTop;
  //voButton.paddingBottom = voBtnDf.paddingBottom;
  voButton.paddingLeft = this.paddingLeft;
  voButton.paddingRight = this.paddingRight;
  voButton.paddingTop = this.paddingTop;
  voButton.paddingBottom = this.paddingBottom;
  voButton.backgroundColor = voBtnDf.backgroundColor;
  voButton.backgroundImage = voBtnDf.backgroundImage;
  voButton.backgroundPosition = voBtnDf.backgroundPosition;
  voButton.backgroundRepeat = voBtnDf.backgroundRepeat;
  voButton.imageFocused = voBtnDf.imageFocused;
  voButton.color = voBtnDf.color;
  voButton.fontFamily = voBtnDf.fontFamily;
  voButton.fontSize = voBtnDf.fontSize;
  voButton.fontStyle = voBtnDf.fontStyle;
  voButton.fontWeight = voBtnDf.fontWeight;
  voButton.textAlign = voBtnDf.textAlign;
  voButton.textDecoration = voBtnDf.textDecoration;
  // slidebuttons의 속성을 버튼속성으로
  voButton.cursor = voBtnDf.cursor;
  voButton.control = this;
  
  // TODO: yhkim 2009.09.15 버튼 클래스를 사실상 아래와 같이 전달해줘야 한다.
  if(this.slideButtons) { 
	  voButton.className = this.slideButtons.className;
	  voButton.outerClassName = this.slideButtons.outerClassName;
  }
  
  var voContentPane = this.contentPaneSet.get(pnIndex);
  voContentPane.borderStyle = voPageDf.borderStyle;
  voContentPane.borderColor = voPageDf.borderColor;
  voContentPane.borderWidth = voPageDf.borderWidth;
  voContentPane.borderLeftWidth = voPageDf.borderLeftWidth;
  voContentPane.borderRightWidth = voPageDf.borderRightWidth;
  voContentPane.borderTopWidth = voPageDf.borderTopWidth;
  voContentPane.borderBottomWidth = voPageDf.borderBottomWidth;
  voContentPane.cursor = this.cursor;
  voContentPane.overflow = voPageDf.overflow;
  voContentPane.overflowX = voPageDf.overflowX;
  voContentPane.overflowY = voPageDf.overflowY;
  voContentPane.backgroundColor = voPageDf.backgroundColor;    
  if(this.expandDirection == "top") voContentPane.top = voBtnDf.height * (pnIndex);
  else voContentPane.top = voBtnDf.height * (pnIndex + 1);
  voContentPane.width = this.innerWidth;
  voContentPane.height = this.innerHeight - voBtnDf.height * vnSize;
  poCtrl.appendChild(voButton.create(poDocument));
  voButton.load(poDocument)
  poCtrl.appendChild(voContentPane.create(poDocument));
};
/**
 * 해당 인덱스의 탭을 제거
 * @param {Number} pnIndex 제거할 탭의 인덱스
 */
eXria.controls.xhtml.SlideTab.prototype.removeTab = function(pnIndex) {
  var voButton = this.buttonSet.remove(pnIndex);
  voButton.clear();
  var voContentPane = this.contentPaneSet.remove(pnIndex);
  voContentPane.clear();
  var voCtrl = this.getCtrl();
  if(voCtrl) {
    this.refresh(this.document);
  }
};
/**
 * 지정된 버튼의 인덱스 값을 반환 
 * @param {eXria.controls.xhtml.SlideButton} poButton 탭 버튼
 * @return 탭 버튼 인덱스
 * @type Number
 */
eXria.controls.xhtml.SlideTab.prototype.getItemIndex = function(poButton) {
  var voIterator = this.buttonSet.iterator();
  var voButton = null;
  while(voIterator.hasNext()) {
    voButton = voIterator.next();
    if(voButton == poButton) return voIterator.cursor;
  }
  return -1;
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 인덱스 번호 반환.
 * @param {String} psLabel 탭 버튼 라벨
 * @return 탭 인덱스
 * @type Number
 */
eXria.controls.xhtml.SlideTab.prototype.getIndex = function(psLabel) {
  var voIterator = this.buttonSet.iterator();
  var voTabButton = null;
  var i = 0;
  while(voIterator.hasNext()) {
    voTabButton = voIterator.next();
    if (voTabButton.value.indexOf(psLabel) == 0) { return i; }
    i++;
  }
  return -1;
};
/**
 * 지정된 pageId에 해당하는 탭 인덱스 반환.
 * @param {String} psPageId 탭 페이지 아이디
 * @return 탭 인덱스
 * @type Number
 */  
eXria.controls.xhtml.SlideTab.prototype.getIndexById = function(psPageId) {
  var vnIndex = -1;
  var vsPageId = this.id + "_page_" + psPageId;
  var voIterator = this.contentPaneSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == vsPageId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};
/**
 * 지정된 pageId에 해당하는 탭 인덱스 반환.
 * @param {String} psPageSubId 페이지 아이디.
 * @return 탭 인덱스
 * @type Number
 */  
eXria.controls.xhtml.SlideTab.prototype.getIndexBySubId = function(psPageSubId) {
  var vnIndex = -1;
  var voIterator = this.contentPaneSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.subId == psPageSubId) {
      vnIndex = cnt;
      break;
    }
  }
  return vnIndex;
};
/**
 * 모든 탭 제거.
 */
eXria.controls.xhtml.SlideTab.prototype.removeAll = function() {
  var vnSize = this.buttonSet.size();
  for(var i = 0; i < vnSize; i++) {
		this.removeTab(0);
  };
};
/**
 * 지정된 라벨에 해당하는 탭 제거.
 * @param {String} psLabel 탭 버튼 레이블명.
 */
eXria.controls.xhtml.SlideTab.prototype.removeTabByLabel = function(psLabel) {
  var vnIndex = this.getIndex(psLabel);
  this.removeTab(vnIndex);
};
/**
 * 지정된 페이지 아이디에 해당하는 탭 버튼 제거.
 * @param {String} psPageSubId 텝 페이지 아이디.
 */
eXria.controls.xhtml.SlideTab.prototype.removeTabById = function(psPageSubId) {
  var vnIndex = this.getIndexBySubId(psPageSubId);
  this.removeTab(vnIndex);
};
/**
 * 지정된 인덱스에 해당하는 탭 버튼 반환.
 * @param {Number} pnIndex 탭 인덱스
 * @return 지정된 인덱스에 해당하는 탭 버튼
 * @type eXria.controls.xhtml.SlideButton  
 */   
eXria.controls.xhtml.SlideTab.prototype.getButton = function(pnIndex) {
  var voTabButton = this.buttonSet.get(pnIndex);
  return voTabButton;
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 반환.
 * @param {String} psLabel 탭 버튼 레이블명
 * @return 지정된 라벨에 해당하는 탭 버튼 객체
 * @type eXria.controls.xhtml.SlideButton
 */
eXria.controls.xhtml.SlideTab.prototype.getButtonByLabel = function(psLabel) {
  var voIterator = this.buttonSet.iterator();
  var voTabButton = null;
  while(voIterator.hasNext()) {
    voTabButton = voIterator.next(); 
    if (voTabButton.value == psLabel) { return voTabButton; }
  }
  return null;
};
/**
 * 지정된 라벨에 해당하는 탭 버튼 반환.
 * @param {String} psButtonSubId 탭 버튼 아이디
 * @return 지정된 아이디에 해당하는 탭 버튼 객체
 * @type eXria.controls.xhtml.SlideButton
 */
eXria.controls.xhtml.SlideTab.prototype.getButtonById = function(psButtonSubId) {
	var voIterator = this.buttonSet.iterator();
  var voTabButton = null;
  while(voIterator.hasNext()) {
    voTabButton = voIterator.next();
    if (voTabButton.subId == psButtonSubId) { return voTabButton; }
  }
  return null;
};
/**
 * 지정된 인덱스에 해당하는 탭 페이지 반환.
 * @param {Number} pnIndex 탭 인덱스
 * @return 지정된 인덱스에 해당하는 탭 페이지
 * @type eXria.controls.xhtml.SlidePage  
 */   
eXria.controls.xhtml.SlideTab.prototype.getPage = function(pnIndex) {
  var voContentPane = null;
  try {
  	voContentPane = this.contentPaneSet.get(pnIndex);
  } catch(err) {}
  return voContentPane;
};
/**
 * 지정된 페이지 ID에 해당하는 탭 페이지 반환.
 * @param {String} psPageId 탭 인덱스
 * @return 지정된 페이지 ID에 해당하는 탭 페이지
 * @type eXria.controls.xhtml.SlidePage
 */    
eXria.controls.xhtml.SlideTab.prototype.getPageById = function(psPageId) {
  var vnIndex = -1;
  var vsId = this.id + "_page_" + psPageId;
  var voIterator = this.contentPaneSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {      
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == vsId) {
      vnIndex = cnt;
      break;
    }
  }
  
  var voContentPane = null;
  voContentPane = this.contentPaneSet.get(vnIndex);
  return voContentPane;  
};  
/**
 * 슬라이드 버튼의 atclick 이벤트 핸들러
 * @private
 */
eXria.controls.xhtml.SlideTab.prototype.click = function(poEvent) {
  var voButton = poEvent.object;
  var voButtonSelected = null;
  var voControl = this.control;
  if(voControl.selectedIndex != -1 && voControl.selectedIndex < voControl.buttonSet.size()) voButtonSelected = voControl.buttonSet.get(voControl.selectedIndex);
  
  if(voButton == voButtonSelected){
  	if(voControl.closable && voControl.selectedPageId) {
  	  voControl.collapseButton(voControl.selectedIndex);
      voControl.selectedPageId = null;
      return;
  	} else if(voControl.closable && voControl.selectedPageId == null) {  
      var vnIndex = voControl.getItemIndex(voButton);
      var vsPageId = voControl.contentPaneSet.get(vnIndex).id;
      voControl.selectedPageId = vsPageId.slice(voControl.id.length + 6);          
  		voControl.expandButton(vnIndex);
      return;
  	} else {
      return;
    }
  }

  var vnIndex = voControl.getItemIndex(voButton);
  voControl.expandButton(vnIndex);
  voControl.selectedIndex = vnIndex;
  this.selectedIndex = vnIndex;
  var vsPageId = voControl.contentPaneSet.get(vnIndex).id;
  voControl.selectedPageId = vsPageId.slice(voControl.id.length + 6);
};
/**
 * 지정된 인덱스에 해당하는 탭 페이지 펼침
 * @param {Number} pnIndex 탭 버튼/페이지 인덱스
 * @private
 */
eXria.controls.xhtml.SlideTab.prototype.expandButton = function(pnIndex) {
  var voButton = null;
  var voButtonCtrl = null;
  var voContentPane = null;
  var vnTop = null;
  var vnSize = this.buttonSet.size();
  var vnVisibleSize = this.buttonVisibleSet.size();
  var vnVisibleIndex = 0;
  var voBtnDf = this.slideButtons;

  if(pnIndex < 0 || pnIndex > vnSize - 1) return;
  for(var i = 0; i < vnSize; i++) {
    voButton = this.buttonSet.get(i);
    voButtonCtrl = voButton.getCtrl(this.document).childNodes[0];
    voContentPane = this.contentPaneSet.get(i);
    if(this.expandDirection == "top") {
      if(i >= pnIndex) {
        vnTop = this.innerHeight - voBtnDf.height * (vnVisibleSize);
      } else {
        vnTop = voBtnDf.height * (vnVisibleIndex);
      }
    } else {
      if(i > pnIndex) {
        vnTop = this.innerHeight - voBtnDf.height * (vnVisibleSize);
      } else {
        vnTop = voBtnDf.height * (vnVisibleIndex);
      }
    }
    voButton.applyAttrRebuild("top", vnTop);
    if(voButton.visible == false) {
      voContentPane.applyAttr("visible", false);
      voButton.applyAttr("visible", false);
    } else {
      vnVisibleSize = vnVisibleSize - 1;
      vnVisibleIndex = vnVisibleIndex + 1;      
      if(i == pnIndex) {
        voButton.imageFocused = voBtnDf.imageFocused;
        voButton.oldImage = voBtnDf.imageFocused;
        voButton.setAttrCtrl("backgroundColor", voBtnDf.focusBackgroundColor, voButtonCtrl);
        voButton.setAttrCtrl("color", voBtnDf.focusColor, voButtonCtrl);
        voButton.setAttrCtrl("backgroundImage", voBtnDf.imageFocused, voButtonCtrl);
        if(voButton.visible != null) {
          voContentPane.applyAttr("visible", voButton.visible);
        } else {
          voContentPane.setAttrCtrl("visible", true);
          var vsPageId = this.voContentPane.id;
          this.selectedPageId = vsPageId.slice(this.id.length + 6);  
        }
        if(voContentPane.rendered == false) {
          voContentPane.createChildren(this.document);
          voContentPane.rendered = true;
        }
      } else {
        if(i == this.selectedIndex) {
          if(voBtnDf.backgroundColor) voButton.setAttrCtrl("backgroundColor", voBtnDf.backgroundColor, voButtonCtrl);
          else voButton.setAttrCtrl("backgroundColor", "", voButtonCtrl);
          //voButton.setAttrCtrl("color", voBtnDf.color, voButtonCtrl);
          // 이렇게 하게 되면 css 클래스를 따르게 된다
          voButton.setAttrCtrl("color", "", voButtonCtrl);
          if(voBtnDf.backgroundImage == null) voBtnDf.backgroundImage = "";
          voButton.setAttrCtrl("backgroundImage", voBtnDf.backgroundImage, voButtonCtrl);
        }
        voContentPane.setAttrCtrl("visible", false);
      }
    }
  }
};
/**
 * 지정된 인덱스에 해당하는 탭 선택
 * @param {String} pnIndex 지정된 탭의 인덱스
 */
eXria.controls.xhtml.SlideTab.prototype.selectTab = function(pnIndex) {
  this.expandButton(pnIndex);
  this.selectedIndex = pnIndex;
  var vsPageId = this.contentPaneSet.get(pnIndex).id;
  this.selectedPageId = vsPageId.slice(this.id.length + 6);
}
/**
 * 지정된 페이지 아이디에 해당하는 탭 페이지 선택
 * @param {String} psPageId 지정된 페이지의 아이디
 */
eXria.controls.xhtml.SlideTab.prototype.selectById = function(psPageId) {
  var vnIndex = -1;
  var vsId = this.id + "_page_" + psPageId;
  var voIterator = this.contentPaneSet.iterator();
  var voPage = null;
  var cnt = -1;
  while(voIterator.hasNext()) {
    voPage = voIterator.next();
    cnt++;
    if(voPage.id == vsId) {
      vnIndex = cnt;
      break;
    }
  }
  
  this.selectedIndex = vnIndex;
  var voCtrl = this.getCtrl(this.document);
  if(voCtrl) this.expandButton(vnIndex);
};
/**
 * 지정된 인덱스에 해당하는 탭 페이지 닫음
 * @param {Number} pnIndex
 */
eXria.controls.xhtml.SlideTab.prototype.collapseButton = function(pnIndex) {
  var voButton = null;
  var voButtonCtrl = null;
  var voContentPane = null;
  var vnTop = null;
  var vnSize = this.buttonSet.size();
	var voBtnDf = this.slideButtons;
  for(var i = 0; i < vnSize; i++) {
    voButton = this.buttonSet.get(i);
    voButtonCtrl = voButton.getCtrl(this.document).childNodes[0];
    if(this.expandDirection == "top")  {
      if(i >= pnIndex) {
        vnTop = voBtnDf.height * (i);
        voButton.applyAttrRebuild("top", vnTop);
      }
    } else {
      if(i > pnIndex) {
        vnTop = voBtnDf.height * (i);
        voButton.applyAttrRebuild("top", vnTop);
      }
    }
    voContentPane = this.contentPaneSet.get(i);
    if(i == pnIndex) {
    	voButton.imageFocused = voBtnDf.backgroundImage;
      voButton.oldImage = voBtnDf.backgroundImage;
      voButton.setAttrCtrl("backgroundColor", voBtnDf.backgroundColor, voButtonCtrl);
      voButton.setAttrCtrl("color", voBtnDf.color, voButtonCtrl);
      voButton.setAttrCtrl("backgroundImage", voBtnDf.backgroundImage, voButtonCtrl);
      voContentPane.setAttrCtrl("visible", false);
    }
  }  
};
/**
 * @ignore
 */
eXria.controls.xhtml.SlideTab.prototype.clear = function() {
  var voButton = null;
  var voContentPane = null;
  var voIterator = this.buttonSet.iterator();
  while(voIterator.hasNext()) {
    voButton = voIterator.next();
    voButton.clear();
  }
  voIterator = this.contentPaneSet.iterator();
  while(voIterator.hasNext()) {
    voContentPane = voIterator.next();
    voContentPane.clear();
  }    
  this.clearCtrl();
  this.clearControl();
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type String|Number
 * @ignore
 */
eXria.controls.xhtml.SlideTab.prototype.getSpecificDefaultValue = function(psAttrName){
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.SlideTab[psAttrName];
  } else if (vaAttrName.length == 2) {
    if(eXria.controls.xhtml.Default.SlideTab[vaAttrName[0]]) vsDefaultValue = eXria.controls.xhtml.Default.SlideTab[vaAttrName[0]][vaAttrName[1]] == null ? vsDefaultValue : eXria.controls.xhtml.Default.SlideTab[vaAttrName[0]][vaAttrName[1]]; 
  }
  if(vsDefaultValue === undefined) {
    //alert(psAttrName + " - Default 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};

/**
 * 지정된 탭을 보이거나 숨기기
 * @param  {Number} pnIndex 탭의 인덱스
 * @param  {Boolean} pbShow 탭을 보이거나 숨길지의 여부 
 */
eXria.controls.xhtml.SlideTab.prototype.showTab = function(pnIndex, pbShow){
  if(pbShow){
    this.getButton(pnIndex).visible = true;
    this.getPage(pnIndex).visible = true;
    this.refresh();
    this.selectTab(pnIndex);
  } else {
    var voVisibleButton = null;
    var voButton = this.getButton(pnIndex);
    var vnSize = this.buttonVisibleSet.size();
    
    for(var i = 0; i < vnSize; i++) {
      voVisibleButton = this.buttonVisibleSet.get(i);
      if(voVisibleButton == voButton) {
        if(i == (vnSize-1)) voVisibleButton = this.buttonVisibleSet.get(0);
        else voVisibleButton = this.buttonVisibleSet.get(i+1);
        break;
      }   
    }
     
    voButton.visible = false;
    this.getPage(pnIndex).visible = false;        
    this.refresh();
    var vnIndex = this.getItemIndex(voVisibleButton);
    this.selectTab(vnIndex);
  }				
}

/**
 * 클래스 명을 반환.
 * @return "SlideTab"
 * @type String
 */
eXria.controls.xhtml.SlideTab.prototype.toString = function() {
  return "SlideTab";
};
