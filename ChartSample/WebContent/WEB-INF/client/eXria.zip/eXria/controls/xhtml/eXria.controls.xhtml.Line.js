/**
 * @fileoverview
 * Concreate xhtml Line(XHTML Line 컨트롤)
 * @author 이종녕
 */

/**
 * @class xhtml Line Control.<br>
 * 심플 라인 도형을 표현하는 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Line 객체
 * @type eXria.controls.xhtml.Line
 * @constructor
 * @base eXria.controls.xhtml.ShapeControl
 */ 
eXria.controls.xhtml.Line = function(psId, pnLeft, pnTop, pnWidth, pnHeight){
//  var base = this;
	/**
	 * pnLeft 컨트롤 좌상단 점의 x좌표.
	 * @type Number
	 */
  pnLeft =  pnLeft == null ? 20 : pnLeft;
  /**
   * pnTop 컨트롤 좌상단 점의 y좌표.
   * @type Number
   */
  pnTop =  pnTop == null ? 20 : pnTop;
  /**
   * pnWidth 컨트롤의 가로 길이.
   * @type Number
   */
  pnWidth =  pnWidth == null ? 100 : pnWidth;
  /**
   * pnHeight 컨트롤의 세로 길이.
   * @type Number
   */
  pnHeight =  pnHeight == null ? 100 : pnHeight;

  eXria.controls.xhtml.ShapeControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /////////////////////////////////////////////////////////////////////////////
  ////속성 
  
  /**
   * top/bottom
   * @type String
   */
  this.startPosition = null;
  
  /**
   * 컨트롤의 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.ShapeControl, eXria.controls.xhtml.Line);
//////////////////////////////////////////////////////////////////   
//// 메소드 

/**
 * 실체화 컨트롤 생성.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 실체화 객체의 최외곽 div
 * @type HTMLDiv
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.createCtrl = function(poDocument){ 
  var voDiv = poDocument.createElement("div");
  var voStyle = voDiv.style;
  voDiv.setAttribute("id",this.id);
  voStyle.padding = "0px";
  voStyle.margin = "0px";
  voStyle.borderStyle = "none";
  voStyle.borderWidth = "0px";
  voStyle.position = "absolute";
  
  this.ctrl = voDiv;
  return voDiv;
};
/*
this.angleHeight = function(pnWidth,pnHeight) {
  var vnR = Math.pow(pnWidth,2) + Math.pow(pnHeight,2);
  vnR = (Math.sqrt(vnR)/2);
  var vnAngle = Math.asin(this.height/2/vnR)*180/Math.PI;
  var vnL = Math.sin(Math.PI/180*(vnAngle+this.angle%91));
  vnR = vnR*vnL;
  return Math.round(vnR);
}

this.angleWidth = function(pnWidth,pnHeight) {
  var vnR = Math.pow(pnWidth,2) + Math.pow(pnHeight,2);
  vnR = (Math.sqrt(vnR)/2);
  var vnAngle = Math.asin(this.width/2/vnR)*180/Math.PI;
  var vnL = Math.sin(Math.PI/180*(vnAngle+this.angle%91));
  vnR = vnR*vnL;
  return Math.round(vnR);
}
*/

/**
 * createLineCtrl
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.createLineCtrl = function(poCtrl,poDocument){
  var voWindow = this.window;
  poCtrl.style.top = this.top ;
  poCtrl.style.left = this.left;
/*
  var vnDistanceY = this.angleHeight(this.width,this.height); 
  var vnDistanceX = this.angleWidth(this.width,this.height);
  var vnHeight = (vnDistanceY - this.height/2);  
  var vnWidth = (vnDistanceX - this.width/2);  */
  gCore.init(voWindow); // 초기화.....
  var voDf = this.df;
  var pane = new voWindow.Pane(this.id+"_draw",0,0,this.width,this.height,poDocument);
  var voCtrl = null;
  if(voDf.startPosition == "top") {
    voCtrl = new voWindow.Line(this.id+"_line",0, 0, this.width, this.height);
  }  
  else if(voDf.startPosition == "bottom") { 
    voCtrl = new voWindow.Line(this.id+"_line",0,this.height,this.width,0);
  }
  var voCtrlStroke = voCtrl.stroke;
  
  voCtrlStroke.color = voDf.penColor;
  voCtrlStroke.weight = voDf.penWeight + "px";
  voCtrlStroke.type = this.toConstPenstyle(voDf.penStyle);
  voCtrlStroke.opacity = this.toPercent(voDf.penOpacity);
  if(voDf.penColor == "transparent") voCtrlStroke.opacity = 0;
  voCtrlStroke.lineCap = this.toConstPencap(voDf.penCap);
  voCtrlStroke.joinType = this.toConstJointype(voDf.joinType); 
  voCtrl.angle = voDf.angle;
  voCtrl.cursor = voDf.cursor;
  //yhkim shapeType 추가
  voCtrl.shapeType = "line";
  pane.addShape(voCtrl);
  pane.draw(poCtrl);
}; 
/**
 * setMainCtrlStyles
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
//eXria.controls.xhtml.Line.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
//};  

/**
 * setSpecificDefaults
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document 
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  this.df.startPosition = this.getAttrValue("startPosition",this.startPosition);
};

/**
 * setSpecificAttrs
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.setSpecificAttrs = function(poCtrl,poDocument) {
  this.createLineCtrl(poCtrl,poDocument);
};  

/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
};

/**
 * setSpecificEvents
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document 
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.setSpecificEvents = function(poCtrl, poDocument) {
};

/**
 * removeSpecificDefaults
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  //this.setAttrCtrl("borderColor", "", voCtrl);
  //this.setAttrCtrl("borderStyle", "", voCtrl);
  this.df = {};
};

/**
 * refreshSpecificAttrs
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.refreshSpecificAttrs = function(poCtrl, poDocument){
  var voDiv = this.getCtrl(poDocument);
  var voPaneCtrl = voDiv.childNodes[0];
  voDiv.removeChild(voPaneCtrl);
  this.setSpecificAttrs(poCtrl, poDocument);
};  

/**
 * applyAttrRefresh
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.Line.prototype.applyAttrRefresh = function(psAttrName, psAttrValue, poDocument) {
  this.setAttr(psAttrName, psAttrValue);
//  this.setAttrCtrl(psAttrName, psAttrValue);
//  var voDiv = this.getCtrl(poDocument);
//  var voPaneCtrl = voDiv.childNodes[0];
//  voDiv.removeChild(voPaneCtrl);
//  this.createLineCtrl(voDiv,poDocument);
  this.refresh(poDocument);
}; 

/**
* 서브 컨트롤 실체화 객체를 얻어온다.
* @param {String} psTagName 컨트롤 태그 이름
* @param {HTMLDiv} poCtrl 실체화 컨트롤, 생략가능
* @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document, 생략가능
* @return 서브 컨트롤 실체화 객체
* @type Object
*/
eXria.controls.xhtml.Line.prototype.getSubCtrl = function(psTagName, poCtrl, poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  var subCtrl = poCtrl.getElementsByTagName(psTagName)[0];
  return subCtrl;
};

/**
 * 클래스 명을 반환한다.
 * @return "Line"
 * @type String
 */
eXria.controls.xhtml.Line.prototype.toString = function() {
  return "Line";
};

/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 해당 속성명의 디폴트 속성 값
 * @type String
 * @ignore 
 */
eXria.controls.xhtml.Line.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Line[psAttrName];
  if(vsDefaultValue == null) vsDefaultValue = this.getShapeDefaultValue(psAttrName);
  if(vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};