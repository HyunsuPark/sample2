/**
 * @fileoverview
 * Concreate xhtml TreeView(XHTML TreeView 컨트롤)
 * @author 조영진
 */

/**
 * @class Concreate xhtml TreeView.<br>
 * XHTML TreeView 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return eXria.controls.xhtml.TreeView 새로운 객체
 * @type eXria.controls.xhtml.TreeView
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */ 
eXria.controls.xhtml.TreeView = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  
  pnLeft =  pnLeft == null ? 20 : pnLeft;
  pnTop =  pnTop == null ? 20 : pnTop;
  pnWidth =  pnWidth == null ? 200 : pnWidth;
  pnHeight =  pnHeight == null ? 250 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  //** 데이타연동관련
  /**
   * Data 연동 객체.
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  
  /**
   * 인스턴스로 부터 라벨 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.labelTagName = "label";
   
  /**
   * 인스턴스로 부터 value 데이타를 가져올 때 사용될 DOM Element 명.
   * @type String
   */
  this.valueTagName = "value";  
  //** 데이타연동관련End
  
  //////////////////////////////////////////////////////////////////
  // 속성   
  /**
   * 루트노드 전체 노드의 최상위 노드. 화면에 보여지지는 않음.
   * readOnly
   */
  this.root = null;
  
  /**
   * 전체 트리노드 저장 collection 객체
   * @type ArrayCollection()
   */
  this.items = new eXria.data.ArrayMap();
  
  /**
   * 노드 생성 시 순차적으로 증가하는 노드 인덱스(노드 ID 생성에 이용)의 최근값 저장.
   * @private
   */
  this.latestIdx = 0;
  
  /**
   * 아이콘 이미지 경로를 나타내는 상수.
   * @type Object
   */
  this.iconFiles = {
    blank : null, //0
    verticalLine : null, //1                     
    closedLastnode : null, //2  
    closedNode : null, //3 
    openedLastnode : null, //4 
    openedNode : null, //5 
    lastnode : null, //6 
    node : null, //7 
    closedFolder : null, //8     
    openedFolder : null, //9
    leafItem : null, //10
    selectedLeafItem : null //11
  };
  
  /**
   * 아이콘 이미지 경로 상수에 해당하는 실체화 객체를 저장하는 Map.
   * @type eXria.data.ArrayMap
   */ 
  this.icons = new eXria.data.ArrayMap();
    
  /**
   * Selection Mode.<br>
   * 트리노드의 선택 유형[단일선택, 다중선택]
   * @type String
   * @ignore
   */    
  this.selectionMode = null;//[single | multi]
  
  /**
   * Selected Node instance.<br>
   * 선택된 트리노드 리스트(펼쳐진 트리노드와는 구별됨. 텍스트가 선택된 트리노드).
   * @private
   */
  this.selectedItems = new eXria.data.ArrayCollection();
  
  /**
   * Opened Node.<br>
   * 열려진 트리노드(마지막으로 선택된 트리노드).
   * @type eXria.controls.xhtml.TreeNode
   * @private
   */
  this.openedItem = null;
  
  /**
   * 아이템 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;
  
  /**
   * 아이템 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;
  
  /**
   * 아이템 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;
  
  /**
   * 아이템 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;
  
  /**
   * 아이템 텍스트 컨텐츠 오버플로우 속성.
   * @type String
   */
  this.overflow = null;
  
  /**
   * Directory for tree icon, must absolute path from webroot<br>
   * 이미지 파일이 위치한 디렉토리.
   * @type String
   */
  this.iconDir = null;
  
  /**
   * 이미지 파일의 가로길이(사용되는 모든 이미지 파일에 사이즈는 동일해야함).
   * @type Number
   */
  this.iconWidth = 19;
  
  /**
   * 이미지 파일의 세로길이.
   * @type Number
   */
  this.iconHeight = 16;
  
  /**
   * Changed node list for repaint.<br>
   * redraw 해할야 트리노드 목록.
   * @private
   */
  this.changedNodes = new eXria.data.ArrayCollection();
  
  /**
   * Name of Root Node
   * @private
   */
  this.rootName = "ROOT";
  
  /**
   * Value of Selected TreeNode.
   * @type String
   */
  this.value = null;
  
  /**
   * 드래그&드랍을 허용할 지 여부
   * @type Boolean
   */  
  this.dragDrop = true;
  
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   */
  this.innerWidth = this.width;
  
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   */
  this.innerHeight = this.height;
  
  /**
   * 아이템 공통 속성 저장 오브젝트.
   * @type Object
   * @private
   */
  this.itemgroup = new eXria.controls.xhtml.TreeView_itemgroup();

  /**
   * 마우스가 텍스트에 위치해 있을 때의 마우스 커서 타입.
   * @type String
   * @private
   */
  this.spanCursor = "pointer";  
  
  /**
   * 이벤트 target이 컨트롤인지 아이템인지를 구분하기 위한 속성
   * @type String
   * @private
   */
   this.eventObjectType = null;
  
  /**
   * 컨트롤이 디스플레이 되는 document 객체.
   * @type Object
   * @private
   */
  this.document = null;
  
  /**
   * 펼쳐진 노드의 루트 노드로부터의 상대 위치를 저장하는 배열 
   * @type Array(String)
   * @private
   */  
  this.expandedIndexes = null;
    
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  
  /**
   * init
   */
  this.init();  
};
  
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.TreeView);
  
//////////////////////////////////////////////////////////////////
// 메소드  
/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.init = function() {
  this.root = this.createTreeNode(this.rootName);
  this.root.index = this.latestIdx++;
  this.root.setValue("");
  this.root.tree = this;
  this.root.depth = 0;
  this.root.expand = true;
  this.items.put(this.root.index, this.root);
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.createCtrl = function(poDocument) { 
  var voCtrl = poDocument.createElement("div");
  voCtrl.setAttribute("id", this.id);
  this.document = poDocument;
  return voCtrl;
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.createSubCtrl = function(poCtrl, poDocument) {
  /*var voTable = poDocument.createElement("div");
  voTable.setAttribute("id", this.id + "_table");
  var voStyle = voTable.style;
  voStyle.position = "absolute" ;
  voStyle.margin = "0px";
  voStyle.padding = "0px"  
  voStyle.left = "0px";
  voStyle.top = "0px";
     
  voTable.ondragstart = function(e) { return false; };
  voTable.onselectstart = function(e) { return false; };
  voTable.oncontextmenu = function(e) { return false; };
  poCtrl.appendChild(voTable);
  */
  vaTemplate = this.template;
  vaTemplate.push("<div id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_table' style='position:absolute;margin:0;padding:0;left:0;top:0;'");
  vaTemplate.push(" ongragstart = 'return false' onselectstart = 'return false' oncontextmenu = 'return false'");
  vaTemplate.push(">");
  vaTemplate.push("</div>");
  
  
  this.loadIcons(); 
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
  var voTable = poCtrl.childNodes[0];
  this.setAttrCtrl("className", this.className, voTable);
  this.setAttrCtrl("className", this.outerClassName, poCtrl);      
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.setSpecificDefaults = function(poCtrl, poDocument) {    
  var voIconFiles = this.iconFiles;
  var voDf = this.df;
  var voItemgroupDf = this.itemgroup.df;
  voIconFiles.blank = this.getAttrValue("iconFiles.blank",voIconFiles.blank);
  voIconFiles.verticalLine = this.getAttrValue("iconFiles.verticalLine",voIconFiles.verticalLine);
  voIconFiles.closedLastnode = this.getAttrValue("iconFiles.closedLastnode",voIconFiles.closedLastnode);
  voIconFiles.closedNode = this.getAttrValue("iconFiles.closedNode",voIconFiles.closedNode);
  voIconFiles.openedLastnode = this.getAttrValue("iconFiles.openedLastnode",voIconFiles.openedLastnode);
  voIconFiles.openedNode = this.getAttrValue("iconFiles.openedNode",voIconFiles.openedNode);
  voIconFiles.lastnode = this.getAttrValue("iconFiles.lastnode",voIconFiles.lastnode);
  voIconFiles.node = this.getAttrValue("iconFiles.node",voIconFiles.node);
  voIconFiles.closedFolder = this.getAttrValue("iconFiles.closedFolder",voIconFiles.closedFolder);
  voIconFiles.openedFolder = this.getAttrValue("iconFiles.openedFolder",voIconFiles.openedFolder);
  voIconFiles.leafItem = this.getAttrValue("iconFiles.leafItem",voIconFiles.leafItem);
  voIconFiles.selectedLeafItem = this.getAttrValue("iconFiles.selectedLeafItem",voIconFiles.selectedLeafItem);
         
  var voCssStyle = this.getCssStyle(this.outerClassName, poDocument);
  voDf.borderColor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderColor");
  voDf.borderStyle = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderStyle");
  voDf.borderWidth = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderWidth");
  voDf.borderLeftWidth = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderLeftWidth");
  voDf.borderRightWidth = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderRightWidth");
  voDf.borderTopWidth = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderTopWidth");
  voDf.borderBottomWidth = this.makeSpecificAttrValue(poCtrl, voCssStyle, "borderBottomWidth");
  if(voDf.borderWidth != null) voDf.borderWidth = parseInt(voDf.borderWidth);
  else voDf.borderWidth = 0;
  if(voDf.borderLeftWidth != null) voDf.borderLeftWidth = parseInt(voDf.borderLeftWidth);
  else voDf.borderLeftWidth = voDf.borderWidth;
  if(voDf.borderRightWidth != null) voDf.borderRightWidth = parseInt(voDf.borderRightWidth);
  else voDf.borderRightWidth = voDf.borderWidth;    
  if(voDf.borderTopWidth != null) voDf.borderTopWidth = parseInt(voDf.borderTopWidth);
  else voDf.borderTopWidth = voDf.borderWidth;
  if(voDf.borderBottomWidth != null) voDf.borderBottomWidth = parseInt(voDf.borderLeftWidth);
  else voDf.borderBottomWidth = voDf.borderWidth;
  if(voDf.borderStyle == "none") {
    voDf.borderWidth = 0;
    voDf.borderLeftWidth = 0;
    voDf.borderRightWidth = 0;
    voDf.borderTopWidth = 0;
    voDf.borderBottomWidth = 0;
  }
  this.innerWidth = this.width - voDf.borderLeftWidth - voDf.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - voDf.borderTopWidth - voDf.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
  
  voCssStyle = this.getCssStyle(this.className, poDocument);
  voDf.backgroundColor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "backgroundColor");
  voDf.color = this.makeSpecificAttrValue(poCtrl, voCssStyle, "color");
  voDf.cursor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "cursor");
  voDf.textAlign = this.makeSpecificAttrValue(poCtrl, voCssStyle, "textAlign");
  voDf.fontFamily = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontFamily");
  voDf.fontSize = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontSize");
  voDf.fontStyle = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontStyle");
  voDf.fontWeight = this.makeSpecificAttrValue(poCtrl, voCssStyle, "fontWeight");
  voDf.overflow = this.makeSpecificAttrValue(poCtrl, voCssStyle, "overflow");
  voDf.overflowX = this.makeSpecificAttrValue(poCtrl, voCssStyle, "overflowX");
  voDf.overflowY = this.makeSpecificAttrValue(poCtrl, voCssStyle, "overflowY");
  if(voDf.overflowX == null) voDf.overflowX = voDf.overflow;
  if(voDf.overflowY == null) voDf.overflowY = voDf.overflow;
  if(voDf.fontSize != null) voDf.fontSize = parseInt(voDf.fontSize);
  voDf.iconDir = this.getAttrValue("iconDir",this.iconDir);
  voDf.iconWidth = this.getAttrValue("iconWidth",this.iconWidth);
  voDf.iconHeight = this.getAttrValue("iconHeight",this.iconHeight);
  voDf.expandAll = this.getAttrValue("expandAll",this.expandAll);
  voDf.selectionMode = this.getAttrValue("selectionMode",this.selectionMode);
  
  voItemgroupDf.className = this.getAttrValue("itemgroup.className",this.itemgroup.className);
  voCssStyle = this.getCssStyle(voItemgroupDf.className, poDocument);
  voItemgroupDf.backgroundColor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.backgroundColor");
  voItemgroupDf.color = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.color");
  voItemgroupDf.cursor = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.cursor");
  voItemgroupDf.fontFamily = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.fontFamily");
  voItemgroupDf.fontSize = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.fontSize");
  voItemgroupDf.fontStyle = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.fontStyle");
  voItemgroupDf.fontWeight = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.fontWeight");
  voItemgroupDf.textAlign = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.textAlign");
  voItemgroupDf.verticalAlign = this.makeSpecificAttrValue(poCtrl, voCssStyle, "itemgroup.verticalAlign");
  if(voItemgroupDf.fontSize != null) voItemgroupDf.fontSize = parseInt(voItemgroupDf.fontSize);
  voItemgroupDf.selectedBackgroundColor = this.getAttrValue("itemgroup.selectedBackgroundColor",this.itemgroup.selectedBackgroundColor);
  voItemgroupDf.selectedColor = this.getAttrValue("itemgroup.selectedColor",this.itemgroup.selectedColor);
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  /*var voRuler = this.lookup(this.id + "_ruler");    
  var voStyle = voRuler.style;
  voStyle.fontFamily = this.fontFamily;
  voStyle.fontSize = this.fontSize + "pt";*/
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  
  /*
  this.setAttrCtrl("width", this.innerWidth, poCtrl);
  this.setAttrCtrl("height", this.innerHeight, poCtrl);
  this.setAttrCtrl("borderColor", voDf.borderColor, poCtrl);
  this.setAttrCtrl("borderStyle", voDf.borderStyle, poCtrl);
  this.setAttrCtrl("borderLeftWidth", voDf.borderLeftWidth + "px", poCtrl);
  this.setAttrCtrl("borderRightWidth", voDf.borderRightWidth + "px", poCtrl);
  this.setAttrCtrl("borderTopWidth", voDf.borderTopWidth + "px", poCtrl);
  this.setAttrCtrl("borderBottomWidth", voDf.borderBottomWidth + "px", poCtrl);
  this.setAttrCtrl("backgroundColor", voDf.backgroundColor, poCtrl);
  this.setAttrCtrl("color", voDf.color, poCtrl);
  this.setAttrCtrl("overflowX", voDf.overflowX, poCtrl);
  this.setAttrCtrl("overflowY", voDf.overflowY, poCtrl);
  this.setAttrCtrl("cursor", voDf.cursor, poCtrl);
  this.setAttrCtrl("textAlign", voDf.textAlign, poCtrl);
  this.setAttrCtrl("fontFamily", voDf.fontFamily, poCtrl);
  this.setAttrCtrl("fontSize", voDf.fontSize, poCtrl);
  this.setAttrCtrl("fontStyle", voDf.fontStyle, poCtrl);
  this.setAttrCtrl("fontWeight", voDf.fontWeight, poCtrl);
  */
  poCtrl["tabIndex"] = voDf.tabIndex
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  vfcSetCssStrBuf(vaCssStrBuf, "tooltip", voDf.tooltip);
  vfcSetCssStrBuf(vaCssStrBuf, "disabled", voDf.disabled);
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", voDf.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", voDf.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", voDf.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", voDf.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", voDf.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", voDf.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", voDf.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", voDf.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", voDf.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", voDf.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", voDf.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", voDf.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", voDf.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", voDf.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", voDf.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-x", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow-y", voDf.overflow);
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", voDf.cursor);

  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  
  this.loadIcons();
  
  this.changedNodes.clear();    
  var voTable = poCtrl.childNodes[0];
  try {
    var size = voTable.childNodes.length;
    for(var j = 0; j < size; j++) {
      this.deleteTreeNode(0, poDocument);
    }
  } catch(err) {
  }    
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  this.setSpecificAttrs(poCtrl, poDocument);
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.setSpecificEvents = function(poCtrl) {
  this.finalmouseup = function(poEvent) {
    this.sourceItem = null;
    this.targetItem = null;
  };
  this.atclick = function(poEvent) {
    poEvent.objectType = this.eventObjectType;
  };    
  this.dochange = function(poEvent, poControl) {
    if(poControl.atchange) { poControl.atchange(poEvent); }
    if(poControl.cochange) { poControl.cochange(poEvent); }
    if(poControl.onchange) { poControl.onchange(poEvent); }
  };    
};

/**
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
  this.itemgroup.df = {};
};

/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;

  switch(psAttrName) {
  case "width" :
    break;
  case "height" :
    break;
  case "borderWidth" :
    break;
  }
};  

/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "disabled" :
    this.setAttrCtrl("disabled", psAttrValue, voCtrl);
    this.setDisable(psAttrValue, poDocument);
    break;
  case "left" :
  case "top" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "width" :
  case "height" :
    this.refresh(poDocument);
    break;
  case "borderColor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    break;
  case "borderStyle" :
  case "borderWidth" :
  case "borderLeftWidth" :
  case "borderRightWidth" :
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.refresh(poDocument);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};

/**
 * loadData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.loadData = function(poDocument) {
  if(poDocument == null) poDocument = this.document;
  this.deployTreeNode(this.root);
  var voCtrl = this.getCtrl(poDocument);     
  //this.setSpecificAttrs(voCtrl, poDocument)
  this.repaintNode(this.root, 0, true, voCtrl, poDocument);
  this.changedNodes.clear();
  /*if(this.data.instanceId != null && this.data.instancePath != null) {
    var vsRefValue = this.data.getData();
    var voIterator = this.items.getValueCollection().iterator();
    var voTreeNode = null;
    while(voIterator.hasNext()) {
      voTreeNode = voIterator.next();
      if(voTreeNode.getValue() == vsRefValue) {
        this.toggleNode(voTreeNode);
        break;
      }
    }
  }*/
};

eXria.controls.xhtml.TreeView.prototype.reloadData = function(poCtrl, poDocument) {
  this.expandedIndexes = [];
  this.remarkExpand(this.root, "");
  this.clearItems();
  this.deployTreeNode(this.root);
  this.restoreExpand();
  this.repaintNode(this.root, 0, true, poCtrl, poDocument);
  this.changedNodes.clear();
  this.loadComplete(poDocument);
};

eXria.controls.xhtml.TreeView.prototype.loadComplete = function(poDocument) {
  if(poDocument == null) poDocument = this.document;
  if(this.df.expandAll) this.expandAllNode();
  this.setDisable(this.disabled, poDocument);
  
  var voCover = this.lookup(this.id + "_cover", poDocument);
  if(voCover != null) {
    if(this.visible == false) {
      this.setAttrCtrl("display", "none", voCover);
    } else {
      this.setAttrCtrl("display", "", voCover);
    }
  }   
};

eXria.controls.xhtml.TreeView.prototype.clearItems = function() {
  this.items.clear();
  this.selectedItems.clear();
  this.items.put(this.root.index, this.root);
  this.latestIdx = this.root.index + 1;
};

eXria.controls.xhtml.TreeView.prototype.deployTreeNode = function(poTreeNode) {
  poTreeNode.deployChildren();
  var voIterator = poTreeNode.childCollection.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild instanceof eXria.controls.xhtml.TreeNode) {
      this.deployTreeNode(voChild);
    }
  };

};

/**
 * 실체화 컨트롤 활성화/비활성화
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {String} psValue 컨트롤 disabled설정
 */
eXria.controls.xhtml.TreeView.prototype.setDisable = function(pbValue, poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  if(voCtrl == null) return;
  
  var voParent = voCtrl.parentNode;
  var voDiv = null;
  var voStyle = null;
  if(pbValue) {
    voDiv = voDiv = this.lookup(this.id + "_cover");
    if(voDiv == null) {
      voDiv = poDocument.createElement("div");
      voDiv.setAttribute("id", this.id + "_cover");
		voStyle = voDiv.style;
      voStyle.position = "absolute"; 
      voStyle.backgroundColor = "#aaaaaa";
      var vnZIndex = this.getAttrValue("zIndex", this.zIndex);
      if(vnZIndex == null) vnZIndex = this.getUIControlAttrValue("zIndex", this.zIndex);
      if(vnZIndex == null) vnZIndex = 0;
      voStyle.zIndex = vnZIndex + 1;
      this.setOpacity(voDiv, "alpha(opacity:50)", "0.50");
      voParent.appendChild(voDiv);
    }
    voStyle.left = this.left + "px";
    voStyle.top = this.top + "px";      
    voStyle.width = this.width + "px";
    voStyle.height = this.height + "px";
          
  } else {
    voDiv = this.lookup(this.id + "_cover");
    if(voDiv != null) voParent.removeChild(voDiv);
  }

};

/**
 * 컨트롤에 값을 설정.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 */
eXria.controls.xhtml.TreeView.prototype.setValue = function(poNode) {
  this.value = poNode.get("value");
  if(this.data.instanceId) this.data.setData(this.value);
};

/**
 * 컨트롤의 할당된 값 반환
 * @return 컨트롤 value 속성 값
 * @type String
 */
eXria.controls.xhtml.TreeView.prototype.getValue = function() {
  return this.value;
};  

/**
 * Create a tree node with the given node name.<br>
 * 트리노드 생성
 * @param {String} psName 트리노드에 표시될 라벨명
 * @return 새롭게 생성된 트리노드 객체 
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.createTreeNode = function(psName) {
  var voNode = new eXria.controls.xhtml.TreeNode(psName);
  //voNode.index = this.latestIdx++;
  //this.items.put(voNode.index, voNode);
  
  return voNode;
};

/**
 * Create a tree nodeset with the given node name.<br>
 * 트리노드셋 생성
 * @param {String} psName
 * @return 새롭게 생성된 트리노드셋 객체 
 * @type eXria.controls.xhtml.TreeNodeset
 */
eXria.controls.xhtml.TreeView.prototype.createTreeNodeset = function(psName) {
  var voNodeset = new eXria.controls.xhtml.TreeNodeset(psName);
  //voNode.index = this.latestIdx++;
  //this.items.put(voNode.index, voNode);
  
  return voNodeset;
};

/**
 * 트리노드 제거
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.remove = function(poNode) {
  this.items.remove(poNode.index);  
};

/**
 * 아이콘 이미지 경로 상수에 행당하는 실체화 객체를 생성하여 this.icons에 저장하는 메소드.<br>
 * Preload icons
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.loadIcons = function() {
   var voIcon = null;
   var vsIconTag = null;
   for(vsIconTag in this.iconFiles) {
      voIcon = new Image();
      voIcon.src = this.canvas.page.metadata.resourceBaseUrl + this.df.iconDir + "/" + this.iconFiles[vsIconTag];
      this.icons.put(vsIconTag, voIcon);
   }

};

/**
 * paint tree
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.paint = function(poDocument) {
  this.paintNode(this.root, poDocument);
};

/**
 * paint node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.paintNode = function(poNode, poDocument) {
   var voTable = this.lookup(this.id + "_table");
   var voDiv = poDocument.createElement("div");
   var voStyle = voDiv.style;
   this.setAttrCtrl("backgroundColor", this.df.backgroundColor, voDiv);
   voDiv.setAttribute("id", "node" + poNode.index);
   voStyle.position = "absolute";
   voStyle.left = "0px";
   voStyle.top = (voTable.childNodes.length * this.df.iconHeight) + "px";
   voStyle.height = this.df.iconHeight + "px";
   this.setNodeCtrl(poNode, voDiv, poDocument);
   for(var i = 0; i < poNode.children.length && poNode.expand; i++) {
      this.paintNode(poNode.children[i], voDiv);
   }
};

/**
 * Get the index of row by specified row id.<br>
 * row id에 해당하는 row 인덱스 번호 반환
 * @param {String} psRowId row id
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return row 인덱스 번호
 * @type Number
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getRowIndexById = function(psRowId, poDocument) {
   var voTable = this.lookup(this.id + "_table", poDocument);
   var voRows = voTable.childNodes;
   for(var i = 0; i < voRows.length; i++) {
      if(voRows.item(i).id == psRowId)
      return i;
   }
   return - 1;
}; 
 
/**
 * repaint tree.
 * 트리 새로 그리기.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.repaint = function(poDocument) {
  var voCtrl = this.getCtrl(poDocument);
  this.repaintChanged(voCtrl, poDocument);
  
  this.changedNodes.clear();    
};

/**
 * Repaint nodes of which displays are changed.
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.repaintChanged = function(poCtrl, poDocument) { 
  if(poDocument == null) poDocument = document;
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  var voTable = poCtrl.childNodes[0];
  for(var i = 0; i < this.changedNodes.size(); i++) {
    var voNode = this.changedNodes.get(i);
    var vsRowId = "node" + voNode.index;
    var nextRowId = - 1;
    var vnRowIndex1 = - 1;
    var vnRowIndex2 = - 1;
    if(voNode != this.root) {
      vnRowIndex1 = this.getRowIndexById(vsRowId, poDocument);        
      try {
        nextRowId = "node" + voNode.parent.getChildAfter(voNode).index;
        vnRowIndex2 = this.getRowIndexById(nextRowId, poDocument) - 1;
        if(vnRowIndex2 < 0) throw new Error(9999, "Index out of bound!");          
      } catch(err) {
        try {
          nextRowId = "node" + this.getNextOpenedAncestor(voNode, poDocument).index;
          vnRowIndex2 = this.getRowIndexById(nextRowId, poDocument) - 1;
          if(vnRowIndex2 == -1) throw new Error(9999, "Index Out of bound!");
        } catch(err) {
          vnRowIndex2 = voTable.childNodes.length - 1;          
        }
      }
    } else {
      vnRowIndex1 = 0;
      vnRowIndex2 = voTable.childNodes.length - 1;
    }
    try {
      for(var j = 0; j <(vnRowIndex2 - vnRowIndex1) + 1; j++) {
         this.deleteTreeNode(vnRowIndex1, poDocument);
      }
    } catch(err) {
    }
    
    var vbRoot = false;
    if(voNode == this.root) vbRoot = true;
    this.repaintNode(voNode, vnRowIndex1, vbRoot, poCtrl, poDocument);
  }
};

/**
 * deleteTreeNode.
 * @param {Number} pnIndex 현재 보여지는 트리 리스트의 row 인덱스
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.deleteTreeNode = function(pnIndex, poDocument) {
  var voTable = this.lookup(this.id + "_table", poDocument);
  this.clearCtrlNode(voTable.childNodes.item(pnIndex));
  voTable.removeChild(voTable.childNodes.item(pnIndex));
  var voDiv = null;
  var voStyle = null;
  for(var i = pnIndex; i < voTable.childNodes.length; i++) {
    voDiv = voTable.childNodes.item(i);
    voStyle = voDiv.style;
    voStyle.top = (parseInt(voStyle.top) - this.df.iconHeight) + "px";
  }
};

/**
 * repaint node.
 * @param {eXria.controls.xhtml.TreeNode} poNode 새로고침 대상 트리노드
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @param {Boolean} pbRoot 루트노드인지 여부
 * @param {HTMLDiv} 실체화 컨트롤 객체의 최외곽 div 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.repaintNode = function(poNode, pnIndex, pbRoot, poCtrl, poDocument) {
  if(poNode.visible == false || pnIndex < 0) return;
  if(poCtrl == null) poCtrl = this.getCtrl(poDocument);
  var voTable = poCtrl.childNodes[0];
  var voDiv = poDocument.createElement("div");
  var voStyle = voDiv.style;    
  voDiv.setAttribute("id", "node" + poNode.index);
  voStyle.padding = "0px";
  voStyle.margin = "0px";
  voStyle.position = "absolute"
  voStyle.left = "0px";
  voStyle.top = (pnIndex * this.df.iconHeight) + "px";
  voStyle.height = this.df.iconHeight + "px";
  
  if(!pbRoot) {
    if(pnIndex == voTable.childNodes.length) voTable.appendChild(voDiv);       
    else voTable.insertBefore(voDiv, voTable.childNodes.item(pnIndex));
    
    this.setNodeCtrl(poNode, voDiv, poDocument);
    
    for(var i = pnIndex + 1; i < voTable.childNodes.length; i++) {
      voDiv = voTable.childNodes.item(i);
      voStyle = voDiv.style;
      voStyle.top = (parseInt(voStyle.top) + this.df.iconHeight) + "px";
    }
  }
      
  var voNextAncestor = null;
  var voPrevious = null;
  for(var i = 0; i < poNode.children.length && poNode.expand; i++) {
    //** 하위노드(0) 추가 후 그 하위노드의 하위 노드들이 추가되었을 경우 하위노드(0)의 다음노드(1)은
    //** 하위노드(0)의 NextOpenedAncestor에 위치하여야 한다.
    if(i == 0) {
       if(pbRoot) this.repaintNode(poNode.children[i], pnIndex, false, poCtrl, poDocument);
       else this.repaintNode(poNode.children[i], pnIndex + 1, false, poCtrl, poDocument);
    } else {
       var rowId = null;
		 var rowIndex = null;
       try {
          voNextAncestor = this.getNextOpenedAncestor(voPrevious, poDocument);
          if(voNextAncestor == null) throw new Error(9999, "It has no next opened ancestor!");
          rowId = "node" + voNextAncestor.index;
          rowIndex = this.getRowIndexById(rowId, poDocument);
          if(rowIndex == -1) throw new Error(9999, "Index out of bound!");
          this.repaintNode(poNode.children[i], rowIndex, false, poCtrl, poDocument);
          
       } catch(err) {         
          rowIndex = voTable.childNodes.length;
          this.repaintNode(poNode.children[i], rowIndex, false, poCtrl, poDocument);
       }
    }
    if(poNode.children[i].visible != false) voPrevious = poNode.children[i];
  }
};  

/**
 * generate leftside.<br>
 * 지정된 트리노드 렌더링.
 * @param {eXria.controls.xhtml.TreeNode} poNode 렌더링할 트리노드
 * @param {HTMLDiv} poDiv 트리노드가 렌더링될 div객체
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.setNodeCtrl = function(poNode, poDiv, poDocument){  
  var voIcon = null;
  var voTag = null;
  var voStyle = null;
  for(var i = 0; i < poNode.leftside.length; i++) {
    voIcon = this.icons.get("blank");
    if(poNode.leftside[i] == 1) {
       voIcon = this.icons.get("verticalLine");
    }
    voTag = poDocument.createElement("img");      
    voTag.border = "0";      
    voTag.src = voIcon.src;
    voStyle = voTag.style;
    voStyle.position = "absolute";
    voStyle.left = (i * this.df.iconWidth) + "px";
    voStyle.top = "0px";
    voStyle.width = this.df.iconWidth + "px";
    voStyle.height = this.df.iconHeight + "px";
    
    poDiv.appendChild(voTag);      
  }
  if(poNode != this.root) {
    if(poNode.isLeaf()) {
      voIcon = this.icons.get("lastnode");
      if(poNode.parent.getLastChild() != poNode) {
         voIcon = this.icons.get("node");
      }
      voTag = poDocument.createElement("img");
      voTag.border = "0";
      voTag.src = voIcon.src;
      voStyle = voTag.style;
      voStyle.position = "absolute";
      voStyle.left = (poNode.leftside.length * this.df.iconWidth) + "px";
      voStyle.top = "0px";
      voStyle.width = this.df.iconWidth + "px";
      voStyle.height = this.df.iconHeight + "px";        
      
      poDiv.appendChild(voTag);
    } else {
      if(poNode.expand) {
        voIcon = this.icons.get("openedLastnode");
        if(poNode.parent.getLastChild() != poNode) {
          voIcon = this.icons.get("openedNode");
        }
      } else {
        voIcon = this.icons.get("closedLastnode");;
        if(poNode.parent.getLastChild() != poNode) {
          voIcon = this.icons.get("closedNode");
        }
      }
      voTag = poDocument.createElement("img");
      voTag.control = this;
      voTag.border = "0";
      voTag.src = voIcon.src;
      voStyle = voTag.style;
      voStyle.position = "absolute";
      voStyle.left = (poNode.leftside.length * this.df.iconWidth) + "px";
      voStyle.top = "0px";
      voStyle.width = this.df.iconWidth + "px";
      voStyle.height = this.df.iconHeight + "px";
      if(poNode.disabled != true) voTag.onclick = function(e) {
        this.control.items.get(poNode.index).tree.toggleNode(this.control.items.get(poNode.index), poDocument);
      };
      poDiv.appendChild(voTag);
      
    }
  }
  var vbSelectedNode = false;
  for(var i = 0; i < this.selectedItems.size(); i++) {
    if(this.selectedItems.get(i) == poNode) {
      vbSelectedNode = true;
    }
  }
  if(this.openedItem == poNode) {
    voIcon = this.icons.get("openedFolder_" + poNode.depth);
    if(voIcon == null) {
      if(poNode.isLeaf()) voIcon = this.icons.get("selectedLeafItem");
      else voIcon = this.icons.get("openedFolder");
    }
    //if(poNode.icon != "") {
    //  voIcon = new Image();
    //  if(poNode.isLeaf()) voIcon.src = this.df.iconDir + "/selectedleaf_" + poNode.icon + "_item." + this.iconExt;
    //  voIcon.src = this.df.iconDir + "/opened_" + poNode.icon + "_folder." + this.iconExt;
    //}
    if(poNode.iconOpened && poNode.iconOpened != "") {
      voIcon = new Image();
      voIcon.src = poNode.iconOpened;        
    }

  } else {
    voIcon = this.icons.get("closedFolder_" + poNode.depth);
    if(voIcon == null) {
      if(poNode.isLeaf()) voIcon = this.icons.get("leafItem");
      else voIcon = this.icons.get("closedFolder");
    }
    //if(poNode.icon != "") {
    //   voIcon = new Image();
    //   if(poNode.isLeaf())  voIcon.src = this.df.iconDir + "/leaf_" + poNode.icon + "_item." + this.iconExt;
    //   else voIcon.src = this.df.iconDir + "/closed_" + poNode.icon + "_folder." + this.iconExt;         
    //}
    if(poNode.icon && poNode.icon != "") {
      voIcon = new Image();
      voIcon.src = poNode.icon;        
    }     
  }
  var vnOffset = 0;
  voTag = poDocument.createElement("img");
  voTag.border = "0";
  voTag.src = voIcon.src;
  voStyle = voTag.style;
  voStyle.position = "absolute";
  vnOffset = poNode.leftside.length + 1;
  if(poNode == this.root) vnOffset = 0;
  voStyle.left = (vnOffset * this.df.iconWidth) + "px";
  voStyle.top = "0px";
  voStyle.width = this.df.iconWidth + "px";
  voStyle.height = this.df.iconHeight + "px";
  poDiv.appendChild(voTag);        
          
  var vsFontColor = poNode.color;
  if(vsFontColor == null) vsFontColor = this.itemgroup.df.color;
  if(vsFontColor == null) vsFontColor = this.df.color;
  var vsBackgroundColor = poNode.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = this.itemgroup.df.backgroundColor;
  if(vsBackgroundColor == null) vsBackgroundColor = this.df.backgroundColor;
  if(vbSelectedNode)
  {
    vsFontColor = this.itemgroup.df.selectedColor;
    vsBackgroundColor = this.itemgroup.df.selectedBackgroundColor;
  }
  vnOffset++;
  voTag = poDocument.createElement("div");
  voTag.control = this;
  this.setAttrCtrl("position", "absolute", voTag);
  this.setAttrCtrl("margin", "0px", voTag);
  this.setAttrCtrl("padding", "0px", voTag);
  //this.setAttrCtrl("left", (vnOffset * this.df.iconWidth), voTag);
  voTag.style.left = (vnOffset * this.df.iconWidth) + "px";
  //this.setAttrCtrl("top", 0, voTag);
  voTag.style.top = "0px";
  this.setAttrCtrl("width", (this.innerWidth - (vnOffset * this.df.iconWidth)), voTag);
  this.setAttrCtrl("height", this.df.iconHeight, voTag);
  this.setAttrCtrl("backgroundColor", vsBackgroundColor, voTag);
  if(poNode.disabled != true) this.setAttrCtrl("cursor", "pointer", voTag);
  var voTable = poDocument.createElement("table");
  this.setAttrCtrl("position", "absolute", voTable);
  this.setAttrCtrl("cellSpacing", "0px", voTable);
  this.setAttrCtrl("cellPadding", "0px", voTable);
  //this.setAttrCtrl("left", 0, voTable);
  voTable.style.left = "0px";
  //this.setAttrCtrl("top", 0, voTable);
  voTable.style.top = "0px";
  this.setAttrCtrl("width", (this.innerWidth - (vnOffset * this.df.iconWidth)), voTable);
  this.setAttrCtrl("height", this.df.iconHeight, voTable);
  this.setAttrCtrl("color", vsFontColor, voTable);
  var vuAttr = poNode.fontFamily;
  if(vuAttr == null) vuAttr = this.itemgroup.df.fontFamily;
  this.setAttrCtrl("fontFamily", vuAttr, voTable);
  vuAttr = poNode.fontSize;
  if(vuAttr == null) vuAttr = this.itemgroup.df.fontSize;
  this.setAttrCtrl("fontSize", vuAttr, voTable);
  vuAttr = poNode.fontSize;
  if(vuAttr == null) vuAttr = this.itemgroup.df.fontStyle;
  this.setAttrCtrl("fontStyle", vuAttr, voTable);
  vuAttr = poNode.fontWeight;
  if(vuAttr == null) vuAttr = this.itemgroup.df.fontWeight;
  this.setAttrCtrl("fontWeight", vuAttr, voTable);
  var voTbody = poDocument.createElement("tbody");
  var voTr = poDocument.createElement("tr");
  var voTd = poDocument.createElement("td");
  var voStyle = voTag.style;
  //var voRuler = this.lookup(this.id + "_ruler");
  //voRuler.innerHTML = poNode.name;
  //voStyle.width = voRuler.offsetWidth + "px";
  //voStyle.cursor = "pointer";
  if(voTag.disabled != true) voTag.onmousedown = function(e) {
    this.control.sourceItem = poNode;      
  };
  if(voTag.disabled != true) voTag.onmouseup = function(e) {
    this.control.targetItem = poNode;
  };
  if(voTag.disabled != true) voTag.onclick = function(e) {
    this.control.items.get(poNode.index).tree.treeSelectionListener(e, this.control.items.get(poNode.index), poDocument);
    this.control.eventObjectType = "item";
    this.control.mediateEvent(e);
    this.control.eventObjectType = null;
    this.control.sourceItem = null;
    this.control.targetItem = null;
  };
  this.setAttrCtrl("textAlign", this.itemgroup.df.textAlign, voTd);
  this.setAttrCtrl("verticalAlign", this.itemgroup.df.verticalAlign, voTd);
  //voTd.appendChild(poDocument.createTextNode(poNode.name));
  this.setText(voTd, eXria.controls.xhtml.Util.parseLang(poNode.name));
  voTr.appendChild(voTd);
  voTbody.appendChild(voTr);
  voTable.appendChild(voTbody);
  voTag.appendChild(voTable);
  if(poNode.disabled) voTag.disabled = true;
  poDiv.appendChild(voTag);             
};

/**
 * 현재 랜더링된 트리노드 리스트에서 지정된 트리노드의 다음번 상위노드를 찾는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 기준 트리노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document   
 * @Returns next opened ancestor
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getNextOpenedAncestor = function(poNode, poDocument) {
  var voTable = this.lookup(this.id + "_table", poDocument);
  var vnRowIndex = this.getRowIndexById("node" + poNode.index, poDocument);
  var voNextNode = null;
  var voTempNode = null;
  var vsId = null;
  for(var i = vnRowIndex + 1; i < voTable.childNodes.length; i++)
  {
    vsId = voTable.childNodes.item(i).id;
    voTempNode = this.items.get(vsId.substring(4, vsId.length));
    if(voTempNode.parent == null) continue;
    if(!poNode.isAncestor(voTempNode) && !voTempNode.isAncestor(poNode))
    {
      voNextNode = voTempNode;
      break;
    }
  }
  return voNextNode;
};  

/**
 * Returns the number of rows that are currently being displayed
 * @Return the number of rows that are currently being displayed.
 * @type Number
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getRowCount = function() {
  var voTable = this.lookup(this.id + "_table");
  return voTable.childNodes.length;
};

/**
 * Returns the path to the first selected node
 * @Return the path to the first selected node.
 * @type String
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.getSelectionPath = function() {
};

/**
 * Move node
 * @param {eXria.controls.xhtml.TreeNode} poSource 트리노드가 원래 위치한 상위 노드
 * @param {eXria.controls.xhtml.TreeNode} poTarget 옮겨진 트리노드를 포함할 상위 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.moveNode = function(poSource, poTarget) {
  poSource.parent.remove(poSource);
  poTarget.add(poSource);
};

/**
 * Copy node
 * @param {eXria.controls.xhtml.TreeNode} poSource 복제될 노드
 * @param {eXria.controls.xhtml.TreeNode} poTarget 복제될 노드를 포함할 상위 노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.copyNode = function(poSource, poTarget) {
  var voNode = poSource.clone();
  poTarget.add(voNode);
};

/**
 * Returns true if the node at the specified display row is collapsed.
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isCollapsed = function(pnIndex) {
  var voTable = this.lookup(this.id + "_table");
  var vsId = voTable.rows[pnIndex].id;
  vsId = vsId.substring(4, vsId.length);
  
  return this.items.get(parseInt(vsId)).expand ? false : true;
};

/**
 * Returns true if the node at the specified display row is currently expanded.
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isExpanded = function(pnIndex) {
  var voTable = this.lookup(this.id + "_table");
  var vsId = voTable.rows[pnIndex].id;
  vsId = vsId.substring(4, vsId.length);
  
  return this.items.get(parseInt(vsId)).expand ? true : false;
};

/**
 * Returns true if the node at the specified display row is currently selected
 * @param {Number} pnIndex 현재 디스플레이된 트리노드 리스트에서의 인덱스 번호
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isSelected = function(pnIndex) {
  var voTable = this.lookup(this.id + "_table");
  var vsId = voTable.rows[pnIndex].id;
  vsId = vsId.substring(4, vsId.length);
  
  return this.items.get(parseInt(vsId)).isSelected() ? false : false;
};

/**
 * Ensures that the node in the specified row is expanded and viewable.
 * @param {Number} pnIndex
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.expandRow = function(pnIndex) {
};

/**
 * Ensures that the node identified by the specified path is expanded and viewable.
 * @param {String} psPath
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.expandPath = function(psPath) {
};

/**
 * expandAll.<br>
 * 모든 노드를 펼침.
 */
eXria.controls.xhtml.TreeView.prototype.expandAllNode = function() {       
  this.root.expandDecendants();
};

/**
 * Returns true if the node identified by row is selected.
 * @param {Number} pnIndex
 * @return this.selectedItems
 * @type Boolean
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.isRowSelected = function(pnIndex) {
  var voTable = this.lookup(this.id + "_table");
  var vsId = voTable.rows[pnIndex].id;
  vsId = vsId.substring(4, vsId.length);
  
  return this.selectedItems.get(0) == this.items.get(parseInt(vsId)) ? true : false;
};

/**
 * Removes the row at the index row from the current selection.
 * @ignore
 */
eXria.controls.xhtml.TreeView.prototype.removeSelectionRow = function() {
};

/**
 * Selects the node at the specified row in the display.<br>
 * 현재 보여지는 트리 상에서 지정된 row를 선택하는 메소드.
 * @param {Number} pnIndex 현재 보여지는 트리 상에서 지정된 row 인덱스 번호
 */
eXria.controls.xhtml.TreeView.prototype.setSelectionRow = function(pnIndex) {
  var voTable = this.lookup(this.id + "_table");
  var vsId = voTable.rows[pnIndex].id;
  vsId = vsId.substring(4, vsId.length);
  
  this.selectNode(this.items.get(parseInt(vsId)));
};

/**
 * unselectNode.
 * 지정된 트리노드 선택 해제
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 트리노드
 */
eXria.controls.xhtml.TreeView.prototype.unselectNode = function(poNode) {
  for(var i = 0; i < this.selectedItems.size(); i++) {
    if(this.selectedItems.get(i) == poNode) {
      this.selectedItems.remove(i);
      this.addChangedNode(poNode);
      return;
    }
  }    
};

/**
 * Selects the specified node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @param {eXria.event.Event} poEvent 이벤트 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.selectNode = function(poNode, poEvent, poDocument) {
  if(this.df.selectionMode == "single") {
    if(this.selectedItems.get(0) != null) {
       this.addChangedNode(this.selectedItems.get(0));
    }
    this.selectedItems.set(0, poNode);
    if(this.opendedItem != poNode) {
      this.dochange(poEvent, this);
    }      
    this.openedItem = poNode;
  } else {
    var vbCtrl = false;
    if(poEvent) vbCtrl = poEvent.ctrlKey;
    if(vbCtrl) {
      if(poNode.isSelected()) {
         this.unselectNode(poNode);
      } else {
         this.selectedItems.add(poNode);
      }
    } else {
      for(var i = 0; i < this.selectedItems.size(); i++) {
         this.addChangedNode(this.selectedItems.get(i));
      }
      if(this.openedItem != null) this.addChangedNode(this.openedItem);
      this.selectedItems.clear()
      this.selectedItems.set(0, poNode);
      if(this.opendedItem != poNode) {
        this.dochange(poEvent, this);
      }
      this.openedItem = poNode;
    }
  }
  this.addChangedNode(poNode);
  this.repaint(poDocument);
  this.setValue(poNode);
};

/**
 * remove node from selected node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.removeFromSelectedNode = function(poNode) {
  for(var i = 0; i < this.selectedItems.size(); i++) {
    if(poNode == this.selectedItems.get(i)) {
      this.selectedItems.remove(i)
      return;
    }
  }     
};

/**
 * open node
 * 지정된 트리노드를 선택하는 메소드.(노드를 펼치는 것과는 다름)
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 */
eXria.controls.xhtml.TreeView.prototype.openNode = function(poNode) {
  if(this.openedItem != null) this.addChangedNode(this.openedItem);
  this.openedItem = poNode;
  this.addChangedNode(poNode);
};

/**
 * toggleNode
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.TreeView.prototype.toggleNode = function(poNode, poDocument) {
  var vbExpand = poNode.expand ? false : true;
  poNode.expand = vbExpand;
  if(vbExpand == false) {
    var setSelected = false;
    for(var i = 0; i < this.selectedItems.size(); i++) {
      if(poNode.isAncestor(this.selectedItems.get(i))) {
        this.unselectNode(this.selectedItems.get(i));
        setSelected = true;
        i--;
      }
    }
    if(setSelected) this.selectedItems.add(poNode);
    if(this.openedItem != null && poNode.isAncestor(this.openedItem)) this.openNode(poNode);
  }
  this.addChangedNode(poNode);
  this.repaint(poDocument);
};

/**
 * add node to changed node.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.addChangedNode = function(poNode) {
  if(!this.hasChangedAncestor(poNode)) this.changedNodes.add(poNode);
};

/**
 * remove node from changed node
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.removeFromChangedNode = function(poNode) {
  for(var i = 0; i < this.changedNodes.size(); i++) {
    if(poNode == this.changedNodes.get(i)) {
      this.changedNodes.remove(i);
      return;
    }
  }    
};

/**
 * Returns true if node has changed ancestor
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return 변경 사항이 존재하는 부모 트리노드 
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.hasChangedAncestor = function(poNode) {
  var voParent = poNode;
  var vbHasChangedAncestor = false;
  while(voParent != this.root) {
    voParent = voParent.parent;
    if(this.isChangedNode(voParent)) {
      vbHasChangedAncestor = true;
      break;
    }
  }
  return vbHasChangedAncestor;
};

/**
 * Returns true is node is changed
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return vbChanged
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.isChangedNode = function(poNode) {
  var vbChanged = false;
  for(var i = 0; i < this.changedNodes.size(); i++) {
    if(this.changedNodes.get(i) == poNode) vbChanged = true;
  }
  return vbChanged;
};

/**
 * treeSelectionListener
 * @param {HTMLEvent} e 윈도우이벤트
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.TreeView.prototype.treeSelectionListener = function(e, poNode, poDocument) {
  //var voEvent = e ? e : window.event;
  var voEvent = new eXria.event.Event(e, this.window);
  this.selectNode(poNode, voEvent, poDocument); 
  voEvent.stopEvent();
};
 
/**
 * refresh시 해당 노드의 이전의 펼쳐진 상태로 복원하기 위해
 * 해당 노드와 그 하위 노드의 펼쳐진 상태를 인덱스를 통해 기록하는 메소드.   
 * @param {eXria.controls.xhtml.TreeNode} poNode 펼쳐진 상태를 체크할 노드.
 * @param {String} psIndexes 노드의 위치를 root로 부터의 상대적 인덱스 형태로 표현한 값.
 * root 노드는 "", this.root.children[0].childrent[0]은 "0,0" 인 형태.
 * @private
 */  
eXria.controls.xhtml.TreeView.prototype.remarkExpand =  function(poNode, psIndexes) {
  var voChild = null;
  var vsIndexes = null;
  if(psIndexes != "") psIndexes += ","
  for(var i = 0; i < poNode.children.length; i++) {
    voChild = poNode.children[i];
    vsIndexes = psIndexes + i;
    if(voChild.expand) {
      this.expandedIndexes.push(vsIndexes);
      this.remarkExpand(voChild, vsIndexes);
    }
  }    
};

/**
 * root로 부터의 상대적 위치 값을 통해 노드를 검색하는 메소드.
 * @param {String} 노드의 위치를 root로 부터의 상대적 인덱스 형태로 표현한 값.
 * @return 검색된 노드.
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.getNodeFromRoot = function(psIndexes) {
  var vaIndex = psIndexes.split(",");
  var vnIndex = null;
  var voNode = this.root;    
  for(var i = 0; i < vaIndex.length; i++) {
    vnIndex = parseInt(vaIndex[i]);
    voNode = voNode.children[vnIndex];
    if(voNode == null) return null;
  }
  return voNode;
};

/**
 * 트리의 펼쳐진 상태를 refresh 이전의 펼쳐진 상태로 복원시켜 주기위한 메소드.   
 * @private
 */  
eXria.controls.xhtml.TreeView.prototype.restoreExpand = function() {
  var voNode =  null;
  var vsIndexes = null;
  for(var i = 0 ; i < this.expandedIndexes.length; i++) {
    vsIndexes = this.expandedIndexes[i];
    voNode = this.getNodeFromRoot(vsIndexes);
    if(voNode) {
      voNode.expand = true;
    }
  }
};

/**
 * 해당 노드에 매핑된 인스턴스 element의 인덱스(그 상위 노드를 기준)를 반환하는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @return 해당 노드에 매핑된 인스턴스 element의 인덱스
 * @type Number
 * @private
 */    
eXria.controls.xhtml.TreeView.prototype.getInstanceIndex = function(poNode) {
  if(poNode.nodeset) {
   var voCollectionNode = poNode.nodeset.data.getNodesetData();
   var vnSize = voCollectionNode.size();
   var voMapNode = null;
   var vsLabelNode = poNode.nodeset.labelTagName;
   var vsValueNode = poNode.nodeset.valueTagName;
   var vsLabel = null;
    var vsValue = null;    
   for(var i = 0; i < vnSize; i++) {
     voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(i));
     vsLabel = voMapNode.get(vsLabelNode);
     vsValue = voMapNode.get(vsValueNode);
     if(poNode.name == vsLabel && poNode.getValue() == vsValue) {
      return i;
     }
   }    
  }
  return -1;
};

/**
 * 노드를 위, 아래로 이동시켜주는 메소드.
 * @param {eXria.controls.xhtml.TreeNode} poNode 이동시킬 노드
 * @param {Boolean} pbUp 위로 이동시킬지 여부
 */    
eXria.controls.xhtml.TreeView.prototype.upDownNode = function(poNode, pbUp) {
  var vnSourceIndex = poNode.parent.getIndex(poNode);
  var voTargetNode = null;
  if(pbUp) {
    if(vnSourceIndex == 0) return;
    voTargetNode = poNode.parent.children[vnSourceIndex - 1];
  } else {
    voTargetNode = poNode.parent.children[vnSourceIndex + 1];
  }
  if(voTargetNode == null) return;
  this.switchNode(poNode, voTargetNode);
};  

/**
 * 두 노드의 위치를 상호 교환시켜주는 메소드
 * @param {eXria.controls.xhtml.TreeNode} poSourceNode 이동시킬 노드
 * @param {eXria.controls.xhtml.TreeNode} poTargetNode 이동시킬 위치의 기존 노드
 */  
eXria.controls.xhtml.TreeView.prototype.switchNode = function(poSourceNode, poTargetNode) {
  if(poSourceNode == poTargetNode) return;
  if(poSourceNode.parent != poTargetNode.parent) return;
  var vnSourceIndex = poSourceNode.parent.getIndex(poSourceNode);
  var vnTargetIndex = poTargetNode.parent.getIndex(poTargetNode);
  var vnAdjust = 1;
  if(vnTargetIndex < vnSourceIndex) vnAdjust = 0;
  
  poSourceNode.parent.remove(poSourceNode);
  vnTargetIndex = poTargetNode.parent.getIndex(poTargetNode);
  poTargetNode.parent.add(poSourceNode, vnTargetIndex + vnAdjust);
  this.repaintChanged();
  this.switchInstanceNode(poSourceNode, poTargetNode);
};

/**
 * 두 노드의 인스턴스 위치를 상호 교환시켜주는 메소드
 * @param {eXria.controls.xhtml.TreeNode} poSourceNode 이동시킬 노드
 * @param {eXria.controls.xhtml.TreeNode} poTargetNode 이동시킬 위치의 기존 노드
 * @private
 */   
eXria.controls.xhtml.TreeView.prototype.switchInstanceNode = function(poSourceNode, poTargetNode) {
  if(poSourceNode == poTargetNode) return;
  if(poSourceNode.nodeset != poTargetNode.nodeset) return;
  var vnSourceIndex = this.getInstanceIndex(poSourceNode);
  var vnTargetIndex = this.getInstanceIndex(poTargetNode);
  if(vnSourceIndex == -1 || vnTargetIndex == -1) return;
  var voCollectionNode = poSourceNode.nodeset.data.getNodesetData();
  var voSourceMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(vnSourceIndex));
  var voTargetMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(vnTargetIndex));
  var vsLabelTag = poTargetNode.nodeset.labelTagName;
  var vsValueTag = poTargetNode.nodeset.valueTagName;
  var vsParentTag = poTargetNode.nodeset.parentTagName;
  var vsTargetLabel = voTargetMapNode.get(vsLabelTag);
  var vsTargetValue = voTargetMapNode.get(vsValueTag);
  var vsTargetParent = voTargetMapNode.get(vsParentTag);
  voTargetMapNode.put(vsLabelTag, voSourceMapNode.get(vsLabelTag));
  voTargetMapNode.put(vsValueTag, voSourceMapNode.get(vsValueTag));
  voTargetMapNode.put(vsParentTag, voSourceMapNode.get(vsParentTag));
  voSourceMapNode.put(vsLabelTag, vsTargetLabel);
  voSourceMapNode.put(vsValueTag, vsTargetValue);
  voSourceMapNode.put(vsParentTag, vsTargetParent);
};
 
/**
 * 각 속성에 따른 디폴트 속성값을 반환
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 */
eXria.controls.xhtml.TreeView.prototype.getSpecificDefaultValue = function(psAttrName){
  var vaAttrName = psAttrName.split(".");
  var vsDefaultValue = null;
  if(vaAttrName.length == 1) {
    vsDefaultValue = eXria.controls.xhtml.Default.TreeView[psAttrName];      
  } else if (vaAttrName.length == 2) {
    vsDefaultValue = eXria.controls.xhtml.Default.TreeView[vaAttrName[0]][vaAttrName[1]];
  }
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};  

/**
 * 지정된 값을 포함한 트리노드를 얻어오기 위한 메소드
 * @param {String} psValue 검색할 값
 * @return 지정된 값을 포함한 트리노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeView.prototype.getNodeByVal = function(psValue) {
  var voIterator = this.items.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voNode = voIterator.next();
    if(voNode.getValue() == psValue) {
      return voNode;
    }   
  }
  return null;
};

/**
 * 클래스 명을 반환.
 * @return "TreeView"
 * @type String
 */
eXria.controls.xhtml.TreeView.prototype.toString = function() {
  return "TreeView";
};
  
  


/**
 * Concreate xhtml TreeNode
 * @author 조영진
 * @version 1.0
 * @param {String} psName
 * @constructor
 */
 
eXria.controls.xhtml.TreeNode = function(psName) {
  /**
   * 상위 트리 객체 지정.
   * @type eXria.controls.xhtml.Tree
   */
  this.tree = null;
  
  /**
   * 트리노드 식별 index번호.
   * readOnly
   * @type Number
   */
  this.index = -1;
  
  /**
   * Node name.
   * 트리노드 라벨 텍스트.
   * @type String
   */
  this.name = psName;
  
  /**
   * Depth of node.
   * @type Number
   * @private
   */
  this.depth = - 1;
  
  /**
   * leftside icons ( 0 : blank, 1: vertical line )
   * @type Array()
   * @private
   */
  this.leftside = new Array();
  
  /**
   * is expand
   * @type Boolean
   */
  this.expand = false;
  
  /**
   * is child allow.
   * 자식 노드 허용 여부
   * @type Number
   */
  this.isAllowsChildren = 0;
  
  /**
   * icon name.
   * 아이콘 파일명.
   * @type String
   */
  this.icon = "";
  
  /**
   * parent node.
   * readOnly
   * @type eXria.controls.xhtml.TreeNode
   */
  this.parent = null;
  
  /**
   * childCollection
   * @type eXria.data.ArrayMap
   * @private
   */
  this.childCollection = new eXria.data.ArrayCollection();
  
  /**
   * children.
   * 자식 노드를 저장하는 배열.
   * @type Array
   */
  this.children = new Array();
  
  /**
   * name이외의 속성을 저장하기 위한 Object.<br>
   * value속성도 이곳에 저장됨.
   * @type eXria.data.ArrayMap
   */
  this.extData = new eXria.data.ArrayMap();
  
  /**
   * 노드가 포함된 노드셋을 참조하기 위한 속성
   * @type eXria.controls.xhtml.TreeNodeset
   * @private
   */
  this.nodeset = null;
  
};
  
/**
 * Returns true if this node has no children.
 * 자식 노드를 가지고 있는지 여부.
 * @return 자식 노드를 가지고 있는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.TreeNode.prototype.isLeaf = function() {
   return this.children.length == 0 ? true : false;
}

/**
 * Returns true if this node is Ancestor of specified node
 * 지정된 노드의 부모노드 인지 여부 반환
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @return 대상 노드의 부모노드 인지 여부
 * @type Boolean
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.isAncestor = function(poNode) {
  if(poNode == this.tree.root) return false;
  var parent = poNode.parent;
  var vbAncestor = false;
  while(parent != this.tree.root) {
    if(parent == this) {
       vbAncestor = true;
       break;
    }
    parent = parent.parent;
  }
  return vbAncestor;
};

/**
 * 노드 혹은 노드셋 추가 메소드
 * @param {eXria.controls.xhtml.TreeNode|eXria.controls.xhtml.TreeNodeset} poChild 추가할 노드 혹은 노드셋
 */
eXria.controls.xhtml.TreeNode.prototype.addChild = function(poChild) {
  this.childCollection.add(poChild);
};

/**
 * childCollection의 노드를 children 속성에 위치시키는 메소드
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.deployChildren = function() {
  this.removeAllChildren();
  var voIterator = this.childCollection.iterator();
  var voChild = null;
  while(voIterator.hasNext()) {
    voChild = voIterator.next();
    if(voChild instanceof eXria.controls.xhtml.TreeNode) {
      this.add(voChild);
    } else {
      this.addNodeset(voChild, this.tree.canvas);
    }
  };
}

/**
 * Removes newChild from its parent and makes it a child of this node by adding it to the end of this node's child array.
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.add = function(poNode, pnIndex) {
  if(pnIndex == null) {
   poNode.index = this.tree.latestIdx++;
   this.tree.items.put(poNode.index, poNode);  
   this.children[this.children.length] = poNode;
   poNode.tree = this.tree;
   poNode.parent = this;
   poNode.depth = this.depth + 1;
   if(this.depth > 0) {
     poNode.leftside = new Array();
     for(var i = 0; i < this.leftside.length; i++) {
       poNode.leftside[poNode.leftside.length] = this.leftside[i];
     }
     poNode.leftside[poNode.leftside.length] = this.parent.getLastChild() == this ? 0 : 1;
   }
   poNode.fixDecendantsInfo();
   if(this.getChildCount() > 1) this.children[this.children.length - 2].fixLeftsideOfChildren();
   if(this.tree != null) this.tree.addChangedNode(this);
  } else {
    poNode.index = this.tree.latestIdx++;
    this.tree.items.put(poNode.index, poNode);
    for(var i = this.children.length - 1; i >= pnIndex; i--) {
      this.children[i + 1] = this.children[i];
    } 
    this.children[pnIndex] = poNode;
    poNode.tree = this.tree;
    poNode.parent = this;
    poNode.depth = this.depth + 1;
    if(this.depth > 0) {
      poNode.leftside = new Array();
      for(var i = 0; i < this.leftside.length; i++) {
        poNode.leftside[poNode.leftside.length] = this.leftside[i];
      }
      poNode.leftside[poNode.leftside.length] = this.parent.getLastChild() == this ? 0 : 1;
    }
    poNode.fixDecendantsInfo();
    if(this.tree != null) this.tree.addChangedNode(this);
  }
};

/**
 * addNodeset
 * @param {eXria.controls.xhtml.TreeNodeset} poNodeset
 * @param {eXria.form.xhtml.Canvas} poCanvas
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.addNodeset = function(poNodeset, poCanvas) {
  //this.children[this.children.length] = poNodeset;
  poNodeset.tree = this.tree;
  if(this.tree != null) this.tree.addChangedNode(this);
  poNodeset.loadData(this, poCanvas);
};

/**
 * Expand all children.<br>
 * 자식 노드를 expand속성을 true로 갱신하는 메소드.<br>
 * 노드 새로고침기 트리에 결과 반영.
 */
eXria.controls.xhtml.TreeNode.prototype.expandChildren = function() {
  this.expand = true;
  for(var i=0; i<this.children.length; i++){
    this.children[i].expand = true;
  }
};

/**
 * Expand all Decendants
 * 자식 노드와 그 하위의 자식노드 모두의 expand속성을 true로 갱신하는 메소드.<br>
 * 노드 새로고침기 트리에 결과 반영.
 */
eXria.controls.xhtml.TreeNode.prototype.expandDecendants = function() {
  this.expand = true;
  for(var i=0; i<this.children.length; i++){
    this.children[i].expand = true;
    this.children[i].expandDecendants();
  }
};  
   
/**
 * Fix depth of decendants
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.fixDecendantsInfo = function() {
  for(var i = 0; i < this.children.length; i++) {
    this.children[i].tree = this.tree;
    this.children[i].depth = this.depth + 1;
    this.children[i].leftside = new Array();
    for(var j = 0; j < this.leftside.length; j++) {
      this.children[i].leftside[this.children[i].leftside.length] = this.leftside[j];
    }
    this.children[i].leftside[this.children[i].leftside.length] = this.parent.getLastChild() == this ? 0 : 1;
    this.children[i].fixDecendantsInfo();
  }
};

/**
 * Fix Leftside of Children
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.fixLeftsideOfChildren = function() {
  this.fixLeftsideOfDescendants(this.depth, this.parent.getLastChild() == this ? 0 : 1);
};

/**
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.fixLeftsideOfDescendants = function(pnDepth, pnValue) {
  for(var i = 0; i < this.children.length; i++) {
    this.children[i].leftside[pnDepth - 1] = pnValue;
    this.children[i].fixLeftsideOfDescendants(pnDepth, pnValue);
  }
};

/**
 * Removes aChild from this node's child array, giving it a null parent.  
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @private   
 */
eXria.controls.xhtml.TreeNode.prototype.remove = function(poNode) {
  for(var i = 0; i < this.children.length; i++) {
    if(this.children[i] == poNode) {
      poNode.parent = null;
      poNode.depth = - 1;
      poNode.tree = null;
      this.tree.removeFromChangedNode(poNode);
      this.tree.removeFromSelectedNode(poNode);
      if(this.tree.openedItem == poNode) {
        this.tree.openedItem = null;
      }
      this.children.splice(i, 1);
      break;
    }
  }
  if(this.getChildCount() > 0) this.children[this.children.length - 1].fixLeftsideOfChildren();
  if(this.tree != null) this.tree.addChangedNode(this);    
};

/**
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeChild = function(poChild) {
  var vnIndex = this.getChildCollectionIdx(poChild);
  if(vnIndex != -1) this.childCollection.remove(vnIndex);
};

/**
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.getChildCollectionIdx = function(poChild) {
  var vnIndex = -1;
  var voIterator = this.childCollection.iterator();
  var voChild = null;
  var i = -1;
  while(voIterator.hasNext()) {
    i++;
    voChild = voIterator.next();
    if(voChild == poChild) {
      vnIndex = i;
      break;
    }
  }    
  return vnIndex;
};  

/**
 * Removes all of this node's children, setting their parents to null.
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeAllChildren = function() {
  for(var i = 0; i < this.children.length; i++) {
    this.children[i].parent = null;
    this.children[i].depth = - 1;
    this.children[i].tree = null;
    if(this.tree) this.tree.removeFromChangedNode(this.children[i]);
  }
  this.children = new Array();
  if(this.tree) this.tree.addChangedNode(this);
};

/**
 * Removes the subtree rooted at this node from the tree, giving this node a null parent
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.removeFromParent = function() {
  this.parent.remove(this);
};

/**
 * Returns true if node is selected.<br>
 * 이 노드가 선택되었는지 여부 반환
 */
eXria.controls.xhtml.TreeNode.prototype.isSelected = function() {
  var vbSelected = false;
  if(this.tree != null) {
    for(var i = 0; i < this.tree.selectedItems.size(); i++) {
      if(this.tree.selectedItems.get(i) == this) vbSelected = true;
    }
  }
  return vbSelected;
};

/**
 * Returns true is node is opened.<br>
 * 현재 선택되어진 상태라는 점에서 expanded와는 구별됨.
 * @return 노드가 열려져 있는지 여부
 * @type Boolean
 */
eXria.controls.xhtml.TreeNode.prototype.isOpened = function() {
  var vbOpened = false;
  if(this.tree != null) {
    if(this.tree.openedItem == this) vbOpened = true;
  }
  return vbOpened;
};

/**
 * Returns the number of children of this node.<br>
 * 자식 노드의 개수 반환.
 * @return this.children.length
 * @type Number
 */
eXria.controls.xhtml.TreeNode.prototype.getChildCount = function() {
   return this.children.length;
};

/**
 * Returns the child in this node's child array that immediately follows aChild, which must be a child of this node.<br>
 * if the specified child is the lastest node or is not child of this, returns null;
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return 지정된 노드의 다음 형제 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getChildAfter = function(poNode) {
  var voAfter = null;
  for(var i = 0; i < this.children.length - 1; i++) {
    if(this.children[i] == poNode) {
      for(var j = i + 1; j < this.childrent.length; j++) {
        voAfter = this.children[j];
        if(voAfter.visible != false) {
          return voAfter;
        }
      }
    }      
  }
  return null;
};

/** 
 * Returns the child in this node's child array that immediately precedes aChild, which must be a child of this node.<br>
 * if the specified child is the first node or is not child of this, returns null;
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return 지정된 노드의 이전 형제 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getChildBefore = function(poNode) {
   var voBefore = null;
   for(var i = 1; i < this.children.length; i++) {
      if(this.children[i] == poNode) voBefore = this.children[i - 1];
   }
   return voBefore;
};

/**
 * Returns this node's first child.<br>
 * 첫 번째 자식 노드 반환.
 * @return 첫 번째 자식 노드 반환
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getFirstChild = function() {
   return this.children[0];
};

/**
 * Returns this node's last child.<br>
 * 마지막 자식 노드 반환.
 * @return 마지막 자식 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getLastChild = function() {
  var voChild = null;
  for(var i = this.children.length - 1; i >= 0; i--) {
    voChild = this.children[i];
    if(voChild.visible != false) return voChild;
  }
  return null; 
};
//this.getLastChild = function() {
//  return this.children[this.children.length - 1];
//};

/**
 * Returns the child at the specified index in this node's child array.<br>
 * 지정된 인덱스에 해당하는 자식 노드를 반환.
 * @return 지정된 인덱스에 해당하는 자식 노드
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getChildAt = function(pnIndex) {
   return this.children[pnIndex];
};

/**
 * Returns the index of the specified child in this node's child array.<br>
 * if this node does not have the specified child, return -1
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상 노드
 * @return 지정된 자식노드의 인덱스 번호
 * @type Number
 */
eXria.controls.xhtml.TreeNode.prototype.getIndex = function(poNode) {
   var index = - 1;
   for(var i = 0; i < this.children.length; i++) {
      if(this.children[i] == poNode) index = i;
   }
   return index;
};

/**
 * Returns the path from the root, to get to this node.
 * @return 루트노드로 부터의 path값
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.getPath = function() {
  var vsPath = "";
  vsPath = this.updatePath(this, vsPath);
  
  return vsPath;
};

/**
 * path 속성 값 갱신
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @param {String} psPath 갱신될 path 값
 * @return vsPath
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.updatePath = function(poNode, psPath) {
  var vsPath = psPath;
  var vsNodePath = "/tn[@name='" + poNode.name + "']";
  vsPath = vsNodePath + vsPath;
  if(poNode.parent != null) {
    vsPath = this.updatePath(poNode.parent, vsPath);
  } else {
    vsPath = "/root" + vsPath;
  }
  
  return vsPath;
};

/**
 * Returns the root of the tree that contains this node.
 * @return this.tree.root
 * @type eXria.controls.xhtml.TreeNode
 */
eXria.controls.xhtml.TreeNode.prototype.getRoot = function() {
   return this.tree.root;
};

/**
 * Associates the specified value with the specified key in this map.
 * @param {String} psKey
 * @param {String} poValue
 */
eXria.controls.xhtml.TreeNode.prototype.put = function(psKey, poValue) {
   this.extData.put(psKey, poValue);
};

/**
 * Returns the value to which the specified key is mapped in this identity hash map, or null if the map contains no mapping for this key
 * @param {String} poKey extData에서 추출할 데이타의 키 값
 * @return 해당 키 값에 대한 value 값
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.get = function(poKey) {
   var value = null;
   value = this.extData.get(poKey);
   return value;
};

/**
 * 트리노드에 할당된 값 반환
 * @return 트리노드에 할당된 값
 * @type String
 */  
eXria.controls.xhtml.TreeNode.prototype.getValue = function() {
  var vsValue = null;
  vsValue = this.extData.get("value");
  return vsValue;
};

/**
 * 트리노드에 value값 할당
 * @param {String} psValue 할당될 value값
 */  
eXria.controls.xhtml.TreeNode.prototype.setValue = function(psValue) {
  this.extData.put("value", psValue);    
};

/**
 * Clone of this
 * @return Clone of this
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeNode.prototype.clone = function() {
   var voNode = new TreeNode(this.name);
   voNode.icon = this.icon;
   voNode.isAllowChildren = this.isAllowChildren;
   voNode.extData = this.extData;
   for(var i = 0; i < this.getChildCount(); i++) {
      voNode.add(this.children[i].clone());
   }
   return voNode;
};

/**
 * 트리노드의 스타일 속성값을 일괄적으로 변경하기 위한 메소드
 * @param {Object} poStyleObject 변경될 속성값을 담은 오브젝트
 */
eXria.controls.xhtml.TreeNode.prototype.setNodeStyle = function(poStyleObject) {
  var vsAttr = null;
  for(vsAttr in poStyleObject) {
    this[vsAttr] = poStyleObject[vsAttr];
  }
  this.tree.addChangedNode(this);
};

/**
 * 클래스 명을 반환.
 * @return "TreeNode"
 * @type String
 */
eXria.controls.xhtml.TreeNode.prototype.toString = function() {
  return "TreeNode";
};   


/**
 * @class Concreate xhtml TreeNodeset.<br>
 * TreeView 컨트롤을 구성하는 아이템의 속성정보를 담당하는 클래스.
 * 아이템의 실체화는 TreeView에서 담당.
 * @version 1.0
 * @return 새로운 eXria.controls.xhtml.TreeNodeset 객체
 * @type eXria.controls.xhtml.TreeNodeset
 * @constructor
 */
eXria.controls.xhtml.TreeNodeset = function() {
  
  /**
   * @private
   */
  //this.index = null;
  
  /**
   * 인스턴스 데이터로 부터 label 데이타를 가져오기 위한 element 태그명
   * @type String
   */
  this.labelTagName = null;
  
  /**
   * 인스턴스 데이터로 부터 value 데이타를 가져오기 위한 element 태그명
   * @type String
   */
  this.valueTagName = null;
  
  /**
   * 부모 데이타 노드에서 라벨 데이타를 가져올 때 사용되는 DOM Element 명.
   * @type String
   */
  this.parentTagName = "parent";
  
  
  /**
   * tree 컨트롤 참조 변수
   * readOnly
   * @type eXria.controls.xhtml.TreeView
   */
  this.tree = null;
  
  /**
   * 데이타 연동 객체
   * @type eXria.controls.DataRefNodeset()
   */
  this.data = new eXria.controls.DataRefNodeset();
  
};
  
/**
 * loadData
 * @param {eXria.controls.xhtml.TreeNode} poParentTreeNode
 * @param {eXria.form.xhtml.Canvas} poCanvas
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.loadData = function(poParentTreeNode, poCanvas) {
  if(this.tree == null || (this.data.nodesetInstanceId == null || this.data.nodesetInstancePath == null)) return;   
  this.data.control = this.tree;

  var vsRefValue = null;
  if(this.data.instanceId != null) vsRefValue = this.data.getData(); 
  var voCollectionNode = this.data.getNodesetData();
  if(voCollectionNode == null) return;
  var vnLoop = voCollectionNode.size();
  var voMapNode = null;
  var vsLabelNode = null;
  var vsValueNode = null;
  var vaIndex = new Array();
  var vnIndex = 0;
  var voItem = null;
  for(var i = 0; i < vnLoop; i++) {
    voMapNode = new eXria.data.xhtml.MapNode(voCollectionNode.get(i));
    vsLabelNode = voMapNode.get(this.labelTagName);
    vsValueNode = voMapNode.get(this.valueTagName);
    vsParentNode = voMapNode.get(this.parentTagName);
    
   var voTreeNode = this.tree.createTreeNode(vsLabelNode);
   voTreeNode.nodeset = this;
   voTreeNode.put("value", vsValueNode);      
   /*if(vsLabelNode == vsRefValue) {
     this.tree.selectedItems.add(voTreeNode);
   }*/
         	   
   this.checkParent(voTreeNode, vsParentNode);
  }          
};

eXria.controls.xhtml.TreeNodeset.prototype.checkParent = function(poTreeNode, psParentNode) {
  var voParentNode = null;
  if(psParentNode == null) {
    if(this.tree) voParentNode = this.tree.root;
    if(voParentNode) voParentNode.add(poTreeNode);
    return;
  }
  var voIterator = this.tree.items.getValueCollection().iterator();
  while(voIterator.hasNext()) {
    voParentNode = voIterator.next();
    if(voParentNode.getValue() == psParentNode) {
      voParentNode.add(poTreeNode);
      break;
    }
  }
};


/**
 * data 속성으로 부터 DOM 데이타를 얻어옴.
 * @return data 속성으로 부터 얻어온 DOM 데이타
 * @type XMLElement
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.getInstanceData =function() {  
  var viInstance = this.data.getNodesetInstance();
  var voDataNode = null;
  if(viInstance) voDataNode = viInstance.selectSingleNode(this.data.nodesetInstancePath);
  return voDataNode;
};    

/**
 * makeTreeByData
 * @param {eXria.controls.xhtml.TreeNode} poParentTreeNode
 * @param {XMLElement} poParentDataNode
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.makeTreeByData = function(poParentTreeNode, poParentDataNode) {
  var voTreeNode = null;
  var voChild = null;
  var vnNodeType = -1;    
  for(var i = 0; i < poParentDataNode.childNodes.length; i++) {
    voChild = poParentDataNode.childNodes[i];
    vnNodeType = voChild.nodeType;
    if(vnNodeType == 1) {
      voTreeNode = this.makeTreeNodeByData(voChild);
      poParentTreeNode.add(voTreeNode);
      if(voChild.childNodes.length > 0) this.makeTreeByData(voTreeNode, voChild);
    }
  }
};

/**
 * makeTreeNodeByData
 * @param {eXria.controls.xhtml.TreeNode} poNode 대상노드
 * @return poNode에 의해 새롭게 생성된 트리노드 
 * @type eXria.controls.xhtml.TreeNode
 * @private
 */
eXria.controls.xhtml.TreeNodeset.prototype.makeTreeNodeByData = function(poNode) {
  var vsName = poNode.getAttribute(this.labelTagName);
  var voTreeNode = this.tree.createTreeNode(vsName);
  var voAttr = null;
  var vnNodeType, vsAttrName, vsAttrValue;
  for(var i = 0; i < poNode.attributes.length; i++) {
    voAttr = poNode.attributes[i];
    vsAttrName = voAttr.nodeName;
    if(vsAttrName == this.labelTagName) continue;
    vsAttrValue = voAttr.nodeValue;
    voTreeNode.put(vsAttrName, vsAttrValue);      
  }    
  return voTreeNode;
};  

/**
 * 클래스 명을 반환.
 * @return "TreeNodes"
 * @type String
 */
eXria.controls.xhtml.TreeNodeset.prototype.toString = function() {
  return "TreeNodeset";
};


/**
 * 트리뷰 아이템의 공통 속성을 저장하기 위한 클래스.
 * @version 1.0
 * @constructor
 */
eXria.controls.xhtml.TreeView_itemgroup = function() {
  /**
   * 아이템 배경 색상.
   * @type String
   */
  this.backgroundColor = null;  
  /**
   * 아이템 텍스트 색상.
   * @type String
   */
  this.color = null;  
  /**
   * 선택된 아이템의 배경 색상.
   * @type String
   */
  this.selectedBackgroundColor = null;  
  /**
   * 선택된 아이템의 텍스트 색상.
   * @type String
   */
  this.selectedColor = null;  
  /**
   * 아이템에 마우스 위치 시 커서 유형.
   * @type String
   */
  this.cursor = null;  
  /**
   * 아이템 폰트 패밀리.
   * @type String
   */
  this.fontFamily = null;  
  /**
   * 아이템 폰트 사이즈.
   * @type Number
   */
  this.fontSize = null;  
  /**
   * 아이템 폰트 스타일.
   * @type String
   */
  this.fontStyle = null;  
  /**
   * 아이템 폰트 두께.
   * @type Number
   */
  this.fontWeight = null;  
  /**
   * 아이템 텍스트 가로 정렬 방식.
   * @type String
   */
  this.textAlign = null;  
  /**
   * 아이템 텍스트 세로 정렬 방식.
   * @type String
   */
  this.verticalAlign = null;  
  /**
   * 아이템에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 아이템의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};
