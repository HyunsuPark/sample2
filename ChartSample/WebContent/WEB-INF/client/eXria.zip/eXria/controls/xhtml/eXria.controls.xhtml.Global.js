/**
 * @fileoverview
 * Construct Default
 * @author 김경태
 * @version 2.0
 * @ignore
 */
 
/**
 * Const 
 * 컨트롤에서 사용하는 기본값에 대한 정의 클래스
 */
eXria.controls.xhtml.Default = {
  version : "1.0"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.UIControl = {
	position : "absolute",
  backgroundColor : "white",
  color : "black",
  visible :  true,
  disabled :  false,
  zIndex :  0,
  movable : false,
  cursor : "default",
  tooltip : null,
  tooltipDisplay : true,
  dir : "ltr",
  tabIndex : 0, 
  borderColor : "#A5BACC",
  borderStyle : "solid", 
  borderWidth :  1,
  focusBorderColor : "#006600",  
  focusBorderStyle : "solid",
  focusBorderWidth : "auto",
  debug : true
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.UIControl.tooltip = {
  rightBottomImage : "eXria/controls/xhtml/images/arrow_rb.gif",   // arrowImage
  leftBottomImage : "eXria/controls/xhtml/images/arrow_lb.gif",   // arrowImage
  rightTopImage : "eXria/controls/xhtml/images/arrow_rt.gif",   // arrowImage
  leftTopImage : "eXria/controls/xhtml/images/arrow_lt.gif",   // arrowImage
  borderColor : "#317082",
  borderStyle : "solid", 
  borderWidth : 2,
  color : null,
  backgroundColor : "#FFFFFF",
  fontSize : 10,
  filter : "alpha(opacity:70)",
  opacity : "0.70"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.UIControl.dragDrop = {
  backgroundImage : "eXria/controls/xhtml/images/bigWaiting.gif",   // dragDropImage
  borderColor : "#317082",
  borderStyle : "solid", 
  borderWidth : 2,
  color : null,
  backgroundColor : "#FFFFFF",
  fontSize : 10,
  filter : "alpha(opacity:70)",
  opacity : "0.70"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.InputBox = {
  value : null,
  maxLength : null,
  readOnly : false,
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none",
  textTransform : "none"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Button = {
  value : "",
  backgroundImage : null,
  imageFocused : null,
  imagePushed : null,
  imageMouseover : null,
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  padding : 2,
  borderWidth : 1,
  borderStyle : "outset",
  borderColor : "#1475C5",
  color : "white",
  backgroundColor : "#1683D7",
  cursor : "pointer",
  backgroundRepeat : "no-repeat",
  backgroundPosition : "center center"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.SecretBox = {
  value : null,
  maxLength : null,
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Label = {
  backgroundColor : "transparent",	// TODO : 스튜디오와 동기화 된 이후에 white로 변경할것. kkt
  borderWidth: 1,
  overflow : "hidden",
  value : "",
  wordWrap : true,
  textDecoration : "none",
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "center",
  verticalAlign : "middle"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.DateInput = {
  value : null,
  calendarEnable : true,
  dateFormat : "YYYY-MM-DD",
  maskPrompt : "_",
  minDate : "19000101",
  maxDate : "38001231",
  calendarImageUrl : "eXria/controls/xhtml/images/calendar.jpg",
  readOnly : false,
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  fontFamily : "Arial",
  textDecoration : "none",
  textAlign : "left",
  verticalAlign : "middle",
  btnCursor : "pointer"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Output = {
  value : "",
  format : null,
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  verticalAlign : "middle",
  textDecoration : "none",
  letterSpacing : "normal",
  lineHeight : "normal"
};
  
/**
* @ignore
*/
eXria.controls.xhtml.Default.TextArea = {
  rows : 20,
  cols : 20,
  readOnly : false,
  value : null,
  maxLength : null,
  overflow : "auto",
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  textAlign : "left",
  textDecoration : "none"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Image = {
  src : null,
  imageOpacity : 100,
  borderStyle : "ridge"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Object = {
  archive : null,
  classid : null,
  codebase : null,
  dataUrl : null,
  declare : null,
  standby : null,
  type : null,
  codetype : null,
  color : "white",
  backgroundColor : "black",
  borderWidth : 3,
  borderStyle : "ridge",
  borderColor : "green"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Select = {
  displayMode : "horizontal",
  displayNum : 2,
  value : null,
  horizontalGap : 0,
  verticalGap : 0,
  offsetLeft : 0,
  offsetTop : 0,
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  itemgroup : { 
      labelPos : "right", 
      height : 30,
      width : 100, 
      textAlign : "left", 
      verticalAlign : "middle", 
      fontFamily : "Arial",
      fontSize : 10,
      fontWeight : "normal",
      fontStyle : "normal",
      color : "#000000",
      backgroundColor : "transparent", 
      borderWidth : 0,
      borderStyle : "none", 
      borderColor : "#000000",
      cursor : "pointer"
  },
  labelTagName : "labelNode",
  valueTagName : "valueNode"  
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.ComboBox = {
  value : null,
  readOnly : false,
  selectedIndex : -1,
  heightBySize : false,
  verticalAlign : "middle",
  textAlign : "left",
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  btnWidth : 20,
  btnBackgroundColor : "#E7E7EB",
  btnColor : "black",
  collapseImage : null,
  expandImage : null,
  btnCursor : "pointer",
  itemgroup : {
    className : null,
    optionWidth : 20,
    selectorWidth : null,
    overflow : "hidden",
    borderWidth : 0,
    borderStyle : "dotted",
    borderColor : "black",
    height : 20,
    verticalAlign : "middle"
  },
  listarea : {
    className : null,
    appearance : "normal",
    multiSelect : false,
    size : 5,
    heightBySize : false,
    widthByMaxLength : true,
    color : "black",
    focusColor : "#000000",
    overflowY : "auto",
    overflowX : "visible",
    backgroundColor : "#FFFFFF",
    focusBackgroundColor : "#0000FF",
    borderWidth : 1,
    borderStyle : "solid",
    borderColor : "black",
    cellSpacing : 0,
    height : 200
  },
  labelTagName : "labelNode",
  valueTagName : "valueNode"   
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.ListBox = {
  value : null,
  selectedIndex : -1,
  overflow : "auto",
  overflowX : "hidden",
  overflowY : "auto",
  textAlign : "left",  
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  appearance : null,
  multiSelect : true,
  size : 5,
  heightBySize : false,
  focusColor : "#FFFFFF",
  focusBackgroundColor : "#0000FF",
  cellSpacing : 0,
  itemgroup : {
    className : null,
    selectorWidth : 20,
    overflow : "hidden",
    borderWidth : 0,
    borderStyle : "dotted",
    borderColor : "black",
    height : 20,
    verticalAlign : "middle"
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.EditMask = {
  maskType : "string",
  mask : "xxxxx",
  maskPrompt : "_",
  value : "",
  verticalAlign : "middle",
  spinWidth : 20,
  spinNum : 1,
  useSpin : false,
  readOnly : false,
  maxLength : null,
  calendarImageUrl : "eXria/controls/xhtml/images/calendar.jpg",
  calendarEnable : "true",
  textDecoration : "none",
  textTransform : "none",
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  btnCursor : "pointer"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Group = {
  overflow : "hidden",
  borderColor : "silver",
  borderStyle : "none",
  borderWidth : 0,
  backgroundColor : "transparent"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.TabHeader = {
  backgroundColor : "white",
  fontFamily : "Arial",
  fontSize : 12,
  fontStyle : "normal",
  fontWeight : "normal",
  borderWidth : 1,
  borderStyle : "solid",
  borderColor : "black",
  scrollBtnWidth : 30,
  tabbuttons : {
    cellSpacing : 1,
    borderWidth : 1,
    borderStyle : "outset",
    borderColor : "#688BA1",
    width : 100,
    backgroundImage : null,
    imageFocused : null,
    backgroundColor : "white",
    color : "black",
    focusBackgroundColor : "#76A7C1",
    focusColor : "white",
    fontSize : 12
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Tab = {
  headerHeight : 50,
  tabPageZindex : 0,
  headerPos : "top",
  borderWidth : 1,
  borderStyle : "solid",
  borderColor : "gray",
  backgroundColor : "#FFFFFF",
  tabpages : {
    className : null,
    outerClassName : null,
    backgroundColor : "transparent",
    borderWidth : 1,
    borderStyle : "solid",
    borderColor : "#000000"
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Timer = {
  interval : 1000,
  stopCount : 0
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Progress = {
  step : 1,
  startPos : 0,
  interval : 100,
  min : 0,
  max : 1000,
  progressColor : "#6AA8E3",
  //borderColor : "#736A5E",
  backgroundColor : "#D4D0C9"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.TreeView = {
  expandAll : false,
  selectionMode : "single",  
  iconDir : "eXria/controls/xhtml/images",
  iconWidth : 19,
  iconHeight : 16,
  overflow : "auto",
  backgroundColor : "#E4EEF3",
  borderColor : "#98BBD1",
  borderStyle : "solid",
  fontFamily : "Arial",
  fontSize : 12,
  fontStyle : "normal",
  fontWeight : "normal",
  itemgroup : {
    className : null,
    backgroundColor : "#E4EEF3",
    color : "black",
    selectedBackgroundColor : "navy",
    selectedColor : "#FFFFFF",
    cursor : "pointer",
    fontFamily : "Arial",
    fontSize : 10,
    fontStyle : "normal",
    fontWeight : "normal",
    textAlign : "left",
    verticalAlign : "middle"
  },
  iconFiles : {
    blank : "blank.png", //0
    verticalLine : "vertical_line.png", //1
    closedLastnode : "closed_lastnode.png", //2  
    closedNode : "closed_node.png", //3 
    openedLastnode : "opened_lastnode.png", //4 
    openedNode : "opened_node.png", //5 
    lastnode : "lastnode.png", //6 
    node : "node.png", //7 
    closedFolder : "closed_default_folder.png", //8
    openedFolder : "opened_default_folder.png", //9
    leafItem : "leaf_item_rend.gif", //10
    selectedLeafItem : "selectedleaf_item_rend.gif" //11
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Calendar = {
  selectedColor : "#CCCCCC",
  headerBackgroundColor : "#F2F2F2",
  bodyBackgroundColor : "#FFFFFF",
  backgroundColor : "white",
  backgroundImage : null,
  backgroundRepeat : "no-repeat",
  backgroundPosition : "center center",
  borderWidth : 1,
  borderTopWidth : 0,
  borderLeftWidth : 0,
  borderRightWidth : 1,
  borderBottomWidth : 1,
  borderStyle : "solid",
  borderColor : "#777777",
  fontFamily : "Arial",
  fontSize : 10,
  fontWeight : "normal",
  fontStyle : "normal",
  toLastImage : null,
  toNextImage : null,
  innerBorderWidth : 1,
  innerBorderStyle : "solid",
  innerBorderColor : "#CCCCCC"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.FreeForm = {
/* TODO 추후예정 */
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Grid = {
/* TODO 추후예정 */
  multiSelect : false,
  sortable : false
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.GridHeader = {
/* TODO 추후예정 */
  backgroundColor : null,
  color : null,
  textAlign : null,
  textDecoration : null,
  fontSize : null,
  fontStyle : null,
  fontWeight : null
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.GridBody = {
/* TODO 추후예정 */
  backgroundColor : null,
  oddBackgroundColor : null,
  selectedBackgroundColor : null,
  color : null,
  selectedColor : null,
  borderColor : null,
  borderStyle : null,
  borderWidth : null,
  selectedBorderColor : null,
  selectedBorderStyle : null,
  selectedBorderWidth : null,
  focusCellBorderColor : null,
  focusCellBorderStyle : null,
  focusCellBorderWidth : null,
  textAlign : null,
  textDecoration : null,
  fontSize : null,
  fontStyle : null,
  fontWeight : null
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.HeadColumn = {
/* TODO 추후예정 */
  backgroundColor : null,
  color : null,
  textAlign : null,
  fontFamily : null,
  fontSize : null,
  fontStyle : null,
  fontWeight : null
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.BodyColumn = {
/* TODO 추후예정 */
  backgroundColor : null,
  color : null,
  textAlign : null,
  readOnly : false,
  fontFamily : null,
  fontSize : null,
  fontStyle : null,
  fontWeight : null
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.GridEx = { 	
	  backgroundImage : null,
	  fontFamily : "Arial",
	  fontSize : 10,
	  fontWeight : "normal",
	  fontStyle : "normal",
	  cursor : "auto",
	  backgroundRepeat : "no-repeat",
	  backgroundPosition : "center center",
	  defaultFileName : "/eXria/config/gridex/Defaults.xml",
	  textFileName : "/eXria/config/gridex/Text.xml"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Shape = {
  position : "absolute",
  visible : true,
  movable : false,
  zIndex : 0,
  cursor : "auto",
  tooltip : null,
  tooltipDisplay : true,
  penCap : "round",
  penStyle : "solid",
  penWeight :1,
  penColor : "#938B81",
  penOpacity : 100,
  joinType : "round",
  angle : 0,
  cursor : "default",
  focusBorderColor : "#006600",  
  focusBorderStyle : "solid",
  focusBorderWidth : "auto"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Line = {
  startPosition : "top",
  penColor : "#736A5E"
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Rectangle = {
  fillStartColor : "#E4EEF3",
  fillEndColor : "white",
  fillType : "solid",
  fillAngle : 0,
  fillOpacity : 100
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Roundrect = {
  round : 20,
  fillStartColor : "#FAEBD7",
  fillEndColor : "white",
  fillType : "solid",
  fillAngle : 0,
  fillOpacity : 100
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Ellipse = {
  fillStartColor : "#D6E3B1",
  fillEndColor : "white",
  fillType : "solid",
  fillAngle : 0,
  fillOpacity : 100
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.SlideTab = {
  expandDirection : "top",
  selectedIndex : 0,
  renderAll : false,
  slideButtons : {
    className : null,
    outerClassName : null,
    height : 50,
    borderStyle : "outset",
    borderWidth : 1,
    borderColor : "#1475C5",
    //backgroundImage : "url(http://img.yahoo.co.kr/spirit/pyramid/2008/08/08/nw1a1_img1_1218157383.jpg)",
    backgroundImage : null,
    imageFocused : null,
    backgroundColor : "#1683D7",
    focusBackgroundColor : "#76A7C1",
    color : "black",
    focusColor : "white",
    fontSize : 12
  },
  slidePages : {
    className : null,
    outerClassName : null,
    borderStyle : "none",
    borderWidth : 0,
    borderColor : "white",
    backgroundColor : "white"
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.ContextMenu = {
  borderWidth : 1,
  borderStyle : "solid", 
  borderColor : "#1475C5",  
  backgroundColor : "white",
  zIndex :  100000,
  shadowEnable : true,
//  iconarea : {
//    width : 20,
//    backgroundColor : "#A5BACC"
//  },
  itemgroup : { 
      iconWidth : 20, 
      iconBackgroundColor : "#A5BACC",
      separatorColor : "#1683D7",
      separatorHeight : 2,
      textIndent : 10,       
      height : 30,
      width : 100,
      textAlign : "left", 
      verticalAlign : "middle", 
      fontFamily : "Arial",
      fontSize : 10,
      fontWeight : "normal",
      fontStyle : "normal",
      color : "#000000",
      backgroundColor : "#D4D0C9",
      focusColor : "white",      
      focusBackgroundColor : "blue"
  },
  shadow : {
  		backgroundColor : "#777777",
  		borderWidth : 0,
  	  borderStyle : "solid",
  	  borderColor : "#CCCCCC",
  		filter : "alpha(opacity:50)",
  	  opacity : "0.50",
  	  left : "3px",
  	  top : "3px"
  }
};
  
/**
* @ignore
*/
eXria.controls.xhtml.Default.FileSelector = {
  backgroundColor : "#FFFFFF",
  borderWidth : 1,
  borderStyle : "solid",
  borderColor : "#A5BACC",
  color : "#000000",
  fontFamily : "Arial",
  fontSize : 10,
  fontStyle : "normal",
  fontWeight : "normal",

  browseBtn : {
    className : null,
    borderWidth : 2,
    borderColor : "#CCCCCC",
    borderStyle : "outset",
//    backgroundImage : "css/theme1/btn/btnBig_orange.gif",
    backgroundRepeat : "no-repeat",
    backgroundPosition : "center center",
    backgroundColor : "#E7E7EB",
    color : "#000000",
    fontFamily : "Arial",
    fontSize : 9,
    fontStyle : "normal",
    fontWeight : "bold",
    width : 58,
    value : "Browse"
  } 
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Print = {
  css : "print.css",
  marginLeft : 10,
  marginTop : 10,
  marginRight : 10,
  marginBottom : 10,
  formSpacing : 10,
  
  HeaderFooter : {
    borderWidth : 1,
    borderStyle : "solid",
    borderColor : "black",
    backgroundColor : "",
    backgroundImage : "",
    height : 100
  }
};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Canvas = {

};

/**
* @ignore
*/
eXria.controls.xhtml.Default.Cover = {
	backgroundColor : "#000000",
	filter : "alpha(opacity:10)",
  opacity : "0.10"
};