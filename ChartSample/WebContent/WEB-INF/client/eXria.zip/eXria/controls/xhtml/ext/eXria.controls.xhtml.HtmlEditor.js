/**
 * @fileoverview
 * Concreate xhtml HtmlEditor(XHTML HtmlEditor 컨트롤)
 * @author 
 */
 
/**
 * @class 에디터 컨트롤을 생성하는 class입니다.<br />
 * XHTML TextArea Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.HtmlEditor 객체
 * @type eXria.controls.xhtml.HtmlEditor
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.HtmlEditor = function(psId,pnLeft, pnTop, pnWidth, pnHeight) {
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 100 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */      
  this.data = new eXria.controls.DataRefNode(this);
  /////////////////////////////////////////////////////////////////////////////
  ////속성
  /**
   * 컨트롤의 설정된 값.
   * @type String
   */       
  this.value = null;
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;  
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
  /**
   * 텍스트 오버플로우
   */
  this.inputOverFlow = false;
  /**
   * 에디터 객체
   * @type Object
   * @private
   */
  this.editorInstance = null;
  /**
   * 에디터 객체
   * @type Boolean
   * @private
   */
  this.readOnly = null;
  
  /**
    TODO 속성중에 editor 속성은 전부 private 으로 만듬
  **/      
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.HtmlEditor);

/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.createCtrl = function(poDocument){
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};

/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.setTemplate = function(poCtrl, poDocument){
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<textarea id='" + this.id + "_CKEDITORTextArea' ");
//  vaTemplate.push("<textarea id='" + this.id + "_CKEDITORTextArea' class='" + vsClass + "' ");
  vaTemplate.push("@attStrBuf");
  vaTemplate.push(" style=\"");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("\">");
  vaTemplate.push("</textarea>")
};
/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.refreshTemplate = null;
/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voUserAttr = null;
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
//  this.value = this.getAttrValue("value",this.value);

  this.skin  = this.getAttrValue("skin",this.skin);  
  this.toolbarSet  = this.getAttrValue("toolbarSet",this.toolbarSet); 
  this.formatListSet  = this.getAttrValue("formatListSet",this.formatListSet);
  this.fontListSet  = this.getAttrValue("fontListSet",this.fontListSet);
  this.fontSizeStyle  = this.getAttrValue("fontSizeStyle",this.fontSizeStyle);
  this.language  = this.getAttrValue("language",this.language);
  this.enterMode  = this.getAttrValue("enterMode",this.enterMode);
  this.shiftEnterMode  = this.getAttrValue("shiftEnterMode",this.shiftEnterMode);
  this.styleTagMode  = this.getAttrValue("styleTagMode",this.styleTagMode);
  this.readOnly = this.getAttrValue("readOnly",this.readOnly);
    
  if(null === this.readOnly){
    if(this.userAttr) {
      if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);            
    
      this.readOnly = voUserAttr.readOnly;
    }    
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaTemplate = this.template;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;  
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "overflow", "hidden");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  
  poCtrl.style.cssText = vaCssStrBuf.join("");
  
  vaAttStrBuf = [];
  
  var vnWidth = this.innerWidth - this.paddingLeft - this.paddingRight;
  if(vnWidth < 0) vnWidth = 0;
  
  var vnHeight = this.innerHeight - this.paddingTop - this.paddingBottom;
  if(vnHeight < 0) vnHeight = 0;
  
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;padding:0px;border-style:none;top:0px;left:0px;");//overflow:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", vnWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", vnHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", "transparent");
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  vaTemplate[3] = vaCssStrBuf.join("");
  
  poCtrl.innerHTML = vaTemplate.join("");

  vaCssStrBuf = null;
  vaAttStrBuf = null;
  vaTemplate = null;
  this.template = null;

  //////////////////////////////////////////////////////////////////////////////////////
  // 에디터 관련 처리 Start
  //////////////////////////////////////////////////////////////////////////////////////

  //1.에디터 속성값 불러오기
  var voOuterControl = poCtrl;
  var voEditorConfig = this.getEditorConfig();
  var voReadOnly = this.readOnly;
   
  //2.에디터 높이지정  
  voEditorConfig.height = vnHeight + this.setEditorHeight(voEditorConfig);
  
  //readOnly 여부 결정
  CKEDITOR.on("instanceReady", function (ev) {
      var bodyelement = ev.editor.document.$.body;
      if(!!voReadOnly) bodyelement.setAttribute("contentEditable", false);
      else bodyelement.setAttribute("contentEditable", true);
  });    
  
  //3.에디터 로딩
  var voEditor = CKEDITOR.replace( this.id+'_CKEDITORTextArea', voEditorConfig);
  this.editorInstance = voEditor;   

  //4.에디터 Value 지정
  if(!!this.value)
    this.editorInstance.setData( this.value );  
  
  //5.에디터 textStyle 지정     
  this.setEditorContentsStyle(voOuterControl);
  
  //6.에디터 이벤트 핸들러 지정
  this.setEditorEventHandler();  
  
  
  //////////////////////////////////////////////////////////////////////////////////////
  // 에디터 관련 처리 End
  //////////////////////////////////////////////////////////////////////////////////////
  
}


/**
 * HTMLEditor readOnly 여부 적용
 * @param {String} psText 설정 값.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.HtmlEditor.prototype.setReadOnly = function(pbReadOnly){
  var voCtrl = this.ctrl;
  var voDocument = this.document;
  this.readOnly = pbReadOnly;//(!!pbReadOnly)? true : false;

  var voEditor = this.editorInstance;
  if (voEditor) {
      //voEditor.destroy();
      CKEDITOR.remove(voEditor);
  }
       
  while( voCtrl.hasChildNodes() ) { voCtrl.removeChild( voCtrl.lastChild ); }
    
  this.setTemplate(voCtrl, voDocument);
  this.setSpecificDefaults(voCtrl, voDocument);
  this.setSpecificAttrs(voCtrl, voDocument);
     
}

/** 
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.setEditorHeight = function(poEditorConfig){
  var vsToolBarCase =  (!!this.toolbarSet) ? this.toolbarSet : 'default' ;
  var vsSkinCase = (!!this.skin) ? this.skin : 'default'
  var vnHeight = 0;
  
  //TODO - 높이를 하드 코딩 했기때문에 브라우저에 따라서
  //문제가 될 소지가 있음...수정해야함
  if(vsSkinCase === "default"){
    switch(vsToolBarCase){
      case 'default' : vnHeight = -137; break;      
      case 'eXriaBasic' : vnHeight = -137;; break;          
      case 'basic' :  vnHeight = -75; break;          
      case 'all' :  vnHeight = -200; break;    
      default : break;
    }    
  }else if(vsSkinCase === "office2003"){
    switch(vsToolBarCase){
      case 'default' : vnHeight = -137 + 28; break;      
      case 'eXriaBasic' : vnHeight = -137 + 28; break;          
      case 'basic' :  vnHeight = -75 + 18-3; break;          
      case 'all' :  vnHeight = -200 + 38-5; break;    
      default : break;
    }    
  }else if(vsSkinCase === "v2"){
    switch(vsToolBarCase){
      case 'default' : vnHeight = -137 + 28; break;      
      case 'eXriaBasic' : vnHeight = -137 + 28; break;          
      case 'basic' :  vnHeight = -75 + 18; break;          
      case 'all' :  vnHeight = -200 + 38; break;    
      default : break;
    }    
  }
  
  return vnHeight;
}

/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.setEditorContentsStyle = function(poCtrl){
  var vaCssStrBuf = [];
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var voEditorId = this;
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding", this.padding, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
     
  //에디터가 준비 되면 CSS 와 inlineStyle 적용
  this.editorInstance.on('instanceReady', function(ev){
    
    //eXria_CRE_Configuration.css 를 iframe 에 복사
    var voOriginCssElement = document.getElementsByTagName("link")[0];
    var voIframeContentDocument = document.getElementById("cke_contents_"+voEditorId.id+"_CKEDITORTextArea")
                                 .childNodes[0].contentWindow.document;    
    var voIframeContentHead = voIframeContentDocument.getElementsByTagName("head")[0];
    var voTargetCssElement = voIframeContentDocument.createElement('link');

    voTargetCssElement.type = 'text/css';
    voTargetCssElement.rel = 'stylesheet';
    voTargetCssElement.href = voOriginCssElement.href;
    voTargetCssElement.media = 'screen';    
    voIframeContentHead.appendChild(voTargetCssElement);
    
    //inlineStyle 지정             
    voIframeContentDocument.getElementsByTagName("body")[0]
    .style.cssText = vaCssStrBuf.join("");    

  });         
  
  //에디터가 focus / blur  될경우 스타일 지정
  var vsCssTextBackup = poCtrl.style.cssText;
  if(!!this.focusDisplay){
    this.editorInstance.on('focus', function(){
      voEditorId.setFocusStyle(true);
    });
    this.editorInstance.on('blur', function(){
      //poCtrl.style.cssText = vsCssTextBackup;
      voEditorId.setFocusStyle(false);
    });     
  }  
}

/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.setEditorEventHandler = function(){
  if(!!this.onblur)
    this.editorInstance.on('blur', this.onblur);
    
  if(!!this.onfocus)
    this.editorInstance.on('focus', this.onfocus);
  
  if(!!this.onkeydown)
    this.editorInstance.on('key', this.onkeydown);  
  
  if(!!this.onready)
    this.editorInstance.on('instanceReady', this.onready);
}


/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.getEditorConfig = function(){
  var voEditorConfig = {};
  //에디터 리사이즈 지정
  voEditorConfig.resize_enabled = false;
    
  //에디터 스킨 지정
  if(!!this.skin){
    switch(this.skin){
      case "default" : break;
      default : voEditorConfig.skin = this.skin; break;
    }
  }
  
  //에디터 툴바 지정
  if(!!this.toolbarSet){
    switch(this.toolbarSet){
      case 'default' : break;      
      case 'eXriaBasic' : break;      
      
      case 'basic' : 
          voEditorConfig.toolbar = 'Basic';  
        break;      
      
      case 'all' : 
          voEditorConfig.toolbar = 'Full';
        break;
      
      default : break;
    }    
  }
  
  //에디터 포맷 리스트 지정 
  if(!!this.formatListSet){    
    switch(this.formatListSet){
      case 'title' : 
        voEditorConfig.format_tags = 'h1;h2;h3;h4;h5;h6'; 
        break;
    }
  }
  
  //에티터 폰트 포맷 리스트 지정
  if(!!this.fontListSet){
    switch(this.fontListSet){
      case 'kor' : 
        voEditorConfig.font_names =   '굴림' + ';'+ '굴림체' + ';'+
                                      '돋움' + ';'+ '돋움체' + ';'+                        
                                      '맑은 고딕' + ';'+ '바탕' + ';'+
                                      '바탕체' + ';'+ '궁서' + ';'+
                                      '궁서체' + ';'+ '새굴림' + ';'+
                                      '으뜸체' + ';'+ '휴먼둥근헤드라인' + ';'+
                                      '휴먼아미체' + ';'+ '휴먼옛체' + ';'+
                                      '휴먼매직체';
        break; 
      case 'eng' : 
        voEditorConfig.font_names =   'Arial/Arial, Helvetica, sans-serif;' +
                                      'Comic Sans MS/Comic Sans MS, cursive;' +
                                      'Courier New/Courier New, Courier, monospace;' +
                                      'Georgia/Georgia, serif;' +
                                      'Lucida Sans Unicode/Lucida Sans Unicode, Lucida Grande, sans-serif;' +
                                      'Tahoma/Tahoma, Geneva, sans-serif;' +
                                      'Times New Roman/Times New Roman, Times, serif;' +
                                      'Trebuchet MS/Trebuchet MS, Helvetica, sans-serif;' +
                                      'Verdana/Verdana, Geneva, sans-serif;'        
        break;  
    }
  }

  //에디터 폰트 사이즈 리스트 지정
  if(!!this.fontSizeStyle){
     switch(this.fontSizeStyle){
       case 'css' : 
        voEditorConfig.fontSize_sizes = '12 Pixels/12px;Big/2.3em;30 Percent More/130%;Bigger/larger;Very Small/x-small';
        break;        
     }      
  }

  //에디터 언어 포맷 지정  
  if(!!this.language){
    switch(this.language){
      case 'kor' : 
        voEditorConfig.language = 'ko'; 
        break;
      case 'eng' : 
        voEditorConfig.language = 'en'; 
        break;      
      case 'jpn' : 
        voEditorConfig.language = 'ja'; 
        break;      
      case 'chn' : 
        voEditorConfig.language = 'zh'; 
        break;
      default : 
        var vsLanguage = eXria.controls.xhtml.Util.getDefaultLocale();
        switch(vsLanguage){
          case 'kor' : voEditorConfig.language = 'ko'; break;
          case 'eng' : voEditorConfig.language = 'en'; break;
          case 'jpn' : voEditorConfig.language = 'ja'; break;
          case 'chn' : voEditorConfig.language = 'zh'; break;
        }        
    }
  }
  
  //에디터 엔터키 속성 지정
  if(!!this.enterMode){      
      switch(this.enterMode){
        case 'P': voEditorConfig.enterMode = 1; break;
        case 'BR': voEditorConfig.enterMode = 2; break;
        case 'DIV': voEditorConfig.enterMode = 3; break;
      }    
  }
  
  //에디터 쉬프트 엔터키 속성 지정
  if(!!this.shiftEnterMode){
    switch(this.shiftEnterMode){
        case 'P': voEditorConfig.enterMode = 1; break;
        case 'BR': voEditorConfig.enterMode = 2; break;
        case 'DIV': voEditorConfig.enterMode = 3; break;
    }    
  }
  
  //에디터 TextArea Font 스타일 지정
  if(!!this.styleTagMode){
    switch(this.styleTagMode){
      case 'block'  :
       voEditorConfig.stylesSet = [
        { name : 'Blue Title'   , element : 'h3', styles : { 'color' : 'Blue' } },
        { name : 'Red Title'    , element : 'h3', styles : { 'color' : 'Red' } },
        { name : 'Yellow Title' , element : 'h3', styles : { 'color' : 'Yellow' } },
        { name : 'Green Title' , element : 'h3', styles : { 'color' : 'Green' } }
       ];
       break;
      case 'inline' :       
       voEditorConfig.stylesSet = [
        { name : 'Marker: Yellow' , element : 'span', styles : { 'background-color' : 'Yellow' } },
        { name : 'Marker: Green'  , element : 'span', styles : { 'background-color' : 'Lime' } },
        { name : 'Big'        , element : 'big' },
        { name : 'Small'      , element : 'small' },
        { name : 'Typewriter'   , element : 'tt' },
        { name : 'Computer Code'  , element : 'code' },
        { name : 'Keyboard Phrase'  , element : 'kbd' },
        { name : 'Sample Text'    , element : 'samp' },
        { name : 'Variable'     , element : 'var' },
        { name : 'Deleted Text'   , element : 'del' },
        { name : 'Inserted Text'  , element : 'ins' },
        { name : 'Cited Work'   , element : 'cite' },
        { name : 'Inline Quotation' , element : 'q' },
        { name : 'Language: RTL'  , element : 'span', attributes : { 'dir' : 'rtl' } },
        { name : 'Language: LTR'  , element : 'span', attributes : { 'dir' : 'ltr' } }
       ];       
       break;
    }
  }
  
  //에디터 bodyClass 적용
  voEditorConfig.bodyClass = this.getCSSClass(this, 1);
      
  return voEditorConfig;
}


/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {}

/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */ 
eXria.controls.xhtml.HtmlEditor.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  var voDf = this.df;
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }

  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voCtrl, psAttrValue);
    break;
  default :
    this.refresh(poDocument);
    break;
  }
};

/**
 * 컨트롤에 설정된 값을 반환합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 컨트롤의 할당된 값
 * @type String
 */
eXria.controls.xhtml.HtmlEditor.prototype.getValue = function(poDocument) {  
  this.value = this.editorInstance.getData();
  return this.value;
};

/**
 * 컨트롤에 지정된 값을 설정합니다.
 * @param {String} psText 설정 값.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.HtmlEditor.prototype.setValue = function(psText, poCtrl, poDocument) {  
  this.value = psText;  
  this.data.setData(this.value);
  this.editorInstance.setData( this.value );
};

/**
 * 컨트롤의 포커스가 위치한 영역에 값을 추가 합니다.
 * @param {String} psText 설정 값.
 */
eXria.controls.xhtml.HtmlEditor.prototype.insertHtml = function(psText, poCtrl, poDocument) {
  this.editorInstance.insertHtml( psText );  
  this.value = this.getValue();
  this.data.setData(this.value);    
};


/**
 * loadData
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.HtmlEditor.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var voCtrl = this.ctrl;
  var vsRefData = this.data.getData();
  this.setValue(vsRefData, voCtrl, poDocument);  
};
/**
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
};  

/**
 * 각 속성에 따른 디폴트 값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @ignore
 */
eXria.controls.xhtml.HtmlEditor.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.HtmlEditor[psAttrName];
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};

/**
 * 클래스 명을 반환합니다.
 * @return "HtmlEditor"
 * @type String
 */
eXria.controls.xhtml.HtmlEditor.prototype.toString = function() {
  return "HtmlEditor";
};