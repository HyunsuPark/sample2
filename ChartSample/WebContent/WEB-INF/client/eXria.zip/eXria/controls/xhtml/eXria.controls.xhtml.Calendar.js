/**
 * @fileoverview
 * Concreate xhtml Calendar(XHTML 카렌더 컨트롤)
 * @author
 */
/**
 * @class 달력을 생성하는 class입니다. DateInput이나 EditMask에서 날자를 입력할때 주로 쓰입니다.<br/>
 * XHTML Calendar Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @param {Boolean} pbFlag DateInput, EditMask 에서 호출되었는지 여부
 * @return 새로운 eXria.controls.xhtml.Calendar 객체
 * @type eXria.controls.xhtml.Calendar
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Calendar = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pbFlag){

    pnLeft = pnLeft == null ? 20 : pnLeft;
    pnTop = pnTop == null ? 20 : pnTop;
    pnWidth = pnWidth == null ? 250 : pnWidth;
    pnHeight = pnHeight == null ? 250 : pnHeight;
    
  /**
	 * UIControl을 상속받는다.
	 */ 	
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
    
	/**
	 * Data 연동 객체(싱글 노드 연동).
	 * @type eXria.controls.DataRefNode
	 */
	this.data = new eXria.controls.DataRefNode(this);
  /**
   * Calendar에 의해 선택된 날짜를 셋팅할 컨트롤
   * @type eXria.controls.xhtml.UIControl
	 * @private
   */
  this.target;
  
  this.width = pnWidth;
  
  this.height = pnHeight;
  /**
   * 외부 컨트롤에 의해 호출되었는지 여부를 저장하는 속성
   * @type Boolean
   * @private
   */
  this.isCalledBy = pbFlag;
  /**
   * 컨트롤에 지정된 값을 Date형태로 접근하기 위한 속성.
   * @type Date
   */
  this.date;
  /**
   * 기본형 달력VIEW와 년도와 월을 동시에 변경(getMultiSelectHTML)하는 VIEW를 구분하기 위한 속성.
   * @private
   */
  this.calType = 'default';
  
  /**
   * 년도와 월을 동시에 변경(getMultiSelectHTML)하는 VIEW를 유지 하기 위한 속성
   * @type Boolean
   * @private
   */
  this.keepMultiSelector = null;
    
  /**
   * Defaults.xml의 경로 설정
   * @type String
   */
  this.defaultFileName = null;
  /**
   * Text.xml의 경로 설정
   * @type String
   */
  this.textFileName = null;
  /**
   * 상위 컨트롤과의 위치 관계(absolute | relative | static).
   * @type String
   */
  this.position = "absolute";
    
  var date = (!this.date) ? new Date() : this.date;
  var now = new Date();
	/**
	 * 년 
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
  this.year = date.getUTCFullYear();
	/**
	 * 월 
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
  this.month = date.getUTCMonth() + 1;
	/**
	 * 일
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
  this.dayNum = date.getUTCDate();
	/**
	 * 다국어 처리를 언어 locale
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
	this.locale = null;
	/**
	 * TreeGrid 관련 CSS
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
  this.CSS = null;
  /**
	 * 올해 년 
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
	this.NOWYEAR = now.getUTCFullYear();
  /**
	 * 올해 월 
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
  this.NOWMONTH = now.getUTCMonth() + 1;
  /**
	 * 올해 일 
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */
	this.NOWDAYNUM = now.getUTCDate();
  /**
   * 일자 선택 관련 속성
   * 달력 연산을 처리 하기 위한 내부 속성으로 사용됨
   * @private
   */    
  this.FY;
  /**
   * 달과 년이 선택되었는지 여부(0|1)
   * @type Number
   * @private
   */   
  this.record;
  /**
   * @private
   */   
  this.loadedStyles = [];
  //this.loadDefaultSpce();
};

/////////////////////////////////////////
// 상속 Start
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Calendar);
// 상속 End
/////////////////////////////////////////


/////////////////////////////////////////
// Setter Method
/**
 * Calendar에 의해 선택된 날짜를 셋팅할 컨트롤을 설정합니다.
 * @param {eXria.controls.xhtml.UIControl} poCtrl 타겟 컨트롤
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.setTarget = function(poCtrl){
    this.target = poCtrl;
};
/**
 * Calendar에 의해 선택된 날짜를 셋팅합니다.
 * @param {Date} poDate 달력에 선택될 날짜 개체
 */
eXria.controls.xhtml.Calendar.prototype.setDate = function(poDate){
    this.date = poDate;
};
// Setter Method
/////////////////////////////////////////


/////////////////////////////////////////
// Lifecycle Method START
eXria.controls.xhtml.Calendar.prototype.createCtrl = function(poDocument){
    ///// DIV Control Create Start /////
    var voCtrl = poDocument.createElement("div");
    voCtrl["id"] = this.id;
    voCtrl["tabIndex"] = -1;
    if (this.canvas.page.metadata.browser.ie > 0) 
        voCtrl["hideFocus"] = true;
    this.template = [];
    this.document = poDocument;
    this.ctrl = voCtrl;
    return voCtrl;
};

eXria.controls.xhtml.Calendar.prototype.setTemplate = function(poCtrl){
	this.loadDefaultSpce();
  var voCaltyp = this.calType;
	
	//2010.04.20
	//Ref 처리를 위해 추가
	if(this.data.instanceId == null || this.data.isRelativeRef()){
  }else{
		if(!this.loadNodeRefFlag) this.loadNodeRef();	
	}

  if(true === this.keepMultiSelector) {
      this.getMultiSelectHTML(this.keepMultiSelector);     
  }else{
    //일반적인 경우 
    if (!!voCaltyp && voCaltyp === 'default') {
      this.getHTML();
    } else {
      if (!!voCaltyp && voCaltyp === 'multi') this.getMultiSelectHTML();
    }
  }  
};
/**
 * 인스턴스에 매핑된 data를 얻어오기 위한 메소드.
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.loadNodeRef = function(){
	var vsNodeRef = this.data.getData();

	if(!!vsNodeRef && vsNodeRef.length >= 8) {
		
		this.loadNodeRefFlag = true; //@ignore
		
		vsNodeRef = vsNodeRef + '';
		vsNodeRef = vsNodeRef.replace(/[^0-9]/gi,'');
		var vsDate = new Date(Date.UTC(Number(vsNodeRef.substring(0, 4)), Number(vsNodeRef.substring(4, 6)) - 1, Number(vsNodeRef.substring(6, 8)), 0, 0, 0));
		    
		this.date = vsDate; 
		this.year = vsDate.getUTCFullYear();
		this.month = vsDate.getUTCMonth() + 1;
		this.dayNum = vsDate.getUTCDate();
		
		this.NOWYEAR = vsDate.getUTCFullYear();
		this.NOWMONTH = vsDate.getUTCMonth() + 1;
		this.NOWDAYNUM = vsDate.getUTCDate();				
	}
};
/**
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.loadComplete = function(){
    if (this.isCalledBy == true) 
        this.focusDate();
};
/**
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.focusDate = function(){
    var voDocument = this.document;
    var voCal = voDocument.getElementById(this.id);
    voCal.focus();
};
/**
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl){
    if (poCtrl.id != this.id) return;
    
    var voTable = poCtrl.childNodes.item(0);
    
    //width, height 180px 미만이면 메세지 출력(발생될 경우가 절대 없음)
    if (psAttrName == "width" && this.width < 180) {
      alert(" width 최소값: 180px \n 180px 이상으로 입력하십시오.");
    } else {
      if (psAttrName == "height" && this.height < 180) {
        alert(" height 최소값: 180px \n 180px 이상으로 입력하십시오.");
      }
    }
    switch (psAttrName) {
      case "width":
        this.setAttrCtrl("width", this.innerWidth, voTable);
        break;
      case "height":
        this.setAttrCtrl("height", this.innerHeight, voTable);
        break;
    }
};

/**
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument){

    var voCtrl = this.getCtrl(poDocument);
    this.setAttr(psAttrName, psAttrValue);
    switch (psAttrName) {
      case "visible":
        this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
        break;
      case "disabled":
        this.setDisable(voCtrl, psAttrValue);
        break;
      default:
        this.refresh(poDocument);
        break;
    }
};

eXria.controls.xhtml.Calendar.prototype.removeSpecificDefaults = function(poCtrl, poDocument){
    this.df = {};
};

eXria.controls.xhtml.Calendar.prototype.setSpecificDefaults = function(poCtrl, poDocument){
    var voDf = this.df;
    var vaCssStrBuf = null;
    var vaAttStrBuf = null;
    var vaInnStrBuf = null;
    var vaTemplate = this.template;
    var vfcSetCssStrBuf = this.setCssStrBuf;
    
    poCtrl["tabIndex"] = this.tabIndex;
    poCtrl["tooltip"] = this.tooltip;
    if (this.disabled) poCtrl["disabled"] = true;
    
    vaCssStrBuf = [];
    vaCssStrBuf.push("margin:0px;padding:0px;");
    if (this.visible == false) vaCssStrBuf.push("display:none;");
    else vaCssStrBuf.push("display:block;");
    vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
    vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
    vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
    vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
    vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
    
    vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
    vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
    vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
    vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
    vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
    poCtrl.style.cssText = vaCssStrBuf.join("");
    
    poCtrl.innerHTML = vaTemplate.join("");
    this.template = null;
    this.templateIndexMap = null;
    
    this.defaultFileName = this.getAttrValue("defaultFileName", this.defaultFileName);
    this.textFileName = this.getAttrValue("textFileName", this.textFileName);
};

eXria.controls.xhtml.Calendar.prototype.setSpecificAttrs = function(poCtrl, poDocument){
    var voDf = this.df;
    var vaCssStrBuf = null;
    var vaAttStrBuf = null;
    var vaInnStrBuf = null;
    var vaTemplate = this.template;
    var vfcSetCssStrBuf = this.setCssStrBuf;
    var vfcSetAttStrBuf = this.setAttStrBuf;
    var voIndexMap = this.templateIndexMap;
    
    poCtrl["tabIndex"] = this.tabIndex;
    poCtrl["tooltip"] = this.tooltip;
    if (this.disabled) poCtrl["disabled"] = true;
    
    
    vaCssStrBuf = [];
    vaCssStrBuf.push("margin:0px;padding:0px;");
    if (this.visible == false) vaCssStrBuf.push("display:none;");
    else vaCssStrBuf.push("display:block;");
    vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
    vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
    vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
    vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
    vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
    
    vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
    vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
    vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
    vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
    vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
    vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
    poCtrl.style.cssText = vaCssStrBuf.join("");
};

/**
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.atkeydown = function(e){
  if(!!this.target && !!this.target.ctrl.firstChild.value) {
     if(e.keyCode == 27)
      this.close();
  }
};

// Lifecycle Method END
/////////////////////////////////////////

/////////////////////////////////////////
//달력상수
/**
 * @ignore
 */
eXria.controls.xhtml.Calendar.CGLang = {
    "kor": {
        "month": "",
        "day": ""
    },
    "eng": {
        "month": "",
        "day": ""
    },
    "chn": {
        "month": "",
        "day": ""
    },
    "jpn": {
        "month": "",
        "day": ""
    }
};
//달력상수
/////////////////////////////////////////

/////////////////////////////////////////////
// 사용자 메소드 리스트 START
/**
 * Calendar의 visible속성을 설정합니다.
 * @param {boolean} pbVisible 화면 보여짐 여부
 */
eXria.controls.xhtml.Calendar.prototype.setVisible = function(pbVisible){
    this.visible = pbVisible;
};

/**
 * 달력을 화면에 표시해주는 메소드.
 * @param {HTMLElement} poCtrl 컨트롤이 위치한 상위 Dom Element. 생략가능.
 * @param {HTMLElement} poDocument 컨트롤이 생성될 document 객체. 생략가능.
 */
eXria.controls.xhtml.Calendar.prototype.show = function(poCtrl, poDocument){
  this.visible = true;
  var voTarget = this.target;
  var voCanvas = null;
  if(voTarget) voCanvas = voTarget.canvas;
  if(voCanvas == null) voCanvas = this.canvas;
  if(voCanvas) {
    if(!!this.target && !!this.target.ctrl.firstChild.value) {
      var voDateStr = this.target.getValue();
      var vsRegType = /[^0-9]/gi;
      voDateStr = voDateStr.replace(vsRegType, '');	
      
      this.date = new Date(Date.UTC(Number(voDateStr.substring(0, 4)), Number(voDateStr.substring(4, 6)) - 1, Number(voDateStr.substring(6, 8)), 0, 0, 0));
      
      this.year = this.date.getUTCFullYear();
      this.month = this.date.getUTCMonth() + 1;
      this.dayNum = this.date.getUTCDate();
    }

    // 부모 컨트롤 밑에 appendChild 되게 수정 (poCtrl이 없는 경우에는 parent 컨트롤이 없는 경우)
    if(!poCtrl) poCtrl = this.canvas;
		
    var voCanvasCtrl = poCtrl.getCtrl();
    voCalendarCtrl = this.create();
    voCanvasCtrl.appendChild(voCalendarCtrl);
    this.load();
  }
};

/**
 * Calendar가 화면에서 보이지 않게 만들어줍니다.
 * @param {HTMLElement} poDocument 실체화 컨트롤이 위치할 Doucment. 생략가능
 */
eXria.controls.xhtml.Calendar.prototype.hide = function(poDocument){
  this.visible = false;
  
  if(!!this.ctrl && !!this.ctrl.parentNode && null != this.ctrl.parentNode.oriZindex) {
    this.ctrl.parentNode.style.zIndex = this.ctrl.parentNode.oriZindex;  
  }
  
  this.clearCtrl();
  if(this.lifted) {
//    this.setAttrCtrl("zIndex", this.zIndex, this.ctrl);
    voParent = this.parent;
    while(voParent) {
      if(voParent.ctrl) {
        vnZIndex = voParent.zIndex == null ? 0 : voParent.zIndex;
        this.setAttrCtrl("zIndex", vnZIndex, voParent.ctrl);
      }
      voParent = voParent.parent;
    }
    this.lifted = false;
  }
  this.ctrl = null;
};

/**
 * 기준 날짜의 년도를 구하는 메소드입니다.
 * @return 년도
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getYear = function(){

  var vnYear = this.date.getUTCFullYear();
  if (vnYear > 1900) {
    return vnYear;
  }
  return 1900 + vnYear;
};

/**
 * 기준 날짜의 월을 반환합니다.
 * @return 월(1 ~ 12)
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getMonth = function(){
  var vnMonth = this.date.getUTCMonth() + 1;
  return vnMonth;
};

/**
 * 기준 날짜의 일을 반환합니다.
 * @return 일
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getDate = function(){
  var vnDate = this.date.getUTCDate();
  return vnDate;
};

/**
 * 선택된 날짜의 년도를 반환 합니다.
 * @return 년도
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getSelectYear = function(){
  var vnYear;
  vnYear = this.date;
  
  if(!!this.date) vnYear = Number(this.date.substring(0, 4));
  else vnYear = this.getYear();
    
  return vnYear;
};

/**
 * 선택된 날짜의 월을 반환 합니다.
 * @return 월(1 ~ 12)
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getSelectMonth = function(){
  var vnMonth;
  vnMonth = this.date;
  
  if(!!this.date) vnMonth = Number(this.date.substring(4, 6));
  else vnMonth = this.getMonth();
    
  return vnMonth;
};

/**
 * 선택된 날짜의 일을 반환 합니다.
 * @return 일
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getSelectDate = function(){
  var vnDate;
  vnDate = this.date;
  
  if(!!this.date) vnDate = Number(this.date.substring(6, 8));
  else vnDate = this.getDate();
    
  return vnDate;
};

/**
 * 기준 날짜의 최대 일자를 반환합니다(파라미터값 미입력시 현재날짜를 기준).
 * @param pnYear 기준년도(생략가능)
 * @param pnMonth 기준달(생략가능)
 * @return 기준 달의 최대 일자
 * @type Number
 */
eXria.controls.xhtml.Calendar.prototype.getMaxDay = function(pnYear, pnMonth){
  var vnMonth = pnMonth;
  var vnYear = pnYear;
  if (pnYear == null) vnYear = this.date.getUTCFullYear();
  if (pnMonth == null) vnMonth = this.date.getUTCMonth();
  else vnMonth -= 1;
  var vnMaxDay = 30;
  if (vnMonth == 0 || vnMonth == 2 || vnMonth == 4 || vnMonth == 6 || vnMonth == 7 || vnMonth == 9 || vnMonth == 11) {
    vnMaxDay = 31;
  }
  if (vnMonth == 1) {
    if (vnYear % 4 == 0 && (vnYear % 400 == 0 || vnYear % 100 != 0)) {
      vnMaxDay = 29;
    } else {
      vnMaxDay = 28;
    }
  }
  return vnMaxDay;
};

/**
 * 기준날짜를 지난 달로 이동합니다.
 */
eXria.controls.xhtml.Calendar.prototype.toLastMonth = function(){
  this.monthChange(-1);
};

/**
 * 기준날짜를 다음 달로 이동합니다.
 */
eXria.controls.xhtml.Calendar.prototype.toNextMonth = function(){
  this.monthChange(1);
};

/**
 * 기준날짜를 지난 해로 이동합니다.
 */
eXria.controls.xhtml.Calendar.prototype.toLastYear = function(){
  this.yearSelect(this.year - 1);
};

/**
 * 기준날짜를 다음 해로 이동합니다.
 */
eXria.controls.xhtml.Calendar.prototype.toNextYear = function(){
  this.yearSelect(this.year + 1);
};

/**
 * 원하는 일자로 달력을 이동시킵니다.
 * @param {Number} pnYear 기준년도
 * @param {Number} pnMonth 기준월
 * @param {Number} pnMonth 기준일
 */
eXria.controls.xhtml.Calendar.prototype.move = function(pnYear, pnMonth, pnDay){
  this.year = pnYear;
  this.month = pnMonth;
  this.dayNum = pnDay;
  this.update();
};

/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @private
 */
eXria.controls.xhtml.Calendar.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Calendar[psAttrName];
  if (vsDefaultValue === undefined) {
    return null;
  }
  return vsDefaultValue;
};

/**
 * 클래스 명을 반환합니다.
 * @return "Calendar"
 * @type String
 */
eXria.controls.xhtml.Calendar.prototype.toString = function(){
  return "Calendar";
};
// 사용자 메소드 리스트 END
/////////////////////////////////////////////


/////////////////////////////////////////////
// 달력처리 내부 메소드 리스트 START
/**
 * SPEC 정보를 로딩
 * @return undefined
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.loadDefaultSpce = function(){
  this.loadLocale();
  this.calendarLocale();
  this.calendarDefaultCSS();
  this.loadCSS(this.CSS);
};

/**
 * Default.xml 로드
 * @return undefined
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.calendarDefaultCSS = function(){
  //Defaults.XML을 읽어 온다.
    
  if (!this.defaultFileName) this.defaultFileName = page.metadata.resourceBaseUrl + 'eXria/config/gridex/Defaults.xml';
    
  var vaFilePath = this.defaultFileName;
    
  if (this.defaultFileName !== 'eXria/config/gridex/Defaults.xml') {
    var vaXMLObj = eXria.controls.xhtml.Util.loadXML(vaFilePath);
    if (vaXMLObj.success) {
			try{
        var vsStyle = vaXMLObj.xmlDox.getElementsByTagName("Cfg")[0].getAttribute("Style");
        vsStyle = {
            "Borders": "GB",
            "Light": "GL",
            "Modern": "GM",
            "Office": "GO",
            "Plain": "GP",
            "Robust": "GR",
            "Standard": "GS"
        }[vsStyle];
        this.CSS = vsStyle;
        eXria.controls.xhtml.Calendar.CSSStyle = this.CSS;
			}catch(e){
				//load 실패시 default 파일 로드							
				var vaXMLObj = eXria.controls.xhtml.Util.loadXML(page.metadata.resourceBaseUrl + 'eXria/config/gridex/Defaults.xml');
        var vsStyle = vaXMLObj.xmlDox.getElementsByTagName("Cfg")[0].getAttribute("Style");
        vsStyle = {
            "Borders": "GB",
            "Light": "GL",
            "Modern": "GM",
            "Office": "GO",
            "Plain": "GP",
            "Robust": "GR",
            "Standard": "GS"
        }[vsStyle];
        this.CSS = vsStyle;
        eXria.controls.xhtml.Calendar.CSSStyle = this.CSS;

			}
		}
  } else {
    this.CSS = eXria.controls.xhtml.Calendar.CSSStyle;
  }
    
};

/**
 * Text.xml 로드
 * @return undefined
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.calendarLocale = function(){
  if (!this.textFileName) this.textFileName = page.metadata.resourceBaseUrl +'eXria/config/gridex/Text.xml';
    
  //Text.XML을 읽어 온다.
  var vaFilePath = this.textFileName;
    
  if (!eXria.controls.xhtml.Calendar.CGLang["kor"]['month']) {
    var vaXMLObj = eXria.controls.xhtml.Util.loadXML(vaFilePath);
    if (vaXMLObj.success) {
			try {
        //vaXMLObj.xmlDox.document.getElementsByTagName("Format")[0].getAttribute("LongMonthNames_"+this.locale); //"January,February,March									
        var vaLangArr = ["kor", "eng", "jpn", "chn"];
        
        for (var i = 0; i < vaLangArr.length; i++) {
          var vsDayCharNames = vaXMLObj.xmlDox.getElementsByTagName("Format")[0].getAttribute("Day2CharNames_" + vaLangArr[i]);
          var vsMonthNames = vaXMLObj.xmlDox.getElementsByTagName("Format")[0].getAttribute("ShortMonthNames_" + vaLangArr[i]);
          vsDayCharNames = vsDayCharNames.split(',');
          vsMonthNames = vsMonthNames.split(',');
          eXria.controls.xhtml.Calendar.CGLang[vaLangArr[i]]['month'] = vsMonthNames;
          eXria.controls.xhtml.Calendar.CGLang[vaLangArr[i]]['day'] = vsDayCharNames;
        }
				
			} catch(e) {
        //load 실패시 default 파일 로드
				var vaLangArr = ["kor", "eng", "jpn", "chn"];
        var vaXMLObj = eXria.controls.xhtml.Util.loadXML(page.metadata.resourceBaseUrl + 'eXria/config/gridex/Text.xml');
				
        for (var i = 0; i < vaLangArr.length; i++) {
          var vsDayCharNames = vaXMLObj.xmlDox.getElementsByTagName("Format")[0].getAttribute("Day2CharNames");
          var vsMonthNames = vaXMLObj.xmlDox.getElementsByTagName("Format")[0].getAttribute("ShortMonthNames");
          vsDayCharNames = vsDayCharNames.split(',');
          vsMonthNames = vsMonthNames.split(',');
          eXria.controls.xhtml.Calendar.CGLang[vaLangArr[i]]['month'] = vsMonthNames;
          eXria.controls.xhtml.Calendar.CGLang[vaLangArr[i]]['day'] = vsDayCharNames;
        }
			}
			
    }
  }
};

/**
 * locale 정보를 동적으로 로드한다.
 * @return undefined
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.loadLocale = function(){
//  var vsLocale = "kor";
//  if (this.locale == null) {
    var vsLocale = eXria.controls.xhtml.Util.getDefaultLocale();
//  }
    
  this.locale = vsLocale;
};

/**
 * css를 동적으로 로드한다.
 * @param (String) css명
 * @return undefined
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.loadCSS = function(psCss){
  if (!psCss) psCss = 'GL';
  
  this.CSS = psCss;
  
  var vaFilePath = page.metadata.resourceBaseUrl + 'eXria/config/gridex/';
  vaFilePath = vaFilePath +
  {
      "GS": "Standard/Grid.css",
      "GM": "Modern/Grid.css",
      "GO": "Office/Grid.css",
      "GL": "Light/Grid.css",
      "GB": "Borders/Grid.css",
      "GR": "Robust/Grid.css",
      "GP": "Plain/Grid.css"
  }[psCss]
  
  //여러번 Calendal가 여러개 있을경우 CSS의 반복호출을 막기 위해 사용
  if (vaFilePath && !this.loadedStyles[psCss]) {
    var voRtnVal = eXria.controls.xhtml.Util.loadCSSFile(vaFilePath);
    if (voRtnVal) this.loadedStyles[psCss] = vaFilePath;
  }
}

/**
 * 넘어온 인자의 양끝에 ' 문자를 찍어서 반환하는 메소드
 * @param {String} 양끝에 ' 찍혀서 반환될 문자열
 * @return 양끝에 ' 찍혀서 반환된 문자열
 * @type String
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.getPreString = function(psName){
  return "'" + psName + "'";
};

/**
 * 이벤트 핸들러를 정의하는 문자열을 반환하는 메소드
 * @param {String} psFuncName 이벤트 핸들러 내부에서 호출되는 working 메소드 명
 * @return 이벤트 핸들러를 정의하는 문자열
 * @type String
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.getEHandler = function(psFuncName){
  var vaStrBuf = [];
  
  vaStrBuf.push("page.getControl('");
  if (this.target) {
    vaStrBuf.push(this.target.id);
    vaStrBuf.push("').calendar.");
  } else {
    vaStrBuf.push(this.id);
    vaStrBuf.push("').");
  }
  var vsStrCommon = vaStrBuf.join("");
  vaStrBuf.push("eventStopPropagation(event); ");
  vaStrBuf.push(vsStrCommon);
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("(");
  
  for (var i = 1; i < arguments.length; i++) {
      if (i == 1) vaStrBuf.push(arguments[i]);
      else vaStrBuf.push("," + arguments[i]);
  }
  vaStrBuf.push(");");
  
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};

eXria.controls.xhtml.Calendar.prototype._showTimesInfo = function(psTime){
  var voDocument = this.document;
  var voDomFoot = voDocument.getElementById(this.id + '_tfoot'),voINPUT,voTR,voTD;
  var that = this;

  voINPUT = document.createElement('input');
  voINPUT.id = this.id + '_tfoot_ipb'
  voINPUT.type = 'text';
  voINPUT.setAttribute('style','border: 0px;padding:0px; font:12px Verdana,Arial;text-align:right;');
  voINPUT.value = psTime;
  voINPUT.onkeydown = function(e){
    that._hhmmss = voINPUT;
    var voEvent = e || window.event;
    if(voEvent.keyCode === 13) {
      var dayNum = (10 > that.dayNum) ? '0' + that.dayNum : that.dayNum;
      var month =  (10 > that.month) ? '0' + that.month : that.month;
      var selectDate = that.year + "" + month + "" + dayNum;
      
      that.daySelect(that.dayNum, that.dayNum, selectDate);
    }
  }
  
  voTR = document.createElement('tr');
  voTR.className = this.CSS + 'PickTimeCell';
  voTR.setAttribute('style', 'height: 20px; padding: 5px;');
  
  voTD = document.createElement('td');
  voTR.appendChild(voTD);
  
  voTD = document.createElement('td');
  voTD.colSpan = '7'
  voTD.appendChild(voINPUT);
  voTR.appendChild(voTD);
  
  voTD = document.createElement('td');                
  voTR.appendChild(voTD);  
  
  voDomFoot.appendChild(voTR);
}

/**
 * 달력그리기
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.getHTML = function(){
  this.template = [];
  var vaTemplate = this.template;
  var p = 0, CNBSP = "&#160;", vsLocale = this.locale;
  var monthYear = eXria.controls.xhtml.Calendar.CGLang[vsLocale]["month"][this.month - 1] + CNBSP + this.year + CNBSP;
  var re = /[^0-9]/gi;
  
  vaTemplate[p++] = "<table cellspacing='0' cellpadding='0' class='" + this.CSS + "PickBorder'><tfoot id='"+this.id+'_tfoot'+"'>";
  // --- month and year ---
  vaTemplate[p++] = "<tr><td></td><td colspan='7'></td><td></td></tr>";
  vaTemplate[p++] = "<tr class='" + this.CSS + "PickDate'><td></td>";
  vaTemplate[p++] = "<td colspan='7' class='" + this.CSS + "PickMY'>";
  
  vaTemplate[p++] = "<div class='" + this.CSS + "PickBL " + this.CSS + "PickBLIE7' onclick=\"" + this.getEHandler('monthChange', -1) +
    "\"><center>" +
    "</center></div>";
  
  vaTemplate[p++] = "<div class='" + this.CSS + "PickBR " + this.CSS + "PickBRIE7' onclick=\"" + this.getEHandler('monthChange', 1) + "\"><center>" +
    "</center></div>";
  
  vaTemplate[p++] = "<center><table cellspacing='0' cellpadding='0'><tfoot><tr style='cursor:pointer;' onclick=\"" + this.getEHandler('downSel') + "\">" +
    "<td class='" +
    this.CSS +
    "PickMY " +
    this.CSS +
    "PickMYDown' dir='ltr'>" +
    monthYear +
    "</td>" +
    "<td><center>" +
    "</center></td></tr></tfoot></table></center></td>";
  vaTemplate[p++] = "<td></td></tr>";
  
  // --- day names ---
  vaTemplate[p++] = "<tr class='" + this.CSS + "PickRowW'><td></td>";
  for (var i = 0; i < 7; i++) {
    vaTemplate[p++] = "<td class='" + this.CSS + "PickCell'><div class='" + this.CSS + "PickWDN'>" +
    eXria.controls.xhtml.Calendar.CGLang[vsLocale]["day"][i] +
    "</div></td>";
  }
  vaTemplate[p++] = "<td></td></tr>";
  
  // --- days Num---
  //GLPickOM - 공백날자
  //GLPickWD - 일반
  //GLPickSa - 토요일
  //GLPickSu - 일요일
  //GLPickSel- 선택된 날자
  //GLPickNow- 지금날자
  
  var m1 = new Date(this.year, this.month - 1, 0);
  
  m1 = m1.getDate(); //m1 저번달 마지막일
  var m2 = new Date(this.year, this.month, 0);
  m2 = m2.getDate(); //m2 이번달 마지막일
  var d1 = new Date(this.year, this.month - 1, 1);
  d1 = d1.getDay(); //이번달 시작요일(월화수 등)
  if (d1 < 0) d1 += 7;
  var d = 1 - d1; // 이번달 시작요일의 전일(월화수등)
  var sun = 0;
  var sat = 6;
  
  for (var r = 0; r < 6; r++) {
    vaTemplate[p++] = "<tr class='" + this.CSS + "PickRow'><td></td>";
    for (var c = 0; c < 7; c++) {
      var cls = "" + this.CSS + "PickWD";
      if (c == sun) cls = "" + this.CSS + "PickSu";
      else if (c == sat) cls = "" + this.CSS + "PickSa";
      var ds = d;
      
      if (d <= 0) {		// 저번달일 경우
        ds = d + m1;
        cls = "" + this.CSS + "PickOM";
      } else if (d > m2) {	// 다음달일 경우
        ds = d - m2;
        cls = "" + this.CSS + "PickOM";
      }

      // 저번달 또는 다음달 영역에 있는 날짜를 선택했을 경우의 처리 추가 
			var selectMonth = this.month;
			var selectYear = this.year;
			if(d<=0) {
				selectMonth = selectMonth - 1;
		    if(selectMonth < 1) {
		      selectYear--;
		      selectMonth = 12;
		    }							
			}
			if(d>m2) {
				selectMonth = selectMonth + 1;
		    if(selectMonth > 12) {
		      selectYear++;
		      selectMonth = 1;
		    }									
			}
			
      var selectDate = selectYear + "" +
        ((selectMonth < 10) ? "0" + selectMonth : selectMonth) +
        "" +
        ((ds < 10) ? "0" + ds : ds);	
      
      //오늘 날자
      var nowDate = this.NOWYEAR + "" +
        ((this.NOWMONTH < 10) ? "0" + this.NOWMONTH : this.NOWMONTH) +
        "" +
        ((this.NOWDAYNUM < 10) ? "0" + this.NOWDAYNUM : this.NOWDAYNUM);
      
      cls = ((selectDate.replace(re, "") == nowDate) &&
        !(d <= 0) &&
        !(d > m2)) ? "" + this.CSS + "PickNow" : cls;
      
      //선택된 날자	            
      if (!!this.target && !!this.target.ctrl.firstChild.value) {
        cls = ((this.target.ctrl.firstChild.value.replace(re, "").substring(0,8) == selectDate.replace(re, "")) &&
            !(d <= 0) &&
            !(d > m2)) ? "" + this.CSS + "PickSel" : cls;
      } else {
        //target 없이 Calendar 가 단독으로 사용되는 경우 
        //2010.05.14
        //Calendar가 단독으로 작동하는경우 선택날짜가 있으면          
        //this.date가 8자리(yyyymmdd)형태로 넘어옴
        cls = ((this.date == selectDate.replace(re, "")) &&
            !(d <= 0) &&
            !(d > m2)) ? "" + this.CSS + "PickSel" : cls;
      }
      
      vaTemplate[p++] = "<td class='" + this.CSS + "PickCell'><div class='" +
        cls +
        "'" +
        "onmouseover='this.className=\"" +
        this.CSS +
        "PickHover\";'" +
        "onmouseout='this.className=\"" +
        cls +
        "\";'" +
        "onclick=\"" +
        this.getEHandler('daySelect', d, ds, this.getPreString(selectDate)) +
        "\">" +
        ds +
        "</div></td>";
      
      d++;
    }
    vaTemplate[p++] = "<td></td></tr>";
  }
  
  vaTemplate[p++] = "</tfoot></table>";
};

/**
 * 달력닫기
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.close = function(){
  this.hide();
};

/**
 * 일자선택
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.daySelect = function(postionNum, selectDay, selectDate){
  if (selectDay) {
    if (!!this.target) {	//Calnedar가 다른 컨트롤에서 사용되는 경우
      var voMaxDate = this.target.max;
      var voMinDate = this.target.min;						
      var re = /[^0-9]/gi;
  
      if(!!voMaxDate){
        voMaxDate = voMaxDate.replace(re, "");
        voMinDate = voMinDate.replace(re, "");			
      }			
  			
      if(!!voMaxDate && voMaxDate.length >= 8){ 							
        voMaxdate = (voMaxDate).substring(0,8);
        selectDate = (selectDate >= voMaxdate) ? 
            voMaxdate : selectDate;																									    											
      }
  			
      if(!!voMinDate && voMinDate.length >= 8){
        voMindate = (voMinDate).substring(0,8);
        selectDate = (selectDate >= voMindate) ? 
            selectDate : voMindate;																	    						
      }
      
      if(this.target.mask.length > 14){
        if(!this._hhmmss){
          var temp = this.target.value;
          var vnHours = temp.substring(8, 10);
          if(vnHours == "") vnHours = "0";
          vnHours = parseInt(vnHours);
          var vnMinutes = temp.substring(10, 12);
          if(vnMinutes == "") vnMinutes = "0";
          vnMinutes = parseInt(vnMinutes);
          var vnSeconds = temp.substring(12, 14);
          if(vnSeconds == "") vnSeconds = "0";
          vnSeconds = parseInt(vnSeconds);
          
          selectDate = (10 > vnHours) ? selectDate + '0' + vnHours : selectDate + vnHours;
          selectDate = (10 > vnMinutes) ? selectDate + '0' + vnMinutes : selectDate + vnMinutes;
          selectDate = (10 > vnSeconds) ? selectDate + '0' + vnSeconds : selectDate + vnSeconds;
        }else{
          this._hhmmss = this._hhmmss.value.replace(/[^0-9]/gi, "");
          selectDate = selectDate + this._hhmmss;
        }        
      }    
      this.target.setValueWithNotify(selectDate);
      delete this['_hhmmss'];
      
      this.close();
              
    } else {  //Calnedar 가 단독으로 사용되는 경우
      this.setDate(selectDate);
      this.show(this.parent);
    }
  }
};

/**
 * 월(month 네비게이션) 변경
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.monthChange = function(monthNum){
  this.calType = 'default';
  this.month += monthNum
  if (this.month < 1) {
    this.year--;
    this.month = 12;
  }
  if (this.month > 12) {
    this.year++;
    this.month = 1;
  }
  this.update();
    
};

/**
 * 변경된 달력 그리기
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.update = function(pbYear){
  this.close();
  this.visible = true;

  //target 과 parent를 구분
  //Calendar 는 target 의 parent에 appendChild 되야 한다. 
  var voTarget = this.target; //(!!this.parent)? this.parent : (!!this.target) ?this.target.parent : null;
  var voCanvas = null;
  if (voTarget) voCanvas = voTarget.parent; //(!!voTarget.parent)?voTarget.parent : voTarget;
  if (voCanvas == null) {
  
    //Tab 컨트롤에 Calendar 가 추가될 경우 parent는 존재하는데 target이 없어서
    //로직상 문제가 있어서 아래 코드를 추가        
    if(!!this.parent)
      voCanvas = this.parent;
    else
      voCanvas = this.canvas;
        
  }

  if (voCanvas) {
    if(!!voTarget && 'EditMask' === voTarget.toString()) voCanvas = this.canvas;
    var voCanvasCtrl = voCanvas.getCtrl();
    voCalendarCtrl = this.create();

    if(!!voTarget && -1 !== 'EditMaskDateInput'.indexOf(voTarget.toString())){

      if(voTarget.parent && voTarget.parent.ctrl){
       voTarget.parent.ctrl.oriZindex = voTarget.parent.ctrl.style.zIndex; 
       voTarget.parent.ctrl.style.zIndex = 50000;             
      }  
    }
  
    voCanvasCtrl.appendChild(voCalendarCtrl);
    this.load();
    
    if(!!voTarget && -1 !== 'EditMaskDateInput'.indexOf(voTarget.toString())){
       voTarget.calendarShowed = true;
       voCanvas.collapseControl = voTarget;
       var voCtrl = this.ctrl;
       voTarget.setAttrCtrl("zIndex", 50000, voCtrl);
       var voParent = this.parent;
       while(voParent) {
         if(voParent.ctrl) voTarget.setAttrCtrl("zIndex", 50000, voParent.ctrl);
         voParent = voParent.parent;
       }
       voTarget.lifted = true;
     }
     
  }
};



/**
 * 다중(년도 월 동시)변경 달력 그리기
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.getMultiSelectHTML = function(pbKeepMultiSelect){
  this.template = [];
  var vaTemplate = this.template;
  var p = 0, CNBSP = "&#160;", vsLocale = this.locale;
  var monthYear = eXria.controls.xhtml.Calendar.CGLang[vsLocale]["month"][this.month - 1] + CNBSP + this.year + CNBSP;
  var re = /[^0-9]/gi;
  
  vaTemplate[p++] = "<table cellspacing='0' cellpadding='0' class='" + this.CSS + "PickBorder'><tfoot>";
  
  // --- month and year ---
  vaTemplate[p++] = "<tr><td></td><td colspan='7'></td><td></td></tr>";
  vaTemplate[p++] = "<tr class='" + this.CSS + "PickDate'><td></td>";
  //vaTemplate[p++] = "<td colspan='7' >";
  vaTemplate[p++] = "<td colspan='7' class='" + this.CSS + "PickMY'>";
  
  vaTemplate[p++] = "<div class='" + this.CSS + "PickBL " + this.CSS + "PickBLIE7' onclick=\"" + this.getEHandler('monthChange', -1) + "\"></div>";
  
  vaTemplate[p++] = "<div class='" + this.CSS + "PickBR " + this.CSS + "PickBRIE7' onclick=\"" + this.getEHandler('monthChange', 1) + "\"></div>";
  
  if(true === pbKeepMultiSelect){
    vaTemplate[p++] = "<center><table cellspacing='0' cellpadding='0'><tfoot><tr style='cursor:pointer;' onclick=\"" + this.getEHandler('upSel') + "\">" +
      "<td dir='ltr'>" +
      monthYear +
      "</td>" +
      "<td><center>" +
      "</center></td></tr></tfoot></table></center></td>";
  }else{
    vaTemplate[p++] = "<center><table cellspacing='0' cellpadding='0'><tfoot><tr style='cursor:pointer;' onclick=\"" + this.getEHandler('upSel') + "\">" +
      "<td class='" +
      this.CSS +
      "PickMY " +
      this.CSS +
      "PickMYUp' dir='ltr'>" +
      monthYear +
      "</td>" +
      "<td><center>" +
      "</center></td></tr></tfoot></table></center></td>";    
  }  
    
    
  vaTemplate[p++] = "<td></td></tr>";
  
  // --- month and year select ---
  if (!this.record) this["FY"] = Math.floor(this.year / 5) * 5;
  var fy = this["FY"];
  
  for (var i = 0; i < 6; i++) {
    vaTemplate[p++] = "<tr class='" + this.CSS + "Pick2Row'><td></td>";
    for (var j = 0; j <= 6; j += 6) {
        vaTemplate[p++] = "<td class='" + this.CSS + "Pick2Cell'>" +
          "<div class='" +
          this.CSS +
          "Pick2M" +
          ((i + j + 1) == this.month ? "Sel" : "") +
          "'" +
          "onmouseover='this.className=\"" +
          this.CSS +
          "Pick2M" +
          ((i + j + 1) == this.month ? "Sel" : "") +
          "Hover\";'" +
          "onmouseout='this.className=\"" +
          this.CSS +
          "Pick2M" +
          ((i + j + 1) == this.month ? "Sel" : "") +
          "\";'" +
          "onclick=\"" +
          this.getEHandler('monthSelect', (i + j + 1)) +
          "\">" +
          eXria.controls.xhtml.Calendar.CGLang[vsLocale]["month"][i + j] +
          "</div></td>";
    }
      
    vaTemplate[p++] = "<td><div class='" + this.CSS + "Pick2Sep'>" + CNBSP + "</div></td>";
      
    if (!i) {
      vaTemplate[p++] = "<td class='" + this.CSS + "Pick2BL' onclick=\"" + this.getEHandler('yearChange', -5) + "\">" +
        "</td>" +
        "<td class='" +
        this.CSS +
        "Pick2BR' onclick=\"" +
        this.getEHandler('yearChange', 5) +
        "\">" +
        "</td>";
    } else {
        for (var j = -1; j <= 4; j += 5) {
          vaTemplate[p++] = "<td class='" + this.CSS + "Pick2Cell'>" +
            "<div class='" +
            this.CSS +
            "Pick2Y" +
            ((fy + i + j) == this.year ? "Sel" : "") +
            "'" +
            "onmouseover='this.className=\"" +
            this.CSS +
            "Pick2Y" +
            ((fy + i + j) == this.year ? "Sel" : "") +
            "Hover\";'" +
            "onmouseout='this.className=\"" +
            this.CSS +
            "Pick2Y" +
            ((fy + i + j) == this.year ? "Sel" : "") +
            "\";'" +
            "onclick=\"" +
            this.getEHandler('yearSelect', (fy + i + j)) +
            "\">" +
            (fy + i + j) +
            "</div></td>";
        }
    }
      
    vaTemplate[p++] = "<td></td></tr>";
  };
  
  vaTemplate[p++] = "<tr class='" + this.CSS + "PickFooter'><td></td>";
  vaTemplate[p++] = "<td class='" + this.CSS + "PickFootText' colspan='5' align='right'>";
  vaTemplate[p++] = "<button class='" + this.CSS + "PickButton' ";
  
  
  if(true === pbKeepMultiSelect){
    var vsTempDate = this.year + '' + ((this.month <10)? '0'+this.month : this.month) + '01'
    vaTemplate[p++] = "onclick=\"" + this.getEHandler('daySelect', true, true, this.getPreString(vsTempDate))  + "\">";  
  }else{
    vaTemplate[p++] = "onclick=\"" + this.getEHandler('calSelect') + "\">";
  }
  
  vaTemplate[p++] = "OK</button>"
  vaTemplate[p++] = "</td><td></td></tr>"
  vaTemplate[p++] = "</tfoot></table>";
};

/**
 * 년도(년도네비게이션) 변경
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.yearChange = function(yer){
  if (!!yer) {
    this.calType = 'multi';
    this.record = 1;
    this.FY = this.FY + yer;
    this.update(true);
  }
    
}

/**
 * 년도(Year) 선택
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.yearSelect = function(yer){
  if (!!yer) {
    this.record = 1;
    this.year = yer;
    this.update(true);
  }
};

/**
 * 월(Month) 선택
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.monthSelect = function(mon){
  if (!!mon) {
    this.record = 1;
    this.month = mon;
    this.update();
  }
};

/**
 * ok 버튼 클릭
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.calSelect = function(){
  this.calType = 'default';
  this.update();
  var voTarget = this.target;
  if(voTarget.mask.length > 14 && !voTarget.noUseHMS) {
    var vnTmp = voTarget.getDate(voTarget.value).getTime();
    eXria.controls.xhtml.Calendar.prototype._showTimesInfo.call(this, TGP.GetString(vnTmp, voTarget.formatType, 'HH:mm:ss'));
  }
};

/**
 * ▼ 버튼 클릭
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.downSel = function(){
  this.calType = 'multi';
  this.record = 0;
  this.update(true);
};

/**
 * ▲ 버튼 클릭
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.upSel = function(){
  this.calType = 'default';
  this.update(true);
};

/**
 * 이벤트 전파 방지
 * @ignore
 */
eXria.controls.xhtml.Calendar.prototype.eventStopPropagation = function(e){
  if (!!this.target) {
    var voEvent = new eXria.event.Event(e, this.window);
    voEvent.stopPropagation();
  }
}

// 달력처리 내부 메소드 리스트 END
////////////////////////////////////////////
