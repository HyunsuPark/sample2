/**
 * @fileoverview
 * Concreate Shape Roundrect(XHTML Roundrect 컨트롤)
 * @author 이종녕
 */

/**
 * @class xhtml Roundrect Control.<br>
 * 모서리가 둥근 사각형 도형을 표현하는 컨트롤.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Roundrect 객체
 * @type eXria.controls.xhtml.Roundrect
 * @constructor
 * @base eXria.controls.xhtml.ShapeControl
 */ 
eXria.controls.xhtml.Roundrect = function(psId, pnLeft, pnTop, pnWidth, pnHeight){

	/**
	 * pnLeft 컨트롤 좌상단 점의 x좌표.
	 * @type Number
	 */
  pnLeft =  pnLeft == null ? 20 : pnLeft;
  /**
   * pnTop 컨트롤 좌상단 점의 y좌표.
   * @type Number
   */
  pnTop =  pnTop == null ? 20 : pnTop;
  /**
   * pnWidth 컨트롤의 가로 길이.
   * @type Number
   */
  pnWidth =  pnWidth == null ? 100 : pnWidth;
  /**
   * pnHeight 컨트롤의 세로 길이.
   * @type Number
   */
  pnHeight =  pnHeight == null ? 100 : pnHeight;

  eXria.controls.xhtml.ShapeControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /////////////////////////////////////////////////////////////////////////////
  ////속성 
  /**
   * 도형 채움 색상의 글라데이션 시작 값.
   * @type String
   */
  this.fillStartColor = null;
  /**
   * 도형 채움 색상의 글라데이션 마무리 값.
   * @type String
   */
  this.fillEndColor = null;
  /**
   * 도형 색상 채움 타입.<br>
   * "none" | "solid" | "gradient" | "gradientradial"  (default:solid)
   * @type String
   */
  this.fillType = null;
  /**
   * 글라데이션 진행 각도.
   * @type Number
   */
  this.fillAngle = null;
  /**
   * 색상 채움 불투명도.
   * @type Number
   */
  this.fillOpacity = null;
  /**
   * 사각형 모서리 곡률.
   * @type Number
   */
  this.round = null;
  /**
   * 컨트롤의 디폴트 속성값을 저장하기 위한 오브젝트
   * @type Object
   * @private
   */
  this.df = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.ShapeControl, eXria.controls.xhtml.Roundrect);
//////////////////////////////////////////////////////////////////   
//// 메소드 
/**
 * 실체화 컨트롤 생성.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 실체화 객체의 최외곽 div
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.createCtrl = function(poDocument){
  var voDiv = poDocument.createElement("div");
  var voStyle = voDiv.style;
  voDiv.setAttribute("id",this.id);
  voStyle.padding = "0px";
  voStyle.margin = "0px";
  voStyle.borderStyle = "none";
  voStyle.borderWidth = "0px";
  this.ctrl = voDiv;
  return voDiv;
};
/**
 * 지정된 각도를 -90 ~ 90도 사이에 값으로 변환하는 메소드.
 * @param {Number} pnAngle 지정한 각도
 * @return 변경된 각도
 * @type Number
 */
eXria.controls.xhtml.Roundrect.prototype.quartAngle = function(pnAngle) {
  var vnNumber = pnAngle%180;
  if( vnNumber > 90) vnNumber = 180 - vnNumber;
  return vnNumber;
};
/**
  * 도형이 회전했을 때 회전된 div영역을 포함하는 사각형 영역의 세로 길이의 1/2 반환.
  * @param {Number} pnWidth 컨트롤의 가로 길이
  * @param {Number} pnHeight 컨트롤의 세로 길이
  * @return 도형이 회전했을 때 회전된 div영역을 포함하는 사각형 영역의 세로 길이의 1/2
  * @type Number
  */
eXria.controls.xhtml.Roundrect.prototype.angleHeight = function(pnWidth,pnHeight) {
  /*var vnR = Math.pow(pnWidth,2) + Math.pow(pnHeight,2);
  vnR = (Math.sqrt(vnR)/2);
  var vnAngle = Math.asin(this.height/2/vnR)*180/Math.PI;
  var vnL = Math.sin(Math.PI/180*(vnAngle+this.quartAngle(this.angle)));
  vnR = vnR*vnL;
  return Math.round(vnR);*/
  var vnAngle = this.angle % 90;
  var vnR1 = pnWidth * Math.sin(vnAngle * Math.PI / 180); 
  var vnR2 = pnHeight * Math.cos(vnAngle * Math.PI / 180);
  var vnR = (vnR1 + vnR2)/2;
  return vnR;
};
/**
  * 도형이 회전했을 때 회전된 div영역을 포함하는 사각형 영역의 가로 길이의 1/2 반환.
  * @param {Number} pnWidth 컨트롤의 가로 길이
  * @param {Number} pnHeight 컨트롤의 세로 길이
  * @return 도형이 회전했을 때 회전된 div영역을 포함하는 사각형 영역의 가로 길이의 1/2
  * @type Number
  */
eXria.controls.xhtml.Roundrect.prototype.angleWidth = function(pnWidth,pnHeight) {
  /*var vnR = Math.pow(pnWidth,2) + Math.pow(pnHeight,2);
  vnR = (Math.sqrt(vnR)/2);
  var vnAngle = Math.asin(this.width/2/vnR)*180/Math.PI;
  var vnL = Math.sin(Math.PI/180*(vnAngle+this.quartAngle(this.angle)));
  vnR = vnR*vnL;
  return Math.round(vnR);*/
  var vnAngle = this.angle % 90;
  var vnR1 = pnWidth * Math.cos(vnAngle * Math.PI / 180); 
  var vnR2 = pnHeight * Math.sin(vnAngle * Math.PI / 180);
  var vnR = (vnR1 + vnR2)/2;
  return vnR;
};
/*
 * 지정된 round값을 컨트롤의 크기에 맞는 round값으로 반환
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return vnRound
 * @type Number
 */
eXria.controls.xhtml.Roundrect.prototype.getRound = function(pnWidth, pnHeight){
  var vnL = pnHeight;
  if(pnWidth < pnHeight) vnL = pnWidth;
  var vnRound = this.df.round / vnL * 2;
  return vnRound;
};
/**
 * 도형 객체 생성.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.createRoundrectCtrl = function(poCtrl,poDocument){
  var voWindow = this.window;
  poCtrl.style.top = this.top ;
  poCtrl.style.left = this.left;
  var vnDistanceY = this.angleHeight(this.width,this.height); 
  var vnDistanceX = this.angleWidth(this.width,this.height);
  var vnHeight = (vnDistanceY - this.height/2);  
  var vnWidth = (vnDistanceX - this.width/2);
  gCore.init(voWindow); // 초기화.....
  var pane = new voWindow.Pane(this.id+"_draw",-vnWidth,-vnHeight,vnDistanceX*2,vnDistanceY*2,poDocument);
  var border = this.df.penWeight/2;
  //var voRound = this.toPercent(this.df.round);
  var voRound = this.getRound(this.width,this.height);
  /*if(this.angle != 0) var voCtrl = new RoundRect(this.id+"roundrect",border+vnWidth, border+vnHeight, this.width-(border*2), this.height-(border*2),voRound);
  else var voCtrl = new RoundRect(this.id+"roundrect", 0, 0, this.width, this.height,voRound); */
  var vnCtrlHeight = this.height-this.df.penWeight;
  var vnCtrlWidth = this.width-this.df.penWeight;
  if(gCore.browser.msie && gCore.browser.msie < 9 && border%1 == 0){
    vnCtrlHeight -= 1;
    vnCtrlWidth -= 1;
  }
  var voCtrl = new voWindow.RoundRect(this.id+"_roundrect",border+vnWidth, border+vnHeight, vnCtrlWidth, vnCtrlHeight,voRound);
  var voCtrlStroke = voCtrl.stroke;
  var voCtrlFill = voCtrl.fill;
  var voDf = this.df;
  voCtrlStroke.weight = voDf.penWeight + "px";
  voCtrlStroke.color = voDf.penColor;
  voCtrlStroke.type = this.toConstPenstyle(voDf.penStyle);
  voCtrlStroke.opacity = this.toPercent(voDf.penOpacity);
  if(voDf.penColor == "transparent") voCtrlStroke.opacity = 0;
  voCtrlStroke.lineCap = this.toConstPencap(voDf.penCap);
  voCtrlStroke.joinType = this.toConstJointype(voDf.joinType); 
  voCtrlFill.color = voDf.fillStartColor;
  voCtrlFill.color2 = voDf.fillEndColor;
  voCtrlFill.type = voDf.fillType;
  voCtrlFill.angle = voDf.fillAngle;
  voCtrlFill.opacity = this.toPercent(voDf.fillOpacity); 
  voCtrl.angle = voDf.angle;
  voCtrl.cursor = voDf.cursor;
  pane.addShape(voCtrl);
  pane.draw(poCtrl);
}; 

/**
 * setSpecificDefaults.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.setSpecificDefaults = function(poCtrl,poDocument) {
  var voDf = this.df;
  voDf.round = this.getAttrValue("round",this.round);
  voDf.fillStartColor = this.getAttrValue("fillStartColor",this.fillStartColor);
  voDf.fillEndColor = this.getAttrValue("fillEndColor", this.fillEndColor);
  voDf.fillType = this.getAttrValue("fillType",this.fillType);
  voDf.fillAngle = this.getAttrValue("fillAngle",this.fillAngle);
  voDf.fillOpacity = this.getAttrValue("fillOpacity",this.fillOpacity);
};
/**
 * setSpecificAttrs.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document 
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.setSpecificAttrs = function(poCtrl,poDocument) {
  this.createRoundrectCtrl(poCtrl,poDocument);
};
/**
 * setAttrSubCtrl.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;
};
/**
 * setSpecificEvents.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.setSpecificEvents = function(poCtrl,poDocument) {
};
/**
 * removeSpecificDefaults.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.removeSpecificDefaults = function(poCtrl,poDocument) {
  this.df = {};
};
/** 
 * refreshSpecificAttrs.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.refreshSpecificAttrs = function(poCtrl,poDocument){
  var voDiv = this.getCtrl(poDocument);
  var voPaneCtrl = voDiv.childNodes[0];
  voDiv.removeChild(voPaneCtrl);
  this.setSpecificAttrs(poCtrl, poDocument);
};
/**
 * applyAttrRefresh.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Roundrect.prototype.applyAttrRefresh = function(psAttrName, psAttrValue, poDocument) {
  this.setAttr(psAttrName, psAttrValue);
//  this.setAttrCtrl(psAttrName, psAttrValue);
//  var voDiv = this.getCtrl(poDocument);
//  var voPaneCtrl = voDiv.childNodes[0];
//  voDiv.removeChild(voPaneCtrl);
//  this.createRoundrectCtrl(voDiv,poDocument);
  this.refresh(poDocument);
};   
/**
* 서브 컨트롤 실체화 객체를 얻어온다.
* @param {String} psTagName
* @return (Object) subControl
* @private
*/
eXria.controls.xhtml.Roundrect.prototype.getSubCtrl = function(psTagName,poCtrl,poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  var subCtrl = poCtrl.getElementsByTagName(psTagName)[0];
  return subCtrl;
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 */
eXria.controls.xhtml.Roundrect.prototype.getSpecificDefaultValue = function(psAttrName){
  var vsDefaultValue = eXria.controls.xhtml.Default.Roundrect[psAttrName];
  if(vsDefaultValue == null) vsDefaultValue = this.getShapeDefaultValue(psAttrName);
  if( vsDefaultValue === undefined) { 
    //alert(psAttrName + " - Defaul 속성 리스트가 아닙니다.");
    return null;
  }
  return vsDefaultValue;
};
/**
 * 클래스 명을 반환.
 * @return "Roundrect"
 * @type String
 */
eXria.controls.xhtml.Roundrect.prototype.toString = function() {
  return "Roundrect";
};
