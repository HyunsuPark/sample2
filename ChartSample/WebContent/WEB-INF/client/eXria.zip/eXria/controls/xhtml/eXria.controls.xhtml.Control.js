﻿/**
 * @fileoverview
 * Abstract UIControl(Control 컨트롤에 대한 xhtml 기본 클래스)
 * @author 김경태
 */
 
/**
 * @class Concreate xhtml Control.<br>
 * Control 컨트롤에 대한 xhtml 기본 클래스.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Control 객체
 * @type eXria.controls.xhtml.Control
 * @constructor
 * @base eXria.controls.Control
 */ 
eXria.controls.xhtml.Control = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  eXria.controls.Control.call(this, psId);
  this.initGeneral();
}; // End of Control
eXria.controls.xhtml.Util.createInheritance(eXria.controls.Control, eXria.controls.xhtml.Control);
/**
 * 공통 속성을 설정.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @ignore
 */
eXria.controls.xhtml.Control.prototype.setGeneralAttrs = function(poCtrl) {
  poCtrl.setAttribute("lang", this.lang); 
};
/**
 * 공통 이벤트를 설정한다.
 * @ignore
 */
eXria.controls.xhtml.Control.prototype.setGeneralEvents = null;
/**
 * 속성 값을 설정.
 * 그러나 값만 설정할 뿐 해당 속성의 관련된 UI 갱신작업까지 수행하지는 않음.
 * @param {String} psFullName 속성명
 * @param {String} psAttrValue 속성값
 */   
eXria.controls.xhtml.Control.prototype.setAttr = function(psFullName, psAttrValue) {
  var vsAttrName = psFullName.split('.');

  if(vsAttrName.length == 1) {
    if (this[vsAttrName[0]] !== undefined) this[vsAttrName[0]] = psAttrValue;
    else {
      //throw new Error("정의되지 않은 속성 값에 대한 설정입니다.");
    }
  } else if (vsAttrName.length == 2) {
//    if(this[vsAttrName[0]][vsAttrName[1]] !== undefined) {
    this[vsAttrName[0]][vsAttrName[1]] = psAttrValue;
//    } else { 
      //throw new Error("정의되지 않은 속성 값에 대한 설정입니다.");
//    }
  } else if (vsAttrName.length == 3) {
//    if(this[vsAttrName[0]][vsAttrName[1]][vsAttrName[2]] !== undefined) 
    this[vsAttrName[0]][vsAttrName[1]][vsAttrName[2]] = psAttrValue;
  } else if (vsAttrName.length == 4) {
//    if(this[vsAttrName[0]][vsAttrName[1]][vsAttrName[2]][vsAttrName[3]] !== undefined) 
    this[vsAttrName[0]][vsAttrName[1]][vsAttrName[2]][vsAttrName[3]] = psAttrValue;
  } else {
    throw new Error("속성 값 설정에 대한 형식이 잘못 구성되어 있습니다."); 
  }
};
/**
 * 속성 값을 설정하고 바로 적용.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.Control.prototype.applyAttr = function(psAttrName, psAttrValue, poDocument) {
//  try {
//    var voNotify = new eXria.controls.Notify();
//    voNotify.type = eXria.controls.CommonDefine.Notice.APPLY_ATTRIBUTE;
//    voNotify.datas.put(psAttrName, psAttrValue);
//    this.observerHandler.notify(voNotify, poDocument); 
//    delete voNotify;
//    voNotify = null;        
//  } catch(err) {
//    throw new Error("Notify 처리 시에 오류가 발생하였습니다");     
//    return false;  
//  }      
//  return true;
	if(poDocument == null) poDocument = this.document;
    if(this.applyAttrSimple) {
      if(this.applyAttrSimple(psAttrName, psAttrValue, poDocument) == true) return; // 속성 설정으로 끝나는 경우
    }     
    if(this.applyAttrRebuild) {
      this.applyAttrRebuild(psAttrName, psAttrValue, poDocument); // 재계산이 필요한 경우
    } else if(this.applyAttrRefresh) {
      this.applyAttrRefresh(psAttrName, psAttrValue, poDocument); // Refresh가 필요한 경우
    }
};
/**
 * 속성 적용이 속성 설정으로 끝나는 경우의 속성 설정 메소드.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @private
 */
eXria.controls.xhtml.Control.prototype.applyAttrSimple = function(psAttrName, psAttrValue) {
  var voCtrl = this.getCtrl();

  if(psAttrName == "tooltip") {
    this.setAttr(psAttrName, psAttrValue);
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    return true;
  }
  //이미지컨트롤의 커서속성은 이미지컨트롤내에서 처리
  if(psAttrName == "cursor" && this.toString() != "Image") {
    this.setAttr(psAttrName, psAttrValue);
//    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    if(this.setCursor) this.setCursor(voCtrl, psAttrValue);
    return true;
  }    
  return false;  
};
/**
 * 속성 값을 반환.
 * @param {String} psAttrName 속성명
 * @return 속성값
 * @type Unknown
 * @ignore
 */ 
eXria.controls.xhtml.Control.prototype.getAttrValue = function(psAttrName) {
  if(this[psAttrName] != null)
    return this[psAttrName];
  else
    return null;
};
/**
 * 속성을 제거.
 * @param {String} psAttrName 속성명
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 성공여부
 * @type Boolean
 */ 
eXria.controls.xhtml.Control.prototype.removeAttr = function(psAttrName, poDocument) {
  if(this[psAttrName] == undefined) {
    throw new Error("속성이 존재하지 않습니다."); 
    return false;
  }  else {
    try {
      var voNotify = new eXria.controls.Notify();
      voNotify.type = eXria.controls.CommonDefine.Notice.REMOVE_ATTRIBUTE;
      voNotify.datas.put(psAttrName, null);
      this.observerHandler.notify(voNotify, poDocument);
      delete voNotify;
      voNotify = null;
      this[psAttrName] = null;
    } catch(err) {
      throw new Error("Notify 처리 시에 오류가 발생하였습니다");
      return false;
    } finally {
      return true;
    }
  }
};
/**
 * 컨트롤의 정보를 문자열로 반환.
 * @ignore
 */    
eXria.controls.xhtml.Control.prototype.toString = null; 
/**
 * 해당 ID를 갖는 실체화 컨트롤을 반환.
 * @param {String} psId 컨트롤 식별자
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @return 실체화컨트롤
 * @type Object
 */   
eXria.controls.xhtml.Control.prototype.lookup = function(psId, poDocument) {
  if(poDocument == null) poDocument = this.document;
  if(poDocument == null) return null;
  /*var voCtrl = null;
  if(idMap != null) voCtrl = idMap.get(psId);*/
  //var voCtrl = poDocument.getElementById(psId);
  var voRet = null;
  if(this.ctrl) {
    var voCtrl = this.ctrl;
    if(voCtrl["id"] == psId) {
      voRet = voCtrl;
    } else if(voCtrl.all && voCtrl.all[psId]) {
      voRet = voCtrl.all[psId];
      if(voRet[0]) voRet = voRet[0];
    } else {
      if(poDocument.getElementById(psId)) voRet = poDocument.getElementById(psId);
    }
  } else {
    if(poDocument.getElementById(psId)) voRet = poDocument.getElementById(psId);
  }
  return voRet;
};
/**
 * 하위 노드를 추가.
 * @param {HTMLElement} poCtrl 실체화 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.Control.prototype.appendChild = function(poCtrl, poDocument) {
  this.getCtrl(poDocument).appendChild(poCtrl);  
};
/**
 * 하위 노드를 제거.
 * @param {HTMLElement} poCtrl 실체화 객체
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 */
eXria.controls.xhtml.Control.prototype.removeChild = function(poCtrl, poDocument) { 
  this.getCtrl(poDocument).removeChild(poCtrl); 
};
/**
 * Template 정보를 새로고침.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */  
eXria.controls.xhtml.Control.prototype.refreshTemplate = function(poCtrl, poDocument) {
  if(this.setTemplate) this.setTemplate(poCtrl, poDocument); 
};
/**
 * Control에 설정된 공통 정보(css예외 속성)를 새로고침.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */  
eXria.controls.xhtml.Control.prototype.refreshGeneralAttrs = function(poCtrl, poDocument) {
  this.setGeneralAttrs(poCtrl, poDocument); 
};
/**
 * 옵저버로써 수신된 변경내용을 반영한다.
 * @param {eXria.controls.Notify} poNotify
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Control.prototype.update = function(poNotify, poDocument) {
  if(poDocument == null) poDocument = this.document;
  var vb = false;          // 각 처리 결과의 수행 여부
  var NOTICE = eXria.controls.CommonDefine.Notice;
  var voIterator = poNotify.datas.getKeyCollection().iterator();
  var vsKey = null;
  var vsValue = null;
      
  while(voIterator.hasNext()) {
    vsKey = voIterator.next();
    vsValue = poNotify.datas.get(vsKey);
  }
  
  switch(poNotify.type) {
    case NOTICE.APPLY_ATTRIBUTE : 
      if(this.applyAttrSimple) {
        if(this.applyAttrSimple(vsKey, vsValue, poDocument) == true) break; // 속성 설정으로 끝나는 경우
      }     
      if(this.applyAttrRebuild) {
        if(this.applyAttrRebuild(vsKey, vsValue, poDocument) == true) break; // 재계산이 필요한 경우
      }
      if(this.applyAttrRefresh) {
        if(this.applyAttrRefresh(vsKey, vsValue, poDocument) == true) break; // Refresh가 필요한 경우
      }
      break;
    case NOTICE.REMOVE_ATTRIBUTE :        
      if(this.removeAttrSimple) this.removeAttrSimple(vsKey, poDocument);     // 속성 설정으로 끝나는 경우      
      if(this.removeAttrRebuild) this.removeAttrRebuild(vsKey, poDocument);    // 재계산이 필요한 경우    
      if(this.removeAttrRefresh) this.removeAttrRefresh(vsKey, poDocument);   // Refresh가 필요한 경우        
      break;        
    case NOTICE.REFRESH :
      this.refresh(poDocument);
      break;
  }
}; 
/**
 * eventManager에 등록된 이벤트를 제거
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @ignore
 */
eXria.controls.xhtml.Control.prototype.clearEvents = function(poDocument) {
  if(this.ctrl == null) return;
  var vaId = [];
  var vaEventType = [];
  var voIterator = this.eventManager.events.getKeyCollection().iterator();
  var vsId = null;
  var vsEventId = null;
  var vsEventType = null;
  var vaStr = null;
  while(voIterator.hasNext()) {
    vsEventId = voIterator.next();
    vaStr = vsEventId.split(".");
    vsId = vaStr.slice(0, vaStr.length - 1).join(".");
    vsEventType = vaStr[vaStr.length - 1];
    vaId.push(vsId);
    vaEventType.push(vsEventType);
  }
  var voCtrl = null;
  for(var i = 0; i < vaId.length; i++) {     
    voCtrl = this.lookup(vaId[i], poDocument);
    if(voCtrl == null) continue;
    vsEventId = vaId[i] + "." + vaEventType[i];
    this.eventManager.removeListener(voCtrl, vaEventType[i], this.eventManager.events.get(vsEventId));
  }    
};
/**
 * Ctrl을 제거.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @private
 */    
eXria.controls.xhtml.Control.prototype.clearCtrl = function(poDocument) {
  this.clearEvents(poDocument);
  var voCtrl = this.getCtrl(poDocument);
//  if(this.ctrl) this.ctrl = null;
  if (voCtrl != null) {
    //this.clearCtrlNode(voCtrl);
    if(this.setDisable) this.setDisable(voCtrl, false);
    if(voCtrl.parentNode) voCtrl.parentNode.removeChild(voCtrl);
  }
};
/**
 * 노드에 연결된 함수를 제거.
 * @param {HTMLElement} poElement 실체화 객체 
 * @private
 */
eXria.controls.xhtml.Control.prototype.clearCtrlNode = function(poElement) {
  var voAttrs = poElement.attributes;
  if (voAttrs) {
    var vnLength = voAttrs.length;
    for (var i = 0; i < vnLength; i++) {
      var vsName = voAttrs[i].name;
      if (typeof poElement[vsName] === "function") {
        poElement[vsName] = null;
      }
    }
  }

  var voNodes = poElement.childNodes;
  if (voNodes) {
    var vnLength = voNodes.length;
    for (var i = 0; i < vnLength; i++) {
      this.clearCtrlNode(poElement.childNodes[i]);
    }
  }   
};    
/**
 * 공통 초기화 수행
 * @ignore
 */
eXria.controls.xhtml.Control.prototype.initGeneral = function() {
  this.observerHandler = new eXria.controls.ObserverHandler();   // ObserverHandler 생성  
  this.observerHandler.addObserver(this.id, this);              // Observer 등록
  this.eventManager = new eXria.event.EventManager();            // EventManager 생성 => TODO : 향후 변경될 코드, 테스트를 위해 삽입됨
};
/**
 * 멀티라인 텍스트 설정.
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {String} psText
 * @private
 */
eXria.controls.xhtml.Control.prototype.setText = function(poCtrl, psText) {
//  var voDocument = poCtrl.ownerDocument;
//  var voChild = null;
//  var size = poCtrl.childNodes.length;
//  for(var i = 0; i < size; i++) {
//    voChild = poCtrl.childNodes[0];
//    //this.clearCtrlNode(voChild);
//    poCtrl.removeChild(voChild);
//  }
//  if(psText == null) return;
//  var vaText = psText.split("\n");
//  for(var i = 0; i < vaText.length; i++) {
//    poCtrl.appendChild(voDocument.createTextNode(vaText[i]));
//    if(i != vaText.length - 1) poCtrl.appendChild(voDocument.createElement("br"));
//  }
  if(psText == null) psText = "";
  psText = eXria.controls.xhtml.Util.parseLang(psText);
  psText = psText.replace(/</g, "&lt;");
  psText = psText.replace(/>/g, "&gt;");
	psText = psText.replace(/\n/g, "<br>");  
	psText = psText.replace(/\s/g, "&nbsp;");  
  poCtrl.innerHTML = psText;
};

/**
 * dom element가 브라우저를 기준으로 한 절대 좌표를 접하거나 포함하고 있는지 여부 확인
 * @ignore
 */
eXria.controls.xhtml.Control.prototype.isContain = function(poCtrl, pnX, pnY) {
  var vbContain = false;
//  var voStyle = poCtrl.style;

  var vnBorderLeft = 0, vnBorderRight = 0, vnBorderTop = 0, vnBorderBottom = 0;
  
  if(!!this.getStyleCurrentValue) {
    vnBorderLeft = parseInt(this.getStyleCurrentValue(poCtrl, "border-left-width", "borderLeftWidth"), 10);
    vnBorderRight = parseInt(this.getStyleCurrentValue(poCtrl, "border-right-width", "borderRightWidth"), 10);
    vnBorderTop = parseInt(this.getStyleCurrentValue(poCtrl, "border-top-width", "borderTopWidth"), 10);
    vnBorderBottom = parseInt(this.getStyleCurrentValue(poCtrl, "border-bottom-width", "borderBottomWidth"), 10);
  }
  
  var vnWidth = parseInt(poCtrl.offsetWidth) - vnBorderLeft - vnBorderRight;
  var vnHeight = parseInt(poCtrl.offsetHeight) - vnBorderTop - vnBorderBottom;	

  var vnLeft = 0;
  var vnTop = 0;
  var voElement = poCtrl;
  while(voElement.offsetParent) {      
    vnLeft += voElement.offsetLeft;
    vnTop += voElement.offsetTop;
    voElement = voElement.offsetParent ;
  };
  if(pnX >= vnLeft && pnX < vnLeft + vnWidth && pnY >= vnTop && pnY < vnTop + vnHeight) {
    vbContain = true;    
  }
      
  return vbContain;
};
