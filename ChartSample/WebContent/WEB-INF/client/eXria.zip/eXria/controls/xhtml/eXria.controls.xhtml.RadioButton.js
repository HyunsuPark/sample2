﻿/**
 * @fileoverview
 * Concreate xhtml RadioButton(XHTML RadioButton 컨트롤)
 * @author 김경태
 */

/**
 * @class 선택영역에서 어느 하나를 선택 또는 취소하기 위해 사용하는 컨트롤을 생성하는 class입니다. <br />
 * 선택 버튼과 같은 의미로 사용되며, 일련의 선택 사항 중 한 번에 하나씩만 선택하게 되어 있습니다.<br />
 * XHTML RadioButton Control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.RadioButton 객체
 * @type eXria.controls.xhtml.RadioButton
 * @constructor
 * @base eXria.controls.xhtml.Select
 */
eXria.controls.xhtml.RadioButton = function(psId, pnLeft, pnTop, pnWidth, pnHeight){
  
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 250 : pnWidth;
  pnHeight = pnHeight == null ? 100 : pnHeight;
  
  eXria.controls.xhtml.Select.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight); // UIControl을 상속받는다.
  /**
   * Data 연동 객체(노드 셋 연동).
   * @type eXria.controls.DataRefNodeset
   */
  this.data = new eXria.controls.DataRefNodeset(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 선택 버튼 타입.
   * @ignore
   * @type String
   */
  this.type = "radio";
  /**
   * 아이템 다중선택 여부.
   * @ignore
   * @type Boolean
   */ 
  this.multiple = false; 

	/**
	 * @private
	 */
  this.cursor = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Select, eXria.controls.xhtml.RadioButton);
//////////////////////////////////////////////////////////////////
// 메소드 
/**
 * 클래스 명을 반환합니다.
 * @return "RadioButton"
 * @type String
 */
eXria.controls.xhtml.RadioButton.prototype.toString = function(){
  return "RadioButton";
};

