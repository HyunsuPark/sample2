/**
 * @fileoverview
 * Concreate xhtml Timer(XHTML Timer 컨트롤)
 * @author 조동일 , 이종녕
 */

/**
 * @class 설정한 Interval 수치에 따라서 원하는 동작을 반복할 수 <br />
 * 있는 컨트롤을 생성하는 class입니다.<br />
 * XHTML Timer Control.
 * @version 1.0
 * @param {String} psId 컨트롤 식별자
 * @return 새로운 eXria.controls.xhtml.Timer 객체
 * @type eXria.controls.xhtml.Timer
 * @constructor
 * @base eXria.controls.Control
 */ 
eXria.controls.xhtml.Timer = function(psId) {
  
  eXria.controls.Control.call(this, psId);
  /**
   * 구동중인 Timer ID.
   * @type Number
   */
  this.timerID; //long
  /**
   * Timer 구동중 여부.
   * @type Boolean
   */
  this.isRun = false;
  /**
   * 타이머 유형을 지정하기 위한 상수.
   * TIMEOUT | INTERVAL
   * @type Object
   */
  this.TYPE = {
    TIMEOUT : 1,
    INTERVAL : 2
  };
  /**
   * 구동중인 Timer의 구분.
   * @type Number
   * @assert eXria.controls.xhtml.Timer.TYPE.TIMEOUT || eXria.controls.xhtml.Timer.TYPE.INTERVAL
   */
  this.runType = -1;
  /**
   * 타이머 호출 시간 간격(ms).
   * @type Number
   */
  this.interval = 1000;
  /**
   * 타이머 호출 중지 카운트.
   * @type Number
   */
  this.stopCount = 0; // -1 지정시 무한반복
  /**
   * 현재까지 반복된 카운트 저장.
   * @type Number
   */
  this.curCount = this.stopCount;
  /**
   * 타이머 반복 호출 시 수행될 사용자 지정 함수.
   * @type Number
   */
  this.ontimer = null;
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.Control, eXria.controls.xhtml.Timer);
//////////////////////////////////////////////////////////////////
// 메소드  

/**
 * @ignore
 */
eXria.controls.xhtml.Timer.prototype.getEHandler = function(psFuncName) {
  var vaStrBuf = [];
  //vaStrBuf.push("var e=null;");
  //vaStrBuf.push("if(arguments[0]) e=arguments[0];");
  vaStrBuf.push("var voPage=eXria.controls.xhtml.Util.getPage('");
  vaStrBuf.push(this.canvas.page.id);
  vaStrBuf.push("');");
  vaStrBuf.push("voPage.getControl('");
  vaStrBuf.push(this.id);
  vaStrBuf.push("').");
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("();");
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};

/**
 * 타이머를 시작합니다.
 */ 
eXria.controls.xhtml.Timer.prototype.start = function() {
  //this.setInterval(this.timeEvent,this.interval);
  this.curCount = this.stopCount;
	//this.setInterval(this.getEHandler("timeEvent"), this.interval);
	var voBase = this;
	var voFunc = function() {
	  voBase.timeEvent();
	};
	this.setInterval(voFunc, this.interval);
};
/**
 * 타이머를 중지시킵니다.
 */
eXria.controls.xhtml.Timer.prototype.stop = function() {
  this.clearInterval();
};
/**
 * 속성 값을 설정합니다.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 */
eXria.controls.xhtml.Timer.prototype.setAttr = function(psAttrName,psAttrValue) {
  switch(psAttrName){
    case "stopCount":
      this.stopCount = psAttrValue;
      this.curCount = psAttrValue;
      break;
    case "interval":
      this.interval = psAttrValue;
      break;
  };
};
/**
 * 속성 값을 설정하고 바로 적용합니다. (설정된 속성을 실체화 컨트롤에 바로 적용)
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 */
eXria.controls.xhtml.Timer.prototype.applyAttr = function(psAttrName,psAttrValue) {
  switch(psAttrName){
    case "stopCount":
      this.stopCount = psAttrValue;
      this.curCount = psAttrValue;
      break;
    case "interval":
      this.interval = psAttrValue;
      break;
  };  
};
/**
 * start 메소드에 의해 수행되는 작업입니다.
 * @private
 */
eXria.controls.xhtml.Timer.prototype.timeEvent = function(e) {
  if(this.curCount == 0){
		this.clearInterval();
	} else if(this.curCount == -1){
	  if(this.ontimer) this.ontimer(e);
	} else {
		if(this.ontimer) this.ontimer(e);
		this.curCount--;		
	}
};
/**
 * 일정시간 후 지정함수를 호출합니다.
 * @param {String} psFuntion 
 * @param {Number} pnDelay (단위 milisecond = 1/1000초)
 */
eXria.controls.xhtml.Timer.prototype.setTimeout = function(psFunction, pnDelay) {
  var voWindow = this.window;
  if(voWindow == null) voWindow = window;
  if(this.isRun == false) {
    //this.timerID = voWindow.setTimeout(eval(psFunction), pnDelay);
  	this.timerID = voWindow.setTimeout(psFunction, pnDelay);
    this.isRun = true;
    this.runType = this.TYPE.TIMEOUT;
  } else {
    //TODO throw Exception
  }
};
/**
 * setTimeout()메소드에의해 수행되고 있는 함수를 중지시킵니다.
 */
eXria.controls.xhtml.Timer.prototype.clearTimeout = function() {
  var voWindow = this.window;
  if(voWindow == null) voWindow = window;
  if(this.isRun == true) {
    voWindow.clearTimeout(this.timerID);
    this.isRun = false;
    this.runType = -1;
  } else {
    //TODO throw Exception
  }
};
/**
 * 일정시간 간격으로 지정 메소드를 반복 호출합니다.
 * @param {String} psFuntion 호출될 메소드명
 * @param {Number} pnDelay 지연시간 (단위 milisecond = 1/1000초)
 */
eXria.controls.xhtml.Timer.prototype.setInterval = function(psFunction, pnDelay) {
  if(this.isRun == false) {
    //this.timerID = window.setInterval(eval(psFunction), pnDelay);
    var voWindow = this.window;
    if(voWindow == null) voWindow = window;
    this.timerID = voWindow.setInterval(psFunction, pnDelay);
    this.isRun = true;
    this.runType = this.TYPE.INTERVAL;
  } else {
    //TODO throw Exception
  }
};
/**
 * setInterval()메소드에의해 수행되고 있는 함수를 중지시킵니다.
 */
eXria.controls.xhtml.Timer.prototype.clearInterval = function() {
  if(this.isRun == true) {
    window.clearInterval(this.timerID);
    this.isRun = false;
    this.runType = -1;
    //this.stopCount = this.oriStopCount;
  } else {
    //TODO throw Exception
  }
};
/**
 * 실체화 컨트롤에 대한 소멸 처리를 수행합니다.
 */
eXria.controls.xhtml.Timer.prototype.clearCtrl = function() {
  if(this.isRun == true) {
    switch(this.runType) {
      case this.TYPE.TIMEOUT :
        this.clearTimeout();
        break;
      case this.TYPE.INTERVAL :
        this.clearInterval();
        break;
    }
  }
};
/**
 * 클래스 명을 반환합니다.
 * @return "Timer"
 * @type String
 */
//this.toString = function() {
eXria.controls.xhtml.Timer.prototype.toString = function() {
  return "Timer";
};