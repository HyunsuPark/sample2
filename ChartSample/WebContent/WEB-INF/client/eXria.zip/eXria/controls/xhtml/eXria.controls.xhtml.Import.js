﻿/**
 * @fileoverview
 * Concreate xhtml Image(XHTML Import 컨트롤)
 * @author 조동일
 */

/**
 * @class page 내부에 외부 page를 포함하는 기능을 수행<br>
 * 서버 측에서 포함 시킬 page의 내용을 상위 page에 하나로 병합하여 보여줌.
 * SubPage와는 다르게 import 페이지는 사용자 화면에서 개별적으로 접근할 수 있는 컨트롤이 아님.<br>
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Import 객체
 * @type eXria.controls.xhtml.Import
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 * @ignore
 */ 
eXria.controls.xhtml.Import = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 400 : pnWidth;
  pnHeight = pnHeight == null ? 300 : pnHeight;
  
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);   // UIControl을 상속받는다.
  /**
   * Import에 속한 컨트롤들의 표시 여부.<br>
   * true | false
   * @type Boolean
   * @ignore
   */
  this.visible = null;
  /**
   * Import에 속한 컨트롤들의 활성화 여부.<br>
   * true | false
   * @type Boolean
   * @ignore
   */
  this.enable = null;
  /**
   * 불러오는 화면에 대한 URL 및 파일 경로.
   * @type String
   */
  this.src = null;
  
  this.cursor = null;
};

eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Import);
/**
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.createCtrl = function() {
  var voDocument = this.document;
  var voCtrl = voDocument.createElement("iframe");
  voCtrl["id"] = this.id;
	if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  voCtrl.frameBorder = "no";
  voCtrl.scrolling = "no";
  this.ctrl = voCtrl;
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.createSubCtrl = function(poCtrl) {
  if(this.src) {
    poCtrl.src = this.src;
  }
  if(this.visible) {
    poCtrl.style.visibility = this.visible;
  }
};
/** 
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  switch(psAttrName) {
    case "disabled" :
      //this.setEnable(!psAttrValue, poCtrl);
      break;
    case "visible" :
      this.setVisible(psAttrValue, poCtrl);
      break;
    default :
      break;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.setSpecificAttrs = function(poCtrl) {
  this.setAttrCtrl("src", this.src, poCtrl);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.setSpecificEvents = null;
/**
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.refreshSpecificAttrs = function(poCtrl) {
  this.setSpecificAttrs(poCtrl);
};
/**
 * 불러오는 화면에 대한 URL 및 파일 경로를 설정합니다.
 * @param {String} psSrc URL 및 파일 경로
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document. 생략가능.
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.setSrc = function(psSrc, poDocument) {
  this.src = psSrc;
  var voCtrl = this.getCtrl(poDocument);
  if(voCtrl) {
    voCtrl.src = this.src;
  }
};
/**
 * 컨트롤 화면 디스플레이 여부를 설정합니다.
 * @param {String} psVisible 화면 디스플레이 여부
 * @param {HTMLIframe} poCtrl 실체화 컨트롤
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.setVisible = function(psVisible, poCtrl) {
  this.visible = psVisible;
  poCtrl.style.visibility = psVisible;
};
/**
 * 컨트롤의 화면 디스플레이 상태 값 반환합니다.
 * @return 컨트롤의 visible 속성값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.getVisible = function() {
  return this.visible;
};
/**
 * 불러오는 화면에 대한 URL 및 파일 경로 반환합니다.
 * @return 컨트롤의 src 속성 값
 * @type String
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.getSrc = function() {
  return this.src;
};
/**
 * 이벤트를 활성화 시킵니다.
 * @param {Boolean} pbEnable 활성화 설정
 * @param {HTMLIframe} poCtrl 실체화 컨트롤
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.setEnable = function(pbEnable, poCtrl) {
  if(this.enable != pbEnable) {
    //iframe inner control들을 disable 시킨다.
    this.enable = pbEnable;
    var voImportWindow = poCtrl.contentDocument || poCtrl.contentWindow;
    
    var voControls = voImportWindow.page.canvas.controls.getValueCollection();
    var voControlIterator = voControls.iterator();
    var voControl;
    while(voControlIterator.hasNext()) {
      voControl = voControlIterator.next();
      voControl.applyAttr("disabled", !this.enable);
    }
  }
};
/**
 * 클래스 명을 반환합니다.
 * @return "Import"
 * @type String
 * @ignore
 */
eXria.controls.xhtml.Import.prototype.toString = function() {
  return "Import";
};
