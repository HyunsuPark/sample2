/**
 * @fileoverview
 * UIControl 컨트롤에 대한 xhtml 기본 클래스
 * @author 김경태
 */

/**
 * @class 컨트롤에 대한 xhtml 기본 클래스입니다.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.UIControl 객체
 * @type eXria.controls.xhtml.UIControl
 * @constructor
 * @base eXria.controls.xhtml.Control
 */
eXria.controls.xhtml.UIControl = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  eXria.controls.xhtml.Control.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * 툴팁에 표시될 문자열.
   * @type String
   */
  this.tooltip = null;
  /**
   * 컨텍스트 메뉴 컨트롤에 대한 id
   * @type String
   */  
  this.contextMenuId = null;
  /**
   * 컨트롤에 적용될 css 클래스 명.
   * @type String
   */
  this.className = null;
  /**
   * 컨트롤의 최외곽 DIV 보더 스타일을 지정하는 css의 class 이름.
   * @type String
   */
  this.outerClassName = null;
  /**
   * 컨트롤 탭 인덱스.<br>
   * 폼에서 탭키에 의한 컨트롤 이동 시 이용됨.
   * @type Number
   */
  this.tabIndex = null;
  /**
   * 컨트롤을 비활성화 여부.
   * @type Boolean
   */
  this.disabled = false;
  /**
   * 컨트롤 포커싱 키보드 단축키.
   * @type String
   */
  this.accessKey = "";
  /**
   * 포커스가 위치했을 때의 색상 변경 적용 여부.
   * @type Boolean
   */
  this.focusDisplay = false;
  /**
   * 툴팁 표시 여부.
   * @type Boolean
   */
  this.tooltipDisplay = null;
  /**
   * 컨트롤 이동시의 pane 객체의 불투명도.
   * @type Number
   * @private
   */
  this.paneOpacity = 30;     // TODO : 현재 스펙에서 외부에 노출되어 있지 않음
  /**
   * 마우스 드래그에 의한 컨트롤 이동 가능 여부.<br>
   * this.setMove메소드에 의해서만 값 설정.
   * @type Boolean
   * @private
   */
  this.movable = false;       // @private this.setMove메소드에 의해서만 값 설정
  /**
   * 프린트를 위한 프린트 동작 상태 여부.
   * @type Boolean
   * @ignore
   */
  this.printMode = false;
  /**
   * 컨트롤 화면 디스플레이 여부.
   * @type Boolean
   */  
  this.visible = null;
  /**
   * 폼에서 컨트롤의 겹침 순서 지정.<br>
   * @type Number
   */
  this.zIndex = null;
  /**
   * TableLayout 사용시 들어갈 열 인덱스.<br>
   * @type Number
   */
  this.rowNum = null;
  /**
   * TableLayout 사용시 들어갈 행 인덱스.<br>
   * @type Number
   */
  this.colNum = null;
  /**
   * 상위 컨트롤과의 위치 관계(absolute | relative | static).<br>
   * absolute : 상위 컨트롤의 좌상단 점을 원점으로 left, top 지정.<br>
   * relative : 상위 컨트롤이 컨트롤을 자동 위치시킨 상태에서의 left, top 이동값 지정.<br>
   * @type String
   */
  this.position = null;
  /**
   * 컨트롤에 표시될 텍스트 색상 값.<br>
   * @type String
   */
  this.color = null;
  /**
   * 컨트롤의 배경색.<br>
   * @type String
   */              
  this.backgroundColor = null;
  /**
   * 컨트롤 외곽 보더의 두께.<br>
   * @type Number
   */
  this.borderWidth = null;
  /**
   * 컨트롤 외곽 상단보더의 두께.<br>
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 컨트롤 외곽 우측보더의 두께.<br>
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 컨트롤 외곽 하단보더의 두께.<br>
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 컨트롤 외곽 좌측보더의 두께.<br>
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 컨트롤 외곽 보더 스타일.<br>
   * "none" | "hidden" | "dotted" | "dashed" | "solid" | "double" | "groove" | "ridge" | "inset" | "outset" (초기값 : solid)
   * @type String
   */
  this.borderStyle = null;
  /**
   * 컨트롤 외곽 보더 색상.<br>
   * @type String
   */
  this.borderColor = null;
  /**
   * 컨트롤 위에 마우스 위치시에 마우스 커서 타입.<br>
   * "all-scroll" | "col-resize" | "crosshair" | "default" | "help" | "move" | "no-drop" | "not-allowed" | "row-resize" | "text" | "url" | "vertical-text" | "wait" | "NW-resize" | "NE-resize" | "progerss" | "pointer" (초기값 : default)
   * @type String
   */
  this.cursor = "default";
  /**
   * 컨트롤에 포커스 위치 시 외곽 보더의 두께.<br>
   * 포커스 효과 관련
   * @type Number
   */
  this.focusBorderWidth = null;
  /**
   * 컨트롤에 포커스 위치 시 외곽 보더의 색상.<br>
   * 포커스 효과 관련
   * @type String
   */
  this.focusBorderColor = null;
  /**
   * 컨트롤에 포커스 위치 시 외곽 보더 스타일.
   * @type String
   */
  this.focusBorderStyle = null;
  /**
   * dataset id
   * @type String
   */
  this.datasetId = null;
  /**
   * 포커싱에 의해 컨트롤 외곽 보더 두께 변경 시 원본 값 저장.
   * @type Number
   * @private
   */
  this.oldBorderWidth = null;
  /**
   * 포커싱에 의해 컨트롤 외곽 보더 색상 변경 시 원본 값 저장.
   * @type String
   * @private
   */
  this.oldBorderColor = null;
  /**
   * 포커싱에 의해 컨트롤 외곽 보더 스타일 변경 시 원본 값 저장.
   * @type String
   * @private
   */
  this.oldBorderStyle = null;
  /**
   * 컨트롤 disabled 상태에서의 폰트 색상.
   * @type String
   */
  this.disabledColor = null;
  /**
   * 컨트롤이 폼에 attach 된 후 load 작업이 수행되었는지 여부.<br>
   * 유의사항으로 isLoaded()는 attach 되었는지 여부 만을 체크.
   * @type Boolean
   */
  this.loaded = false;
  
  
  /**
   * 컨트롤 좌상단 점의 x좌표.
   * @type Number
   */
  this.left = pnLeft == null ? 0 : pnLeft;
  /**
   * 컨트롤 좌상단 점의 y좌표.
   * @type Number
   */
  this.top = pnTop == null ? 0 : pnTop;
  /**
   * 컨트롤의 가로 길이.
   * @type Number
   */
  this.width = pnWidth == null ? 100 : pnWidth;
  /**
   * 컨트롤의 세로 길이.
   * @type Number
   */
  this.height = pnHeight == null ? 100 : pnHeight;
  
  
  /**
   * 컨트롤 위치 이동 시 마우스 위치를 기준으로 left 경계와의 거리
   * @type Number
   * @private
   */
  this.leftOffset = -1;
  /**
   * 컨트롤 위치 이동 시 마우스 위치를 기준으로 top 경계와의 거리
   * @type Number
   * @private
   */
  this.topOffset = -1;
  /**
   * 컨트롤 위치 이동 시 마우스 위치를 기준으로 right 경계와의 거리
   * @type Number
   * @private
   */
  this.rightOffset = -1;
  /**
   * 컨트롤 위치 이동 시 마우스 위치를 기준으로 bottom 경계와의 거리
   * @type Number
   * @private
   */
  this.bottomOffset = -1;
  /**
   * @ignore
   */
  this.divOffsetHeight;
  
  this.initUIGeneral();
}; // End of Control
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.Control, eXria.controls.xhtml.UIControl);
/**
 * Main Ctrl을 생성합니다.
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 컨트롤을 둘러싸는 최외곽 Div 객체
 * @type HTMLDiv
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.createCtrl = function(poDocument) {};
/**
 * 컨트롤을 구성하기 위한 HTML 레이아웃을 문자열 버퍼에 설정하는 메소드.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setTemplate = function(poCtrl, poDocument) {};
/**
 * Composite Child Ctrl을 생성합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.createSubCtrl = function(poCtrl, poDocument) {};
/**
 * Main Style을 적용합니다.
 * @param {HTMLDiv} voCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
//	var vsClassName = this.getSpecificAttrValue("className", this.className);
//  var vsOuterClassName = this.getSpecificAttrValue("className", this.outerClassName);
//  var vsJoinedClassName = this.getCtrlClassName(vsClassName, vsOuterClassName);
//  if(vsJoinedClassName != " ") this.setAttrCtrl("className", vsJoinedClassName, poCtrl);
  
	poCtrl.className = this.getCSSClass(this, 0);
};
/**
 * Composite Child Style을 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */      
eXria.controls.xhtml.UIControl.prototype.setSubCtrlStyles = function(poCtrl, poDocument) {};
/**
 * 개별 초기값을 설정합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */    
eXria.controls.xhtml.UIControl.prototype.setSpecificDefaults = function(poCtrl, poDocument) {};
/**
 * 공통 속성들에 속성값을 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */    
eXria.controls.xhtml.UIControl.prototype.setGeneralAttrs = function(poCtrl, poDocument) {};
/**
 * 컨트롤 별 속성들에 속성값을 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setSpecificAttrs = function(poCtrl, poDocument) {};
/**
 * 공통 Events를 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */        
eXria.controls.xhtml.UIControl.prototype.setGeneralEvents = function(poCtrl) {};
/**
 * 컨트롤 별 Events를 적용합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */    
eXria.controls.xhtml.UIControl.prototype.setSpecificEvents = function(poCtrl) {};
/**
 * 컨트롤 별 초기값으로 지정된 속성값을 제거합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {};
/**
 * Composite Child Style을 새로고침 합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */    
eXria.controls.xhtml.UIControl.prototype.refreshSubStyles = function(poCtrl, poDocument) {};
/**
 * 공통 속성들에 대한 새로고침을 수행합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */    
eXria.controls.xhtml.UIControl.prototype.refreshGeneralAttrs = function(poCtrl, poDocument) {};

/**
 * 컨트롤 별 속성들에 대한 새로고침을 수행합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {};
/**
 * Data를 재로딩합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.reloadData = function(poCtrl, poDocument) {};  
/**
 * Data관련 UI를 새로고침 합니다.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */
eXria.controls.xhtml.UIControl.prototype.refreshData = function(poCtrl, poDocument) {
  if(this.reloadData) this.reloadData(poCtrl, poDocument);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.getSpecificDefaultValue = function(psAttrName) {};
/**
 * 웹 페이지에 로딩된 스타일 클래스를 참조합니다.
 * @param {String} psClassName 참조 대상 클래스명
 * @param {HTMLDocument} poDocument 참조 대상 클래스 파일을 로딩 한 Document
 * @return 참조된 css 클래스 오브젝트
 * @type StyleObject
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.getCssStyle = function(psClassName, poDocument) {
  return this.canvas.getCssStyle(psClassName, poDocument);
};
/** 
 * HTML element의 className 속성에 할당 가능한 형태의 문자열을 반환해주는 메소드.
 * @param {String} psClassName 반환될 문자열 내에서 내부 css 요소를 결정할 css 클래스 명
 * @param {String} psOuterClassName 반환될 문자열 내에서 외부 css 요소를 결정할 css 클래스 명
 * @return HTML element의 className 속성에 할당 가능한 형태의 문자열
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.getCtrlClassName = function(psClassName, psOuterClassName) {
  var vsClassName = "";
  if(psClassName == null) psClassName = "";
  if(psOuterClassName == null) psOuterClassName = "";
  vsClassName = psClassName + " " + psOuterClassName;
  vsClassName = eXria.util.StringUtil.trim(vsClassName);
  
  return vsClassName;
};
/**
 * 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @param {String} psAttrName 속성명
 * @param {String} psCtrlAttrName psAttrName에 대응되면 실체화 객체 속성명
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeUIGeneralAttrValue = function(poCtrl, poCssStyle, psAttrName, psCtrlAttrName) {  
  if(this[psAttrName] != null) {  // 사용자 지정 속성값이 있을 경우
    return this[psAttrName]; // this.setAttrCtrl(psCtrlAttrName, this[psAttrName], poCtrl);
  } else {  // 사용자 지정 속성값이 없을 경우
    if(poCssStyle != null) {  // 지정된 CSS가 있을 경우
      if(poCssStyle[psCtrlAttrName] !== undefined && poCssStyle[psCtrlAttrName] != null && poCssStyle[psCtrlAttrName] != "") { // CSS에 해당 속성 값이 있을 경우
        return poCssStyle[psCtrlAttrName];  // this.setAttrCtrl(psCtrlAttrName, poCssStyle[psCtrlAttrName], poCtrl);
      } else {  // CSS에 해당 속성 값이 없을 경우
        return this.getUIControlAttrValue(psAttrName, null);  // this.setAttrCtrl(psCtrlAttrName, this.getUIControlAttrValue(psAttrName, null), poCtrl);
      }
    } else {  // 지정된 CSS가 없을 경우
      return this.getUIControlAttrValue(psAttrName, null);  // this.setAttrCtrl(psCtrlAttrName, this.getUIControlAttrValue(psAttrName, null), poCtrl);      
    }
  }
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @param {String} psAttrName 속성명
 * @param {String} psCtrlAttrName psAttrName에 대응되면 실체화 객체 속성명
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeSpecificAttrValue = function(poCtrl, poCssStyle, psAttrName, psCtrlAttrName, psClassName) {
  var vaAttrName = psAttrName.split(".");
  var voAttr = this;
  for(var i = 0; i < vaAttrName.length; i++) {
    voAttr = voAttr[vaAttrName[i]];
    if(voAttr == null) {
      break;
    }
  }
     
  if(voAttr != null) {  // 사용자 지정 속성값이 있을 경우
    return voAttr;
  } else {  // 사용자 지정 속성값이 없을 경우
    if(poCssStyle != null) {  // 지정된 CSS가 있을 경우
      if(psCtrlAttrName == null) psCtrlAttrName = vaAttrName[vaAttrName.length - 1];
      if(poCssStyle[psCtrlAttrName] != null && poCssStyle[psCtrlAttrName] != "") {
        voAttr = poCssStyle[psCtrlAttrName];
        if(psCtrlAttrName == "backgroundImage") {
          if(psClassName) voAttr = eXria.controls.xhtml.Util.convertImagePathToXrf(psClassName, voAttr, this.document);
        }
        return voAttr;
      } else {  // CSS에 해당 속성 값이 없을 경우
        return this.getAttrValue(psAttrName, null);
      }
    } else {  // 지정된 CSS가 없을 경우
      return this.getAttrValue(psAttrName, null);
    }
  }
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 visible 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 visible 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeVisibleValue = function(poCtrl, poCssStyle) {
  if(this.visible != null) {
    return this.visible;
  } else {
    if(poCssStyle != null) { 
      if(poCssStyle["display"] != "" && poCssStyle["display"] != null) {
        if(poCssStyle["display"] == "none") return false;
        else return true;
      } else {
        return this.getUIControlAttrValue("visible", null);
      } 
    } else {
      return this.getUIControlAttrValue("visible", null);
    }
  }   
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 zIndex 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 zIndex 속성값
 * @type Number
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeZIndexValue = function(poCtrl, poCssStyle) {
  var vnValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "zIndex", "zIndex");
  return vnValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 position 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 position 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makePositionValue = function(poCtrl, poCssStyle) {
  return "absolute";
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 color 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 color 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeColorValue = function(poCtrl, poCssStyle) {  
  var vsValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "color", "color");
  return vsValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 backgroundColor 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 backgroundColor 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeBackgroundColorValue = function(poCtrl, poCssStyle) {  
  var vsValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "backgroundColor", "backgroundColor");
  return vsValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 cursor 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 cursor 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeCursorValue = function(poCtrl, poCssStyle) {
  var vsValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "cursor", "cursor");
  return vsValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 borderWidth 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 borderWidth 속성값
 * @type Number
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeBorderWidthValue = function(poCtrl, poCssStyle) {
  var vnValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "borderWidth", "borderWidth");
  this.innerWidth = this.width - (2 * parseInt(vnValue));
  this.innerHeight = this.height - (2 * parseInt(vnValue));
  return vnValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 borderStyle 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 borderStyle 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeBorderStyleValue = function(poCtrl, poCssStyle) {
  var vsValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "borderStyle", "borderStyle");
  return vsValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 borderColor 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 borderColor 속성값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeBorderColorValue = function(poCtrl, poCssStyle) {
  var vsValue = this.makeUIGeneralAttrValue(poCtrl, poCssStyle, "borderColor", "borderColor");
  return vsValue;
};
/**
 * 사용자 할당 값,css, canvas, UISpecific에서 우선순위에 따라 tabIndex 속성값을 가져오는 메소드.
 * @param {HTMLDiv} poCtrl 컨트롤 최외곽 DIV Element
 * @param {HTMLStyle} poCssStyle 값을 검색할 Css style 객체
 * @return 사용자 할당 값,css, canvas, UIDefault에서 우선순위에 따라 결정된 tabIndex 속성값.(디폴트 값 : 0)
 * @type Number
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.makeTabIndexValue = function(poCtrl, poCssStyle) {
  var vsValue = this.makeUIGeneralAttrValue(poCtrl, null, "tabIndex", "tabIndex");
  if(vsValue == null) vsValue = 0;
  return vsValue;
};
/**
 * 컨트롤에 적용될 공통속성(css 스타일 적용가능 속성)의 초기값을 설정.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setUIGeneralDefaults = function(poCtrl, poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(); }

   // CSS 적용가능한 속성
  var voDf = this.df;
  var voCssStyle = this.canvas.getCssStyle(this.className, poDocument); 
  //var voCtrlValueMaker = this.ctrlValueMaker;
  this["visible"] = this.makeVisibleValue(poCtrl, voCssStyle);
  this["zIndex"] = this.makeZIndexValue(poCtrl, voCssStyle);
//  this["position"] = this.makePositionValue(poCtrl, voCssStyle); 
//  voDf["color"] = this.makeColorValue(poCtrl, voCssStyle); 
//  voDf["backgroundColor"] = this.makeBackgroundColorValue(poCtrl, voCssStyle); 
//  voDf["cursor"] = this.makeCursorValue(poCtrl, voCssStyle); 
  this["tooltip"] = this.makeUIGeneralAttrValue(poCtrl, null, "tooltip", "tooltip");
  this["tooltipDisplay"] = this.makeUIGeneralAttrValue(poCtrl, null, "tooltipDisplay", "tooltipDisplay");
  // border CSS가 적용가능한 속성
//  voCssStyle = this.canvas.getCssStyle(this.outerClassName, poDocument);
//  voDf["borderWidth"] = this.makeBorderWidthValue(poCtrl, voCssStyle);
//  voDf["borderStyle"] = this.makeBorderStyleValue(poCtrl, voCssStyle);
//  voDf["borderColor"] = this.makeBorderColorValue(poCtrl, voCssStyle);
  
  // CSS가 적용되지 않는 속성
  this["tabIndex"] = this.makeTabIndexValue(poCtrl, voCssStyle);
  this["disabledColor"] = this.makeUIGeneralAttrValue(poCtrl, null, "disabledColor", "disabledColor");
//  voDf["debug"] = this.makeUIGeneralAttrValue(poCtrl, null, "debug", "debug");
  if(this["debug"] == null) this["debug"] = this.canvas.getFormDefaultValue("debug");
};

///**
// * 컨트롤에 적용될 공통속성(css 예외 속성)의 초기값을 설정한다.
// * @param {HTMLDiv} poCtrl 실체화 컨트롤
// * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
// * @private
// */ 
//eXria.controls.xhtml.UIControl.prototype.setUIGeneralAttrs = function(poCtrl, poDocument) {
//  var voMainCtrl = null; 
//  if (this.getMainCtrl) { voMainCtrl = this.getMainCtrl(poDocument); };
//  if(voMainCtrl == null) voMainCtrl = poCtrl;
//  
//  this.setAttrCtrl("tooltip", this.tooltip, poCtrl);
//  this.setAttrCtrl("tabIndex", this.tabIndex, poCtrl);
//  this.setAttrCtrl("disabled", this.disabled, poCtrl);    
//  this.setAttrCtrl("accessKey", this.accessKey, poCtrl);
//  this.visible == false ? this.setAttrCtrl("display", "none", poCtrl) : this.setAttrCtrl("display", "", poCtrl);
//  this.setAttrCtrl("zIndex", this.zIndex, poCtrl);    
//  this.setAttrCtrl("position", this.position, poCtrl);  
//  this.setAttrCtrl("color", this.color, poCtrl);
//  this.setAttrCtrl("backgroundColor", this.backgroundColor, poCtrl);
//  this.setAttrCtrl("borderWidth", this.borderWidth, poCtrl);
//  this.setAttrCtrl("borderStyle", this.borderStyle, poCtrl);
//  this.setAttrCtrl("borderColor", this.borderColor, poCtrl);
//  this.setAttrCtrl("left", this.left, poCtrl);
//  this.setAttrCtrl("top", this.top, poCtrl);
////  this.setAttrCtrl("width", this.innerWidth, poCtrl);
////  this.setAttrCtrl("height", this.innerHeight, poCtrl);
//  this.setAttrCtrl("cursor",this.cursor, poCtrl);
//};

/**
 * 컨트롤에서 수행할 이벤트 처리를 지정.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.setUIGeneralEvents = function(poCtrl) { 
  // Ctrl에서 발생한 이벤트를 2차적으로 처리하는 사용자용 메소드
//  this.onfocus = null;  // button, div, iframe, img, input, label, object, select, span, table, textarea
//  this.onblur = null; // button, div, iframe, img, input, label, object, select, table, span, window  
//  this.onclick = null; // body, button, div, img, input, label, object, select, span, table, textarea
//  this.ondblclick = null; // body, button, div, img, input, label, object, select, span, table, textarea
//  this.onkeydown = null; // body, button, div, input, label, object, select, span, table, textarea
//  this.onkeypress = null; // body, button, div, input, label, object, select, span, table, textarea
//  this.onkeyup = null; // body, button, div, input, label, object, select, span, table, textarea
//  this.onmousedown = null; // body, button, div, img, input, label, select, span, table, textarea
//  this.onmousemove = null; // body, button, div, img, input, label, select, span, table, textarea
//  this.onmouseout = null; // body, button, div, img, input, label, select, span, table, textarea
//  this.onmouseover = null; // body, button, div, img, input, label, select, span, table, textarea
//  this.onmouseup = null; // body, button, div, img, input, label, select, span, table, textarea
//  this.onresize = null; // body, button, div, img, input, label, object, select, table, textarea
  var voEventManager = this.eventManager;
  voEventManager.addListener(poCtrl, "onclick", this.mediateEvent);
  voEventManager.addListener(poCtrl, "ondblclick", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onmousedown", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onmouseup", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onmouseover", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onmousemove", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onmouseout", this.mediateEvent);    
  voEventManager.addListener(poCtrl, "onkeypress", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onkeydown", this.mediateEvent);
  voEventManager.addListener(poCtrl, "onkeyup", this.mediateEvent);
  voEventManager.addListener(poCtrl, "oncontextmenu", this.mediateEvent);
  poCtrl.control = this;
  
//UI 컨트롤의 우클릭 시 표시되는 브라우저 기본 메뉴를 제한
//  document.oncontextmenu = function() {
//    return false;
//  };    

//  poCtrl.oncontextmenu = function() {
//    return false;
//  };
};
/**
 * 마우스버튼 우클릭을 체크합니다.
 * @param {eXria.event.Event} poEvent 윈도우 이벤트
 * @return 우클릭이 발생하였는지의 여부
 * @type Boolean
 */
eXria.controls.xhtml.UIControl.prototype.isRClick = function(poEvent) {   
  return (poEvent.mousebutton == 2) ? true : false;   
};
/**
 * 해당 컨트롤에서 이벤트가 발생하였는지 체크합니다.
 * @param {eXria.event.Event} poEvent 윈도우 이벤트
 * @param {String} psControlId 해당컨트롤 아이디
 * @return 해당컨트롤에서 이벤트가 발생하였는지의 여부
 * @type Boolean
 */
eXria.controls.xhtml.UIControl.prototype.inElement = function(poEvent, psControlId) {   
  var voCtrl = poEvent.target;
  while (voCtrl) {
    if(voCtrl.id == psControlId) { 
      return true;
    } else if(voCtrl.parentNode) {
      voCtrl = voCtrl.parentNode;
    } else {
      return false;
    }
  }   
};
/**
 * 컨텍스트메뉴를 원하는 좌표값에 보이게 합니다.
 * @param {Number} pnLeft 컨트롤 좌상단점의 left 위치
 * @param {Number} pnTop 컨트롤 좌상단점의 top 위치
 */
eXria.controls.xhtml.UIControl.prototype.showContextMenu = function(pnLeft, pnTop) {
  this.canvas.showContextMenu(this.id, this.contextMenuId, pnLeft, pnTop);
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.cofocus = function(e) {
  if(this.tooltip != "" && this.tooltip != null) {  
    this.tooltipHandler.hide(e);
    //if(this.displayTooltip) this.displayTooltip();
  }
  if(this.afFocusAct) {
    var voObj = this.afFocusAct;
    voObj.func.apply(this, voObj.args);
    this.afFocusAct = null;
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.coclick = function(e) {
  if(this.canvas) {
    var voCanvas = this.canvas;
    if(voCanvas.focusedControl != this && voCanvas.getControl(this.id) != null) voCanvas.setFocusByControl(this, null, e.target);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.finalclick = function(e) {
  if(this.canvas) {
    var voCanvas = this.canvas;
    if(!this.isRClick(e)) voCanvas.hideContextMenu();
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.comousedown = function(e) {
  if(this.document == null) return;
  var voCanvas = this.canvas;
  // 컨트롤 이동을 처리
  if(this.movable) {
    if(this.document.ondragstart !== "undefined")
    {
      this.document.ondragstart = function() { return false; };
    }
    this.startMove(e);
    e.stopEvent();
  } else if(this.dragDrop) {
    if(this.document.ondragstart !== "undefined")
    {
      this.document.ondragstart = function() { return false; };
    }
    this.startDrag(e);
    e.stopEvent();
  }else {
    if(voCanvas.page.metadata.browser.opera) {
    } else {
      this.document.ondragstart = function() { this.body.dragDrop(); };
    }
  }
//  // 컨텍스트 메뉴를 처리      
//  if (!this.inElement(e, this.id))
//     return true;     
//  if (!this.isRClick(e)) {
//     return true;
//  } else {
//    var posx=0,posy=0;
//    if(e.pageX || e.pageY) {
//      posx=e.pageX; posy=e.pageY;
//    } else if(e.clientX || e.clientY) {
//      if(document.documentElement.scrollTop) {
//        posx=e.clientX+document.documentElement.scrollLeft;
//        posy=e.clientY+document.documentElement.scrollTop;
//      } else {
//        posx=e.clientX+document.body.scrollLeft;
//        posy=e.clientY+document.body.scrollTop;
//      }
//    }
//    this.showContextMenu(posx,posy);
//    if(this.contextMenuId) e.stopEvent();       // TODO : 향후 변경할것   
//  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.comouseup = function(e) {
///// 2010.12.20 yjcho edit start
// GlassPane을 이용한 dragDrop 처리 시에 더 이상 불필요하여 주석 처리
//  if(this.dragDrop && this.sourceItem) {
//    var voCanvas = this.canvas;
//    this.dragDropHandler.hide(e);
//    voCanvas.dragDrop = false;
//    voCanvas.dragDropObject = null;
//    var voCanvasCtrl = voCanvas.getCtrl();
//    if(voCanvasCtrl) {
//      voCanvasCtrl.control = null;
//      voCanvasCtrl.onmousemove = voCanvas.oldmousemove;
//      voCanvasCtrl.onmouseup = voCanvas.oldmouseup;
//      voCanvas.oldmousemove = null;
//      voCanvas.oldmouseup = null;
//    }
//  }
///// 2010.12.20 yjcho edit end
};

/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.finalmouseup = function(e) {
  // 컨텍스트 메뉴를 처리      
  var voCanvas = this.canvas;
  var voDocument = this.document;
  voCanvas.doCollapseForAllFrame();
  if (!this.inElement(e, this.id))
     return;
  if (!this.isRClick(e)) {
     return;
  } else {
    var posx=0,posy=0;
    if(e.pageX || e.pageY) {
      posx=e.pageX; posy=e.pageY;
    } else if(e.clientX || e.clientY) {
      if(voDocument.documentElement.scrollTop) {
        posx=e.clientX + voDocument.documentElement.scrollLeft;
        posy=e.clientY + voDocument.documentElement.scrollTop;
      } else {
        posx=e.clientX + voDocument.body.scrollLeft;
        posy=e.clientY + voDocument.body.scrollTop;
      }
    }
    this.showContextMenu(posx,posy);
    if(this.contextMenuId) e.stopEvent();  
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.comouseover = function(e) {
  if(this.tooltipDisplay) {
    var voDocument = this.document;
    var posx=0,posy=0;
    if(e.pageX || e.pageY) {
      posx=e.pageX; posy=e.pageY;
    } else if(e.clientX || e.clientY) {
      if(voDocument.documentElement.scrollTop) {
        posx=e.clientX + voDocument.documentElement.scrollLeft;
        posy=e.clientY + voDocument.documentElement.scrollTop;
      } else {
        posx=e.clientX + voDocument.body.scrollLeft;
        posy=e.clientY + voDocument.body.scrollTop;
      }
    }
    var vnBottom = this.top + this.height;
    var vnRight = this.left + this.width;
    if(posy > this.top && posy < vnBottom && posx < vnRight && posx > this.left) {
      if(this.canvas.focusedControl === null)
	    this.tooltipHandler.hide(e);
	  else  
      	this.tooltipHandler.show(e);
    }
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.comouseout = function(e) {
	if(this.tooltipDisplay) this.tooltipHandler.hide(e);
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.comousemove = function(e) {
	if(!this.tooltipDisplay || this.canvas.focusedControl === this)
	    this.tooltipHandler.hide(e, this.document);
	else  
	  	this.tooltipHandler.show(e);      
};

/**
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.cokeydown = function(e) { 
    //this.tooltipHandler.hide(e);
};

/**
 * 이벤트 연결 브릿지 메소드.
 * @param {HTMLEvent} e 브라우저 이벤트
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.mediateEvent = function(e) {
  if(this.control == null) return;
//  try {
    var voControl = this.control;
    voControl.runEvent(e, voControl);
//  } catch(err) {}
};
/**
 * 실체화 컨트롤의 속성을 지정합니다(클래스 속성 값에 대한 갱신은 하지 않음).
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤(생략가능)
 */ 
eXria.controls.xhtml.UIControl.prototype.setAttrCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(); }
  var voStyle = poCtrl.style;
  
  if(psAttrValue == null) return;
  if(psAttrName == "visible") {
    if(psAttrValue == true) {
      voStyle.display = "block"
      if(this.cover) this.cover.style.display = "block";
    } else {
      voStyle.display = "none";
      if(this.cover) this.cover.style.display = "none";
    }
  } else if(psAttrName == "tooltip") {
    this.tooltipHandler.setCtrl();
  } else if(psAttrName == "cursor") {
    voStyle["cursor"] = psAttrValue;
  } else if(psAttrName == "borderWidth") {
    if(psAttrValue == "" || psAttrValue == null) {
      voStyle[psAttrName] = psAttrValue;
    } else {
      voStyle[psAttrName] = psAttrValue + "px";
    }
  } else if(psAttrName == "left" || psAttrName == "top" || psAttrName == "width" || psAttrName == "height") {
    if(psAttrValue == "" || psAttrValue == null) {
      voStyle[psAttrName] = psAttrValue;
    } else {
      if(psAttrValue < 0) psAttrValue = 0;
      voStyle[psAttrName] = psAttrValue + "px";
    }
  } else if(psAttrName == "fontSize") {
    if(psAttrValue != null && psAttrValue != "") {
      voStyle[psAttrName] = psAttrValue + "pt";
    } else if(psAttrValue == "") {
      voStyle[psAttrName] = "";
    }
  } else if(psAttrName == "color") {
    if(psAttrValue != null) {
      voStyle[psAttrName] = psAttrValue;
    }
  } else if(psAttrName == "backgroundPosition") {
    if(psAttrValue != null && psAttrValue != "") {
      voStyle[psAttrName] = psAttrValue + "pt";
    }
  } else if(psAttrName == "backgroundImage") {
		// AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
		// backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.
		if(psAttrValue.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
			var vsSplit = psAttrValue.split("\'");
			if(vsSplit[0] == "url(") 
				voStyle["filter"] = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[2] + "')";
			else
				voStyle["filter"] = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[1] + "')";		
		} else {
    	voStyle[psAttrName] = psAttrValue;			
		}
  } else if(voStyle[psAttrName] == undefined) {
    poCtrl[psAttrName] = psAttrValue;
  } else {
    voStyle[psAttrName] = psAttrValue;
  }
  if(poCtrl[psAttrName] != undefined) { poCtrl[psAttrName] = psAttrValue; }
  
  // Sub Ctrl이 있어 속성 값을 하위로 전달해야 되는 경우    
  if(this.setAttrSubCtrl) { this.setAttrSubCtrl(psAttrName, psAttrValue, poCtrl); } 
};   
/**
 * 실체화 컨트롤에 설정된 속성값(style 속성값 포함)을 참조.
 * @param {String} psAttrName 속성명
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return 실체화 컨트롤에 설정된 속성값
 * @type String
 */
eXria.controls.xhtml.UIControl.prototype.getAttrValueCtrl = function(psAttrName, poCtrl, poDocument) {
  var vsAttrValue = null;
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  if(poCtrl.style[psAttrName] == undefined) {
    vsAttrValue = poCtrl[psAttrName];          
  } else {    
    vsAttrValue = poCtrl.style[psAttrName];        
  }
  if(vsAttrValue == undefined) { vsAttrValue = null; }
  
  return vsAttrValue;
};
/**
 * 실체화 컨트롤의 속성을 제거.
 * @param {String} psAttrName 속성명
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 */ 
eXria.controls.xhtml.UIControl.prototype.removeAttrCtrl = function(psAttrName, poCtrl, poDocument) {
  if(poCtrl == null || poCtrl == undefined) { poCtrl = this.getCtrl(poDocument); }
  if(this[psAttrName] != null) { this[psAttrName] = null; }
  poCtrl.removeAttribute(psAttrName);    
};
/**
 * 기존에 설정된 UI의 공통 초기값을 제거.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.removeUIGeneralDefaults = function(poCtrl, poDocument) {
    //this.setAttrCtrl("display", "", poCtrl);
    //this.setAttrCtrl("zIndex", "", poCtrl);
    //this.setAttrCtrl("position", "", poCtrl);  
    //this.setAttrCtrl("color", "", poCtrl);
    //this.setAttrCtrl("backgroundColor", "", poCtrl); 
    //this.setAttrCtrl("borderWidth", "", poCtrl);
    //this.setAttrCtrl("borderStyle", "", poCtrl);
    //this.setAttrCtrl("borderColor", "", poCtrl);
    //this.setAttrCtrl("cursor", "", poCtrl);
    
    this.oldBorderWidth = null;
    this.oldBorderStyle = null;
    this.oldBorderColor = null;
};
/**
 * 컨트롤의 메인 css 스타일 클래스를 새로고침 하기 위한 메소드
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.refreshMainStyles = function(poCtrl, poDocument) {
  this.setMainCtrlStyles(poCtrl, poDocument);
};
/**
 * 컨트롤에 적용될 공통속성(css 스타일 적용가능 속성)의 초기값 설정을 새로고침.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */ 
eXria.controls.xhtml.UIControl.prototype.refreshUIGeneralDefaults = function(poCtrl, poDocument) {
  this.setUIGeneralDefaults(poCtrl, poDocument);
};
/**
 * 컨트롤별로 특화된 속성 설정을 새로고침.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.refreshSpecificDefaults = function(poCtrl, poDocument) {
  if(this.setSpecificDefaults)this.setSpecificDefaults(poCtrl, poDocument);
};

///**
// * 컨트롤에 적용될 공통속성(css 예외 속성)의 초기값 설정을 새로고침.
// * @param {HTMLDiv} poCtrl 실체화 컨트롤
// * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
// * @private
// */   
//eXria.controls.xhtml.UIControl.prototype.refreshUIGeneralAttrs = function(poCtrl, poDocument) {
//  this.setUIGeneralAttrs(poCtrl);
//};

/**
 * 컨트롤에서 수행할 이벤트 처리를 재설정.
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @ignore
 */  
eXria.controls.xhtml.UIControl.prototype.refreshUIGeneralEvents = function(poCtrl, poDocument) {
  this.setUIGeneralEvents(poCtrl);
};
/**
 * 컨트롤 활성화 여부 설정.
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {Boolean} psValue 컨트롤 disabled설정
 */
//eXria.controls.xhtml.UIControl.prototype.setDisable = function(poCtrl, psValue) {
//	this.disabled = psValue;
//  if(psValue == true){
//    if(poCtrl.disabled != undefined) poCtrl.disabled = psValue;
//    
//    if(poCtrl.childNodes) {
//      var voChild = null;
//      for(var i = 0; i < poCtrl.childNodes.length; i++) {
//        voChild = poCtrl.childNodes[i];
//        this.setDisable(voChild, psValue);
//      }    
//    }  
//  }else{
//    if(poCtrl.disabled != undefined) poCtrl.removeAttribute("disabled");
//    
//    if(poCtrl.childNodes) {
//      var voChild = null;
//      for(var i = 0; i < poCtrl.childNodes.length; i++) {
//        voChild = poCtrl.childNodes[i];
//        this.setDisable(voChild, psValue);
//      }    
//    }
//  }
//};
eXria.controls.xhtml.UIControl.prototype.setDisable = function(poCtrl, psValue) {
	this.disabled = psValue;
	var voDocument = this.document;
	var voParent = poCtrl.parentNode;
  var vnLeft = 0;
  
  if(psValue == true){
  	voDiv = this.lookup(this.id + "_cover");
    var voStyle = null;
    if(voDiv == null) {
      voDiv = voDocument.createElement("div");
			voDiv.className = "Default_Cover_OuterClass";
      voDiv.setAttribute("id", this.id + "_cover");
      voStyle = voDiv.style;
			if(this.position == null) this.position = this.getStyleCurrentValue(poCtrl, "position", "position");
      
//      voStyle.backgroundColor = eXria.controls.xhtml.Default.Cover["backgroundColor"];
      var vnZIndex = this.getAttrValue("zIndex", this.zIndex);
      if(vnZIndex == null) vnZIndex = this.getUIControlAttrValue("zIndex", this.zIndex);
      if(vnZIndex == null) vnZIndex = 0;
      voStyle.zIndex = vnZIndex + 1;
//      this.setOpacity(voDiv, eXria.controls.xhtml.Default.Cover["filter"], eXria.controls.xhtml.Default.Cover["opacity"]);
      voParent.appendChild(voDiv);
      this.cover = voDiv;
    }
    voStyle = voDiv.style;

    if(this.toString() === "Tab_TabHeader_TabButtons"){
      voStyle.position = "absolute";
      var vnTmpCnt = this.parent.parent.getIndexById(this.pageId);
      var vnTmp = poCtrl.style.borderLeftWidth.replace('px','') * 1 * 2 * vnTmpCnt;
      vnLeft = (poCtrl.style.width.replace('px','') * 1 * vnTmpCnt) + vnTmp;        
    }else{
     voStyle.position = this.position;
    } 
    voStyle.left = (vnLeft||this.left)+"px"; 

    voStyle.top = this.top + "px";
    voStyle.width = this.width + "px";
    voStyle.height = this.height + "px";
    if(this.visible == false) voStyle.display = "none";
  }else{
  	//voDiv = this.lookup(this.id + "_cover");
    voDiv = this.cover;
    this.cover = null;
    if(voDiv != null && voParent) voParent.removeChild(voDiv);
  }
};
/**
 * 실체화 객체의 커서 변경 하위 노드까지 포함.
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @param {String} psValue 커서 타입 구분 문자열
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setCursor = function(poCtrl, psValue) {
  var voStyle = poCtrl.style;
  if(voStyle) voStyle.cursor = psValue;
  
  if(poCtrl.childNodes) {
    var voChild = null;
    for(var i = 0; i < poCtrl.childNodes.length; i++) {
      voChild = poCtrl.childNodes[i];
      this.setCursor(voChild, psValue);
    }    
  }
};
/**
 * 불투명도를 설정.
 * @param {HTMLElement} poCtrl 실체화 객
 * @param {String} psFilter IE에 적용될 형식의 알파필터 스트링.<br>
 * ex) alpha(opacity:50)
 * @param {String} psOpacity 값의 범위 0 ~ 1.0
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setOpacity = function(poCtrl, psFilter, psOpacity) {
  var voStyle = poCtrl.style;
  if(psOpacity) {
	  var vnNumber = parseInt(parseFloat(psOpacity) * 100);
	  var vsFilter = "alpha(opacity=\"" + vnNumber + "\");";
	  voStyle.filter = vsFilter;  
  } 
  if(psOpacity) voStyle.KHTMLOpacity = psOpacity;
  if(psOpacity) voStyle.MozOpacity = psOpacity;
  if(psOpacity) voStyle.opacity = psOpacity;
};
/**
 * 스트링 버퍼에 불투명도 값을 설정하는 메소드.
 * @param {HTMLElement} poCtrl 실체화 객
 * @param {String} psFilter IE에 적용될 형식의 알파필터 스트링.<br>
 * ex) alpha(opacity:50)
 * @param {String} psOpacity 값의 범위 0 ~ 1.0
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setOpacityToCssStrBuf = function(paCssStrBuf, psFilter, psOpacity) {
  if(this.canvas.page.metadata.browser.ie > 0) {
    paCssStrBuf.push("filter:");
    paCssStrBuf.push(psFilter);
    paCssStrBuf.push(";");
  } else {
    //paCssStrBuf.push("KHTMLOpacity:");
    //paCssStrBuf.push(psOpacity);
    //paCssStrBuf.push(";");
    //paCssStrBuf.push("MozOpacity:");
    //paCssStrBuf.push(psOpacity);
    //paCssStrBuf.push(";");
    paCssStrBuf.push("opacity:");
    paCssStrBuf.push(psOpacity);
    paCssStrBuf.push(";");
  }
};
/**
 * 수직정렬 처리.
 * @param {HTMLElement} poCtrl 수직정렬 대상 Element
 * @param {HTMLElement} poParent 수직정렬 대상 Element 의 상위 Element
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setVerticalAlign = function(poCtrl, poParent, psVAlign) {

  if(poCtrl.offsetHeight !== 0)
   this.divOffsetHeight = poCtrl.offsetHeight;

  if(!this.divOffsetHeight)
   this.divOffsetHeight = 0;

   
  var vnHeight = this.divOffsetHeight;
  
  if(psVAlign == null) psVAlign = "middle";
  var vnParentHeight = poParent.style.height;
  if(vnParentHeight == "") vnParentHeight = "0";
  vnParentHeight = parseInt(vnParentHeight);
  var vnPadding = vnParentHeight - vnHeight;
  if(vnPadding < 0) vnPadding = 0;
  switch(psVAlign) {
  case "top" :
    poCtrl.style.top = "0px";
    poCtrl.style.bottom = "";
    break;
  case "bottom" :
    poCtrl.style.top = ""; //(vnParentHeight - vnPadding)
    poCtrl.style.bottom = "0px";
    break;
  case "middle" :
    var vnPadding = vnPadding / 2;
    if(vnParentHeight < vnHeight) vnPadding = 0;
    poCtrl.style.top = vnPadding + "px";
    poCtrl.style.bottom = "";
    break;
  }
};

/////////////////////////////////////////////////////////////////////////////
/**
 * @class Tooltip 처리 오브젝트 생성 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.UIControl} poParent Tooltip이 표시될 UI컨트롤 객체
 * @return Tooltip 처리 오브젝트
 * @type eXria.controls.xhtml.UIControl_tooltipHandler
 * @constructor
 * @ignore
 */
eXria.controls.xhtml.UIControl_tooltipHandler = function(poParent) {
  this.parent = poParent;
  this.rightBottomImage = null;//poParent.getTooltipAttrValue("rightBottomImage", this.rightBottomImage);
  this.leftBottomImage = null;//poParent.getTooltipAttrValue("leftBottomImage", this.leftBottomImage);
  this.rightTopImage = null;//poParent.getTooltipAttrValue("rightTopImage", this.rightTopImage);
  this.leftTopImage = null;//poParent.getTooltipAttrValue("leftTopImage", this.leftTopImage);
  this.borderWidth = null;
  this.borderStyle = null;
  this.borderColor = null;
  this.backgroundColor = null;
  this.fontSize = null;
  this.filter = null;
  this.opacity = null;
  this.width = null;
  this.height = null;
  this.data = new eXria.controls.DataRefNode(this.parent);
  this.fontFamily      = null;
  this.fontStyle       = null;
  this.fontWeight      = null;
  this.padding         = null;  
  this.paddingLeft     = null;
  this.paddingRight    = null;
  this.paddingTop      = null;  
  this.paddingBottom   = null;
  this.backgroundImage = null; 
  this.backgroundPosition = null;
  this.backgroundRepeat = null;	  
 
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_tooltipHandler.prototype.setCtrl = function() {    // 툴팁을 설정한다.  
  var voDocument = this.document
  var voParent = this.parent;
  var voTooltipCtrl = null;
  var voTooltipArrow = null;
  var voTooltipContent = null;
  
  var voData = this.data;
  var vsInstanceId = voData.instanceId;
  var vsRef = voData.instancePath;
//	if(voParent.id == "btn3") debugger
  if((voParent.tooltip != null && voParent.tooltip.length != 0) || (vsInstanceId && vsRef)) {    // 툴팁으로 사용할 내용이 있는 경우
    var voOldTooltip = null;
    voOldTooltip = voDocument.getElementById(voParent.id + "_Tooltip");
    var vsTooltip = null;
	
    if(vsInstanceId && vsRef) {
      vsTooltip = voData.getData();
    } else {
      vsTooltip = eXria.controls.xhtml.Util.parseLang(voParent.tooltip);	  
    }
		
    if(!voOldTooltip) {  // 기존에 생성한 툴팁이 없는 경우 새롭게 생성  
      voTooltipCtrl = voDocument.createElement("DIV");  // Create tooltip ctrl	  	  
      voTooltipCtrl.id = voParent.id + "_Tooltip";  
      var voStyle = voTooltipCtrl.style;
      voTooltipCtrl.style.position = "absolute";
      voTooltipCtrl.style.zIndex = 1000005;   
      //var voTooltipArrow = voDocument.createElement("IMG");
      //voTooltipArrow.id = voParent.id + "_TooltipArrow";	  
      //if(this.rightBottomImage) voTooltipArrow.src  = this.rightBottomImage;
			//voStyle = voTooltipArrow.style;
      voStyle.position = "absolute";
      voStyle.zIndex = 1000005;      
      //voTooltipCtrl.appendChild(voTooltipArrow);
      
      var voTempImage = new Image();
	  //this.rightBottomImage null check 최현종
	  if(this.rightBottomImage) { voTempImage.src = this.rightBottomImage; }
      
      voTooltipContent = voDocument.createElement("SPAN"); // Create content div */
      voStyle = voTooltipContent.style;
      voTooltipContent.id = voParent.id + "_TooltipContent";  
      //voTooltipContent.className = "tooltip_content";
			//var tooltipCSS = voParent.getCSSClass("ToolTip", 0);
			var tooltipCSS = "Default_UIControl_OuterClass Default_Form_ToolTip_OuterClass Default_Form_ToolTip_Class";
      voTooltipContent.className = tooltipCSS;
	  
			//alert("시작 : " + voStyle["fontSize"] + "" + voStyle["padding"]);
			var voCanvas = voParent.canvas;
				
			voParent.setAttrCtrl("fontFamily", voCanvas.tooltipHandler.fontFamily, voTooltipContent);
			voParent.setAttrCtrl("fontStyle", voCanvas.tooltipHandler.fontStyle, voTooltipContent);
			voParent.setAttrCtrl("fontWeight", voCanvas.tooltipHandler.fontWeight, voTooltipContent);
			voParent.setAttrCtrl("padding", voCanvas.tooltipHandler.padding, voTooltipContent);	  
			voParent.setAttrCtrl("paddingRight", voCanvas.tooltipHandler.paddingRight, voTooltipContent);
			voParent.setAttrCtrl("paddingTop", voCanvas.tooltipHandler.paddingTop, voTooltipContent);    
			voParent.setAttrCtrl("paddingBottom", voCanvas.tooltipHandler.paddingBottom, voTooltipContent);	 
			voParent.setAttrCtrl("borderWidth", voCanvas.tooltipHandler.borderWidth, voTooltipContent);
			voParent.setAttrCtrl("backgroundColor", voCanvas.tooltipHandler.backgroundColor, voTooltipContent);
			voParent.setAttrCtrl("fontSize", voCanvas.tooltipHandler.fontSize, voTooltipContent);
			voParent.setAttrCtrl("borderColor", voCanvas.tooltipHandler.borderColor, voTooltipContent);
			voParent.setAttrCtrl("borderStyle", voCanvas.tooltipHandler.borderStyle, voTooltipContent);
			voParent.setAttrCtrl("filter", voCanvas.tooltipHandler.filter, voTooltipContent);	  
			voParent.setAttrCtrl("opacity", voCanvas.tooltipHandler.opacity, voTooltipContent);	  
			voParent.setAttrCtrl("width", voCanvas.tooltipHandler.width, voTooltipContent);	  
			voParent.setAttrCtrl("height", voCanvas.tooltipHandler.height, voTooltipContent);	  	
			voParent.setAttrCtrl("backgroundImage", voCanvas.tooltipHandler.backgroundImage, voTooltipContent);	  
			voParent.setAttrCtrl("backgroundPosition", voCanvas.tooltipHandler.backgroundPosition, voTooltipContent);	  
			voParent.setAttrCtrl("backgroundRepeat", voCanvas.tooltipHandler.backgroundRepeat, voTooltipContent);
	  	
      voStyle.position = "absolute";
      voStyle.overflow = "visible";
      voStyle.wordBreak = "keep-all";
      voStyle.whiteSpace = "nowrap";      
      voStyle.top = "3px";
      voStyle.zIndex = 1000001;

			if(voTempImage) voStyle.left = voTempImage.width;
			if(voStyle.borderWidth) voStyle.left = voStyle.left - parseInt(voStyle.borderWidth);
	  
	  //else voStyle.left = voTempImage.width;
      
			
      voParent.setText(voTooltipContent, vsTooltip);
      voTooltipCtrl.appendChild(voTooltipContent);
      
      //voParent.setOpacity(voTooltipArrow, this.filter, this.opacity);     
      voParent.setOpacity(voTooltipContent, this.filter,  voCanvas.tooltipHandler.opacity); 
      
      voDocument.getElementById(voParent.canvas.id).appendChild(voTooltipCtrl);

      //this.width = voTooltipArrow.offsetWidth + voTooltipContent.offsetWidth;
      //this.height = voTooltipArrow.offsetHeight + voTooltipContent.offsetHeight;
      
      voTooltipCtrl.style.display = "none";
    } else {
      var voSpan = voParent.getSubCtrl("span", voOldTooltip);
      voParent.setText(voSpan, vsTooltip);
    }
  } else {  // 툴팁으로 사용할 내용이 없는 경우    
    var voOldTooltip = voDocument.getElementById(voParent.id + "_Tooltip");
    if(voOldTooltip) {  // 기존에 생성한 툴팁이 있는 경우 이를 삭제
      voDocument.getElementById(voParent.canvas.id).removeChild(voOldTooltip); 
    }        
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_tooltipHandler.prototype.modifyPosition = function(poTooltip) {
	var voDocument = this.document;
  var voParent = this.parent;
	
	//var voTooltipArrow = voDocument.getElementById(voParent.id + "_TooltipArrow");
	var voTooltipContent = voDocument.getElementById(voParent.id + "_TooltipContent");
	//voTooltipArrow.style.left = "0px";
	//voTooltipArrow.style.top = "0px";
	voTooltipContent.style.left = "1px";
	voTooltipContent.style.top = "1px";

//	alert(
//	"voParent.canvas.width : " + voParent.canvas.width
//	+"\n" + "poTooltip.offsetLeft : " + poTooltip.offsetLeft 	
//	+"\n" + "voTooltipContent.offsetWidth : " + voTooltipContent.offsetWidth
//	+"\n" + "voTooltipContent.offsetLeft : " + voTooltipContent.offsetLeft
//	+"\n" + "voParent.canvas.height : " + voParent.canvas.height
//	+"\n" + "poTooltip.offsetTop : " + poTooltip.offsetTop
//	+"\n" + "voTooltipContent.offsetHeight : " + voTooltipContent.offsetHeight
//	+"\n" + "voTooltipContent.offsetTop : " + voTooltipContent.offsetTop			
//	+"\n" + "==============================="
//	+"\n" + "viewportWidth : " + viewportWidth
//	+"\n" + "viewportHeight : " + viewportHeight
//	+"\n" + "horizontalScroll : " + horizontalScroll
//	+"\n" + "verticalScroll : " + verticalScroll	
//	)		
//
//	//poTooltip.style.left == poTooltip.offsetLeft
//	//voTooltipContent.style.left == voTooltipContent.offsetLeft
//	//debugger;
//	//window;
	
	// HTML 문서가 표시되는 화상 표시 영역인 뷰포트(viewport)의 크기
	// 이것은 브라우저 창 크기에서 메뉴바, 툴바, 스크롤바 등의 크기를 뺀 나머지
	var viewportWidth;
	var viewportHeight;
	
	// 다음의 값들은 수평, 수직 스크롤바의 위치를 나타내며, 문서 좌표와 창
	// 좌표를 상호 변환하는데 사용된다. 이 값들은 화면의 좌측 상단
	// 모서리에 문서의 어느 부분이 위치하는지 나타낸다.	
	//var horizontalScroll;
	//var verticalScroll;

	if(voParent.canvas.page.metadata.browser.ie){
		viewportWidth = this.document.documentElement.clientWidth;
		viewportHeight = this.document.documentElement.clientHeight;
		//horizontalScroll = this.document.documentElement.scrollLeft; 
		//verticalScroll = this.document.documentElemnet.scrollTop; 
	}else{
		viewportWidth = window.innerWidth;
		viewportHeight = window.innerHeight; 
		//horizontalScroll = window.pageXOffset; 
		//verticalScroll = window.pageYOffset;
	}
			
	//check horizontal position
	if(viewportWidth < poTooltip.offsetLeft+voTooltipContent.offsetWidth){
//		alert(
//		"poTooltip.offsetLeft : " + poTooltip.offsetLeft 	
//		+"\n" + "voTooltipContent.offsetWidth : " + voTooltipContent.offsetWidth			
//		+"\n" + "poTooltip.offsetLeft-voTooltipContent.offsetWidth : " + parseInt(poTooltip.offsetLeft-voTooltipContent.offsetWidth));
		poTooltip.style.left = parseInt(poTooltip.offsetLeft-voTooltipContent.offsetWidth-12)+"px";
	}	
	// check vertical position	
	if(viewportHeight < poTooltip.offsetTop+voTooltipContent.offsetHeight){
//		alert(
//		"poTooltip.offsetTop : " + poTooltip.offsetTop
//		+"\n" + "voTooltipContent.offsetHeight : " + voTooltipContent.offsetHeight		
//		+"\n" + "poTooltip.offsetTop-voTooltipContent.offsetHeight : " + parseInt(poTooltip.offsetTop-voTooltipContent.offsetHeight));
		poTooltip.style.top = parseInt(poTooltip.offsetTop-voTooltipContent.offsetHeight-10)+"px";
	}

};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_tooltipHandler.prototype.show = function(e) {
//  if(posy < this.top && posy > this.bottom && posx < this.right && posx > this.left) {
//     return false;
//  }
	if(!this.document) this.document = this.parent.document;
  var voDocument = this.document;
  var voParent = this.parent;
  var voTooltip = voDocument.getElementById(voParent.id + "_Tooltip");
  if(voTooltip) {
    var posx=0,posy=0;
    if(e.pageX || e.pageY) {
      posx=e.pageX; posy=e.pageY;
    } else if(e.clientX || e.clientY) {
      if(voDocument.documentElement.scrollTop) {
        posx=e.clientX + voDocument.documentElement.scrollLeft;
        posy=e.clientY + voDocument.documentElement.scrollTop;
      } else {
        posx=e.clientX + voDocument.body.scrollLeft;
        posy=e.clientY + voDocument.body.scrollTop;
      }
    }
    voTooltip.style.top = posy + 15 + "px";
    voTooltip.style.left = posx + 10 + "px";
    if(voTooltip.style.display == "none") {
      voTooltip.style.display = "block";
    }
    this.modifyPosition(voTooltip);
  }   
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_tooltipHandler.prototype.hide = function(e, poDocument) {
  var voDocument = this.document;
  if(poDocument) voDocument = poDocument;
  var voTooltip = voDocument.getElementById(this.parent.id + "_Tooltip");
  if(voTooltip) {
    if(voTooltip.style.display == "block") {
      voTooltip.style.display = "none";
    }
  }         
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_tooltipHandler.prototype.move = function(e) {
  var voDocument = this.document;
  var voTooltip = voDocument.getElementById(this.parent.id + "_Tooltip");
  if(voTooltip) {
    var posx=0,posy=0;
    if(e.pageX || e.pageY) {
      posx=e.pageX; posy=e.pageY;
    } else if(e.clientX || e.clientY) {
      if(voDocument.documentElement.scrollTop) {
        posx=e.clientX + voDocument.documentElement.scrollLeft;
        posy=e.clientY + voDocument.documentElement.scrollTop;
      } else {
        posx=e.clientX + voDocument.body.scrollLeft;
        posy=e.clientY + voDocument.body.scrollTop;
      }
    }
    voTooltip.style.top = posy + 15 + "px";
    voTooltip.style.left = posx + 10 + "px";
    
    this.modifyPosition(voTooltip);
  }    
};

/////////////////////////////////////////////////////////////////////////////
/**
 * @class 컨트롤의 이동 또는 크기 변경시에 윤곽선을 나타내주는 DIV 객체 생성 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.UIControl} poParent 이동할 UI컨트롤 객체
 * @return 컨트롤의 이동 또는 크기 변경시에 윤곽선을 나타내주는 DIV 객체
 * @type eXria.controls.xhtml.UIControl_paneHandler
 * @constructor
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler = function(poParent) {
  this.parent = poParent;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler.prototype.createPane = function(pnLeft, pnTop, pnWidth, pnHeight, poDocument) {
  var voDocument = poDocument;
  if(voDocument == null) voDocument = this.document;
  var voParent = this.parent;
  var voCtrl = voParent.getCtrl();
//  var voParentNode = voCtrl.parentNode;
  var voParentNode = voParent.glassPane.ctrl;
  var thisStyle = voCtrl.style;
  var voPane = voDocument.createElement("div");
  voPane.setAttribute("id", voParent.id + "_dragDrop");
  
  if(pnLeft == null && pnLeft !== 0) pnLeft = thisStyle.left;
  else pnLeft += "px";
  if(pnTop == null && pnTop !== 0) pnTop = thisStyle.top;
  else pnTop += "px";
  if(pnWidth == null && pnWidth !== 0) pnWidth = voParent.width;
  if(pnHeight == null && pnHeight !== 0) pnHeight = voParent.height;
  
  var voStyle = voPane.style;
  voStyle.position = "absolute";
  voStyle.left = pnLeft;
  voStyle.top = pnTop;
  var vnBorderWidth = voParent.borderWidth;
  if(voParent.borderStyle == null || voParent.borderStyle == "none") vnBorderWidth = 0;
  voStyle.width = (pnWidth - 2 * 1) + "px";
  voStyle.height = (pnHeight - 2 * 1) + "px";
  voStyle.backgroundColor = "yellow";
  voStyle.opacity = voParent.paneOpacity / 100;
  voStyle.filter = "alpha(opacity=" + voParent.paneOpacity + ")";
  voStyle.zIndex = 1000010; //Number(thisStyle.zIndex) + 1;
  voStyle.borderColor ="black";
  voStyle.borderStyle ="dotted";
  voStyle.borderWidth = "1px";
  // TODO : voStyle.display = "none";
  this.ctrl = voPane;
  voParentNode.appendChild(voPane);
  return voPane;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler.prototype.getStyle = function() {
  return this.ctrl.style;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler.prototype.getCtrl = function() {
  return this.ctrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler.prototype.removePane = function() {
  var voParent = this.parent;
  voParentNode = voParent.glassPane.ctrl;
  var voPaneCtrl = this.ctrl;
  voPaneCtrl.style.display = "none";
  voParentNode.removeChild(voPaneCtrl);
  if(this.scrAreaLeft) {
    this.scrAreaLeft.onmouseover = null;
    this.scrAreaLeft.style.display = "none";
    voParentNode.removeChild(this.scrAreaLeft);
  }
  if(this.scrAreaRight) {
    this.scrAreaRight.onmouseover = null;
    this.scrAreaRight.style.display = "none";
    voParentNode.removeChild(this.scrAreaRight);
  }
  if(this.scrAreaTop) {
    this.scrAreaTop.onmouseover = null;
    this.scrAreaTop.style.display = "none";
    voParentNode.removeChild(this.scrAreaTop);
  }
  if(this.scrAreaBottom) {
    this.scrAreaBottom.onmouseover = null;
    this.scrAreaBottom.style.display = "none";
    voParentNode.removeChild(this.scrAreaBottom);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler.prototype.applyAttrCtrl = function(psAttrName, psAttrValue) {
  var voPaneCtrl = this.ctrl;
  if(voPaneCtrl.style[psAttrName] == undefined) { 
    voPaneCtrl.setAttribute(psAttrName, psAttrValue); 
  } else { 
    voPaneCtrl.style[psAttrName] = psAttrValue; 
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_dragDropHandler.prototype.createScrollArea = function(pnLeft, pnTop, pnWidth, pnHeight, pnDropWidth, pnDropHeight, psPos, poDocument) {
  var voParent = this.parent;
  var voCtrl = voParent.getCtrl();
//  var voParentNode = voCtrl.parentNode;
  var voParentNode = voParent.glassPane.ctrl;
  var thisStyle = voCtrl.style;
  var voScrollArea = poDocument.createElement("div");
  voScrollArea.setAttribute("id", voParent.id + "_scrollArea_" + psPos);
  
  var voStyle = voScrollArea.style;
  voStyle.position = "absolute";
  voStyle.zIndex = 1000010; //Number(thisStyle.zIndex) + 1;
  var vnBorderWidth = voParent.borderWidth;
  if(voParent.borderStyle == null || voParent.borderStyle == "none") vnBorderWidth = 0;
  switch(psPos) {
  case "top" :
    voStyle.left = pnLeft;
    voStyle.top = pnTop;
    voStyle.width = (pnWidth - 2 * 1) + "px";
    voStyle.height = pnDropHeight + "px";
    this.scrAreaTop = voScrollArea;
    break;
  case "bottom" :
    voStyle.left = pnLeft;
    voStyle.top = (pnTop + pnHeight - pnDropHeight) + "px";
    voStyle.width = (pnWidth - 2 * 1) + "px";
    voStyle.height = pnDropHeight + "px";
    this.scrAreaBottom = voScrollArea;
    break;
  case "left" :
    voStyle.left = pnLeft + "px";
    voStyle.top = pnTop + "px";
    voStyle.width = pnDropWidth + "px";
    voStyle.height = (pnHeight - 2 * 1) + "px";
    this.scrAreaLeft = voScrollArea;
    break;
  case "right" :
    voStyle.left = (pnLeft + pnWidth - pnDropWidth) + "px";
    voStyle.top = pnTop + "px";
    voStyle.width = pnDropWidth + "px";
    voStyle.height = (pnHeight - 2 * 1) + "px";
    this.scrAreaRight = voScrollArea;
    break;
  }
//  voStyle.backgroundColor = "yellow";
//  voStyle.opacity = voParent.paneOpacity / 100;
//  voStyle.filter = "alpha(opacity=" + voParent.paneOpacity + ")";
//  voStyle.borderColor ="black";
//  voStyle.borderStyle ="dotted";
//  voStyle.borderWidth = "1px";
// TODO : voStyle.display = "none";
  voParentNode.appendChild(voScrollArea);
  return voScrollArea;
};
/////////////////////////////////////////////////////////////////////////////
/**
 * @class 컨트롤의 이동 또는 크기 변경시에 윤곽선을 나타내주는 DIV 객체 생성 클래스.
 * @version 1.0
 * @param {eXria.controls.xhtml.UIControl} poParent 이동할 UI컨트롤 객체
 * @return 컨트롤의 이동 또는 크기 변경시에 윤곽선을 나타내주는 DIV 객체
 * @type eXria.controls.xhtml.UIControl_paneHandler
 * @constructor
 * @ignore
 */
eXria.controls.xhtml.UIControl_paneHandler = function(poParent) {
  this.parent = poParent;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_paneHandler.prototype.createPane = function() {
  var voDocument = this.document;
  var voParent = this.parent;
  var voCtrl = voParent.getCtrl();
//  var voParentNode = voCtrl.parentNode;
  var voParentNode = voParent.glassPane.ctrl;
  var thisStyle = voCtrl.style;
  var voPane = voDocument.createElement("div");
  voPane.setAttribute("id", voParent.id + "_pane");

  var voStyle = voPane.style;
  voStyle.position = "absolute";
  voStyle.left = thisStyle.left;
  voStyle.top = thisStyle.top;
  var vnBorderWidth = voParent.borderWidth;
  if(voParent.borderStyle == null || voParent.borderStyle == "none") vnBorderWidth = 0;
  voStyle.width = (voParent.width - 2 * 1) + "px";
  voStyle.height = (voParent.height - 2 * 1) + "px";
  voStyle.backgroundColor = "yellow";
  voStyle.opacity = voParent.paneOpacity / 100;
  voStyle.filter = "alpha(opacity=" + voParent.paneOpacity + ")";
  voStyle.zIndex = 1000010; //Number(thisStyle.zIndex) + 1;
  voStyle.borderColor ="black";
  voStyle.borderStyle ="dotted";
  voStyle.borderWidth = "1px";
  // TODO : voStyle.display = "none";
  voParentNode.appendChild(voPane);
  return voPane;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_paneHandler.prototype.getStyle = function() {
  var voPane = this.document.getElementById(this.parent.id + "_pane");
  return voPane.style;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_paneHandler.prototype.getCtrl = function() {
  var voPaneCtrl = this.document.getElementById(this.parent.id + "_pane");
  return voPaneCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_paneHandler.prototype.removePane = function() {
  var voParent = this.parent;
//  var voParentNode = voParent.getCtrl().parentNode;
  voParentNode = voParent.glassPane.ctrl;
  var voPaneCtrl = voParent.paneHandler.getCtrl();
  voPaneCtrl.style.display = "none";
  voParentNode.removeChild(voPaneCtrl);
};
/**
 * @ignore
 */
eXria.controls.xhtml.UIControl_paneHandler.prototype.applyAttrCtrl = function(psAttrName, psAttrValue) {
  var voPaneCtrl = this.parent.paneHandler.getCtrl();
  if(voPaneCtrl.style[psAttrName] == undefined) { 
    voPaneCtrl.setAttribute(psAttrName, psAttrValue); 
  } else { 
    voPaneCtrl.style[psAttrName] = psAttrValue; 
  }      
};
/**
 * 공통 초기화 수행 메소드
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.initUIGeneral = function() {
  //this.tooltipHandler.parent = this;    // tooltipHandler에 컨트롤 참조를 설정
  this.tooltipHandler = new eXria.controls.xhtml.UIControl_tooltipHandler(this);
  this.paneHandler = new eXria.controls.xhtml.UIControl_paneHandler(this);
  this.dragDropHandler = new eXria.controls.xhtml.UIControl_dragDropHandler(this);
};
/**
 * Style 속성 스트링 버퍼에 속성 추가 메소드
 * @param {Array} paCssStrBuf Style 스트링 버퍼
 * @param {String} psName 스타일 속성명
 * @param {String} psValue 스타일 속성값
 * @parem {String} psUnit 수치형 속성값의 단위
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setCssStrBuf = function(paCssStrBuf, psName, psValue, psUnit) {
  if(psValue != null) {
    paCssStrBuf.push(psName);
    paCssStrBuf.push(":");
    paCssStrBuf.push(psValue);
    if(psUnit) paCssStrBuf.push(psUnit);
    paCssStrBuf.push(";");
  }
};
/**
 * Element 속성 스트링 버퍼에 속성 추가 메소드
 * @param {Array} paAttStrBuf Element 속성 스트링 버퍼
 * @param {String} psName Element 속성명
 * @param {String} psValue Element 속성값
 * @parem {String} psUnit 수치형 속성값의 단위
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setAttStrBuf = function(paAttStrBuf, psName, psValue, psUnit) {
  if(psValue != null) {
    paAttStrBuf.push(psName);
    paAttStrBuf.push("=\"");
    paAttStrBuf.push(psValue);
    if(psUnit) paAttStrBuf.push(psUnit);
    paAttStrBuf.push("\" ");
  }
};
/**
 * 이벤트 핸들러를 정의하는 문자열을 반환합니다.
 * @param {String} psId 컨트롤 id
 * @param {String} psFuncName 이벤트 핸들러 내부에서 호출되는 working 메소드 명
 * @return 이벤트 핸들러를 정의하는 문자열
 * @type String
 */
eXria.controls.xhtml.UIControl.prototype.getEHandler = function(psId, psFuncName) {
  var vaStrBuf = [];
  //vaStrBuf.push("var e=null;");
  //vaStrBuf.push("if(arguments[0]) e=arguments[0];");
  vaStrBuf.push("page.getControl('");
  vaStrBuf.push(psId);
  vaStrBuf.push("').");
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("(event);");
  
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};

/**
 * 이벤트 핸들러를 정의하는 문자열을 반환합니다.
 * @param {String} psId 컨트롤 id
 * @param {String} psItemId 컨트롤에 속해있는 ItemList중 선택된 Item Id
 * @param {String} psFuncName 이벤트 핸들러 내부에서 호출되는 working 메소드 명
 * @return 이벤트 핸들러를 정의하는 문자열
 * @type String
 */
eXria.controls.xhtml.UIControl.prototype.getEItemHandler = function(psId, psItemId, psFuncName) {
  var vaStrBuf = [];
  //vaStrBuf.push("var e=null;");
  //vaStrBuf.push("if(arguments[0]) e=arguments[0];");

  vaStrBuf.push("page.getControl('");
  vaStrBuf.push(psId);
  vaStrBuf.push("').");
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("(event,'");
  vaStrBuf.push(psItemId);
  vaStrBuf.push("');");
  
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * 컨트롤 이동 관련
 * @return  0
 * @type Number
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.getClientAbsLeft = function() { return 0; };
/**
 * 컨트롤 이동 관련
 * @return  0
 * @type Number
 * @ignore
 */
eXria.controls.xhtml.UIControl.prototype.getClientAbsTop = function() { return 0; };
/**
 * 컨트롤의 동적 위치 이동 허용여부를 지정합니다.
 * @param {Boolean} pbMove 위치이동 가능 여부
 */     
eXria.controls.xhtml.UIControl.prototype.setMove = function(pbMove) {
  var voCtrl = this.getCtrl();
  if(voCtrl == null) return;    
  
  if(pbMove) {
    this.movable = true;      
  } else {
    this.movable = false;
  }
};
/**
 * startMove<br>
 * 컨트롤 동적 위치 이동이 가능한 경우 컨트롤에 mousedown이벤트 발생 시 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.startMove = function(e) {
  if (this.disabled == true) { return; }
  
  var voDocument = this.document;
  var voParent = this.parent;
  if(voParent == null) voParent = this.canvas;
  var voCtrl = this.getCtrl();
  
  var voGlassPane = new eXria.controls.xhtml.GlassPane(voParent);
  this.glassPane = voGlassPane;
  voGlassPane.opacity = 10;
  voParent.ctrl.parentNode.appendChild(voGlassPane.create(voDocument));
  
  var voPane = this.paneHandler.createPane();
  var voPaneStyle = voPane.style;
  
  var voEvent = e;
  var voTarget = voEvent.target;
  this.mode = voTarget.style.cursor;

  this.clientAbsLeft = this.getClientAbsLeft();
  this.clientAbsTop = this.getClientAbsTop();

  var vnMouseX = voEvent.e.clientX - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY - this.clientAbsTop;   

  var vnPaneLeft = parseInt(voPaneStyle.left);
  var vnPaneTop = parseInt(voPaneStyle.top);
  this.leftOffset = vnPaneLeft - vnMouseX;
  this.topOffset = vnPaneTop - vnMouseY;
  
  this.backupCtrlCsr = this.getCtrl().style.cursor;
  voPaneStyle.display = "block";
  voDocument.body.style.cursor = "move";
  this.getCtrl().style.cursor = "move";

  voPane.control = this;
  voPane.onmousemove = function(e) {
    this.control.onMove(e);
  };
  voPane.onmouseup = function(e) {
    this.control.stopMove(e);
  };
  voDocument.control = this;
  voDocument.onmousemove = function(e) {
    //this.getEHandler(this.id, "onMove");
    this.control.onMove(e);
  };
  voDocument.onmouseup = function(e) {
    //this.getEHandler(this.id, "stopMove");
    this.control.stopMove(e);
  };
  if (typeof voPane.onselectstart != "undefined") {
    voPane.onselectstart = function(e) {
      return false;
    };
  } else {
    voPane.onmousedown = function(e) {
      return false;
    };
  }
};
/**
 * 컨트롤 동적 위치 이동 시 마우스 드래그 상태에서의 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.onMove = function(e) {
  var voCtrl = this.getCtrl();
  var voParentNode = voCtrl.parentNode;
  var voPaneCtrl = this.paneHandler.getCtrl();
  if(voCtrl == null || voPaneCtrl == null) {
      return;
  }

  var voStyle = voPaneCtrl.style;

  var voEvent = new eXria.event.Event(e, this.window);
  var voTarget = voEvent.target;
  if(voTarget == voPaneCtrl || voTarget == voPaneCtrl.parentNode) {
  } else {
    return;
  }
  var vnMouseX = voEvent.e.clientX; // - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY; // - this.clientAbsTop;

  var vnNewLeft = vnMouseX + this.leftOffset;
  var vnNewTop = vnMouseY + this.topOffset;
 
  if(voParentNode.style.left == null || voParentNode.style.left == "") voParentNode.style.left = 0;
  if(voParentNode.style.top == null || voParentNode.style.top == "") voParentNode.style.top = 0;
//  voStyle.left = vnNewLeft - parseInt(voParentNode.style.left) + "px";
//  voStyle.top = vnNewTop - parseInt(voParentNode.style.top) + "px"; 
  voStyle.left = vnNewLeft + "px";
  voStyle.top = vnNewTop + "px";
};
/**
 * 컨트롤 동적 위치 이동 시 mouseup 이벤트에서의 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */      
eXria.controls.xhtml.UIControl.prototype.stopMove = function(e) {
  if (this.disabled == true) { return; }

  var voDocument = this.document;
  var voCtrl = this.getCtrl();
  var voPane = this.paneHandler.getCtrl();
  var voPaneStyle = voPane.style;

  this.left = parseInt(voPaneStyle.left);
  this.top = parseInt(voPaneStyle.top);
  this.refresh();  
  this.paneHandler.removePane();
  this.glassPane.removeCtrl();
  // Check
  voDocument.body.style.cursor = "auto";
  voCtrl.style.cursor = this.backupCtrlCsr;
          
  voPane.onmousemove = null;
  voPane.onmouseup = null;
  voDocument.onmousemove = null;
  voDocument.onmouseup = null;
  if (typeof voPane.onselectstart != "undefined") {
    voPane.onselectstart = null;
  } else {
    voPane.onmousedown = null;
  }
  
  this.mode = null;
  this.leftOffset = -1;
  this.topOffset = -1;
  this.rightOffset = -1;
  this.bottomOffset = -1;
};
/**
 * startDrag<br>
 * 컨트롤 Drag&Drop이 가능한 경우 컨트롤에 mousedown이벤트 발생 시 처리 수행
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.startDrag = function(e) {
  if (this.disabled == true) { return; }
  
  var voDocument = this.document;
  var voParent = this.parent;
  if(voParent == null) voParent = this.canvas;
  var voCtrl = this.ctrl;
  
  var voGlassPane = new eXria.controls.xhtml.GlassPane(voParent);
  this.glassPane = voGlassPane;
  voGlassPane.opacity = 50;
  voParent.ctrl.parentNode.appendChild(voGlassPane.create(voDocument));
  
  this.dragDropHandler.srcObject = this;
  this.dragDropHandler.srcObjectType = null;
  var voPaneCtrl = this.dragDropHandler.createPane();
  var voPaneStyle = voPaneCtrl.style;
  
  var voEvent = e;
  var voTarget = voEvent.target;
  this.mode = voTarget.style.cursor;

  this.clientAbsLeft = this.getClientAbsLeft();
  this.clientAbsTop = this.getClientAbsTop();

  var vnMouseX = voEvent.e.clientX - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY - this.clientAbsTop;   

  var vnPaneLeft = parseInt(voPaneStyle.left);
  var vnPaneTop = parseInt(voPaneStyle.top);
  this.leftOffset = vnPaneLeft - vnMouseX;
  this.topOffset = vnPaneTop - vnMouseY;
  
  voPaneStyle.display = "block";
  voDocument.body.style.cursor = "move";
  this.getCtrl().style.cursor = "move";

  voPaneCtrl.control = this;
  voPaneCtrl.onmousemove = function(e) {
    this.control.onDrag(e);
  };
  voPaneCtrl.onmouseup = function(e) {
    this.control.stopDrag(e);
  };
  voDocument.control = this;
  voDocument.onmousemove = function(e) {
    this.control.onDrag(e);
  };
  voDocument.onmouseup = function(e) {
    this.control.stopDrag(e);
  };
  if (typeof voPaneCtrl.onselectstart != "undefined") {
    voPaneCtrl.onselectstart = function(e) {
      return false;
    };
  } else {
    voPaneCtrl.onmousedown = function(e) {
      return false;
    };
  }
};
/**
 * 컨트롤 Drag&Drop 시 마우스 드래그 상태에서의 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.onDrag = function(e) {
  var voCtrl = this.getCtrl();
  var voPaneCtrl = this.dragDropHandler.ctrl;
  if(voCtrl == null || voPaneCtrl == null) {
      return;
  }

  var voStyle = voPaneCtrl.style;
  var voEvent = new eXria.event.Event(e, voPaneCtrl.document.parentWindow);
  var voTarget = voEvent.target;
  if(voTarget == voPaneCtrl || voTarget == voPaneCtrl.parentNode) {
  } else {
    return;
  }
  var vnMouseX = voEvent.e.clientX; // - this.clientAbsLeft;
  var vnMouseY = voEvent.e.clientY; // - this.clientAbsTop;

  var vnNewLeft = vnMouseX + this.leftOffset;
  var vnNewTop = vnMouseY + this.topOffset;
 
	voStyle.left = vnNewLeft + "px";
  voStyle.top = vnNewTop + "px";
};
/**
 * 컨트롤 Drag&Drop 시 mouseup 이벤트에서의 처리 수행.
 * @param {HTMLEvent} e 윈도우이벤트
 * @private
 */      
eXria.controls.xhtml.UIControl.prototype.stopDrag = function(e) {
  if (this.disabled == true) { return; }

  var voDocument = this.document;
  var voCtrl = this.ctrl;
  var voPaneCtrl = this.dragDropHandler.ctrl;
  voDocument = voPaneCtrl.document;
  var voEvent = new eXria.event.Event(e, voDocument.parentWindow);
  this.dragDropHandler.removePane();
  this.glassPane.removeCtrl();
  // Check
  voDocument.body.style.cursor = "auto";
  voCtrl.style.cursor = "auto";
          
  voPaneCtrl.onmousemove = null;
  voPaneCtrl.onmouseup = null;
  voDocument.onmousemove = null;
  voDocument.onmouseup = null;
  if (typeof voPaneCtrl.onselectstart != "undefined") {
    voPaneCtrl.onselectstart = null;
  } else {
    voPaneCtrl.onmousedown = null;
  }
  
  this.mode = null;
  this.leftOffset = -1;
  this.topOffset = -1;
  this.rightOffset = -1;
  this.bottomOffset = -1;
  
  var vcCtl = this.glassPane.getControlByEvent(voEvent);
  if(vcCtl == null) return;
  var voEventObject = vcCtl;
  if(vcCtl.getItemByPos) {
    voEventObject = vcCtl.getItemByPos(voEvent.clientX, voEvent.clientY);
    if(voEventObject) voEvent.objectType = "item";
  }
  if(vcCtl.onDrop) {
    voEvent.srcObject = this.dragDropHandler.srcObject;
    voEvent.srcObjectType = this.dragDropHandler.srcObjectType;
    voEvent.object = voEventObject;
    vcCtl.onDrop(voEvent);
  }
  this.dragDropHandler.srcObject = null;
  this.dragDropHandler.srcObjectType = null;
};
/**
 * 포커스 변경에 따른 style 변경 처리
 * @param {Boolean} pbFocus 포커스 in/out 여부
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.setFocusStyle = function(pbFocus) {
  var voCtrl = this.getCtrl();
  var voStyle = voCtrl.style;
  if(this.oldBorderWidth == null) {
    this.oldBorderWidth = voStyle.borderWidth;
    this.oldBorderStyle = voStyle.borderStyle;
    this.oldBorderColor = voStyle.borderColor;
  }    
  if(pbFocus && this.focusDisplay) {
    var vsFocusBorderWidth = this.getUIControlAttrValue("focusBorderWidth", this.focusBorderWidth);
    if(vsFocusBorderWidth != null) {
      if(vsFocusBorderWidth == "auto") {
        voStyle.borderWidth = this.getUIControlAttrValue("borderWidth", this.borderWidth);
//        voStyle.borderWidth = this.oldBorderWidth;
      } else {
        voStyle.borderWidth = vsFocusBorderWidth + "px";
      }
    }
    voStyle.borderStyle = this.getUIControlAttrValue("focusBorderStyle", this.focusBorderStyle);
    voStyle.borderColor = this.getUIControlAttrValue("focusBorderColor", this.focusBorderColor);   
  } else {
    voStyle.borderWidth = "";
    voStyle.borderStyle = "";
    voStyle.borderColor = "";
    if(this.oldBorderWidth) voStyle.borderWidth = this.oldBorderWidth;
    if(this.oldBorderStyle) voStyle.borderStyle = this.oldBorderStyle;
    if(this.oldBorderColor) voStyle.borderColor = this.oldBorderColor;      
  }
}; 
/**
 * UI 공통 속성의 디폴트 값을 구함.
 * @param {String} psAttrName 속성명
 * @return 해당 속성의 디폴트 값
 * @type String
 * @private
 */   
eXria.controls.xhtml.UIControl.prototype.getUIControlDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.UIControl[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;    
};
/**
 * 사용자 할당 값,css, canvas, UISpecific, UIDefault에서 우선순위에 따라 속성값을 가져오는 메소드.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 디폴트 속성값
 * @type String
 */
eXria.controls.xhtml.UIControl.prototype.getAttrValue = function(psAttrName, psAttrValue) {
  if(psAttrValue != null) { 
    return psAttrValue;
  } else { 
    var vsAttrValue = null;
    //if(this.canvas)  vsAttrValue = this.canvas.getFormExtendAttrValue(psAttrName);
    if(vsAttrValue != null) {
      return vsAttrValue;
    } else {
      vsAttrValue = this.getSpecificDefaultValue(psAttrName);  // TODO : 위의 소스로 교체할것
      if(vsAttrValue == null) vsAttrValue = this.getUIControlDefaultValue(psAttrName);
      return vsAttrValue;
    }
  }
};
/**
 * UI 공통 속성에 적용되는 실제값을 구함.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성에 적용되는 실제값
 * @type String
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.getUIControlAttrValue = function(psAttrName, psAttrValue) {  
  if(psAttrValue != null) { 
    return psAttrValue;
  } else { 
    var vsAttrValue = this.canvas.getFormExtendAttrValue(psAttrName);
    if(vsAttrValue != null) {
      return vsAttrValue;
    } else {
      return this.getUIControlDefaultValue(psAttrName);
    }
  }
};
/**
 * 개별 UI 속성에 적용되는 실제값을 구함.
 * @param {String} psAttrName 속성명
 * @return 해당 속성에 적용되는 실제값
 * @type String
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.getSpecificAttrValue = function(psAttrName, psAttrValue) {  
  if(psAttrValue != null) { 
    return psAttrValue;
  } else { 
    var vsAttrValue = this.canvas.getFormExtendAttrValue(psAttrName);
    if(vsAttrValue != null) {
      return vsAttrValue;
    } else {
      return this.getSpecificDefaultValue(psAttrName);  // TODO : 위의 소스로 교체할것       
    }
  }
};
/**
 * toolip의 디폴트 값을 구함. 
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 toolip 디폴트 값
 * @type String
 * @private
 */   
eXria.controls.xhtml.UIControl.prototype.getTooltipAttrValue = function(psAttrName, psAttrValue) {
  if(psAttrValue != null) return psAttrValue;
  else return this.getTooltipDefaultValue(psAttrName);
};
/**
 * toolip의 공통 디폴트 값을 구함. 
 * @param {String} psAttrName 속성명 
 * @return 해당 속성의 toolip 공통 디폴트 값
 * @type String
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.getTooltipDefaultValue = function(psAttrName) {
  //var vsDefaultValue = eXria.controls.xhtml.Default.ToolTip[psAttrName];
  var vsDefaultValue = eXria.controls.xhtml.Default.Form.Tooltip[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;    
};
/**
 * dragDrop의 속성 값을 구함. 
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 해당 속성의 toolip 디폴트 값
 * @type String
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.getDragDropAttrValue = function(psAttrName, psAttrValue) {
  if(psAttrValue != null) return psAttrValue;
  else return this.getDragDropDefaultValue(psAttrName);
};
/**
 * dragDrop의 디폴트 값을 구함.
 * @param {String} psAttrName 속성명 
 * @return 해당 속성의 toolip 공통 디폴트 값
 * @type String
 * @private
 */  
eXria.controls.xhtml.UIControl.prototype.getDragDropDefaultValue = function(psAttrName) {
  if(eXria.controls.xhtml.Default.UIControl.dragDrop == null) return null;
  var vsDefaultValue = eXria.controls.xhtml.Default.UIControl.dragDrop[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;    
};  
/**
 * 컨트롤이 page에 load 될때의 처리 수행.
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.load = function(poDocument) {
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  if(this.data && this.loadData) this.loadData(poDocument);
  if(this.loadComplete) this.loadComplete(poDocument);
  this.loaded = true;
  
  var voCtrl = this.getCtrl(poDocument);
	if(this.disabled) this.setDisable(voCtrl, this.disabled);
//	this.hideFocusLine(voCtrl, true);
};
/**
 * 컨트롤에 데이타 로딩 작업 수행.
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.loadData = function() {};
/**
 * 컨트롤이 page에 load 될때 Canvas 객체의 속성을 참조해야될 작업 수행
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.loadCanvasConfig = function() {
  var voDocument = this.document;
  var voTooltipHandler = this.tooltipHandler;
  voTooltipHandler.document = voDocument;
  this.paneHandler.document = voDocument;
  this.dragDropHandler.document = voDocument;
  
  if(this.canvas && ((this.tooltip != null && this.tooltip.length != 0) || (voTooltipHandler.data.instanceId && voTooltipHandler.data.instancePath))) {
    this.tooltipHandler.setCtrl();
//    this.tooltipHandler.backgroundImage = "url('" + this.canvas.page.metadata.resourceBaseUrl + this.getTooltipAttrValue("backgroundImage", this.tooltipHandler.backgroundImage) + "')";
//    document.getElementById(this.id + "_TooltipArrow").style.backgroundImage = "url('" + this.canvas.page.metadata.resourceBaseUrl + "eXria/controls/xhtml/images/arrow.gif')";
  }
};
/**
 * 새로고침 최종 처리
 * @param {HTMLDiv} voCtrl 실체화 객체 최외곽 Div
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */   
eXria.controls.xhtml.UIControl.prototype.refreshComplete = function(poCtrl, poDocument) {
  if(this.loadCanvasConfig) this.loadCanvasConfig(poDocument);
  this.setDisable(poCtrl, this.disabled);
  this.hideFocusLine(poCtrl, true);
}; 

/**
 * 서브 컨트롤 실체화 객체를 얻어온다.
 * @param {String} psTagName
 * @return subControl
 * @type HTMLElement
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.getSubCtrl = function(psTagName, poCtrl, poDocument, pnIndex) {
  if(poCtrl == null) { poCtrl = this.getCtrl(poDocument); }
  var vnIndex = 0;
  if(pnIndex != null) vnIndex = pnIndex;
  var voSubCtrl = null;
  voSubCtrl = poCtrl.getElementsByTagName(psTagName)[vnIndex];
  return voSubCtrl;
};

/**
 * 지정된 속성 값을 갖는 dom element를 저장하는 배열 객체를 반환하는 메소드
 * @param {Array(HTMLElement)} paCtrl 검색 대상 dom elements
 * @param {String} psAttr 검색할 속성명
 * @param {String} psValue 검색할 값
 * @return 검색 대상 속성값을 갖는 dom elements
 * @type Array(HTMLElement)
 * public
 */
eXria.controls.xhtml.UIControl.prototype.getElementsByAttr = function(paCtrl, psAttr, psValue) {
  var vaRet = [];
  var vnSize = paCtrl.length;
  var voCtrl = null;
  for(var i = 0; i < vnSize; i++) {
    voCtrl = paCtrl[i];
    if(voCtrl.getAttribute(psAttr) == psValue) {
      vaRet.push(voCtrl);
    }
  }
  return vaRet;
};
/**
 * 실체화 객체 focus시 점선제거
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.hideFocusLine = function(poCtrl, pbSubElement) {
	pbSubElement = pbSubElement || false;

	if(poCtrl.tabIndex != undefined){
  	poCtrl.hideFocus = true;
  	poCtrl.style.outlineStyle = "none";
	}
	
	if(pbSubElement === true && poCtrl.childNodes) {
    var voChild = null;
    for(var i = 0; i < poCtrl.childNodes.length; i++) {
      voChild = poCtrl.childNodes[i];
      this.hideFocusLine(voChild, true);
    }
  }
};
/**
 * CSS Class 명을 반환한다.
 * @param poCtrl
 * @param pnType 0 : OuterClass, 1 : Class, 2 : OuterClass & Class
 * @return String
 */
eXria.controls.xhtml.UIControl.prototype.getCSSClass = function(poCtrl, pnType, psSubClass){
	var vsPreFix = "Default";
	var vsType = "";
	if(poCtrl !== null) vsType = "_" + poCtrl.toString();
	if(pnType === null || pnType === undefined) pnType = 0;
	var vsSubClass = "";
	var voClassObj = this;
	var vaSubObj = null;
	if(psSubClass){
		voClassObj = voClassObj[psSubClass];
		vsSubClass = "_" + psSubClass.split(".").join("_");
	}
		
	var vsUIControlClass = "";
	if(pnType == 2) {
	  vsUIControlClass = vsPreFix + "_UIControl_OuterClass " + vsPreFix + "_UIControl_Class";
	} else {
	  vsUIControlClass = vsPreFix + "_UIControl_" + ["OuterClass", "Class"][pnType];
	}
	var vsControlClass = "";
	if(this.control){
		if(pnType == 2) {
		  vsControlClass = vsPreFix + "_" + this.control.toString() + vsType + "s" + vsSubClass + "_OuterClass "
		                + vsPreFix + "_" + this.control.toString() + vsType + "s" + vsSubClass + "_Class"
		} else {
		  vsControlClass = vsPreFix + "_" + this.control.toString() + vsType + "s" + vsSubClass + "_" + ["OuterClass", "Class"][pnType];
		}
	}else{
	  if(pnType == 2) {
	    vsControlClass = vsPreFix + vsType + vsSubClass + "_OuterClass "
	                  + vsPreFix + vsType + vsSubClass + "_Class";
	  } else {
	    vsControlClass = vsPreFix + vsType + vsSubClass + "_" + ["OuterClass", "Class"][pnType];
	  }
	}
	
	var vsUserClass = null;
	if(pnType === 0 && voClassObj != null){
		if(voClassObj.outerClassName) vsUserClass = voClassObj.outerClassName;
	} else if(pnType === 1 && voClassObj != null) {
		if(voClassObj.className) vsUserClass = voClassObj.className;
	} else if(pnType === 2 && voClassObj != null) {
	  if(voClassObj.outerClassName) vsUserClass = voClassObj.outerClassName;
	  if(voClassObj.className) {
	    if(vsUserClass != null) vsUserClass += " " + voClassObj.className;
	    else vsUserClass = voClassObj.className;
	  }
	}

	
	if(vsUserClass == null){ 
		vsUserClass = "";
	}
	
	if(vsUserClass == (vsControlClass + " ") || vsUserClass == vsControlClass) {
		vsUserClass = null; vsUserClass = "";
	}
	return vsSubClass == "" ? vsUIControlClass + " " + vsControlClass + " " + vsUserClass : vsControlClass + " " + vsUserClass;
};
/**
 * CSS로 적용된 style의 값을 반환한다.
 * @param {Object} poElement HTMLElement
 * @param {Object} psProp Style Property
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.getStyleCurrentValue = function(poElement, psCSSProp, psJSProp){
	if(poElement.currentStyle){ // IE, Opera
		return poElement.currentStyle[psJSProp];
	}else if(window.getComputedStyle && poElement.tagName != null){
		if(this.window.document.defaultView){ // Firefox, Mozilla, Navigator
			return this.window.document.defaultView.getComputedStyle(poElement, null).getPropertyValue(psCSSProp);
		}else{ // Safari
			var vsClassName = poElement.className;
			vsClassName = eXria.util.StringUtil.trim(vsClassName);
			vsClassName = vsClassName.split(" ");
			vsClassName = vsClassName[vsClassName.length - 1];
			var voCssStyle = this.getCssStyle(vsClassName);
			if(voCssStyle == null) {
  			var voStyleSheets = window.document.styleSheets;
  			if(voStyleSheets.length > 0){
  				for(var i=voStyleSheets.length-1; i>=0; i--){
  					var voRules = voStyleSheets[i].rules;
  					for(var j=voRules.length-1; j>=0; j--){
  						if(voRules[j].selectorText == "." + vsClassName){
  							this.canvas.cssClassMap.put("." + vsClassName, voRules[j].style); //this.canvas.cssClassMap의 캐시 처리하고 있는 부분을 사용시 고려할 것
  						  return voRules[j].style[psJSProp];
  						}
  					}
  				}
  			}
			} else {
			  return voCssStyle[psJSProp];
			}
		}
	} else {
    var vsClassName = poElement.className;
    vsClassName = eXria.util.StringUtil.trim(vsClassName);
    vsClassName = vsClassName.split(" ");
    vsClassName = vsClassName[vsClassName.length - 1];
    var voCssStyle = this.getCssStyle(vsClassName);
    if(voCssStyle == null) {
      var voStyleSheets = window.document.styleSheets;
      if(voStyleSheets.length > 0){
        for(var i=voStyleSheets.length-1; i>=0; i--){
          var voRules = voStyleSheets[i].rules;
          if(voRules == null) voRules = voStyleSheets[i].cssRules;
          for(var j=voRules.length-1; j>=0; j--){
            if(voRules[j].selectorText == "." + vsClassName){
              this.canvas.cssClassMap.put("." + vsClassName, voRules[j].style); //this.canvas.cssClassMap의 캐시 처리하고 있는 부분을 사용시 고려할 것
              return voRules[j].style[psJSProp];
            }
          }
        }
      }
    } else {
      return voCssStyle[psJSProp];
    }
	}
	return null;
};
/**
 * CSS로 적용된 Border의 값을 속성에 할당한다.
 * @param {Object} poCtrl HTMLElement
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setStyleCurrentBorderValue = function(poControl){
	var voCtrl = poControl.getCtrl();
	
	// yhkim 2009.10.08 borderWidth값이 설정된 경우에 그 설정을  배분해서 넣어주기 
	if(poControl.borderWidth != null) {
		if(poControl.borderLeftWidth == null) poControl.borderLeftWidth = poControl.borderWidth; 
		if(poControl.borderRightWidth == null) poControl.borderRightWidth = poControl.borderWidth;
		if(poControl.borderTopWidth == null) poControl.borderTopWidth = poControl.borderWidth;
		if(poControl.borderBottomWidth == null) poControl.borderBottomWidth = poControl.borderWidth;
	}
	
	if(poControl.borderTopWidth == null) {
		if(poControl.getStyleCurrentValue(voCtrl, "border-top-width", "borderTopWidth") == null)
			poControl.borderTopWidth = null;
		else
			poControl.borderTopWidth = parseInt(poControl.getStyleCurrentValue(voCtrl, "border-top-width", "borderTopWidth"), 10);
	}
	if(poControl.borderRightWidth == null) {
		if(poControl.getStyleCurrentValue(voCtrl, "border-right-width", "borderRightWidth") == null)
			poControl.borderRightWidth = null;
		else
			poControl.borderRightWidth = parseInt(poControl.getStyleCurrentValue(voCtrl, "border-right-width", "borderRightWidth"), 10);
	}
	if(poControl.borderBottomWidth == null) {
		if(poControl.getStyleCurrentValue(voCtrl, "border-bottom-width", "borderBottomWidth") == null)
			poControl.borderBottomWidth = null;
		else
			poControl.borderBottomWidth = parseInt(poControl.getStyleCurrentValue(voCtrl, "border-bottom-width", "borderBottomWidth"), 10);
	}
	if(poControl.borderLeftWidth == null) {
		if(poControl.getStyleCurrentValue(voCtrl, "border-left-width", "borderLeftWidth") == null)
			poControl.borderLeftWidth = null;
		else
			poControl.borderLeftWidth = parseInt(poControl.getStyleCurrentValue(voCtrl, "border-left-width", "borderLeftWidth"), 10);
	}
};

/**
 * Border의 상세 값을 설정한다
 * @param {Object} poCtrl HTMLElement
 * @private
 */
eXria.controls.xhtml.UIControl.prototype.setDetailBorder = function(poControl){
	if(poControl.borderTopWidth == null) poControl.borderTopWidth = poControl.borderWidth;
	if(poControl.borderRightWidth == null) poControl.borderRightWidth = poControl.borderWidth;
	if(poControl.borderBottomWidth == null) poControl.borderBottomWidth = poControl.borderWidth;
	if(poControl.borderLeftWidth == null) poControl.borderLeftWidth = poControl.borderWidth;
};