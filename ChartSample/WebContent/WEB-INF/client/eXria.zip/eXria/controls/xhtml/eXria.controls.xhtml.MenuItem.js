﻿/**
 * @fileoverview
 * Concreate xhtml MenuItem(XHTML MenuItem 컨트롤)
 * @author 김경태
 */

/**
 * Concreate xhtml MenuItem.<br>
 * XHTML MenuItem 컨트롤.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.MenuItem 객체
 * @type eXria.controls.xhtml.MenuItem
 * @constructor
 */
eXria.controls.xhtml.MenuItem = function(psLabel, psValue, psImage, psHotKey, poParentControl, pnLeft, pnTop, pnWidth, pnHeight){
  
  vnLeft = pnLeft == null ? 0 : pnLeft;
  vnTop = pnTop == null ? 0 : pnTop;
  vnWidth = pnWidth == null ? poParentControl.width : pnWidth;
  vnHeight = pnHeight == null ? poParentControl.height : pnHeight;
  
  eXria.controls.MenuItem.call(this, poParentControl.id + "_item_" + psValue, poParentControl, psLabel, psValue, psImage, psHotKey, vnLeft, vnTop, vnWidth, vnHeight);
  
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 이미지 가로 사이즈.
   * @type Number
   */
  this.iconWidth = null;
  /**
   * 이미지 배경색.
   * @type String
   */
  this.iconBackgroundColor = null;
  /**
   * 텍스트 인덴트.
   * @type Number
   */
  this.textIndent = null;
  /**
   * 포커스된 아이템의 배경색.
   * @type String
   */
  this.focusBackgroundColor = null;
  /**
   * 전체 아이템 리스트.
   * @type eXria.data.ArrayMap
   */
  this.items = new eXria.data.ArrayMap();
  /**
   * 하위 아이템이 없는 단독 메뉴인지 여부.
   * @type Boolean
   */
  this.isLeaf = true;
  /**
   * @ignore
   */
  this.df = {};
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   * @private
   */
  this.data = new eXria.controls.DataRefNode(this.parentControl);
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.MenuItem, eXria.controls.xhtml.MenuItem);
//////////////////////////////////////////////////////////////////
// 메소드
/**
 * @ignore
 */ 
eXria.controls.xhtml.MenuItem.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("tr");
  this.createSubCtrl(voCtrl, poDocument);
  //this.setMainCtrlStyles(voCtrl, poDocument);
  this.setSpecificDefaults(voCtrl, poDocument);
  this.setSpecificAttrs(voCtrl, poDocument);
  return voCtrl;
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItem.prototype.createSubCtrl = function(poCtrl, poDocument) {
  if(this.label == "-" && this.value == null) {
    var voSeparator = poDocument.createElement("td");
    voSeparator.colSpan="4";
    voSeparator.style.backgroundColor = "red";
    voSeparator.style.height="3px";
    poCtrl.appendChild(voSeparator);
  } else {
   var voIconArea = poDocument.createElement("td");
   var voImage = poDocument.createElement("img");
   voImage.src = this.parentControl.canvas.page.metadata.resourceBaseUrl + "eXria/controls/xhtml/images/calendar.jpg";
   voIconArea.appendChild(voImage);

   var voLabelArea = poDocument.createElement("td");
   var voText = poDocument.createTextNode(eXria.controls.xhtml.Util.parseLang(this.label));
   voLabelArea.appendChild(voText);  
   
   var voHotKeyArea = poDocument.createElement("td");
   if(this.hotKey) {
    var voText = poDocument.createTextNode(this.hotKey);
    voHotKeyArea.appendChild(voText);
   }
   var voArrowArea = poDocument.createElement("td");
   if(this.items.size() > 0) {
     var voText = poDocument.createTextNode("▶");
     voArrowArea.appendChild(voText);
   }
   poCtrl.appendChild(voIconArea);
   poCtrl.appendChild(voLabelArea); 
   poCtrl.appendChild(voHotKeyArea);
   poCtrl.appendChild(voArrowArea);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItem.prototype.getInnerHTML = function(poCtrl) {
  this.setSpecificDefaults();
  
  this.template = [];
  var vaTemplate = this.template;
  var voParentControl = this.parentControl;

  //var vsItemClass = voParentControl.getCSSClass(this, 1, "itemgroup");
  //var vsIconClass = voParentControl.getCSSClass(this, 1, "Iconarea");
  // yhkim 서버에서 설정되는 설정이 Default_ContextMenu_itemgroup_Class같아서 맞춰줘야 한다. 
  //  voParentControl.getCSSClass(this, 1, "itemgroup");와 같은 구조는 Default_MenuItem_itemgroup_Class 형태로 만들어내는 문제가 있다
  var vsItemClass = "Default_ContextMenu_itemgroup_Class"
  if(this.parent.itemgroup && this.parent.itemgroup.className) vsItemClass = vsItemClass + " " + this.parent.itemgroup.className;
  var vsIconClass = "Default_ContextMenu_Iconarea_Class";
  if(this.parent.iconarea && this.parent.iconarea.className)  vsIconClass = vsIconClass + " " + this.parent.iconarea.className;
	
  vaTemplate.push("<tr class=\"" + vsItemClass + "\" onclick=\"");
  vaTemplate.push(this.getEHandler("atclick"));
  vaTemplate.push("\" onmouseover=\"");
  vaTemplate.push(this.getEHandler("atmouseover"));
  vaTemplate.push("\" onmouseout=\"");
  vaTemplate.push(this.getEHandler("atmouseout"));
  vaTemplate.push("\" ");
  vaTemplate.push("@attStrBuf"); //7
  vaTemplate.push(" style='");
  vaTemplate.push("@cssStrBuf"); //9
  vaTemplate.push("'>");

  if(this.label == "-" && this.value == null) {
    vaTemplate.push("<td colSpan=4");
    vaTemplate.push(" style='");
    vaTemplate.push("@cssStrBuf"); //13
    vaTemplate.push("'>");
  } else {
    vaTemplate.push("<td class='" + vsIconClass + "' style='");
    vaTemplate.push("@cssStrBuf"); //12
    vaTemplate.push("'>");
    if(this.image) {
      vaTemplate.push("<img src='");
      //vaTemplate.push(eXria.controls.xhtml.Util.getImagePath(this.image, this.parentControl.window));
      vaTemplate.push(this.image);
      vaTemplate.push("'/>");
    } else {
      vaTemplate.push("");
      vaTemplate.push("");
      vaTemplate.push("");
    }
    
    vaTemplate.push("<td nowrap style='");
    vaTemplate.push("@cssStrBuf"); //18
    vaTemplate.push("'>");
    vaTemplate.push(eXria.controls.xhtml.Util.parseLang(this.label));
    vaTemplate.push("</td>");
    
    vaTemplate.push("<td style='");
    vaTemplate.push("@cssStrBuf"); //23
    vaTemplate.push("'>");
    if(this.hotKey) vaTemplate.push(this.hotKey);
    else vaTemplate.push("");
    vaTemplate.push("</td>");
    
    vaTemplate.push("<td style='");
    vaTemplate.push("@cssStrBuf"); //28
    vaTemplate.push("'>");
    if(this.items.size() > 0) vaTemplate.push("▶");
    vaTemplate.push("</td>");
  }
  vaTemplate.push("</tr>");
  
  this.setSpecificAttrs();
  
  var vsRet = vaTemplate.join("");
  vaTemplate = null;
  this.template = null;
  return vsRet;
};
/**
 * Main Style 적용
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MenuItem.prototype.setMainCtrlStyles = function(poCtrl, poDocument) {
  //this.parentControl.setAttrCtrl("className", this.className, poCtrl); 
};
/**
 * 개별 초기값 설정
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @return poCtrl
 * @type HTMLDiv
 * @private
 */ 
//eXria.controls.xhtml.MenuItem.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
//  // 구분자에 대한 초기값 설정
//  if(this.value == "-") {
//    var voTdSeparator = poCtrl.childNodes[0];
//    voTdSeparator.colSpan="3";
//    voTdSeparator.style.backgroundColor = this.getItemAttrValue("separatorColor", this.separatorColor);
//    voTdSeparator.style.height="3px";
//    return;
//  }
//  
//  var vsTextAlign = null;
//  var vsVerticalAlign = null;
//
//  // CSS가 적용되는 속성에 대한 초기값 설정
//  var voCssStyle = this.parentControl.canvas.getCssStyle(this.parentControl.itemgroup.className, poDocument);
//  if(voCssStyle) {
//    var vsCssColor = voCssStyle["color"];
//    var vsCssBackgroundColor = voCssStyle["backgroundColor"];
//    var vsCssBorderColor = voCssStyle["borderColor"];
//    var vsCssBorderStyle = voCssStyle["borderStyle"];
//    var vsCssBorderWidth = voCssStyle["borderWidth"];
//    var vsCssFontFamily = voCssStyle["fontFamily"];
//    var vsCssFontSize = voCssStyle["fontSize"];
//    var vsCssFontStyle = voCssStyle["fontStyle"];
//    var vsCssFontWeight = voCssStyle["fontWeight"];
//    var vsCssTextAlign = voCssStyle["textAlign"];
//    var vsCssVerticalAlign = voCssStyle["verticalAlign"];
//    
//    if(vsCssColor == null || vsCssColor == "") this.parentControl.setAttrCtrl("color", this.getItemAttrValue("color", this.color), poCtrl);
//    if(vsCssBackgroundColor == null || vsCssBackgroundColor == "") this.parentControl.setAttrCtrl("backgroundColor", this.getItemAttrValue("backgroundColor", this.backgroundColor), poCtrl);
//    if(vsCssBorderColor == null || vsCssBorderColor == "") this.parentControl.setAttrCtrl("borderColor", this.getItemAttrValue("borderColor", this.borderColor), poCtrl);
//    if(vsCssBorderStyle == null || vsCssBorderStyle == "") this.parentControl.setAttrCtrl("borderStyle", this.getItemAttrValue("borderStyle", this.borderStyle), poCtrl);
//    if(vsCssBorderWidth == null || vsCssBorderWidth == "") this.parentControl.setAttrCtrl("borderStyle", this.getItemAttrValue("borderWidth", this.borderWidth), poCtrl);
//    if(vsCssFontFamily == null || vsCssFontFamily == "") this.parentControl.setAttrCtrl("fontFamily", this.getItemAttrValue("fontFamily", this.fontFamily), poCtrl);
//    if(vsCssFontSize == null || vsCssFontSize == "") this.parentControl.setAttrCtrl("fontSize", this.getItemAttrValue("fontSize", this.fontSize), poCtrl);
//    if(vsCssFontStyle == null || vsCssFontStyle == "") this.parentControl.setAttrCtrl("fontStyle", this.getItemAttrValue("fontStyle", this.fontStyle), poCtrl);
//    if(vsCssFontWeight == null || vsCssFontWeight == "") this.parentControl.setAttrCtrl("fontWeight", this.getItemAttrValue("fontWeight", this.fontWeight), poCtrl);
//    if(vsCssTextAlign == null || vsCssTextAlign == "") vsTextAlign = this.getItemAttrValue("textAlign", this.textAlign);        
//    if(vsCssVerticalAlign == null || vsCssVerticalAlign == "") vsVerticalAlign = this.getItemAttrValue("verticalAlign", this.verticalAlign);
//  } else { // CSS가 지정되어 있지 않은 경우에는 control의  속성 값이 null인 속성에 대해서 Default 값을 구해 직접 xhtml에 반영한다.
//    this.parentControl.setAttrCtrl("color", this.getItemAttrValue("color", this.color), poCtrl);
//    this.parentControl.setAttrCtrl("backgroundColor", this.getItemAttrValue("backgroundColor", this.backgroundColor), poCtrl);
//    this.parentControl.setAttrCtrl("borderColor", this.getItemAttrValue("borderColor", this.borderColor), poCtrl);
//    this.parentControl.setAttrCtrl("borderStyle", this.getItemAttrValue("borderStyle", this.borderStyle), poCtrl);
//    this.parentControl.setAttrCtrl("borderWidth", this.getItemAttrValue("borderWidth", this.borderWidth), poCtrl);
//    vsTextAlign = this.getItemAttrValue("textAlign", this.textAlign);
//    vsVerticalAlign = this.getItemAttrValue("verticalAlign", this.verticalAlign);
//  }
//
//  // CSS가 적용되지 않는 속성에 대한 초기값 설정(main 컨트롤)
//  var vnWidth = this.getItemAttrValue("width", this.width);
//  var vnHeight = this.getItemAttrValue("height", this.height);
//  poCtrl.style.height = vnHeight + "px";
//  
//  // 하위 요소에 대한 초기값 설정(icon 영역)
//  var voTdIcon = poCtrl.childNodes[0];
//  var vnIconWidth = this.getItemAttrValue("iconWidth", this.iconWidth);  
//  voTdIcon.style.backgroundColor = this.getItemAttrValue("iconBackgroundColor", this.iconBackgroundColor);
//  voTdIcon.align = "center";
//  voTdIcon.vertialAlign = "middle";
//  voTdIcon.focusBackgroundColor = this.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
//
//  // 하위 요소에 대한 초기값 설정(label 영역)
//  var voTdLabel = poCtrl.childNodes[1];
//  voTdLabel.style.textIndent = this.getItemAttrValue("textIndent", this.textIndent) + "px";
//  voTdLabel.align = vsTextAlign;
//  voTdLabel.vertialAlign = vsVerticalAlign;
//  voTdLabel.focusBackgroundColor = this.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
//
//  // 하위 요소에 대한 초기값 설정(hotkey 영역)
//  var voTdHotKey = poCtrl.childNodes[2];
//  voTdHotKey.style.paddingLeft = "10px";
//  voTdHotKey.style.paddingRight = "10px";
//  voTdHotKey.align = "center";
//  voTdHotKey.vertialAlign = "middle";
//  voTdHotKey.style.height = vnHeight + "px"; 
//  
//  poCtrl.control = this;
//  poCtrl.onclick = function(e) {
//    this.control.selected = true;
//    this.control.parentControl.selectedItem = this.control;     
//    if(this.control.parent != this.control.parentControl) {
//      this.control.notifyEvent(e, this.control, this.control.parentControl);
//    }
//  };
//  
//  poCtrl.onmouseover = function(e) {
//    if(this.control.parent !== undefined) {
//      if(this.control.parent.items.size() > 0) {
//        var vsKey = null;
//        var voItem = null;    
//        var voIterator1 = this.control.parent.items.getKeyCollection().iterator();   
//        while (voIterator1.hasNext()) {
//          vsKey = voIterator1.next();
//          voItem = this.control.parent.items.get(vsKey);
//          if(!voItem) break;
//          if(voItem.toString() == "MenuItem") {
//              this.control.parentControl.hideSubMenu(poDocument, voItem);
//            } else if(voItem.toString() == "MenuItemSet") {
//              voIterator2 = voItem.items.getKeyCollection().iterator();
//              var voChildItem = null;
//            while (voIterator2.hasNext()) {
//              vsKey = voIterator2.next();
//              voChildItem = voItem.items.get(vsKey);
//              if(voChildItem) this.control.parentControl.hideSubMenu(poDocument, voChildItem);
//            }
//          }
//        }
//      }
//    } 
//    poCtrl.style.backgroundColor = this.control.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor); 
//    voTdIcon.style.backgroundColor = this.control.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
//    voTdLabel.style.backgroundColor = this.control.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
//    if(this.control.items.size() > 0) {
//      this.control.parentControl.showSubMenu(poDocument, this.control);
//    }
//  };
//  
//  poCtrl.onmouseout = function(e) {
//    poCtrl.style.backgroundColor = this.control.getItemAttrValue("backgroundColor", this.backgroundColor);
//    voTdIcon.style.backgroundColor = this.control.getItemAttrValue("iconBackgroundColor", this.iconBackgroundColor);
//    voTdLabel.style.backgroundColor = this.control.getItemAttrValue("backgroundColor", this.backgroundColor); 
//  };
//
//  return poCtrl;
//};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItem.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voDf = this.df;
  this.separatorColor = this.getItemAttrValue("separatorColor", this.parentControl.itemgroup.separatorColor);
  this.separatorHeight = this.getItemAttrValue("separatorHeight", this.parentControl.itemgroup.separatorHeight);
  // CSS가 적용되는 속성에 대한 초기값 설정
  var voParentItemGroup = this.parentControl.itemgroup; 
  var voParentIconArea = this.parentControl.iconarea;
  var voCssStyle = this.parentControl.canvas.getCssStyle(this.parentControl.itemgroup.className, poDocument);
  if(voCssStyle) { 
    this.color = voCssStyle["color"];
    this.backgroundColor = voCssStyle["backgroundColor"];
    this.borderColor = voCssStyle["borderColor"];
    this.borderStyle = voCssStyle["borderStyle"];
    this.borderWidth = voCssStyle["borderWidth"];
    this.fontFamily = voCssStyle["fontFamily"];
    this.fontSize = voCssStyle["fontSize"];
    this.fontStyle = voCssStyle["fontStyle"];
    this.fontWeight = voCssStyle["fontWeight"];
    this.textAlign = voCssStyle["textAlign"];
    this.verticalAlign = voCssStyle["verticalAlign"];
    if(this.fontSize != null && this.fontSize != "") this.fontSize = parseInt(this.fontSize);
    
    if(this.color == null || this.color == "") voDf.color = this.getItemAttrValue("color", voParentItemGroup.color);
    if(this.backgroundColor == null || this.backgroundColor == "") this.backgroundColor = this.getItemAttrValue("backgroundColor", voParentItemGroup.backgroundColor);
    if(this.borderColor == null || this.borderColor == "") this.borderColor = this.getItemAttrValue("borderColor", voParentItemGroup.borderColor);
    if(this.borderStyle == null || this.borderStyle == "") this.borderStyle = this.getItemAttrValue("borderStyle", voParentItemGroup.borderStyle);
    if(this.borderWidth == null || this.borderWidth == "") this.borderWidth = this.getItemAttrValue("borderWidth", voParentItemGroup.borderWidth);
    if(this.fontFamily == null || this.fontFamily == "") this.fontFamily = this.getItemAttrValue("fontFamily", voParentItemGroup.fontFamily);
    if(this.fontSize == null || this.fontSize == "") this.fontSize = this.getItemAttrValue("fontSize", voParentItemGroup.fontSize);
    if(this.fontStyle == null || this.fontStyle == "") this.fontStyle = this.getItemAttrValue("fontStyle", voParentItemGroup.fontStyle);
    if(this.fontWeight == null || this.fontWeight == "") this.fontWeight = this.getItemAttrValue("fontWeight", voParentItemGroup.fontWeight);
    if(this.textAlign == null || this.textAlign == "") this.textAlign = this.getItemAttrValue("textAlign", voParentItemGroup.textAlign);
    if(this.verticalAlign == null || this.verticalAlign == "") this.verticalAlign = this.getItemAttrValue("verticalAlign", voParentItemGroup.verticalAlign);
  } else { // CSS가 지정되어 있지 않은 경우에는 control의  속성 값이 null인 속성에 대해서 Default 값을 구해 직접 xhtml에 반영한다.
  	/*
    this.color = this.getItemAttrValue("color", voParentItemGroup.color);
    this.backgroundColor = this.getItemAttrValue("backgroundColor", voParentItemGroup.backgroundColor);
    this.borderColor = this.getItemAttrValue("borderColor", voParentItemGroup.borderColor);
    this.borderStyle = this.getItemAttrValue("borderStyle", voParentItemGroup.borderStyle);
    this.borderWidth = this.getItemAttrValue("borderWidth", voParentItemGroup.borderWidth);
    this.fontFamily = this.getItemAttrValue("fontFamily", voParentItemGroup.fontFamily);
    this.fontSize = this.getItemAttrValue("fontSize", voParentItemGroup.fontSize);
    this.fontStyle = this.getItemAttrValue("fontStyle", voParentItemGroup.fontStyle);
    this.fontWeight = this.getItemAttrValue("fontWeight", voParentItemGroup.fontWeight);
    this.textAlign = this.getItemAttrValue("textAlign", voParentItemGroup.textAlign);
    this.verticalAlign = this.getItemAttrValue("verticalAlign", voParentItemGroup.verticalAlign);
    */
  }

  // CSS가 적용되지 않는 속성에 대한 초기값 설정(main 컨트롤)
  this.width = this.getItemAttrValue("width", voParentItemGroup.width);
  this.height = this.getItemAttrValue("height", voParentItemGroup.height);
  this.focusBackgroundColor = this.getItemAttrValue("focusBackgroundColor", voParentItemGroup.focusBackgroundColor);
  this.focusColor = this.getItemAttrValue("focusColor", voParentItemGroup.focusColor);
  this.disabled = this.getItemAttrValue("disabled", this.disabled);
  // 하위 요소에 대한 초기값 설정(icon 영역)
  //this.iconWidth = this.getItemAttrValue("iconWidth", voParentIconArea.width);  
  //this.iconBackgroundColor = this.getItemAttrValue("iconBackgroundColor", voParentIconArea.backgroundColor);
  this.iconAlign = this.getItemAttrValue("textAlign", voParentItemGroup.textAlign);
  this.iconVertialAlign = this.getItemAttrValue("verticalAlign", voParentItemGroup.verticalAlign);

  // 하위 요소에 대한 초기값 설정(label 영역)
  this.textIndent = this.getItemAttrValue("textIndent", this.textIndent);
  this.labelAlign = this.textAlign;
  this.labelVertialAlign = this.verticalAlign;
  
  // 하위 요소에 대한 초기값 설정(hotkey 영역)
  this.hotkeyPaddingLeft = 10;
  this.hotkeyPaddingRight = 10;
  this.hotkeyAlign = "center";
  this.hotkeyVertialAlign = "middle";
  
  var voData = this.data;
  if(voData.instanceId && voData.instancePath) {
    this.label = voData.getData();
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItem.prototype.atclick = function(e) {
  if(this.parentControl.disabled || this.disabled) {
	  var voEvent = new eXria.event.Event(e, this.parentControl.window);
	  voEvent.stopEvent();
	  return;
	}
  this.selected = true;
  this.parentControl.selectedItem = this;
  if(this.parent != this.parentControl) {
    this.notifyEvent(e, this, this.parentControl);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItem.prototype.atmouseover = function(e) {
  if(this.parentControl.disabled || this.disabled) {
    var voEvent = new eXria.event.Event(e, this.parentControl.window);
    voEvent.stopEvent();
    return;
  }
  var voDf = this.df;
  var voParentControl = this.parentControl;
  var voDocument = voParentControl.document;
  if(this.parent !== undefined) {
    var voParent = this.parent;
    if(voParent.items.size() > 0) {
      var vsKey = null;
      var voItem = null;    
      var voIterator1 = voParent.items.getKeyCollection().iterator();   
      while (voIterator1.hasNext()) {
        vsKey = voIterator1.next();
        voItem = voParent.items.get(vsKey);
        if(!voItem) break;
        if(voItem.toString() == "MenuItem") {
            voParentControl.hideSubMenu(voDocument, voItem);
          } else if(voItem.toString() == "MenuItemSet") {
            voIterator2 = voItem.items.getKeyCollection().iterator();
            var voChildItem = null;
            while (voIterator2.hasNext()) {
            vsKey = voIterator2.next();
            voChildItem = voItem.items.get(vsKey);
            if(voChildItem) voParentControl.hideSubMenu(voDocument, voChildItem);
          }
        }
      }
    }
  }
  voParentControl.showedItem = this;
  
  var voCtrl = voParentControl.lookup(this.id);
  voCtrl.style.backgroundColor = this.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
  if(voCtrl.childNodes.length > 1) {
    var voTdIcon = voCtrl.childNodes.item(0);
    var voTdLabel = voCtrl.childNodes.item(1);
    voTdIcon.style.backgroundColor = this.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
    voTdLabel.style.backgroundColor = this.getItemAttrValue("focusBackgroundColor", this.focusBackgroundColor);
    voTdLabel.style.color = this.getItemAttrValue("focusColor", this.focusColor);
  }
  if(this.items.size() > 0) {
    voParentControl.showSubMenu(voDocument, this);
  }
};
/**
 * @ignore
 */
eXria.controls.xhtml.MenuItem.prototype.atmouseout = function(e) {
  if(this.parentControl.disabled || this.disabled) {
    var voEvent = new eXria.event.Event(e, this.parentControl.window);
    voEvent.stopEvent();
    return;
  }
  var voParentControl = this.parentControl;
  var voDocument = voParentControl.document;
  var voDf = this.df;
  var voCtrl = voParentControl.lookup(this.id);
//  voCtrl.style.backgroundColor = this.getItemAttrValue("backgroundColor", this.backgroundColor);
	if(this.backgroundColor) voCtrl.style.backgroundColor = this.backgroundColor;
	else voCtrl.style.backgroundColor = "";
  if(voCtrl.childNodes.length > 1) {
    var voTdIcon = voCtrl.childNodes.item(0);
    var voTdLabel = voCtrl.childNodes.item(1);
//    voTdIcon.style.backgroundColor = this.getItemAttrValue("iconBackgroundColor", this.iconBackgroundColor);
//		voTdLabel.style.backgroundColor = this.getItemAttrValue("backgroundColor", this.backgroundColor);
//    voTdLabel.style.color = this.getItemAttrValue("color", this.color);
		if(this.iconBackgroundColor) voTdIcon.style.backgroundColor = this.iconBackgroundColor;
		else voTdIcon.style.backgroundColor = "";
		if(this.backgroundColor) voTdLabel.style.backgroundColor = this.backgroundColor;
		else voTdLabel.style.backgroundColor = "";
		if(this.color) voTdLabel.style.color = this.color;
		else voTdLabel.style.color = "";
  }
};
/**
 * 개별 Attrs 적용
 * @param {HTMLDiv} poCtrl 실체화 컨트롤
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
//eXria.controls.xhtml.MenuItem.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
//  poCtrl.setAttribute("id", this.id);
//  poCtrl.disabled = this.disabled;
//};
eXria.controls.xhtml.MenuItem.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  var voParentControl = this.parentControl;
  var voDf = this.df;
  var vaTemplate = null;
  vaTemplate = this.template;
  var vaAttStrBuf = null;
  var vaCssStrBuf = null;
  var vfcSetAttStrBuf = voParentControl.setAttStrBuf;
  var vfcSetCssStrBuf = voParentControl.setCssStrBuf;
  
  vaAttStrBuf = [];  
  vfcSetAttStrBuf(vaAttStrBuf, "id", this.id);
  //if(voDf.disabled) vaAttStrBuf.push("disabled");
  vaTemplate[7] = vaAttStrBuf.join("");
  
  vaCssStrBuf = [];
  if(this.label == "-" && this.value == null) {
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.separatorHeight, "px");
  } else {
    vfcSetCssStrBuf(vaCssStrBuf, "height", this.height, "px");
  }
  if(this.disabled) vfcSetCssStrBuf(vaCssStrBuf, "color", voParentControl.disabledColor);
  else vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-width", this.borderWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.verticalAlign);
  vaTemplate[9] = vaCssStrBuf.join("");
  
  if(this.label == "-" && this.value == null) {
    vaCssStrBuf = [];
    vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.separatorColor);
    vaTemplate[13] = vaCssStrBuf.join("");
    
    vaAttStrBuf = null;
    vaCssStrBuf = null;
    vaTemplate = null;
    return;
  }
  
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.iconWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.iconBackgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.iconAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.iconVertialAlign);
  vaTemplate[12] = vaCssStrBuf.join("");
  
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "text-indent", this.textIndent, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.labelAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.labelVertialAlign);
  vaTemplate[18] = vaCssStrBuf.join("");
  
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.hotkeyPaddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.hotkeyPaddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.hotkeyAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.hotkeyVertialAlign);
  vaTemplate[23] = vaCssStrBuf.join("");
  
  vaCssStrBuf = [];
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", "center");
  vfcSetCssStrBuf(vaCssStrBuf, "vertical-align", this.labelVertialAlign);
  //vfcSetCssStrBuf(vaCssStrBuf, "font-size", Math.round(voDf.fontSize * 1.5), "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vaTemplate[28] = vaCssStrBuf.join("");
  
  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
};
/**
 * 아이템 새로고침
 * @param {HTMLDocument} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.MenuItem.prototype.refresh = function(poDocument) {
  //this.createCtrl();
};
/**
 * 자식 아이템 추가.
 * @param poItem 추가할 아이템
 * @return void
 * @private
 */
eXria.controls.xhtml.MenuItem.prototype.addChild = function(poItem) {
  this.items.put(this.items.size(), poItem);
  poItem.parent = this;
  this.isLeaf = false;
};
/**
 * 지정된 인덱스에 자식 아이템 추가.
 * @param poItem 추가할 아이템
 * @param pnIndex 지정할 인덱스
 * @return void
 * @private
 */
eXria.controls.xhtml.MenuItem.prototype.addChildToIndex = function(poItem, pnIndex) {
 var voNewItems = new eXria.data.ArrayMap();
 var vnIndex = 0;
 var voValue = null;
 var voIterator = this.items.getValueCollection().iterator();
 while(voIterator.hasNext()) {
   if(vnIndex == pnIndex) voNewItems.put(vnIndex++, poItem);
   voValue = voIterator.next();
   voNewItems.put(vnIndex, voValue);
   vnIndex++;
 }
 this.items.clear();
 this.items = voNewItems;
};
/**
 * 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @return 디폴트 속성값
 * @type String
 */
eXria.controls.xhtml.MenuItem.prototype.getItemAttrValue = function(psAttrName, psAttrValue) {
  if (psAttrValue != null) return psAttrValue;
  else return this.getItemDefaultValue(psAttrName);
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @type Unknown
 */
eXria.controls.xhtml.MenuItem.prototype.getItemDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.ContextMenu.itemgroup[psAttrName];
  if(vsDefaultValue === undefined) return null;
  else return vsDefaultValue;    
};
/**
 * 아이템의 innerHTML요소에 이벤트 핸들러를 추가하기 위한 메소드
 * @param {String} psFuncName 실질적으로 이벤트를 처리할 클래스 내부 메소드명
 * @private
 */
eXria.controls.xhtml.MenuItem.prototype.getEHandler = function(psFuncName) {
  var voParentControl = this.parentControl;
  var vaStrBuf = [];
  vaStrBuf.push("var e=null;")
  vaStrBuf.push("if(arguments[0]) e=arguments[0];");
  vaStrBuf.push("page.getControl('");
  vaStrBuf.push(voParentControl.id);
  vaStrBuf.push("').getItemById('");
  vaStrBuf.push(this.id);
  vaStrBuf.push("').")
  vaStrBuf.push(psFuncName);
  vaStrBuf.push("(e);");
  
  var vsRet = vaStrBuf.join("");
  vaStrBuf = null;
  return vsRet;
};
/**
 * 클래스 명을 반환.
 * @return "MenuItem"
 * @type String
 */
eXria.controls.xhtml.MenuItem.prototype.toString = function() {
  return "MenuItem";
};
