﻿/**
 * @fileoverview
 * Concreate xhtml Button(XHTML 버튼 컨트롤)
 * @author 조영진, 박찬수
 */
 
/**
 * @class 내부에 text나 img를 넣을 수 있는 버튼 컨트롤을 생성하는 class입니다.<br>
 * XHTML Button control.
 * @version 2.0
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @return 새로운 eXria.controls.xhtml.Button 객체 
 * @type eXria.controls.xhtml.Button
 * @constructor
 * @base eXria.controls.xhtml.UIControl
 */
eXria.controls.xhtml.Button = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  pnLeft = pnLeft == null ? 20 : pnLeft;
  pnTop = pnTop == null ? 20 : pnTop;
  pnWidth = pnWidth == null ? 100 : pnWidth;
  pnHeight = pnHeight == null ? 30 : pnHeight;

  /*
   * UIControl을 상속받는다.
   */ 
  eXria.controls.xhtml.UIControl.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  /**
   * Data 연동 객체(싱글 노드 연동).
   * @type eXria.controls.DataRefNode
   */  
  this.data = new eXria.controls.DataRefNode(this);
  //////////////////////////////////////////////////////////////////
  // 속성
  /**
   * 상위 컨트롤과의 위치 관계(absolute | relative | static).
   * @type String
   */
  this.position = "absolute";
  /**
   * 버튼에 라벨값(아이콘 url정보 포함) 저장.
   * @type String
   */
  this.value = null;
  /**
   * 컨트롤 외곽 보더의 좌측 부분 두께.
   * @type Number
   */
  this.borderLeftWidth = null;
  /**
   * 컨트롤 외곽 보더의 우측 부분 두께.
   * @type Number
   */
  this.borderRightWidth = null;
  /**
   * 컨트롤 외곽 보더의 상단 부분 두께.
   * @type Number
   */
  this.borderTopWidth = null;
  /**
   * 컨트롤 외곽 보더의 하단 부분 두께.
   * @type Number
   */
  this.borderBottomWidth = null;
  /**
   * 버튼의 배경이미지 url.
   * @type String
   */
  this.backgroundImage = null;
  /**
   * 이미지 반복 표현 방식 지정.<br>
   * "repeat" | "repeat-x" | "repeat-y" | "no-repeat"
   * @type String
   */
  this.backgroundRepeat = null;
  /**
   * 이미지 위치 방식 지정.<br>
   * 가로 : "left" | "center" | "right" | x% | xpos  세로 : "top" | "center" | "bottom" | y% | ypos
   * @type String
   */
  this.backgroundPosition = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트패밀리.
   * @type String
   */
  this.fontFamily = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트사이즈.
   * @type Number
   */
  this.fontSize = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트스타일.
   * @type String
   */
  this.fontStyle = null;
  /**
   * 컨트롤에 표시될 텍스트 폰트두께.
   * @type Number
   */
  this.fontWeight = null;
  /**
   * 컨트롤에 표시될 텍스트 가로정렬.
   * @type String
   */
  this.textAlign = null;
  /**
   * 텍스트에 밑줄을 넣을때.
   * "underline" | "overline" | "line-through" | "blink"
   * @type String
   */
  this.textDecoration = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 패딩 값.
   * @type Number
   */
  this.padding = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 좌측 패딩 값.
   * @type Number
   */
  this.paddingLeft = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 우측 패딩 값.
   * @type Number
   */
  this.paddingRight = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 상단 패딩 값.
   * @type Number
   */
  this.paddingTop = null;
  /**
   * 컨트롤에 표시될 텍스트에 적용될 하단 패딩 값.
   * @type Number
   */
  this.paddingBottom = null;  
  /**
   * 보더를 제외한 컨트롤의 가로길이.
   * @type Number
   * @private
   */
  this.innerWidth = this.width;
  /**
   * 보더를 제외한 컨트롤의 세로길이.
   * @type Number
   * @private
   */
  this.innerHeight = this.height;
  /**
   * 버튼이 눌려을 때 표시될 이미지.
   * @type String
   */  
  this.imagePushed = null;
  /**
   * 버튼에 포커스가 위치했을 때 표시될 이미지.
   * @type String
   */
  this.imageFocused = null;
  /**
   * 버튼에 마우스가 위치했을 때 표시될 이미지.
   * @type String
   */
  this.imageMouseover = null;
  /**
   * 버튼의 이미지가 바뀌기전의 이미지.
   * @type String
   * @type private
   */
  this.oldImage = null;
  /**
   * 버튼에 포커스가 위치했는지 여부.
   * @type boolean
   * @private
   */
  this.focused = false;
  /**
   * 컨트롤의 css속성값 혹은 디폴트 속성값을 저장하기 위한 오브젝트
   * default로 eXria_CSS_Configure.xml에 정의된 값으로 설정(최소 default 설정 필요함)
   * @type Object
   * @private
   */
  this.cursor = null;   
  /**
   * 자동줄바꿈 여부.
   * @type Boolean
   */
  this.wordWrap = null;
  
  this.df = {};
  /**
   * 컨트롤의 하위 HTMLElement 요소들
   * @private
   */
  this.subElement = {};
};
eXria.controls.xhtml.Util.createInheritance(eXria.controls.xhtml.UIControl, eXria.controls.xhtml.Button);

eXria.controls.xhtml.Button.prototype.createCtrl = function(poDocument) {
  var voCtrl = poDocument.createElement("div");
  voCtrl["id"] = this.id;
  if(this.canvas.page.metadata.browser.ie > 0) voCtrl["hideFocus"] = true;
  this.document = poDocument;
  this.ctrl = voCtrl;
  return voCtrl;
};

eXria.controls.xhtml.Button.prototype.setTemplate = function(poCtrl, poDocument) {
  this.template = [];
  var vaTemplate = this.template;
  var vsClass = this.getCSSClass(this, 1);
  vaTemplate.push("<button hidefocus='true' type='button' id='");
  vaTemplate.push(this.id);
  vaTemplate.push("_btn' style=\"");
  vaTemplate.push("@cssStrbuf"); //setSpecificAttrs메소드에서  스타일 속성이 대체될  부분은 @cssStrBuf로 마크(Element 속성의 경우엔 @attStrBuf로 마크)
  vaTemplate.push("\" class='" + vsClass + "'>");
  vaTemplate.push("@innStrBuf"); //setSpecificAttrs메소드에서 innerHTML이 대체될 부분은 @innStrBuf로 마크
  vaTemplate.push("</button>");
  vaTemplate.push("<span style=\"");
  vaTemplate.push("@cssStrBuf");
  vaTemplate.push("\"/>");
};

eXria.controls.xhtml.Button.prototype.refreshTemplate = null;

eXria.controls.xhtml.Button.prototype.setSpecificDefaults = function(poCtrl, poDocument) {
  var voUserAttr = null;
  if(this.userAttr) {
    if(/^\s*\(\s*\{(.|\n)*\}\s*\)\s*$/.test(this.userAttr)) voUserAttr = eval(this.userAttr);
    else this.labelName = this.userAttr;
  }
  if(voUserAttr) {
    this.showContextByClick = voUserAttr.showContextByClick;
    this.labelName = voUserAttr.labelName;
  }
  this.setStyleCurrentBorderValue(this);
  this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
  if(this.innerWidth < 0) this.innerWidth = 0;
  this.innerHeight = this.height - this.borderTopWidth - this.borderBottomWidth;
  if(this.innerHeight < 0) this.innerHeight = 0;
  
  this.width = this.getAttrValue("width", this.width);
  this.value = this.getAttrValue("value", this.value);
  this.backgroundImage = this.getAttrValue("backgroundImage", this.backgroundImage);
  this.imagePushed = this.getAttrValue("imagePushed", this.imagePushed);
  //if(this.imagePushed) this.imagePushed = eXria.controls.xhtml.Util.getBackgroundImagePath(this.imagePushed, this.window);
  this.imageFocused = this.getAttrValue("imageFocused", this.imageFocused);
  //if(this.imageFocused) this.imageFocused = eXria.controls.xhtml.Util.getBackgroundImagePath(this.imageFocused, this.window);
  this.imageMouseover = this.getAttrValue("imageMouseover", this.imageMouseover);
  //if(this.imageMouseover) this.imageMouseover = eXria.controls.xhtml.Util.getBackgroundImagePath(this.imageMouseover, this.window);
  this.wordWrap = this.getAttrValue("wordWrap", this.wordWrap);
};

eXria.controls.xhtml.Button.prototype.setSpecificAttrs = function(poCtrl, poDocument) {
  ///////////////////////////////////////////////////////////////////////////////////
  // 블럭 A
  // 이 블럭의 코드는 최외곽의 Div element를 보더로 갖는 컨트롤에 동일하게 적용함
  ///////////////////////////////////////////////////////////////////////////////  
  var voDf = this.df;
  var vaCssStrBuf = null;
  var vaAttStrBuf = null;
  var vaInnStrBuf = null;
  var vaTemplate = this.template;
  //반복해서 호출되는 메소드는 다음과 같이 지역변수를 함수를 할당하여 사용.
  //단, 함수 내부에 this라는 키워드가 들어가는 메소드는 지역변수에 할당할 수 없음)
  var vfcSetCssStrBuf = this.setCssStrBuf;
  var vfcSetAttStrBuf = this.setAttStrBuf;
  
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.09.21 기존에 이와같은 코드가 있었는데 아예 동작을 안했는데 여기서는 동작이 되서 side effect 생김
  //if(this.disabled) poCtrl["disabled"] = true;
  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");
  //////////////////////////////////////////////////////////////////////////////////////////
  // 블럭 A 끝
  //////////////////////////////////////////////////////////////////////////////////////////

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;left:0px;top:0px;border-style:none;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);
	
  // AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
	// backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.
  if(this.backgroundImage) {
		if(this.backgroundImage.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
			var vsSplit = this.backgroundImage.split("\'");
			if(vsSplit[0] == "url(") 
			  vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[2] + "')");
			else
			  vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + vsSplit[1] + "')");		
		} else {
			vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
			if(poCtrl.style["filter"]) poCtrl.style["filter"] = "";
		}
  }

  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else if(this.wordWrap == true) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  
  vaTemplate[3] = vaCssStrBuf.join("");
  vaTemplate[5] = this.getLabelText(this.value);
  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;visibility:hidden;");
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vaTemplate[8] = vaCssStrBuf.join("");
  poCtrl.innerHTML = vaTemplate.join("");
  
  vaAttStrBuf = null;
  vaCssStrBuf = null;
  vaTemplate = null;
  this.template = null;
  
  this.setSubElement(poDocument);
};
/**
 * setSubElement
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Button.prototype.setSubElement = function(poDocument) {
	var voCtrl = this.ctrl;
	var voSubElement = this.subElement;
	voSubElement.button = this.getSubCtrl("button", voCtrl, poDocument);
	voSubElement.span = this.getSubCtrl("span", voCtrl, poDocument);
};
/**
 * @ignore
 */
eXria.controls.xhtml.Button.prototype.setSpecificEvents = function(poCtrl) {
  var voBtn = this.subElement.button;
  this.eventManager.addListener(voBtn, "onblur", this.mediateEvent);
  this.eventManager.addListener(voBtn, "onfocus", this.mediateEvent);  
  voBtn.control = this;
};
/**
 * @ignore
 */
eXria.controls.xhtml.Button.prototype.dofocus = function() {
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  if(this.visible != false)
  	voBtn.focus();
};
/**
 * @ignore
 */
eXria.controls.xhtml.Button.prototype.atfocus = function(poEvent) {
  var voDf = this.df;
  this.focused = true;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var vsImage = voBtn.style.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(this.imageFocused) {
    vsImage = this.imageFocused;
  }
  this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.atblur = function(poEvent) {
  var voDf = this.df;
  this.focused = false;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.atmousedown = function(poEvent) {
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  if(poEvent.target == voBtn) this.focused = true;
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(this.imagePushed) vsImage = this.imagePushed;
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.atmouseup = function(poEvent) {
	var voDf = this.df;
	if(!this.imagePushed) return;
	var voBtn = this.subElement.button;
	var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.atmouseover = function(poEvent) {
  if(this.focused == null) return;  //조건절이 true가 될 수 없는 코드
  
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(this.imageFocused && this.imageFocused == vsImage) return;
  if(this.imageMouseover) vsImage = this.imageMouseover;
//  if(poEvent.target.id == this.id) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.atmouseout = function(poEvent) {
  if(this.focused == null) return;  //조건절이 true가 될 수 없는 코드
  
  var voDf = this.df;
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
//if(poEvent.target.id == this.id) this.setAttrCtrl("backgroundImage", this.oldImage, voBtn);
  var vsImage = null;
  if(this.focused && this.imageFocused) vsImage = this.imageFocused;
  else vsImage = this.backgroundImage;
  if(vsImage == null) vsImage = "";
  if(vsImage != null) this.setAttrCtrl("backgroundImage", vsImage, voBtn);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.atclick = function(poEvent) {
  if(this.showContextByClick == null) return;
  var vcCtl = this.canvas.page.getControl(this.showContextByClick);
  vcCtl.left = this.left;
  vcCtl.top = this.top + this.height;
  if(this.showContext) {
    vcCtl.isShowing = false;
    this.showContext = null;
  } else {
    vcCtl.isShowing = true;
    this.showContext = true;
  }
  vcCtl.refresh();
};
/**
 * 텍스트 박스의 텍스트 세로정렬을 새로고침 합니다.
 * @param {HTMLDiv} poCtrl
 * @private
 */
eXria.controls.xhtml.Button.prototype.setInputHeight = function(poCtrl){
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  var vsText = voBtn.value;
  if(vsText == "") voSpan.innerHTML = "&nbsp;";
  else voSpan.innerHTML = vsText;
  //var vnHeight = voSpan.offsetHeight;
  //this.setAttrCtrl("height", vnHeight, voBtn);
}
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.loadComplete = function(poDocument) {
	var voDf = this.df;
	var voCtrl = this.ctrl;
	var voBtn = this.subElement.button;
	if(this.canvas.page.metadata.browser.opera){
		this.setInputHeight(voCtrl);
		this.setVerticalAlign(voBtn, voCtrl);
	}	  
};
/**
 * 수직정렬 처리.
 * @param {HTMLElement} poCtrl 수직정렬 대상 Element
 * @param {HTMLElement} poParent 수직정렬 대상 Element 의 상위 Element
 * @private
 */
eXria.controls.xhtml.Button.prototype.setVerticalAlign = function(poCtrl, poParent) {  
	var vnHeight = this.subElement.span.offsetHeight;
	var vnParentHeight = parseInt(poParent.style.height);
	var vnPadding = vnParentHeight - vnHeight;
	if(vnPadding < 0) vnPadding = 0;
	vnPadding = vnPadding / 2;
	if(vnParentHeight < vnHeight) vnPadding = 0;
	poCtrl.style.paddingTop = vnPadding + "px";
};
/**
 * setAttrSubCtrl
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poCtrl 실체화 컨트롤
 * @private
 */
eXria.controls.xhtml.Button.prototype.setAttrSubCtrl = function(psAttrName, psAttrValue, poCtrl) {
  if(poCtrl.id != this.id) return;    
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  switch(psAttrName) {
  case "disabled" :
    this.setDisable(voBtn, psAttrValue);
    break;
  case "width" :
    this.setAttrCtrl("width", this.innerWidth, voBtn);
    break;
  case "height" :
  	if(this.canvas.page.metadata.browser.opera){  
  		this.setVerticalAlign(voBtn, poCtrl);
  	}
    this.setAttrCtrl("height", this.innerHeight, voBtn);
    break;
  }
};
//eXria.controls.xhtml.Button.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
//  this.df = {};
//  var voEventManager = this.eventManager;
//  var voBtn = this.subElement.button;
//  this.setAttrCtrl("borderColor", "", poCtrl);
//  this.setAttrCtrl("borderStyle", "", poCtrl);
//  this.setAttrCtrl("borderLeftWidth", "", poCtrl);
//  this.setAttrCtrl("borderRightWidth", "", poCtrl);
//  this.setAttrCtrl("borderTopWidth", "", poCtrl);
//  this.setAttrCtrl("borderBottomWidth", "", poCtrl);
//  this.setAttrCtrl("fontFamily","",voBtn);
//  this.setAttrCtrl("fontSize","",voBtn);
//  this.setAttrCtrl("fontStyle","",voBtn);
//  this.setAttrCtrl("fontWeight","",voBtn);
//  this.setAttrCtrl("textAlign", "", voBtn);
//  this.setAttrCtrl("textDecoration", "", voBtn);
//  this.setAttrCtrl("cursor", "", voBtn);
//  this.setAttrCtrl("backgroundImage","",voBtn);  
//  this.setAttrCtrl("backgroundColor","",voBtn);     
//  this.setAttrCtrl("backgroundRepeat", "", voBtn);
//  this.setAttrCtrl("backgroundPosition", "", voBtn);
//  this.setAttrCtrl("color", "", voBtn);
//  voEventManager.removeListener(voBtn, "onblur", this.mediateEvent);
//  voEventManager.removeListener(voBtn, "onfocus", this.mediateEvent);
//};
/**
 * @ignore
 */
eXria.controls.xhtml.Button.prototype.removeSpecificDefaults = function(poCtrl, poDocument) {
  this.df = {};
};

/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.refreshSpecificAttrs = function(poCtrl, poDocument) {
  var voDf = this.df;
  var voBtn = this.subElement.button;
  var vaCssStrBuf = null;
  var vfcSetCssStrBuf = this.setCssStrBuf;
  
  voBtn.className = this.getCSSClass(this, 1);
  poCtrl["tabIndex"] = this.tabIndex;
  poCtrl["tooltip"] = this.tooltip;
  // 2009.09.21 기존 voDF.disabed는 아예 동작을 안했는데 여기서는 동작이 되서 side effect 생김
  //if(this.disabled) poCtrl["disabled"] = true;  
  vaCssStrBuf = [];
  vaCssStrBuf.push("margin:0px;padding:0px;");
  if(this.visible == false) vaCssStrBuf.push("display:none;");
  else vaCssStrBuf.push("display:block;");
  vfcSetCssStrBuf(vaCssStrBuf, "z-index", this.zIndex);
  vfcSetCssStrBuf(vaCssStrBuf, "position", this.position);
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "border-style", this.borderStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "border-color", this.borderColor);
  vfcSetCssStrBuf(vaCssStrBuf, "left", this.left, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "top", this.top, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-left-width", this.borderLeftWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-right-width", this.borderRightWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-top-width", this.borderTopWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "border-bottom-width", this.borderBottomWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  poCtrl.style.cssText = vaCssStrBuf.join("");

  vaCssStrBuf = [];
  vaCssStrBuf.push("position:absolute;margin:0px;left:0px;top:0px;border-style:none;");
  vfcSetCssStrBuf(vaCssStrBuf, "width", this.innerWidth, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "height", this.innerHeight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "color", this.color);
  vfcSetCssStrBuf(vaCssStrBuf, "font-family", this.fontFamily);
  vfcSetCssStrBuf(vaCssStrBuf, "font-size", this.fontSize, "pt");
  vfcSetCssStrBuf(vaCssStrBuf, "font-style", this.fontStyle);
  vfcSetCssStrBuf(vaCssStrBuf, "font-weight", this.fontWeight);
  vfcSetCssStrBuf(vaCssStrBuf, "text-align", this.textAlign);
  vfcSetCssStrBuf(vaCssStrBuf, "text-decoration", this.textDecoration);
  vfcSetCssStrBuf(vaCssStrBuf, "padding-left", this.paddingLeft, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-right", this.paddingRight, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-top", this.paddingTop, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "padding-bottom", this.paddingBottom, "px");
  vfcSetCssStrBuf(vaCssStrBuf, "background-color", this.backgroundColor);
  vfcSetCssStrBuf(vaCssStrBuf, "background-repeat", this.backgroundRepeat);
  vfcSetCssStrBuf(vaCssStrBuf, "background-position", this.backgroundPosition);

	// AlphaImageLoader는 IE 6.0 이하에서 PNG의 투명처리를 위해서 사용되는 비표준 기술임으로 속성으로 빼지않고
	// backgroundImage 속성에 기술되었을 경우에 대해서만 지원한다.	
  if(this.backgroundImage) {
		if(this.backgroundImage.indexOf("filter.progid:DXImageTransform.Microsoft.AlphaImageLoader") > -1) {
			var vsSplit = this.backgroundImage.split("\'");
			if(vsSplit[0] == "url(") 
			  vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\'" + vsSplit[2] + "\')");
			else
			  vfcSetCssStrBuf(vaCssStrBuf, "filter", "progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\'" + vsSplit[1] + "\')");		
		} else {
			vfcSetCssStrBuf(vaCssStrBuf, "background-image", this.backgroundImage);
			if(voBtn.style["filter"]) voBtn.style["filter"] = "";
		}
  }

  vfcSetCssStrBuf(vaCssStrBuf, "cursor", this.cursor);
  if(this.wordWrap == false) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "nowrap");
  else if(this.wordWrap == true) vfcSetCssStrBuf(vaCssStrBuf, "white-space", "normal");
  
  voBtn.style.cssText = vaCssStrBuf.join("");
  if(this.canvas.page.metadata.browser.opera){
	//20091125 최현종 수정 voCtrl -> poCtrl (opera bug)
  	this.setVerticalAlign(voBtn, poCtrl, "middle");
  }
  voBtn.innerHTML = this.getLabelText(this.value)
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.refreshSpecificEvents = function(poCtrl) {
	this.setSpecificEvents(poCtrl);
};
/**
 * applyAttrRebuild
 * @param {String} psAttrName 속성명
 * @param {String} psAttrValue 지정된 속성값
 * @param {HTMLElement} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */ 
eXria.controls.xhtml.Button.prototype.applyAttrRebuild = function(psAttrName, psAttrValue, poDocument) {
  var voCtrl = this.ctrl;
  var voBtn = this.subElement.button;
  var voSpan = this.subElement.span;
  var voDf = this.df;
  
  this.setAttr(psAttrName, psAttrValue);
  var vaAttrName = psAttrName.split(".");
  var voObj = this;
  for(var i = 0; i < vaAttrName.length - 1; i++) {
    voObj = voObj[vaAttrName[i]];
  }
  //if(voObj.df) voObj.df[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
  switch(psAttrName) {
  case "visible" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
    if(this.canvas.page.metadata.browser.opera){
    	this.setInputHeight(voCtrl);
    	this.setVerticalAlign(voBtn, voCtrl, "middle");
    }
    break;
  case "disabled" :
  	this.setDisable(voCtrl, psAttrValue);
  	break;
  case "left" :
  case "top" :
    voCtrl.style[psAttrName] = psAttrValue + "px";
    break;
  case "borderLeftWidth" :
  case "borderRightWidth" :
    this.setAttrCtrl(psAttrName, this[psAttrName] + "px", voCtrl);
  case "width" :
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    break;
  case "borderTopWidth" :
  case "borderBottomWidth" :
    this.setAttrCtrl(psAttrName, this.df[psAttrName] + "px", voCtrl);
  case "height" :
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "borderWidth" :
    this.borderLeftWidth = this.borderWidth;
    this.borderRightWidth = this.borderWidth;
    this.borderTopWidth = this.borderWidth;
    this.borderBottomWidth = this.borderWidth;
    this.innerWidth = this.width - this.borderLeftWidth - this.borderRightWidth;
    if(this.innerWidth < 0) this.innerWidth = 0;
    this.innerHeight = this.height -  this.borderTopWidth - this.borderBottomWidth;
    if(this.innerHeight < 0) this.innerHeight = 0;
    this.setAttrCtrl("borderLeftWidth", this.borderLeftWidth + "px", voCtrl);
    this.setAttrCtrl("borderRightWidth", this.borderRightWidth + "px", voCtrl);
    this.setAttrCtrl("borderTopWidth", this.borderTopWidth + "px", voCtrl);
    this.setAttrCtrl("borderBottomWidth", this.borderBottomWidth + "px", voCtrl);
    this.setAttrCtrl("width", this.innerWidth, voCtrl);
    this.setAttrCtrl("height", this.innerHeight, voCtrl);
    break;
  case "padding" :
    if(this.paddingLeft == null) this.paddingLeft = this.padding;
    if(this.paddingRight == null) this.paddingRight = this.padding;
    if(this.paddingTop == null) this.paddingTop = this.padding;
    if(this.paddingBottom == null) this.paddingBottom = this.padding;
    this.setAttrCtrl("paddingLeft", this.paddingLeft + "px", voBtn);
    this.setAttrCtrl("paddingRight", this.paddingRight + "px", voBtn);
    this.setAttrCtrl("paddingTop", this.paddingTop + "px", voBtn);
    this.setAttrCtrl("paddingBottom", this.paddingBottom + "px", voBtn);
    break;
  case "paddingLeft" :
  case "paddingRight" :
  case "paddingTop" :
  case "paddingBottom" :
    this.setAttrCtrl(psAttrName, psAttrValue + "px", voBtn);
    break;
  case "backgroundImage" :
    psAttrValue = eXria.controls.xhtml.Util.getBackgroundImagePath(psAttrValue, this.window);
    if(voObj) voObj[vaAttrName[vaAttrName.length - 1]] = psAttrValue;
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "value" :
    this.setValue(psAttrValue);
    break;
  case "backgroundColor" :
    this.setAttrCtrl(psAttrName, psAttrValue, voCtrl);
  case "fontFamily" :
  case "fontSize" :
  case "fontStyle" :
  case "fontWeight" :
  case "textAlign" :
  case "textDecoration" :      
  case "backgroundPosition":
  case "backgroundRepeat":
    this.setAttrCtrl(psAttrName, psAttrValue, voBtn);
    break;
  case "outerClassName" :
  case "className" :
  default :
    this.refresh(poDocument);
    break;
  }
};
/**
 * loadData
 * @param {HTMLElement} poDocument 실체화 컨트롤이 위치한 Document
 * @private
 */
eXria.controls.xhtml.Button.prototype.loadData = function(poDocument) {
  this.onchangeInitValue = undefined;
  if(this.data.instanceId == null || this.data.isRelativeRef()) {
    this.onchangeInitValue = this.value ? this.value : "";
    return;
  }
  var vsRefValue = this.data.getData(); 
  this.setValue(vsRefValue);
};
/**
 * @private
 */
eXria.controls.xhtml.Button.prototype.reloadData = function(poCtrl, poDocument) {
  this.loadData(poDocument);
}; 
/**
 * 버튼에 라벨(아이콘 이미지 포함)을 표시합니다.
 * @param {String} psLabel 라벨명
 */
eXria.controls.xhtml.Button.prototype.setValue = function(psLabel) {
  var voBtnCtrl = this.subElement.button;
  var vbChanged = false;
  if(this.onchangeInitValue !== undefined && this.onchangeInitValue != psLabel) {
    vbChanged = true;
  }
  this.value = psLabel;
  if(vbChanged) {
    this.data.setData(this.value);
  }
  
  voBtnCtrl.innerHTML = this.getLabelText(psLabel);
//  var vaLabel = psLabel.split(";");
//  if(vaLabel[0]) {
//    this.setText(poCtrl, eXria.controls.xhtml.Util.parseLang(vaLabel[0]));
//  }
//  var voImg = null;
//  if(vaLabel[1]) {
//    voImg = poDocument.createElement("img");
//    voImg.setAttribute("src", vaLabel[1]);
//    poCtrl.appendChild(voImg);
//  }
};
/**
 * 지정된 값을 버튼에 표시할 라벨 텍스트로 변경시켜 주는 메소드입니다.
 * @param {String} psValue 입력 텍스트
 * @private
 */
eXria.controls.xhtml.Button.prototype.getLabelText = function(psValue) {
  if(psValue == null) return "";
  this.value = psValue;
//  this.df.value = psValue;
  
  var vaLabel = psValue.split(";");
  var vaStrBuf = [];
  var vsStr = null;
  vsStr = vaLabel[0];
  if(vsStr) {
  	vsStr = vsStr.replace(/</g, "&lt;");
  	vsStr = vsStr.replace(/>/g, "&gt;");
  	vsStr = vsStr.replace(/\n/g, "<br/>");
  	vsStr = eXria.controls.xhtml.Util.parseLang(vsStr);
  	vaStrBuf.push(vsStr);
  }
  vsStr = vaLabel[1];
  if(vsStr) {
    vaStrBuf.push("<img src='");
    vaStrBuf.push(vsStr);
    vaStrBuf.push("'>");
  }
  
  return vaStrBuf.join("");
};
/**
 * 버튼에 표시된 라벨값을 반환합니다.
 * @return 컨트롤 value속성 값
 * @type String
 */
eXria.controls.xhtml.Button.prototype.getValue = function() {
  return this.value;
};
/**
 * 버튼의 포커스를 해제합니다.
 */
eXria.controls.xhtml.Button.prototype.blur = function() {
  this.ctrl.blur();
};
/**
 * 버튼에 클릭 이벤트를 발생시킵니다.
 */   
eXria.controls.xhtml.Button.prototype.click  = function() {
  this.ctrl.click();
};
/**
 * 버튼에 포커스를 발생시켜 줍니다.
 */
eXria.controls.xhtml.Button.prototype.focus  = function() {
  this.ctrl.focus();
};
/**
 * 각 속성에 따른 디폴트 속성값을 반환합니다.
 * @param {String} psAttrName 속성명
 * @return 디폴트 속성값
 * @private
 */
eXria.controls.xhtml.Button.prototype.getSpecificDefaultValue = function(psAttrName) {
  var vsDefaultValue = eXria.controls.xhtml.Default.Button[psAttrName];
  if(vsDefaultValue === undefined) {
    return null;
  }
  return vsDefaultValue;
};  
/**
 * 클래스 명을 반환합니다.
 * @return "Button"
 * @type String
 */
eXria.controls.xhtml.Button.prototype.toString = function() {
  return "Button";
};
