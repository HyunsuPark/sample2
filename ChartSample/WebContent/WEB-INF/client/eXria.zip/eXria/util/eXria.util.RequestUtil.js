/**
 * @fileoverview
 * RequestUtil
 */
 
/**
 * RequestUtil
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.util.RequestUtil = {
    APP_NAME_MSIE : "MSIE",
    APP_NAME_FIREFOX : "Firefox",
    APP_NAME_SAFARI : "Safari",
    APP_NAME_OPERA : "Opera",
    vaToResponse : null,

    /**
     *
     * @param {Object} object
     */
    forInView : function( object, poPage ) {
		var voDocument = poPage.window.document;
        var viewData = "";
        var i = 0;
        for( num in object ) {
            viewData += i+" # ["+num + " : \n" + object[num] + "\n]\n<br>";
            i++;
        }
        voDocument.write(viewData);
    },
    forInViews : function( object ) {
        var viewData = "";
        var i = 0;
        for( num in object ) {
            viewData += i+" # ["+num + " : \n" + object[num] + "\n]\n";
            i++;
        }
        alert( viewData );
    },
    httpMessage : function( data ) {
        switch( eXria.lang.Browser.name ) {
            case eXria.util.RequestUtil.APP_NAME_MSIE :
                alert( data.xml );
                break;
            case eXria.util.RequestUtil.APP_NAME_FIREFOX :
                alert( data.documentElement.textContent );
                break;
            case eXria.util.RequestUtil.APP_NAME_SAFARI :
                break;
        }
    },
    /**
     * DOM 객체를 QueryString으로 변환
     * @param {Object} poDOM
     * @param {Object} psXPath
     */
    toResponse : function( poDOM, psXPath ) {
        var voToResponse = "";
        eXria.util.RequestUtil.vaToResponse = new Array();
        try {
            eXria.util.RequestUtil.doRecursive( poDOM.selectNodes(psXPath), "" );
            var vSeparator = "";
            for( var i=0; i < eXria.util.RequestUtil.vaToResponse.length; i++ ) {
                var voQueryString = eXria.util.RequestUtil.vaToResponse[i]+"";
                if( voQueryString != "undefined" ) {
                    voToResponse += vSeparator+voQueryString;
                }
                vSeparator = "&";
            }
        } catch( e ) {
            throw new Error( "eXria.data.Instance#toResponse \n[ERROR : " + e.message + "]");
        }
        return voToResponse;
    },
    /**
     *
     * @param {Object} poDOM
     * @param {Object} pResponse
     */
    doRecursive : function( poDOM, pResponse ) {
        try {
            for( var i=0; i<poDOM.length; i++ ) {
                var voItem = poDOM.item(i);
                var voNodeList = voItem.childNodes;
                switch( voItem.nodeType ) {
                    case eXria.data.transform.dom.Node.NODE_ELEMENT :
                        if( voItem.tagName != "undefined"
                                && voItem.text != ""
                                && voNodeList.item(0).lastChild == null) {
                            var voQueryString = voItem.tagName +"="+ voItem.text;
                            eXria.util.RequestUtil.vaToResponse[eXria.util.RequestUtil.vaToResponse.length+1] = voQueryString;
                        }
                        break;
                    default :
                        break;
                }
                if( voNodeList.length > 0 ) {
                    eXria.util.RequestUtil.doRecursive( voNodeList, pResponse );
                }
            }
        } catch( e ) {
            throw new Error( "eXria.data.Instance#doRecursive() : \n"+e.message );
        }
    }
};