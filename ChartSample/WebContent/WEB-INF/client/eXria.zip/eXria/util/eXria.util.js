/**
 * @fileoverview
 * eXria.util
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 */

/**
 * eXria.util
 */
eXria.util = {}; 