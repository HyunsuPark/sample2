﻿/**
 * @fileoverview
 * StringUtil
 */
 
/**
 * StringUtil
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.util.StringUtil = {
  /**
   * 파라미터로 넘어온 문자열의 null처리
   * @param {Object} puValue null 처리 되어야 할 문자열
   * @param {String} psDefault 첫번째 파라미터가 null일 경우 대체될 문자열
   * @return 첫번째 파라미터가 null이 아니라면 해당문자열 리턴, null이라면 두번째 파라미터로 넘어온 대체 문자열 리턴.
   * @type String
   */
  fix : function(puValue, psDefault) {
    var vsDefault = psDefault || null;
    //return puValue == null || puValue == undefined ? vsFix -> vsDefault(090420 수정 최현종) : new String(puValue).valueOf();
    return puValue == null || puValue == undefined ? vsDefault : new String(puValue).valueOf();
  },
  /**
   * 파라미터로 넘어온 문자열의 null처리
   * @param {String} psValue null 처리 할 문자열
   * @return 파라미터로 넘어온 데이터가 null일 경우 공백 아니라면 파라미터 데이터 리턴
   * @type String
   */
  fixNull : function(psValue) {
    return psValue == null ? "" : psValue;
  },
  /**
   * 파라미터로 넘어온 2개의 문자열이 같은 문자열인지 비교
   * @param {Object} puValue1 비교문자열
   * @param {Object} puValue2 비교문자열
   * @return 같다면 true, 틀리면 false
   * @type Boolean
   */
  equals : function(puValue1, puValue2) {
    return this.fix(puValue1, "").toLowercase() == this.fix(puValue2, "").toLowercase();
  },
  /**
   * 파라미터로 넘어온 문자열 앞 뒤의 공백 삭제
   * @param {Object} puValue 공백을 지울 문자열
   * @return 공백이 지워진 문자열
   * @type String
   */
  trim : function( puValue ) {
    return puValue.replace(/(^\s*)|(\s*$)/g, "");
  },
  /**
   * 첫번째 파라미터의 문자열의 시작이 두번째 파라미터와 일치하는지 검사
   * @param {String} psStr 비교될 문자열
   * @param {String} psWith 비교할 문자열
   * @return 문자열의 시작이 일치한다면 true, 불일치하다면 false
   * @type Boolean
   */
  startsWith : function(psStr, psWith) {
    return (psStr.indexOf(psWith) == 0);
  },
  /**
   * 첫번째 파라미터의 문자열의 끝이 두번째 파라미터와 일치하는지 검사
   * @param {String} psStr 비교될 문자열
   * @paran {String} psWith 비교할 문자열
   * @return 문자열의 끝이 일치한다면 true, 불일치한다면 false
   * @type Boolean
   */
  endsWith : function(psStr, psWith) {
    var vnIdx = psStr.lastIndexOf(psWith);
    return vnIdx != -1 && vnIdx == (psStr.length - psWith.length);
  },
  /**
   * 한글/영어에 맞게 넘어온 문자열의 Byte 길이를 반환합니다.
   * @param {String} psStr
   * @type Number
   * @return 문자열의 길이
   * @author Choe, Hyeon jong.
   */
  getStringLength : function(psStr) {
    for(var i = 0, pnStrLen = 0, pnChCode = null, vsCh = null ; i < psStr.length ; i++) {
      pnChCode = psStr.charCodeAt(i)
      vsCh = psStr.substr(i,1).toUpperCase()
      pnChCode = parseInt(pnChCode)
      if ((vsCh < "0" || vsCh > "9") && (vsCh < "A" || vsCh > "Z") && ((pnChCode > 255) || (pnChCode < 0)))
        pnStrLen = pnStrLen + 2;
      else
        pnStrLen = pnStrLen + 1;
    }
    return pnStrLen;
  },
   
   /**
    * 문자열의 바이트를 수를 구한다.
    * @param {String} pstr 대상 문자열
    * @type Number
    * @return 문자열 바이트 수
    */
   getByteLength : function(psText) {
     var vnByteLength = 0;
     if (psText.valueOf() == null || psText.length == 0) {
       return 0;
     }
     var vsTemp;
     for ( var i = 0; i < psText.length; i++) {
       vsTemp = escape(psText.charAt(i));
       if (vsTemp.length == 1) {
         vnByteLength++;
       } else if (vsTemp.indexOf("%u") != -1) {
         vnByteLength += 2;
       } else if (vsTemp.indexOf("%") != -1) {
         vnByteLength += vsTemp.length / 3;
       }
     }
     return vnByteLength;
   }
};
