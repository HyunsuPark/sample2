﻿/**
 * gCore.LineType
 */
gCore.LineType = {
  DEFAULT : 0,
  SOLID : 0,
  DOT : 1,
  DASH : 2
};
