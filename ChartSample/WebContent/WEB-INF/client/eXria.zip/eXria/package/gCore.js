/**
 * gCore
 *
 * @use YAHOO UI 2.4.1 (BSD) Browser Check
 */
gCore = {
  /**
   * browser
   */  
  browser : {
  msie : 0,
  gecko : 0,
  opera : 0,
  webkit : 0,
  mobile : null,
  trident : 0
  },

  /**
   * init
   * public static method
   */
  init : function(poWindow) {
  var voDocument = poWindow.document;
  var vsAgent = poWindow.navigator.userAgent;
  var voInfo = null;
    // Modern KHTML browsers should qualify as Safari X-Grade
    if ((/KHTML/).test(vsAgent)) { gCore.browser.webkit = 1; }

    // Modern WebKit browsers are at least X-Grade
    voInfo = vsAgent.match(/AppleWebKit\/([^\s]*)/);
    if (voInfo && voInfo[1]) {
      gCore.browser.webkit = parseFloat(voInfo[1]);

      // Mobile browser check
      if (/ Mobile\//.test(vsAgent)) {
        gCore.browser.mobile = "Apple"; // iPhone or iPod Touch
      } else {
        voInfo = vsAgent.match(/NokiaN[^\/]*/);
        if (voInfo) {
          gCore.browser.mobile = voInfo[0]; // Nokia N-series, ex: NokiaN95
        }
      }
    }

    if (!gCore.browser.webkit) { // not webkit
      // @todo check Opera/8.01 (J2ME/MIDP; Opera Mini/2.0.4509/1316; fi; U; ssr)
      voInfo = vsAgent.match(/Opera[\s\/]([^\s]*)/);
      if (voInfo && voInfo[1]) {
        gCore.browser.opera = parseFloat(voInfo[1]);
        voInfo = vsAgent.match(/Opera Mini[^;]*/);
        if (voInfo) {
          gCore.browser.mobile = voInfo[0]; // ex: Opera Mini/2.0.4509/1316
        }
      } else { // not opera or webkit
        voInfo = vsAgent.match(/MSIE\s([^;]*)/);
        if (voInfo && voInfo[1]) {
          gCore.browser.msie = parseFloat(voInfo[1]);
          voInfo = vsAgent.match(/Trident\/([^;]*)/);
          if(voInfo && voInfo[1]) gCore.browser.trident = parseFloat(voInfo[1]);
        } else { // not opera, webkit, or ie
          voInfo = vsAgent.match(/Gecko\/([^\s]*)/);
          if (voInfo) {
            gCore.browser.gecko = 1; // Gecko detected, look for revision
            voInfo = vsAgent.match(/rv:([^\s\)]*)/);
            if (voInfo && voInfo[1]) {
              gCore.browser.gecko=parseFloat(voInfo[1]);
            }
          }
        }
      }
    }    
    
    var voPackage = null;

    if (gCore.browser.msie && gCore.browser.msie < 10.0) {
      var vbHasNameSpace = false;
      for (var i = 0; i < voDocument.namespaces.length; i++) {
        if (voDocument.namespaces.item(i).name == "v") vbHasNameSpace = true;
      }
      if (vbHasNameSpace == false) {
        voDocument.namespaces.add("v", "urn:schemas-microsoft-com:vml");
        var voSheet = voDocument.createStyleSheet();
        var voTmpFnc = function() {
          voSheet.addRule("v\\:arc", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:oval", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:line", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:group", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:polyline", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:rect", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:roundrect", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:stroke", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:path", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:textpath", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:fill", "behavior: url(#default#VML);");
          voSheet.addRule("v\\:image", "behavior: url(#default#VML);");
        }

        if(gCore.browser.msie <= 7){
          try {
           voSheet.addRule("v\\:*", "behavior: url(#default#VML);");
          }catch(e){
           voTmpFnc();
          }
        }else{
          voTmpFnc();
        }
      }

      voPackage = gCore.vml; 
    } else {
      voPackage = gCore.svg;
    }

    poWindow.Pane      = voPackage.Pane      ? voPackage.Pane      : null;
    poWindow.Line      = voPackage.Line      ? voPackage.Line      : null;
    poWindow.Rectangle = voPackage.Rectangle ? voPackage.Rectangle : null;
    poWindow.RoundRect = voPackage.RoundRect ? voPackage.RoundRect : null;
    poWindow.Ellipse   = voPackage.Ellipse   ? voPackage.Ellipse   : null;
    poWindow.Circle    = voPackage.Circle    ? voPackage.Circle    : null;
    poWindow.Polyline  = voPackage.Polyline  ? voPackage.Polyline  : null;
    poWindow.Text      = voPackage.Text      ? voPackage.Text      : null;

/*    
    document.body.style.margin = "0px";
    document.body.style.padding = "0px";
*/
  }

};

