﻿/**
 * gCore.vml.Circle
 */
gCore.vml.Circle = function(psId, pnCenterX, pnCenterY, pnRadius) {

  var vnLeft = pnCenterX - pnRadius;
  var vnTop = pnCenterY - pnRadius;
  var vnDiameter = pnRadius * 2;
  
  /**
   * inherit
   */
  gCore.vml.Ellipse.call(this, psId, vnLeft, vnTop, vnDiameter, vnDiameter);

  this.radius = pnRadius;
};
