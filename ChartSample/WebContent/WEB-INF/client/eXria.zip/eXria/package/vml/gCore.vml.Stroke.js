﻿/**
 * gCore.vml.Stroke
 */
gCore.vml.Stroke = function(pnType, pnWeight, psColor, pnOpacity, pnLineCap, pnJoinType) {
  /**
   * inherit
   */
  gCore.Stroke.call(this, pnType, pnWeight, psColor, pnOpacity, pnLineCap, pnJoinType);
  
  this.apply = function(poCtrl) {
  /*
  var voPane = this.shape.pane;
  var voReadWidth = voPane.width;
  var voRealHeight = voPane.height;
  var voCoordWidth = voPane.coordWidth;
  var voCoordHeight = voPane.coordHeight;
*/
    var voCtrl = this.shape.pane.document.createElement("v:stroke");
    var vsType = gCore.vml.LineTypes[this.type];
    voCtrl.setAttribute("id", this.shape.id + "_stroke");
    voCtrl.setAttribute("dashstyle", vsType); 
    voCtrl.setAttribute("weight", this.weight);
    voCtrl.setAttribute("color", this.color);
    voCtrl.setAttribute("opacity", (this.opacity * 100) + "%");
    voCtrl.setAttribute("endcap", gCore.vml.LineCapTypes[this.lineCap]);
    voCtrl.setAttribute("joinstyle", gCore.vml.JoinTypes[this.joinType]);
    voCtrl.setAttribute("on", this.visible ? true : false);
    
    if(vsType == "none" || parseInt(this.weight) == 0) voCtrl.setAttribute("on", false);

    poCtrl.appendChild(voCtrl);
    return poCtrl;
  };
  
  this.getCtrl = function() {
  return this.shape.pane.document.getElementById(this.shape.id + "_stroke");
  }; 
  
};
