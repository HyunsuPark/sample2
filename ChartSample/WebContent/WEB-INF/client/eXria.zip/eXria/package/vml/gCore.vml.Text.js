﻿/**
 * gCore.vml.Text
 */
gCore.vml.Text = function(psId, pnLeft, pnTop, pnWidth, pnHeight, psString, pnPosition) {
  /**
   * inherit
   */
  gCore.vml.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * default
   */
  this.stroke.visible = false;
  this.fill.color = "#000000";
    
  this.string = psString;
  
  this.position = pnPosition || gCore.TextPosition.DEFAULT;
  
  this.fontFamily = "Dotum";
  this.fontSize = 12;
  this.fontStyle = "normal";
  this.fontWeight = "normal";
   
  this.createCtrl = function() {
    
  var vsTextAlign = null;  
  var vnSx = 0;
  var vnSy = 0;

  switch (this.position) {
    case gCore.TextPosition.TOPLEFT :
      vnSx = this.left;
      vnSy = this.top + Math.round(this.fontSize / 2);
      vsTextAlign = "left";
      break;
    case gCore.TextPosition.TOPCENTER :
      vnSx = this.left + Math.round(this.width / 2);
      vnSy = this.top + Math.round(this.fontSize / 2);
      vsTextAlign = "center";
      break;
    case gCore.TextPosition.TOPRIGHT :
      vnSx = this.left + this.width - 1;
      vnSy = this.top + Math.round(this.fontSize / 2);
      vsTextAlign = "right";
      break;
    case gCore.TextPosition.MIDDLELEFT :
      vnSx = this.left;
      vnSy = this.top + Math.round(this.height / 2);
      vsTextAlign = "left";
      break;
    case gCore.TextPosition.MIDDLECENTER :
      vnSx = this.left + Math.round(this.width / 2);
      vnSy = this.top + Math.round(this.height / 2);
      vsTextAlign = "center";
      break;
    case gCore.TextPosition.MIDDLERIGHT :
      vnSx = this.left + this.width - 1;
      vnSy = this.top + Math.round(this.height / 2);
      vsTextAlign = "right";
      break;
    case gCore.TextPosition.BOTTOMLEFT :
      vnSx = this.left;
      vnSy = this.top + this.height - Math.round(this.fontSize / 2);
      vsTextAlign = "left";
      break;
    case gCore.TextPosition.BOTTOMCENTER :
      vnSx = this.left + Math.round(this.width / 2);
      vnSy = this.top + this.height - Math.round(this.fontSize / 2);
      vsTextAlign = "center";
      break;
    case gCore.TextPosition.BOTTOMRIGHT :
      vnSx = this.left + this.width - 1;
      vnSy = this.top + this.height - Math.round(this.fontSize / 2);
      vsTextAlign = "right";
      break;
    }   
      
  var vnEx = vnSx + 1;
  var vnEy = vnSy + 1;
      
    var voCtrl = this.pane.document.createElement("v:line");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("from", vnSx + " " + vnSy);
    voCtrl.setAttribute("to", vnEx + " " + vnEy);
    voCtrl.style.rotation = this.angle - 45;
    
    var voPath = this.pane.document.createElement("v:path");
    voPath.setAttribute("textpathok", true);
    voCtrl.appendChild(voPath);

    var voTextPath = this.pane.document.createElement("v:textpath");
    voTextPath.setAttribute("on", true);
    voTextPath.setAttribute("string", this.string);

    voTextPath.setAttribute("fitpath", false);
    voTextPath.setAttribute("fitshape", false);    

    var voStyle = voTextPath.style;
    voStyle.fontFamily = "\"" + this.fontFamily + "\"";
    voStyle.fontSize = this.fontSize;
    voStyle.fontStyle = this.fontStyle;
    voStyle.fontWeight = this.fontWeight;
    voStyle["v-text-align"] = vsTextAlign;

    voCtrl.appendChild(voTextPath);
    
    return voCtrl;
  };

  
};