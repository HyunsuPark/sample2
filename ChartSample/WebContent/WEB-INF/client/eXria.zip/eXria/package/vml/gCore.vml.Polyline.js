﻿/**
 * gCore.vml.Polyline
 */
gCore.vml.Polyline = function(psId) {
  /**
   * inherit
   */
  gCore.vml.FillableShape.call(this, psId, null, null, null, null);

  this.minX = 0;
  this.minY = 0;
  this.maxX = 0;
  this.maxY = 0;
    
  this.points = [];
  
  this.addPoint = function(pnX, pnY) {
    this.points.push({"x":pnX, "y":pnY});
    if (this.minX > pnX) { this.minX = pnX; }
    if (this.maxX < pnX) { this.maxX = pnX; }
    if (this.minY > pnY) { this.minY = pnY; }
    if (this.maxY < pnY) { this.maxY = pnY; }
    this.left = this.minX;
    this.top = this.minY;
    this.width = this.maxX - this.minX + 1;
    this.height = this.maxY - this.minY + 1;
  };

  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElement("v:polyline");
    voCtrl.setAttribute("id", this.id);
    var vsPoints = "";
    var vnLength = this.points.length;
    for (var i = 0; i < vnLength; i++) {
      var voPoint = this.points[i];
      vsPoints += voPoint.x + "," + voPoint.y + " ";
    }
    voCtrl.setAttribute("points", vsPoints);
    var voStyle = voCtrl.style;
    voStyle.rotation = this.angle;
    voStyle.cursor = this.cursor;
    return voCtrl;
  };
  
};
