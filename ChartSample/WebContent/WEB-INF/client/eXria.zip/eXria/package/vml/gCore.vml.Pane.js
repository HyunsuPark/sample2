﻿/**
 * gCore.vml.Pane
 */
gCore.vml.Pane = function(psId, pnLeft, pnTop, pnWidth, pnHeight, poDocument) {
  /**
   * inherit
   */
  gCore.Pane.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight, poDocument);
  
  this.createCtrl = function() {
  var voDiv = this.document.createElement("div");
  voDiv.setAttribute("id", this.id);
  var voDivStyle = voDiv.style;
  voDivStyle.position = "absolute";
  voDivStyle.left = this.left + "px";
  voDivStyle.top = this.top + "px";
  voDivStyle.width = this.width + "px";
  voDivStyle.height = this.height + "px";
  voDivStyle.overflow = "visible";

    var voCtrl = this.document.createElement("v:group");
    voCtrl.setAttribute("id", this.id + "_area");
    voCtrl.setAttribute("coordorigin", this.coordLeft + "," + this.coordTop);
    voCtrl.setAttribute("coordsize", this.coordWidth + "," + this.coordHeight);
    
    var voStyle = voCtrl.style;
    voStyle.position = "absolute";
    voStyle.left = 0 + "px";
    voStyle.top = 0 + "px";
    voStyle.width = this.width + "px";
    voStyle.height = this.height + "px";
    
    voDiv.appendChild(voCtrl);
    return voDiv;
  };
  
};