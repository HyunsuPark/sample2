﻿/**
 * gCore.vml.Arc
 */
gCore.vml.Arc = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pnStartAngle, pnEndAngle) {
  /**
   * inherit
   */
  gCore.vml.Ellipse.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  
  this.startAngle = pnStartAngle;
  
  this.endAngle = pnEndAngle;

  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElement("v:arc");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("startAngle", this.startAngle);
    voCtrl.setAttribute("endAngle", this.endAngle);
    var voStyle = voCtrl.style;
    voStyle.left = this.left;
    voStyle.top = this.top;
    voStyle.width = this.width < 0 ? 0 : this.width;
    voStyle.height = this.height < 0 ? 0 : this.height;
    voStyle.rotation = this.angle; //
    voStyle.cursor = this.cursor;
    return voCtrl;
  };
  
};
