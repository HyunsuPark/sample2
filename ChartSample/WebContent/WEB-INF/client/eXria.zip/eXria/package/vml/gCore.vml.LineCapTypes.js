﻿/**
 * gCore.vml.LineCapTypes
 */
gCore.vml.LineCapTypes = [
  "flat", // FLAT
  "round", // ROUND
  "square" // SQUARE
];
