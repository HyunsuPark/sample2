﻿/**
 * gCore.vml.RoundRect
 */
gCore.vml.RoundRect = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pnRound) {
  /**
   * inherit
   */
  gCore.vml.Rectangle.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  this.round = pnRound;
   
  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElement("v:roundrect");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("arcSize", this.round / 2);
    var voStyle = voCtrl.style;
    voStyle.left = this.left;
    voStyle.top = this.top;
    voStyle.width = (this.width < 0 ? 0 : this.width) + "px";
    voStyle.height = (this.height < 0 ? 0 : this.height) + "px";
    voStyle.rotation = this.angle;
    voStyle.cursor = this.cursor;
    return voCtrl;
  };

};
   