﻿/**
 * gCore.Fill
 */
gCore.Fill = function(psType, psColor, psColor2, pnOpacity, pnAngle) {

  /**
   * shape
   * public member
   */  
  this.shape = null;
  
  /**
   * type
   * public member
   */
  this.type = psType;
  
  /**
   * color
   * public member
   */
  this.color = psColor;
  
  /**
   * color2
   * public member
   */
  this.color2 = psColor2;
  
  /**
   * opacity
   * public member
   */
  this.opacity = pnOpacity;
  
  /**
   * angle
   * public member
   */
  this.angle = pnAngle;
  
  /**
   * visible
   * public member
   * default true
   */
  this.visible = true;
    
};