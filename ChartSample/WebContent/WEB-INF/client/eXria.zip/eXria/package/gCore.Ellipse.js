﻿/**
 * gCore.Ellipse
 */
gCore.Ellipse = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /**
   * inherit
   */
  gCore.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  
};
