﻿/**
 * gCore.Arc
 */
gCore.Arc = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pnStartAngle, pnEndAngle) {
  /**
   * inherit
   */
  gCore.Ellipse.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  /**
   * startAngle
   * public member
   */  
  this.startAngle = pnStartAngle;

  /**
   * endAngle
   * public member
   */
  this.endAngle = pnEndAngle;

};
