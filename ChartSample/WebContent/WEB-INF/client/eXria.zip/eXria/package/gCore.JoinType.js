﻿/**
 * JoinType
 */
gCore.JoinType = {
  DEFAULT : 1,
  MITER : 0,
  ROUND : 1,
  BEVEL : 2
};
