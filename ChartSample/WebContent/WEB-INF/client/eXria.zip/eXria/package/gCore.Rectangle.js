﻿/**
 * gCore.Rectangle
 */
gCore.Rectangle = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /**
   * inherit
   */
  gCore.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);
  
};
