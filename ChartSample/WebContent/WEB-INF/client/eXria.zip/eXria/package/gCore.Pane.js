﻿/**
 * gCore.Pane
 */
gCore.Pane = function(psId, pnLeft, pnTop, pnWidth, pnHeight, poDocument) {
  /**
   * inherit
   */
  gCore.Drawable.call(this, psId);
  
  this.document = poDocument || document;

  /**
   * getCtrl
   * public member
   */
  this.getCtrl = function() {
  return this.document.getElementById(this.id);
  };
  
  /**
   * left
   * public member
   */
  this.left = pnLeft;
  
  /**
   * top
   * public member
   */
  this.top = pnTop;
  
  /**
   * width
   * public member
   */
  this.width = pnWidth;
  
  /**
   * height
   * public member
   */
  this.height = pnHeight;

  /**
   * coords
   */
  this.coordLeft = 0;
  
  this.coordTop = 0;
  
  this.coordWidth = this.width;
  
  this.coordHeight = this.height;

  /**
   * shapes
   * private member
   * array
   */
  this.shapes = [];
  
  /**
   * addShape
   * public member
   */
  this.addShape = function(poShape) {
  poShape.pane = this;
    this.shapes.push(poShape);
  };

  this.getAreaCtrl = function() {
  return this.document.getElementById(this.id + "_area");
  };

  /**
   * draw
   * public method
   */
  this.draw = function(poParent) {
    var voCtrl = this.createCtrl();
    (poParent ? poParent : this.document.body).appendChild(voCtrl);
    var vnLength = this.shapes.length;
    for (var i = 0; i < vnLength; i++) {
      this.shapes[i].draw(this.getAreaCtrl()||voCtrl.childNodes[0]);
    }

    return voCtrl;
  };

  /**
   * createCtrl
   * private method
   */
  this.createCtrl = null;
  
};
