﻿/**
 * LineCapType
 */
gCore.LineCapType = {
  DEFAULT : 1,
  FLAT : 0,
  ROUND : 1,
  SQUARE : 2
};
