﻿/**
 * gCore.svg.Line
 */
gCore.svg.Line = function(psId, pnX1, pnY1, pnX2, pnY2) {
  
  var vnLeft = Math.min(pnX1, pnX2);
  var vnTop = Math.min(pnY1, pnY2);
  var vnWidth = Math.abs(pnX1 - pnX2) + 1;
  var vnHeight = Math.abs(pnY1 - pnY2) + 1;

  /**
   * inherit
   */
  gCore.svg.Shape.call(this, psId, vnLeft, vnTop, vnWidth, vnHeight);

  this.startX = pnX1;
  this.startY = pnY1;
  this.endX = pnX2;
  this.endY = pnY2;

  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "line");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("x1", this.startX);
    voCtrl.setAttribute("y1", this.startY);
    voCtrl.setAttribute("x2", this.endX);
    voCtrl.setAttribute("y2", this.endY);
  
    var vnCx = this.left + Math.round(this.width);
    var vnCy = this.top + Math.round(this.height);
    voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + vnCx + "," + vnCy + ")");
    var voStyle = voCtrl.style;
    voStyle.cursor = this.cursor;
    return voCtrl;
  };
  
};