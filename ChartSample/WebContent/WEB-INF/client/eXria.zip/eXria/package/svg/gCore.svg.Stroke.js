﻿/**
 * gCore.svg.Stroke
 */
gCore.svg.Stroke = function(pnType, pnWeight, psColor, pnOpacity, pnLineCap, pnJoinType) {
  /**
   * inherit
   */
  gCore.Stroke.call(this, pnType, pnWeight, psColor, pnOpacity, pnLineCap, pnJoinType);
  
  this.apply = function(poCtrl) {
    poCtrl.setAttribute("stroke", this.visible ? this.color : "none");
    poCtrl.setAttribute("stroke-width", this.weight);
    poCtrl.setAttribute("stroke-opacity", this.opacity);
    var vnWeight = parseInt(this.weight);
    var vsDash = gCore.svg.LineTypes[this.type];
    if(vnWeight > 1 && this.type) {
      var vaLength = vsDash.split(",");
      vaLength[1] = vnWeight * parseInt(vaLength[1]);
      vsDash = vaLength.join(",");
    }
    poCtrl.setAttribute("stroke-dasharray", vsDash);
    poCtrl.setAttribute("stroke-linecap", gCore.svg.LineCapTypes[this.lineCap]);
    poCtrl.setAttribute("stroke-linejoin", gCore.svg.JoinTypes[this.joinType]);
    return poCtrl;
  };

};
