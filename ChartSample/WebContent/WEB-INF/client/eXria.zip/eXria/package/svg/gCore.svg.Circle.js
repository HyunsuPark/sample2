﻿/**
 * gCore.svg.Circle
 */
gCore.svg.Circle = function(psId, pnCenterX, pnCenterY, pnRadius) {

  var vnLeft = pnCenterX - pnRadius;
  var vnTop = pnCenterY - pnRadius;
  var vnDiameter = pnRadius * 2;
  
  /**
   * inherit
   */
  gCore.svg.Ellipse.call(this, psId, vnLeft, vnTop, vnDiameter, vnDiameter);

  this.centerX = pnCenterX;
  this.centerY = pnCenterY;
  this.radius = pnRadius;
  
  this.createCtrl = function() {
  var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "circle");
  voCtrl.setAttribute("id", this.id);
  voCtrl.setAttribute("cx", this.centerX);
  voCtrl.setAttribute("cy", this.centerY);
  voCtrl.setAttribute("r", this.radius);
  voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + this.centerX + "," + this.centerY + ")");
  var voStyle = voCtrl.style;
  voStyle.cursor = this.cursor;
  return voCtrl;
  };
  
};
