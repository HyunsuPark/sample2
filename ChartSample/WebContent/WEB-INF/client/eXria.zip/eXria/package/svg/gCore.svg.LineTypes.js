﻿/**
 * gCore.svg.LineTypes
 */
gCore.svg.LineTypes = [
  "none", // solid
  "1,2",  // dot
  "6,2"  // dash
];
