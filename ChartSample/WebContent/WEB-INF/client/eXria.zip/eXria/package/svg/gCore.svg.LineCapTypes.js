﻿/**
 * gCore.svg.LineCapTypes
 */
gCore.svg.LineCapTypes = [
  "butt", // FLAT
  "round", // ROUND
  "square" // SQUARE
];
