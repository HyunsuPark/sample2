﻿/**
 * gCore.svg.JoinTypes
 */
gCore.svg.JoinTypes = [
  "miter", // MITER
  "round", // ROUND
  "bevel"  // BEVEL
];
