﻿/**
 * gCore.svg.DefaultStroke
 */
gCore.svg.DefaultStroke = function() {

  gCore.svg.Stroke.call(this, gCore.LineType.DEFAULT, 1, "#505050", 1.0, gCore.LineCapType.DEFAULT, gCore.JoinType.DEFAULT);

};
