﻿/**
 * gCore.svg.Polyline
 */
gCore.svg.Polyline = function(psId) {
  /**
   * inherit
   */
  gCore.svg.FillableShape.call(this, psId, null, null, null, null);
  
  this.minX = 0;
  this.minY = 0;
  this.maxX = 0;
  this.maxY = 0;
    
  this.points = [];
  
  this.addPoint = function(pnX, pnY) {
    this.points.push({"x":pnX, "y":pnY});
    if (this.minX > pnX) { this.minX = pnX; }
    if (this.maxX < pnX) { this.maxX = pnX; }
    if (this.minY > pnY) { this.minY = pnY; }
    if (this.maxY < pnY) { this.maxY = pnY; }
    this.left = this.minX;
    this.top = this.minY;
    this.width = this.maxX - this.minX + 1;
    this.height = this.maxY - this.minY + 1;
  };
  
  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "polyline");
    voCtrl.setAttribute("id", this.id);
    var vsPoints = "";
    var vnLength = this.points.length;
    for (var i = 0; i < vnLength; i++) {
      var voPoint = this.points[i];
      vsPoints += voPoint.x + ", " + voPoint.y + " ";
    }
    voCtrl.setAttribute("points", vsPoints);
    
    var vnCx = this.left + Math.round(this.width);
    var vnCy = this.top + Math.round(this.height);
    voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + vnCx + "," + vnCy + ")");
    var voStyle = voCtrl.style;
    voStyle.cursor = this.cursor;      
    return voCtrl;
  };
  
};
