﻿/**
 * gCore.svg.Ellipse
 */
gCore.svg.Ellipse = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /**
   * inherit
   */
  gCore.svg.FillableShape.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  this.createCtrl = function() {
  var vnRx = Math.round(this.width / 2);
  var vnRy = Math.round(this.height / 2);
  var vnCx = this.left + vnRx;
  var vnCy = this.top + vnRy;
    var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("cx", vnCx);
    voCtrl.setAttribute("cy", vnCy);
    voCtrl.setAttribute("rx", vnRx);
    voCtrl.setAttribute("ry", vnRy); 
    voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + vnCx + "," + vnCy + ")");
    var voStyle = voCtrl.style;
    voStyle.cursor = this.cursor;
    return voCtrl;
  };

};
   