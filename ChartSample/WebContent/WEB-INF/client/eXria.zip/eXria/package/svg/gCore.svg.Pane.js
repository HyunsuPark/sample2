﻿/**
 * gCore.svg.Pane
 */
gCore.svg.Pane = function(psId, pnLeft, pnTop, pnWidth, pnHeight, poDocument) {
  /**
   * inherit
   */
  gCore.Pane.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight, poDocument);

  this.createCtrl = function() {
    var voDiv = this.document.createElement("div");
    voDiv.setAttribute("id", this.id);
    var voDivStyle = voDiv.style;
    voDivStyle.position = "absolute";
    voDivStyle.left = this.left + "px";
    voDivStyle.top = this.top + "px";
    voDivStyle.width = this.width + "px";
    voDivStyle.height = this.height + "px";
    voDivStyle.overflow = "visible";
  
    // yhkim shapeType 추가
    var vsWeight = null;
    var vnWeight = 0;
    var vnOffset = 0;
    if(this.shapes[0]) {
      if(this.shapes[0].shapeType) {
        if(this.shapes[0].shapeType == "line") {
        	vsWeight = this.shapes[0].stroke.weight;
            vnWeight = Number(vsWeight.replace("px",""));
            vnOffset = vnWeight / 2;
        }
      }
    }
    
    var voCtrl = this.document.createElementNS("http://www.w3.org/2000/svg", "svg");
    voCtrl.setAttribute("id", this.id + "_area");
    voCtrl.setAttribute("width", (this.width+vnWeight) + "px");
    voCtrl.setAttribute("height", (this.height+vnWeight) + "px");  
    voCtrl.setAttribute("viewBox", (this.coordLeft-vnOffset) + " " + (this.coordTop-vnOffset) + " " + (this.coordWidth+vnWeight) + " " + (this.coordHeight+vnWeight));
    var voStyle = voCtrl.style;
    voStyle.position = "absolute";
    voStyle.left = -(vnOffset) + "px";
    voStyle.top = -(vnOffset) + "px";
    voStyle.width = (this.width+vnWeight) + "px";
    voStyle.height = (this.height+vnWeight) + "px";
    voDiv.appendChild(voCtrl);
    return voDiv;
  };

};