﻿/**
 * gCore.svg.DefaultFill
 */
gCore.svg.DefaultFill = function() {

  gCore.svg.Fill.call(this, gCore.FillType.DEFAULT, "#F0F0F0", "F0F0F0", 1.0, 0);
  
};
