﻿/**
 * gCore.svg.RoundRect
 */
gCore.svg.RoundRect = function(psId, pnLeft, pnTop, pnWidth, pnHeight, pnRound) {
  /**
   * inherit
   */
  gCore.svg.Rectangle.call(this, psId, pnLeft, pnTop, pnWidth, pnHeight);

  this.round = pnRound;
   
  this.createCtrl = function() {
    var voCtrl = this.pane.document.createElementNS("http://www.w3.org/2000/svg", "rect");
    voCtrl.setAttribute("id", this.id);
    voCtrl.setAttribute("x", this.left);
    voCtrl.setAttribute("y", this.top);
    voCtrl.setAttribute("width", this.width);
    voCtrl.setAttribute("height", this.height);
    voCtrl.setAttribute("rx", ((this.height > this.width ? this.width : this.height) * (this.round / 2)));
    
    var vnCx = this.left + Math.round(this.width/2);
    var vnCy = this.top + Math.round(this.height/2);
    voCtrl.setAttribute("transform", "rotate(" + this.angle + "," + vnCx + "," + vnCy + ")");
    var voStyle = voCtrl.style;
    voStyle.cursor = this.cursor;
    return voCtrl;
  };

};
   