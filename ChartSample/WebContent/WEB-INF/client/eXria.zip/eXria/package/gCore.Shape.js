﻿/**
 * Shape
 */
gCore.Shape = function(psId, pnLeft, pnTop, pnWidth, pnHeight) {
  /**
   * inherit
   */
  gCore.Drawable.call(this, psId);

  /**
   *
   */
  this.pane = null;

  /**
   * left
   * public member
   */
  this.left = pnLeft;

  /**
   * top
   * public member
   */
  this.top = pnTop;

  /**
   * width
   * public member
   */
  this.width = pnWidth;
  
  /**
   * height
   * public member
   */
  this.height = pnHeight;

  this.getCtrl = function() {
  return this.pane ? this.pane.document.getElementById(this.id) : null;
  };

  /**
   * createCtrl
   * private method
   */
  this.createCtrl = null;

  /**
   * stroke
   * public member
   */
  this.stroke = null;
  
  /**
   * setStroke
   * public method
   */
  this.setStroke = null;
  
  /**
   * attachStroke
   * private method
   */        
  this.attachStroke = null;
  
  /**
   * angle
   * public member
   */
  this.angle = 0;
  
};
