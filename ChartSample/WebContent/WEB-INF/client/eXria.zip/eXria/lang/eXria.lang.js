/**
 * @fileoverview
 * eXria.lang package
 */

/**
 * eXria.lang package
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 */
eXria.lang = {};
