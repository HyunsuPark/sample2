/**
 * @fileoverview
 * eXria.protocols.xhtml package
 */
/**
 * eXria.protocols.xhtml package
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 */

/**
 * eXria.protocols
 */
eXria.protocols.xhtml = {};
