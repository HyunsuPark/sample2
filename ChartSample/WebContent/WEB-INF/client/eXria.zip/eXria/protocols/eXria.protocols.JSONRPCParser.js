﻿/**
 * @fileoverview
 * JSONRPCParser
 */
 
/**
 * JSONRPCParser
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.JSONParser
 * @constructor
 * @private
 */
eXria.protocols.JSONRPCParser = function(poSubmission) {
  eXria.protocols.JSONParser.call(this, poSubmission);

  this.bind = false;

  this.parse = function(poXMLHttpRequest) {
    var vsJSON = poXMLHttpRequest.responseText; //json text
    var voResponse;
    eval('voResponse = ' + vsJSON);

    return voResponse.result;
  };
}; 