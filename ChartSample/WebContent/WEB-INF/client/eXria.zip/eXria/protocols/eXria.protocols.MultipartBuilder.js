/**
 * @fileoverview
 * MultipartBuilder
 */

/**
 * MultipartBuilder
 * 파일업로드를 사용하기 위한 Builder
 * @author Choe, hyeon jong
 * @param {eXria.protocols.Submission} poSubmission Submission 객체
 * @base eXria.protocols.RequestBuilder
 * @constructor
 * @private
 */
eXria.protocols.MultipartBuilder = function(poSubmission) {
  /**
   * Inherit
   */  
  eXria.protocols.RequestBuilder.call(this, poSubmission);
  
  //hidden 타입의 input 엘레멘트를 추가
  this.appendHiddenParams = function(poPageDocument, poForm, psParamKey, psParamValue) {
    //input 태그를 생성
    var voInputElement = poPageDocument.createElement("input");
    voInputElement.setAttribute("type", "hidden");
    voInputElement.setAttribute("id", psParamKey);
    voInputElement.setAttribute("name", psParamKey);
    voInputElement.setAttribute("value", psParamValue);
    //생성된 input element를 form에 append
    poForm.appendChild(voInputElement);
  };
  this.searchAndAppendInstNode = function(poNode, poForm, poPageDocument) {
    var voWhiteSpace = /\S/;
    
    if (poNode.hasChildNodes()) {
      var vaChildNodes = poNode.childNodes;
      var vnChildNodesLen = vaChildNodes.length;
      
      for (var i = 0; i < vnChildNodesLen; i++) {
        if ((vaChildNodes [i].nodeType == 3 || vaChildNodes [i].nodeType == 4)
        && (voWhiteSpace.test(vaChildNodes [i].nodeValue))) {
          this.appendHiddenParams(poPageDocument, poForm, vaChildNodes [i].parentNode.nodeName, vaChildNodes [i].nodeValue);
        } else {
          if (vaChildNodes [i].nodeType == 1) {
            this.searchAndAppendInstNode(vaChildNodes [i], poForm, poPageDocument);
          }
        }
      }
    } else {
      this.appendHiddenParams(poPageDocument, poForm, poNode.nodeName, "");
    }
  };
  //인스턴스 추가
  this.appendInstanceData = function(poPageDocument, poInstance, psXPath, poForm) {
    var voNode = poInstance.selectSingleNode(psXPath);
    this.searchAndAppendInstNode(voNode, poForm, poPageDocument);
  };
  //디폴트로 올려야 하는 데이터
  this.appendDefaultItem = function(poUploadForm) {
    if (poUploadForm == null) return null;
    var voPage = this.submission.model.page;
    var voPageDocument = voPage.window.document;
    
    this.appendHiddenParams(voPageDocument, poUploadForm, "eXria-Version", voPage.metadata.version);
    this.appendHiddenParams(voPageDocument, poUploadForm, "req-protocol", this.submission.reqProtocol);
    this.appendHiddenParams(voPageDocument, poUploadForm, "res-protocol", this.submission.resProtocol);
    this.appendHiddenParams(voPageDocument, poUploadForm, "req-charset", this.submission.reqCharset);
    this.appendHiddenParams(voPageDocument, poUploadForm, "res-charset", this.submission.resCharset);
  };
  //hiddenframe 생성
  this.createHiddenFrame = function(poPage, poPageDocument, psFrameName) {
    //page에 hidden frame 생성
    var vnBrowserVer = poPage.metadata.browser.ie;
    
    if (vnBrowserVer > 0) {
      //ie일 경우 div 생성 후 내부에 iframe 생성
      var voDiv = poPageDocument.getElementById("hiddenFormDiv");
      
      //div가 없을 경우 생성 div생성 후 iframe을 innerHTML 한다.
      if (voDiv == null || voDiv == undefined) {
        var voFrameDiv = poPageDocument.createElement("DIV");
        voFrameDiv.setAttribute("id", "hiddenFormDiv");
        voFrameDiv.setAttribute("name", "hiddenFormDiv");
        voFrameDiv.innerHTML = "<iframe id='" + psFrameName + "' name='" + psFrameName + "' style='display:none'></iframe>";
        
        if (vnBrowserVer >= 9) {
          poPageDocument.body.appendChild(voFrameDiv);
        } else {
          poPageDocument.appendChild(voFrameDiv);
        }
      }
    } else {
      //ie이외의 브라우저일 경우 hidden frame 생성후 page에 append
      var voHiddenFrm = poPageDocument.getElementById(psFrameName);
      
      if (voHiddenFrm == null || voHiddenFrm == undefined) {
        var voHiddenFrame = poPageDocument.createElement("iframe");
        voHiddenFrame.setAttribute("name", psFrameName);
        voHiddenFrame.setAttribute("id", psFrameName);
        voHiddenFrame.style.display = "none";
        
        poPageDocument.body.appendChild(voHiddenFrame);
      }
    }
  };
  //form 생성
  this.createForm = function(poPage, poPageDocument, psTargetFrame) {
    //폼 생성
    var voUploadForm = poPageDocument.createElement("form");
    //폼 속성
    voUploadForm.setAttribute("name", this.submission.id + "_frm");
    voUploadForm.setAttribute("id", this.submission.id + "_frm");
    
    var vnIeVersion = poPage.metadata.browser.ie;
    if (vnIeVersion > 0 && vnIeVersion <= 7) {
      voUploadForm.setAttribute("encoding", "multipart/form-data");
    } else {
      voUploadForm.setAttribute("enctype", "multipart/form-data");
    }
    voUploadForm.setAttribute("method", this.submission.method);
    voUploadForm.setAttribute("action", this.submission.action);
    voUploadForm.setAttribute("target", psTargetFrame);
    
    return voUploadForm;
  };
  /**
   * build
   * 파일업로드 폼을 생성하기 위한 메소드
   * 현재 canvas에 있는 FileSelector들을 가져와 form을 생성하고 서버로 파일을 올린다.
   */  
  this.build = function() {
    var vsFrameName = "fileUpHiddenFrm";
    var voPage = this.submission.model.page;
    var voPageDocument = voPage.window.document;

    //Hidden Frame 생성
    this.createHiddenFrame(voPage, voPageDocument, vsFrameName);
    //form 생성
    var voUploadForm = this.createForm(voPage, voPageDocument, vsFrameName);
    //form에 default item 셋팅
    this.appendDefaultItem(voUploadForm);

    //submission의 parameter들을 form에 append
    var voSubmitParams = this.submission.parameters;
    var voSubmitParamIter = voSubmitParams.getKeyCollection().iterator();
    while (voSubmitParamIter.hasNext()) {
      //key와 value를 가져와 input element의 속성 셋팅
      vsParamKey = voSubmitParamIter.next();
      vsParamValue = voSubmitParams.get(vsParamKey)[0];
      this.appendHiddenParams(voPageDocument, voUploadForm, vsParamKey, vsParamValue);
    }
    //submission의 req-ref 파라미터들을 form에 append
    var voReqRefParams = this.submission.getRefs();
    var vnReqRefParamLength = voReqRefParams.length;
    var i = 0;
    for (i = 0; i < vnReqRefParamLength; i++) {
      this.appendInstanceData(voPageDocument, voPage.getInstance(voReqRefParams [i].getId()), voReqRefParams [i].getPath(), voUploadForm);
    }

    //input type file인 객체를 찾아 form에 append
    var voElement;
    var vaFileCtrlNames = this.submission.getUpLoadCtrlsMap();
    if(vaFileCtrlNames != null) vaFileCtrlNames = vaFileCtrlNames.entries;

    var voParentNodesMap = new eXria.data.Map();
    for(var i in vaFileCtrlNames){
      if(vaFileCtrlNames[i] == "") return;
      voElement = voPage.window.document.getElementById(vaFileCtrlNames[i]+"_file");
      if(voElement.value){
        voParentNodesMap.put(voElement.id, voElement.parentNode);
        voUploadForm.appendChild(voElement);      
      }
    }

    //page의 body에 생성된 form을 append        
    voPageDocument.body.appendChild(voUploadForm);
    
    var voMultipartParser = new eXria.protocols.MultipartParser(this.submission);
    var voHideFrame = voPageDocument.getElementById(vsFrameName);
    
    var fileUploadComplete = function() {
      voMultipartParser.parse(voHideFrame);
    };
    
    if (voPage.metadata.browser.ie > 0) {
      voPageDocument.getElementById(vsFrameName).onreadystatechange = function() {
        fileUploadComplete();
      };
    } else {
      voPageDocument.getElementById(vsFrameName).onload = function() {
        fileUploadComplete();
      };
    }
    //form Submit 후 reset 한다.
    voUploadForm.submit();
    voUploadForm.reset();
    //submit 된 input 노드를 복사해서 다시 붙여넣는다.
    var voParentNodesItor = new eXria.data.ArrayMap(voParentNodesMap).getKeyCollection().iterator();
    var vsKey = null;
    var voParent = null;
    var voElement = null;
    var voFile = null;
    var voFileSelector = null;
    while (voParentNodesItor.hasNext()) {
      vsKey = voParentNodesItor.next();
      voParent = voParentNodesMap.get(vsKey);
      voElement = voPageDocument.getElementById(vsKey);
      voFile = voElement.cloneNode(true);
      
      voFile.control = voElement.control;
      voFileSelector = voElement.control;
      
      voParent.parentNode.childNodes [0].childNodes [0].childNodes [0].childNodes [0].childNodes [0].value = "";
      voFileSelector.eventManager.removeListener(voFile, "onchange", voFileSelector.mediateEvent);
      voFileSelector.eventManager.addListener(voFile, "onchange", voFileSelector.mediateEvent);
      voElement.parentNode.removeChild(voElement);
      voParent.appendChild(voFile);
    }
    //생성 되었던 form을 삭제한다.
    var voRmForm = voPageDocument.getElementById(this.submission.id + "_frm");
    voRmForm.parentNode.removeChild(voRmForm);
  };
};