﻿/**
 * @fileoverview
 * Abstract ResponseParser
 */
 
/**
 * Abstract ResponseParser
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @constructor
 * @private
 */
eXria.protocols.ResponseParser = function(poSubmission) {
  this.submission = poSubmission;
  /**
   * 서버로 부터 받은 결과 데이터를 파싱하고
   * Response Ref에 처리하기 위한 DOMDocument로 변환하여 리턴한다.
   */
  this.parse = null;
  this.bind = true;
  /**
   * Text를 DOM Element로 Parsing한다.
   * @param psXml xml String
   * @return DOM Element
   */
  this.text2Dom = function(psXml) {
    var voDomParser = eXria.data.DOMParserFactory.getParser(poSubmission.model.page); //create parser
    var voResponseXML = voDomParser.parse(psXml); //parsing
    voDomParser.clear();
    return voResponseXML;
  };
};