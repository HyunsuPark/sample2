/**
 * @fileoverview
 * eXria.protocols.plugin package
 */
/**
 * eXria.protocols.plugin package
 * @author Choe, hyeon jong.
 * @version 1.0
 */

/**
 * eXria.protocols
 */
eXria.protocols.plugin = {};
