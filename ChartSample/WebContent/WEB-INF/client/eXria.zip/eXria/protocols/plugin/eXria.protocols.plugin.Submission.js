/**
 * @fileoverview
 * Plugin Mode 사용시 서버와의 data통신 프로세스를 담당.
 */
 
/**
 * Plugin Mode 사용시 서버와의 data통신 프로세스를 담당.
 * @version 1.0
 * @param {String} psId Submission Id
 * @param {eXria.form.Model} poModel eXria.form.Model
 * @param {eXria.form.Submission} poSubmission Submission Object
 * @constructor
 * @base eXria.protocols.Submission
 */
eXria.protocols.plugin.Submission = function(psId, poModel, poSubmission) {
  eXria.protocols.Submission.call(this, psId, poModel);
  /**
   * id
   * @type String
   */
  this.id = psId;
  /**
   * Submission Object
   * @private
   */
  this.submission = poSubmission;
  /**
   * use decode
   * @return void
   * @type Number
   * @private
   */
  this.isEncodeData = false;
  try {
    this.isEncodeData = (this.model.plugin.getJREVersionNumber() >= 1.7 && this.model.page.metadata.browser.ie == 0);
  } catch(e) {
    this.isEncodeData = false;
  }
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다.<br/>
   * 이때 POST데이터는 Request Reference를 통해 생성되거나 Submission Tag의 Parameter를 통해 생성된다.
   * 이때 사용되는 HTTP request Parameter값을 추가적으로 입력하는 기능으로 <br/>
   * Key와 Value로 분리하여 입력한다. 복수개가 설정 가능하다.
   * @param {String} psName 추가할 Parameter 이름
   * @param {String} psValue 추가할 Parameter 값
   * @return void
   * @type void
   */
  this.addParameter = function(psName, psValue){
	  this.submission.addParameter(psName, psValue);
  };
  /**
   * HttpRequest에 DataSet을 추가한다.(Plugin Mode에서만 사용 가능)
   * @param {String} psId DataSet Id
   * @return void
   * @type void
   */
  this.addDataSetId = function(psId){
	  if(!psId) return;
	  this.submission.addDataSetId(psId);
  };
  /**
   * HttpRequest에 설정된 DataSet을 삭제한다.(Plugin Mode에서만 사용 가능)
   * @param {String} psId DataSet Id
   * @return void
   * @type void
   */
  this.removeDataSetId = function(psId){
	  if(!psId) return;
	  this.submission.removeDataSetId(psId);
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다.<br/>
   * 이때 POST데이터는 Request Reference를 통해 생성되거나 Submission Tag의 Parameter를 통해 생성된다.<br/>
   * 이 Request Reference를 추가하는 기능으로 Instance ID 와 Reference할 Node의 path 정보를<br/>
   * 추가적으로 입력한다. 복수개가 설정 가능하다.
   * @param {String} psId 값을 설정하기 위한 Instance Id
   * @param {String} psPath Node Path 정보
   * @return void
   * @type void
   */
  this.addRef = function(psId, psPath) {
	  this.submission.appendRef(psId, psPath);
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다. 이때 POST데이터는 Request Reference를 통해<br/>
   * 생성되거나 Submission Tag의 Parameter를 통해 생성된다. 이 HTTP request Parameter값을 모두 지워주는 기능을 한다.
   * @return void
   * @type void 
   */
  this.clearParameter = function() {
	  this.submission.clearParameter();
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다. 이때 POST데이터는 Request Reference를 통해<br/>
   * 생성되거나 Submission Tag의 Parameter를 통해 생성된다.<br/>
   * 이 Request Reference을 모두 지워주는 기능을 한다. 
   * @return void
   * @type void
   */
  this.clearRef = function() {
	  this.submission.clearRef();
  };
  /**
   * PlugIn과 Server가 ASync통신할 때 송수신된 정보의 진행율을 표시할 수 있는 기능에 사용되어 지며<br/>
   * currentPos는 진행된 사이즈이며 LONG형의 수치값이 반환된다.
   * @return 현재 진행 값
   * @type void 
   */
  this.getCurrentPos = function() {
	  return this.submission.currentPos();
  };
  /**
   * HTTP통신시 Request Header에 전송될 정보를 반환 받는다.<br/>
   * Parameter로 입력한 Key값에 따른 값을 반환한다.
   * @param {String} psName 조회대상의 Header Name
   * @return 조회된 Header 문자열 값
   * @type String
   */
  this.getHeader = function(psName) {
	  var vsHeader = this.submission.getHeader(psName);

	  vsHeader = decodeURIComponent(vsHeader);
	  if(vsHeader == "null") return null;

	  return vsHeader;
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다.<br/>
   * 이때 POST데이터는 Request Reference를 통해 생성되거나 Submission Tag의 Parameter를 통해 생성된다.<br/>
   * 이때 사용되는 HTTP request Parameter값을 입력한 Key값에 해당되는 Value를 반환한다.
   * @param {String} psName 조회 대상의 Parameter name
   * @return 조회된 Parameter 문자열 값
   * @type String 
   */
  this.getParameter = function(psName) {
	  var vsParam = this.submission.getParameter(psName);

	  if(this.isEncodeData) {
	    vsParam = decodeURIComponent(vsParam);
	    if(vsParam == "null") return null;
	  }
	  
	  return vsParam;
  };
  /**
   * Server와 통신후 반환된 HTTP Error Code를 반환
   * @return Number Type의 오류코드 숫자값
   * @type Number
   */
  this.getResultCode = function() {
	  return this.submission.getResultCode();
  };
  /**
   * PlugIn과 Server가 HTTP ASync통신할 때 송수신된 정보의 진행율을 표시할 수 있는 기능에<br/> 
   * 사용되어 지며 currentPos는 진행된 사이즈이며 maxPos는 수신될 데이터의 전체 크기이며 수치값이 반환된다.
   * @return 수신될 데이터의 전체 크기
   * @type Number
   */
  this.getMaxPos = function() {
	  return this.submission.maxPos();
  };
  /**
   * PlugIn과 Server가 HTTP ASync통신할 때 현재 송수신된 데이터 크기의 수치값이 반환된다. 
   * @return 현재 진행된 데이터의 크기
   * @type Number
   */
  this.currentPos = function() {
	return this.submission.currentPos();
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다.<br/>
   * 이때 POST데이터는 Request Reference를 통해 생성되거나 Submission Tag의 Parameter를 통해 생성된다.<br/>
   * 이 HTTP request Parameter값을 입력된 Key값에 해당되는 Parameter를 제거한다.
   * @param {String} psName 삭제대상의 Parameter Name
   * @return void
   * @type void
   */
  this.removeParameter = function(psName) {
	  this.submission.removeParameter(psName);
  };
  /**
   * Submission Tag에 설정되어 있는 정보에 의해 송신 데이터를 서버로 송신하고 서버의 처리 결과를<br/>
   * 받아 Instance에 저장하는 기능을 담당하며 반환값은 성공과 실패인 Boolean값이 반환된다.
   * @return void
   * @type void
   */
  this.send = function() {
    if(this.isWaitCursor()) this.model.page.waitingSend = true;
    var vbSuccess = this.submission.send();
    this.model.page.waitingSend = false;
    if(vbSuccess == 0) {
      vbSuccess = false;
    } else {
      vbSuccess = true;
    }
    var voDefInstance = this.model.getInstance(this.model.plugin.getDefInstanceID());
    var voRedirectNode = voDefInstance.selectSingleNode("/root/EXRIAREDIRECT");
//    voDefInstance.print("/");
    if(voRedirectNode) {
      var vsPath = String(voRedirectNode.getNodeValue());
      if(vsPath != "") {
        vsPath = eXria.util.UrlUtil.getAbsoluteUrl(vsPath);
        this.model.page.open(vsPath);
      } else {
        return vbSuccess;
      }
    } else {
      return vbSuccess;
    }
  };
  /**
   * HTTP통신시 Request Header에 전송될 정보를 설정 한다.<br/>
   * Parameter는 Key와 Value의 쌍으로 입력한다. 복수개가 설정 가능하다.
   * @param {String} psName 설정 대상의 Header Name
   * @param {String} psValue 설정 할 Header Value
   * @return void
   * @type void
   */
  this.setHeader = function(psName, psValue) {
	  this.submission.setHeader(psName, psValue);
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 POST데이터를 송신한다. <br/>
   * 이때 전송될 POST Data의 문자셑(Character Set)을 설정한다.
   * @param {String} psCharset 설정할 Character Set
   * @return void
   * @type void 
   */
  this.setReqCharset = function(psCharset) {
	  this.submission.setReqCharset(psCharset);
  };
  /**
   * PlugIn과 Server가 HTTP통신할 때 서버로부터 수신된 데이터의 문자셑(Character Set)을 설정한다.
   * @param {String} psCharset 설정할 Character Set
   * @return void
   * @type void
   */
  this.setResCharset = function(psCharset) {
	  this.submission.setResCharset(psCharset);
  };
  /**
   * Submission 완료 후 서버로 부터 받은 결과를 붙일 Instance를 추가한다.
   * </br>plugin 사용시 Arguement와 상관 없이 Replace : True로 동작.<br/>
   * @param {String} psId instance id
   * @param {String} psPath instance path
   * @param {Boolean} pbReplace instance replace 여부 (Plugin 모드 사용시 생략 가능)
   * @return void
   * @type void
   */
  this.addResRef = function(psId, psPath, pbReplace) {
    if(!(pbReplace === true)) {
      pbReplace = false;
    } 
	  this.submission.setResponseRef(psId, psPath, pbReplace);
  };
  /**
   * Server로 MultiPart 데이터를 전송할 때 파일을 설정 하는 함수로 클라이언트(Client) 파일의 절대경로를 설정한다.
   * @param {String} psFilePath Upload 대상 File Path
   * @return void
   * @type void
   */
  this.setUpLoadFileNames = function(psFilePath) {
	  this.submission.setUpLoadFileNames(psFilePath);
  };
  /**
   * 현재 Submission에 설정 되어진 action URL을 동적으로 변경 하고자 할 때 사용하는 메소드.
   * @param {String} psActionTarget 변경하고자 하는 URL
   * @return void
   * @type void
   */
  this.changeAction = function(psActionTarget) {
    this.submission.changeAction(psActionTarget);
  };
  /**
   * submission에 데이타셋 CRUD 문자열 정보를 추가시켜 주는 메소드
   * @param {String} psString 서브미션 전송 시 추가로 보내고자 하는 CRUD 데이터
   * @return void
   * @type void
   */
  this.addCRUDString = function(psString) {
    this.submission.addCRUDString(psString);
  };
  /**
   * 현재 Submission에 addCRUDString으로 설정 되어진 추가 정보를 초기화 하는 메소드.<br/> 
   * add CRUDString만 하고 resetCRUDString을 사용하지 않으면 초기화 되지 않고 계속 서브미션을 수행 할 때 마다. 설정한 값이 전송 되어 진다.
   * @return void
   * @type void
   */
  this.resetCRUDString = function() {
    this.submission.resetCRUDString();
  };
  /**
   * 초기에 만들어진 해당 서브미션에 request-ref에 정보를 동적으로 삭제 할 때 사용한다.<br/>
   * 두번째 인자는 XPath를 넣으면 첫째 인자의 ID를 인스턴스의 아이디로 정하고 공문자열일 경우 DataSetID로 처리한다.
   * @param {String} psId 삭제할 request-ref에 등록한 InstanceID 또는 DataSetID
   * @param {String} psXPath 삭제할 reqeust-ref에 등록한 InstanceID에 XPath
   * @type void
   * @return void
   */
  this.removeRef = function(psId, psXPath) {
    if(psXPath == null) psXPath = "";
    this.submission.removeRef(psId, psXPath);
  };
  /**
   * 서브미션의 action Url 지정
   * @param {String} psUrl action target으로 지정될 url
   * @return void
   * @type void
   */
  this.setAction = function(psUrl) {
    this.submission.setAction(psUrl);
  };
  /**
   * 서브미션의 action target 반환
   * @return 서브미션의 action target
   * @type String
   */
  this.getAction = function() {
    return this.submission.getAction();
  };
  /**
   * Header Attribute 값을 리턴한다.
   * @param {String} psAttrName 리턴 받을 Attribute Name
   * @return Attribute Value
   * @type String
   * @return Attribute Value
   */
  this.getAttrStr = function(psAttrName) {
	return this.submission.getAttrStr(psAttrName);
  };
  /**
   * Header Attribute 값을 설정한다. 만약 해당 Attribute가 있다면 해당 값으로 덮어씌운다.
   * @param {String} psAttrName 설정 Attribute Name
   * @param {String} psValue 설정할 Attribute 값
   * @type void
   * @return void
   */
  this.setAttrStr = function(psAttrName, psValue) {
	this.submission.setAttrStr(psAttrName, psValue);
  };
  /**
   * Header의 Content-type을 재설정한다.
   * @type void
   * @return void
   */
  this.initReqType = function() {
	this.submission.initReqType();
  };
  /**
   * Submission에서 서버로 보낼 데이터를 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return Submission Send 시 서버로 보낼 데이터 문자열
   * @type String
   */
  this.getSubmitData = function() {
	  return this.submission.getSubmitData();
  };
  /**
   * 파라미터로 넘어온 문자열을 Submission의 Response Ref에 지정한 Node에 바인딩 한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psData 바인딩하고자 하는 데이터 문자열
   * @type void
   * @return void
   */
  this.bindUserData = function(psData) {
	  if(!psData || psData == "") return;
	  this.submission.bindUserData(psData);
  };
  /**
   * 파라미터로 넘어온 데이터를 서버로 보낸다.<br/>
   * 해당 메소드를 사용할 경우 Submission에 바인딩 된 Request 데이터는 모두 무시 되며<br/>
   * 오로지 파라미터로 넘긴 문자열에 대해서만 처리한다.<br/>
   * 또한 서버로부터 내려온 데이터는 인스턴스에 바인딩 되지 않으며 문자열로 리턴 된다.<br/>
   * (Plugin Mode 에서만 사용 가능)
   * @param psData 서버로 보낼 데이터 문자열
   * @type String
   * @return 서버로부터 내려온 데이터 문자열
   */
  this.sendUserData = function(psData) {
	  return this.submission.sendUserData(psData);
  };
  /**
   * Response Reference를 String 형태로 리턴한다.<br/>
   * (ex. instaceId:XPath;instanceId2:XPath;)
   * @type String
   * @return Response Reference 문자열
   */
  this.getResponseRefString = function() {
    return this.submission.getResponseRefString();
  };
  /**
   * Request Reference를 String 형태로 리턴한다.<br/>
   * (ex. instaceId:XPath;instanceId2:XPath;)
   * @type String
   * @return Request Reference 문자열
   */
  this.getRequestRefString = function() {
    return this.submission.getRequestRefString();
  };
  /**
   * Request Parameter의 Key를 String 형태로 리턴한다.<br/>
   * (ex. ParamKey1,ParamKey2,ParamKey3)
   * @type String
   * @return Request Parameter Key 문자열
   */
  this.getParameterKeyString = function() {
    return this.submission.getParameterKeyString();
  };
  /**
   * Request CharSet을 리턴한다.<br/>
   * @type String
   * @return Request CharSet
   */
  this.getReqCharSet = function() {
    return this.submission.getReqCharSet();
  };
  /**
   * Response CharSet을 리턴한다.<br/>
   * @type String
   * @return Request CharSet
   */
  this.getResCharSet = function() {
    return this.submission.getResCharSet();
  };
  /**
   * Request DataSet의 ID를 String 형태로 리턴한다.<br/>
   * (ex. dst1,dst2,dst3)
   * @type String
   * @return Request DataSet의 ID 문자열
   */
  this.getDataSetIdString = function() {
    return this.submission.getDataSetIdString();
  };
  /**
   * Request Protocol Type을 String 형태로 리턴한다.<br/>
   * (ex. zip;base64)
   * @type String
   * @return  Request Protocol Type에 해당하는 문자열
   */
  this.getReqType = function() {
    return this.submission.getReqType();
  };
  /**
   * Response Protocol Type을 String 형태로 리턴한다.<br/>
   * (ex. zip;base64)
   * @type String
   * @return  Response Protocol Type에 해당하는 문자열
   */
  this.getResType = function() {
    return this.submission.getResType();
  };
  /**
   * Request Protocol Type을 지정한다.<br/>
   * (ex. zip;base64)
   * @param {String} psResType Request Protocol Type
   * @type void
   * @return void
   */
  this.setReqType = function(psResType) {
    this.submission.setReqType(psResType);
  };
  /**
   * Response Protocol Type을 지정한다.<br/>
   * (ex. zip;base64)
   * @param {String} psResType Response Protocol Type
   * @type void
   * @return void
   */
  this.setResType = function(psResType) {
    this.submission.setResType(psResType);
  };
  
  /**
   * request protocol을 셋팅한다.<br/>
   * @param {String} psReqProtocol request protocol
   * @return void
   * @type void
   */
  this.setReqProtocol = function(psReqProtocol) {
    this.submission.setReqProtocol(psReqProtocol);
  };
  /**
   * request protocol을 리턴한다.
   * @type {String}
   * @return request protocol
   */
  this.getReqProtocol = function() {
    return this.submission.getReqProtocol();
  };
  /**
   * response protocol을 셋팅한다.<br/>
   * @param {String} psResProtocol response protocol
   * @return void
   * @type void
   */
  this.setResProtocol = function(psResProtocol) {
    this.submission.setResProtocol(psResProtocol);
  };
  /**
   * response protocol을 리턴한다.
   * @type {String}
   * @return request protocol
   */
  this.getResProtocol = function() {
    return this.submission.getResProtocol();
  };
  /**
   * wait cursor 사용 유무를 리턴한다.
   * @return wait cusor 사용 유무
   * @type Boolean
   */
  this.isWaitCursor = function() {
    return this.submission.isWaitCursor();
  }
};
