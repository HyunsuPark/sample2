﻿/**
 * @fileoverview
 * JSONBuilder
 */
 
/**
 * JSONBuilder
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.RequestBuilder
 * @constructor
 * @private
 */
eXria.protocols.JSONBuilder = function(poSubmission) {
  //inheritance
  eXria.protocols.RequestBuilder.call(this, poSubmission);

  /* JSONRPC에서 사용함 */
  //escape a character
  this.escapeJSONChar = function(pcChar) {
    if(pcChar == "\"" || pcChar == "\\") return "\\" + pcChar;
    else if(pcChar == "\b") return "\\b";
    else if(pcChar == "\f") return "\\f";
    else if(pcChar == "\n") return "\\n";
    else if(pcChar == "\r") return "\\r";
    else if(pcChar == "\t") return "\\t";
    var hex = pcChar.charCodeAt(0).toString(16);
    if(hex.length == 1) return "\\u000" + hex;
    else if(hex.length == 2) return "\\u00" + hex;
    else if(hex.length == 3) return "\\u0" + hex;
    else return "\\u" + hex;
  };

  //encode a string into JSON format
  this.escapeJSONString = function(psString) {
    //Rather inefficient way to do it
    var parts = psString.split("");
    for(var i = 0; i < parts.length; i++) {
      var c =parts[i];
      if(c == '"' || c == '\\' || c.charCodeAt(0) < 32 || c.charCodeAt(0) >= 128) {
        parts[i] = this.escapeJSONChar(parts[i]);
      }
    }
    return "\"" + parts.join("") + "\"";
  };

  // Marshall objects to JSON format
  this.toJSONString = function(poObject) {
    if(poObject == null) {
      return "null";
    } else if(poObject.constructor == String) {
      return this.escapeJSONString(poObject);
    } else if(poObject.constructor == Number) {
      return poObject.toString();
    } else if(poObject.constructor == Boolean) {
      return poObject.toString();
    } else if(poObject.constructor == Date) {
      return '{javaClass: "java.util.Date", time: ' + poObject.valueOf() +'}';
    } else if(poObject.constructor == Array) {
      var v = [];
      for(var i = 0; i < poObject.length; i++) {
        v.push(this.toJSONString(poObject[i]));
      }
      return "[" + v.join(", ") + "]";
    } else {
      var v = [];
      for(attr in poObject) {
        if(poObject[attr] == null) {
          v.push("\"" + attr + "\": null");
        } else if(typeof poObject[attr] == "function") {
          // TODO function일 경우도 파싱
          // skip
        } else {
          v.push(this.escapeJSONString(attr) + ": " + this.toJSONString(poObject[attr]));
        }
      }
      return "{" + v.join(", ") + "}";
    }
  };

  this.xml2json = function(xml) {
	var X = {
	  toObj: function(xml) {
		var o = {};
		if (xml.nodeType==1) {   // element node ..
		  if (xml.attributes.length)   // element with attributes  ..
			for (var i=0; i<xml.attributes.length; i++)
			  o["@"+xml.attributes[i].nodeName] = (xml.attributes[i].nodeValue||"").toString();
		  if (xml.firstChild) { // element has child nodes ..
			var textChild=0, cdataChild=0, hasElementChild=false;
			for (var n=xml.firstChild; n; n=n.nextSibling) {
			  if (n.nodeType==1) hasElementChild = true;
			  else if (n.nodeType==3 && n.nodeValue.match(/[^ \f\n\r\t\v]/)) textChild++; // non-whitespace text
			  else if (n.nodeType==4) cdataChild++; // cdata section node
			}
			if (hasElementChild) {
			  if (textChild < 2 && cdataChild < 2) { // structured element with evtl. a single text or/and cdata node ..
				X.removeWhite(xml);
				for (var n=xml.firstChild; n; n=n.nextSibling) {
				  if (n.nodeType == 3)  // text node
					o["#text"] = X.escape(n.nodeValue);
				  else if (n.nodeType == 4)  // cdata node
					o["#cdata"] = X.escape(n.nodeValue);
				  else if (o[n.nodeName]) {  // multiple occurence of element ..
					if (o[n.nodeName] instanceof Array)
					  o[n.nodeName][o[n.nodeName].length] = X.toObj(n);
					else
					  o[n.nodeName] = [o[n.nodeName], X.toObj(n)];
				  } else  // first occurence of element..
					  o[n.nodeName] = X.toObj(n);
				}
			  } else { // mixed content
				if (!xml.attributes.length)
				  o = X.escape(X.innerXml(xml));
				else
				  o["#text"] = X.escape(X.innerXml(xml));
			  }
			} else if (textChild) { // pure text
			  if (!xml.attributes.length)
				o = X.escape(X.innerXml(xml));
			  else
				o["#text"] = X.escape(X.innerXml(xml));
			} else if (cdataChild) { // cdata
			  if (cdataChild > 1)
				o = X.escape(X.innerXml(xml));
			  else
				for (var n=xml.firstChild; n; n=n.nextSibling)
				  o["#cdata"] = X.escape(n.nodeValue);
			}
		  }
		  if (!xml.attributes.length && !xml.firstChild) o = null;
		} else if (xml.nodeType==9) { // document.node
		  o = X.toObj(xml.documentElement);
		} else
		  alert("unhandled node type: " + xml.nodeType);
	  return o;
	},
	toJson: function(o, name, ind) {
	  var json = name ? ("\""+name+"\"") : "";
	  if (o instanceof Array) {
		for (var i=0,n=o.length; i<n; i++)
		  o[i] = X.toJson(o[i], "", ind+"\t");
		json += (name ? ":[":"[") + (o.length > 1 ? ("\n"+ind+"\t"+o.join(",\n"+ind+"\t")+"\n"+ind) : o.join("")) + "]";
	  } else if (o == null)
		json += (name&&":") + "null";
	  else if (typeof(o) == "object") {
		var arr = [];
		for (var m in o)
		  arr[arr.length] = X.toJson(o[m], m, ind+"\t");
		json += (name?":{":"{") + (arr.length > 1 ? ("\n"+ind+"\t"+arr.join(",\n"+ind+"\t")+"\n"+ind) : arr.join("")) + "}";
	  } else if (typeof(o) == "string")
		json += (name&&":") + "\"" + o.toString() + "\"";
	  else
		json += (name&&":") + o.toString();
	  return json;
	},
	innerXml: function(node) {
	  var s = ""
	  if ("innerHTML" in node)
		s = node.innerHTML;
	  else {
		var asXml = function(n) {
		  var s = "";
		  if (n.nodeType == 1) {
			s += "<" + n.nodeName;
			for (var i=0; i<n.attributes.length;i++)
			  s += " " + n.attributes[i].nodeName + "=\"" + (n.attributes[i].nodeValue||"").toString() + "\"";
			if (n.firstChild) {
			  s += ">";
			  for (var c=n.firstChild; c; c=c.nextSibling)
				s += asXml(c);
			  s += "</"+n.nodeName+">";
			} else
			  s += "/>";
			} else if (n.nodeType == 3)
			  s += n.nodeValue;
			else if (n.nodeType == 4)
			  s += "<![CDATA[" + n.nodeValue + "]]>";
		  return s;
		};
		for (var c=node.firstChild; c; c=c.nextSibling)
		  s += asXml(c);
	  }
	  return s;
	},
	escape: function(txt) {
	  return txt.replace(/[\\]/g, "\\\\")
			 .replace(/[\"]/g, '\\"')
			 .replace(/[\n]/g, '\\n')
			 .replace(/[\r]/g, '\\r');
      },
      removeWhite: function(e) {
		e.normalize();
		for(var n = e.firstChild; n; ) {
		  if(n.nodeType == 3) {  // text node
			if(!n.nodeValue.match(/[^ \f\n\r\t\v]/)) { // pure whitespace text node
			  var nxt = n.nextSibling;
			  e.removeChild(n);
			  n = nxt;
			} else
			  n = n.nextSibling;
		  } else if(n.nodeType == 1) {  // element node
			X.removeWhite(n);
			n = n.nextSibling;
		  } else                      // any other node
			n = n.nextSibling;
		}
		return e;
	  }
	};
	if(xml.nodeType == 9) { // document node
	  xml = xml.documentElement;
	}
    
	return X.toJson(X.toObj(X.removeWhite(xml)), null, "");
  };
  /*
   * create json request data and
   * sendAction method call from Submission
   */
  this.build = function() {
    var viDocument = eXria.data.xhtml.DocumentFactory.createDocument(this.submission.model.page);
    var viRootNode = viDocument.dom.createElement("root");

    //request ref build
    var vaRefs = this.submission.getRefs();
    var voXPath;
    var viInstance;
    var viRefInstance;
    for(var i = 0; i < vaRefs.length; i++) {
      voXPath = vaRefs[i]; //eXria.protocols.Ref
      //Instance의 Id와 xpath는 eXria.protocols.Ref를 이용하여 가져온다. Submission의 Refs는 eXria.protocols.Ref를 배열로 관리한다.
      viInstance = this.submission.model.getInstance(voXPath.getId());
      viRefInstance = viInstance.document.selectSingleNode(voXPath.getPath()); //DOM Instance
      if(viRefInstance) {
        viRootNode.appendChild(viRefInstance.cloneNode(true));
      }
    }
    //parameter set
    var vaParamValue; //Array
    var viParamNode, viParamValueNode;
    for(var vsParamName in this.submission.parameters.entries) { //parameter search loop
      vaParamValue = this.submission.getParameter(vsParamName);
      for(var i = 0; i < vaParamValue.length; i++) { //parameter value loop
        viParamValueNode = viDocument.dom.createTextNode(vaParamValue[i]); //text node
        viParamNode = viDocument.dom.createElement(vsParamName); //element
        viParamNode.appendChild(viParamValueNode);

        //Root Node의 마지막에 Append
        viRootNode.appendChild(viParamNode);
      }
    }
    this.submission.sendAction(this.xml2json(viRootNode));
  };
};