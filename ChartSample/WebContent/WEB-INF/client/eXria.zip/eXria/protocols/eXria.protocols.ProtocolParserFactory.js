﻿/**
 * @fileoverview
 * ProtocolParserFactory
 */
/**
 * ProtocolParserFactory
 * @version 1.0
 * @constructor
 * @constructor
 * @private
 */
eXria.protocols.ProtocolParserFactory = {
  //create RequestBuilder and return
  getRequestBuilder : function(poSubmission) {
    var voBuilder;
    switch(poSubmission.reqProtocol) {
      case eXria.protocols.SubmissionType.URL_ENCODED :
        voBuilder = new eXria.protocols.URLEncodingBuilder(poSubmission);
        break;
      case eXria.protocols.SubmissionType.JSON :
        voBuilder = new eXria.protocols.JSONBuilder(poSubmission);
        break;
      case eXria.protocols.SubmissionType.JSON_RPC :
        voBuilder = new eXria.protocols.JSONRPCBuilder(poSubmission);
        break;
      case eXria.protocols.SubmissionType.XML :
        voBuilder = new eXria.protocols.XMLBuilder(poSubmission);
        break;
      case eXria.protocols.SubmissionType.SOAP_RPC :
        voBuilder = new eXria.protocols.SOAPRPCBuilder(poSubmission);
        break;
      case eXria.protocols.SubmissionType.MULTIPART :
        voBuilder = new eXria.protocols.MultipartBuilder(poSubmission);
        break;
      case eXria.protocols.SubmissionType.UNENCODED :
      	voBuilder = new eXria.protocols.UnEncodingBuilder(poSubmission);
      	break;
      default :
        throw new Exception("Unsupported Submission Type.");
    }
    return voBuilder;
  },
  //create ResponseParser and return
  getResponseParser : function(poSubmission, psResponseType) {
    var voParser;
    if(psResponseType == null) {
      voParser = new eXria.protocols.XMLParser(poSubmission);
    } else if(psResponseType.indexOf("urlencoded") > -1) {
      voParser = new eXria.protocols.URLEncodingParser(poSubmission);
    } else if(psResponseType.indexOf("json/rpc") > -1) {
      voParser = new eXria.protocols.JSONRPCParser(poSubmission);
    } else if(psResponseType.indexOf("json") > -1) {
      voParser = new eXria.protocols.JSONParser(poSubmission);
    } else if(psResponseType.indexOf("xml") > -1) {
      voParser = new eXria.protocols.XMLParser(poSubmission);
    } else if(psResponseType.indexOf("webservice") > -1) {
      voParser = new eXria.protocols.SOAPRPCParser(poSubmission);
    } else {
      voParser = new eXria.protocols.XMLParser(poSubmission);
    }
    return voParser; 
  },
  //select Request ContentType by type of submission
  getContentType : function(poSubmission) {
    var vsContentType = "";
    switch(poSubmission.reqProtocol) {
      case eXria.protocols.SubmissionType.URL_ENCODED :
        vsContentType = "application/x-www-form-urlencoded";
        break;
      case eXria.protocols.SubmissionType.JSON :
        vsContentType = "text/plain";
        break;
      case eXria.protocols.SubmissionType.JSON_RPC :
        vsContentType = "text/plain";
        break;
      case eXria.protocols.SubmissionType.XML :
        vsContentType = "application/xml";
        break;
      case eXria.protocols.SubmissionType.SOAP_RPC :
        vsContentType = "application/xml";
        break;
      case eXria.protocols.SubmissionType.UNENCODED :
      	vsContentType = "application/x-www-form-urlencoded";
      	break;
      default :
        throw new Exception("Unsupported Submission Type.");
    }
    return vsContentType;
  }
};

