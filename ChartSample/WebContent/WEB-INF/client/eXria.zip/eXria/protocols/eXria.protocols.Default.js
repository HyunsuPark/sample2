﻿/**
 * Abstract Default
 * @작성자 : 최현종
 * @version 1.0

/**
 * Const (추상클래스)
 * Protocol에서 사용하는 기본값에 대한 정의 클래스
 */
eXria.protocols.Default = {};
eXria.protocols.Default.Submission = {};