/**
 * @fileoverview
 * 서버와의 Data 통신 프로세스를 담당하는 클래스의 Interface
 */
/**
 * eXria.protocols.Submission
 * 서버와의 data통신 프로세스를 담당하는 클래스의 Interface
 * @param {String} psId Submission Id
 * @param {eXria.form.Model} poModel eXria.form.Model Object
 * @constructor
 */
eXria.protocols.Submission = function(psId, poModel) {
  /**
   * Submission ID<br/>
   * XHTML 모드에서만 사용 가능
   * @type String
   */
  this.id = psId;
  /**
   * request Type
   * @type String
   * @private
   */
  this.reqProtocol = null;
  /**
   * response Type
   * @type String
   * @private
   */
  this.resProtocol = null;
  /**
   * HTTP ASync통신할 때 송수신된 정보의 진행율을 표시할 수 있는 기능에 사용되어 지며<br/>
   * 진행된 크기의 수치값이 반환된다.<br/>
   * 현재 Plugin Mode일때만 사용 가능하다.
   * @return 현재 진행 값
   * @type Number
   */
  this.getCurrentPos = null;
  /**
   * HTTP ASync통신할 때 송수신된 정보의 진행율을 표시할 수 있는 기능에<br/> 
   * 사용되어 지며 수신될 데이터의 전체 크기이며 수치값이 반환된다.<br/>
   * 현재 Plugin Mode일때만 사용 가능하다.
   * @return 수신될 데이터의 전체 크기
   * @type Number
   */
  this.getMaxPos = null;
  /**
   * PlugIn과 Server가 HTTP ASync통신할 때 현재 송수신된 데이터 크기의 수치값이 반환된다.<br/>
   * 현재 Plugin Mode일때만 사용 가능하다.
   * @return 현재 진행된 데이터의 크기
   * @type Number
   * @private
   */
  this.currentPos = null;
  /**
   * Model Object<br/>
   * XHTML 모드에서만 사용 가능
   * @type eXria.form.Model
   * @see eXria.form.Model
   * @private
   */
  this.model = poModel;
  /**
   * XMLHttpRequest를 synchronized 방식으로 동작시킬지</br>
   * asynchronized로 동작시킬지를 설정한다.</br>
   * true : asynchronized, false : synchronized
   * @type Boolean
   * @default true
   * @private
   */
  this.async = null;
  /**
   * synchronize 유무를 결정한다.
   * XHTML 모드에서만 사용 가능
   * @param {Boolean} pbAsync sync 유무
   * @return void
   * @type void
   */
  this.setAsync = null;
  /**
   * HTTP Method (GET/POST)
   * @type String
   * @private
   */
  this.method = null;
  /**
   * HTTP Meothod를 셋팅한다. (XHTML Mode에서만 사용 가능)
   * @param {String} psMethod method
   * @return void
   * @type void
   */
  this.setMethod = null;
  /**
   * HTTP Server URL
   * @type String
   * @private
   */
  this.action = null;
  /**
   * 서브미션의 action Url 지정
   * @param {String} psAction Action
   * @return void
   * @type void
   */
  this.setAction = null;
  /**
   * submission의 send가 호출될때 호출되는 callback function
   * @param {eXria.protocols.Submission} poSubmission 해당 Event가 발생해야 하는 Submission Object
   * @return void
   * @type void
   * @private
   */
  this.onSubmit = null;
  /**
   * submission 진행중 진행 상태를 표현하기 위한 callback function
   * @param {eXria.protocols.Submission} poSubmission 해당 Event가 발생해야 하는 Submission Object
   * @return void
   * @type void
   * @private
   */
  this.onSubmitProgress = null;
  /**
   * submission 정상처리후 호출되는 callback function
   * @param {eXria.protocols.Submission} poSubmission 해당 Event가 발생해야 하는 Submission Object
   * @return void
   * @type void
   * @private
   */
  this.onSubmitDone = null;
  /**
   * 서버와 통신중 에러가 발생하였을 때의 처리를 담당
   * Application에서 등록 한다. callback function
   * @param {eXria.protocols.Submission} poSubmission 해당 Event가 발생해야 하는 Submission Object
   * @return void
   * @type void
   * @private
   */
  this.onSubmitError = null;
  /**
   * Request Instance Reference Map(Instance id, XPATH)
   * @type Array
   * @private
   */
  this.refs = null;
  /**
   * Request Instance Reference Array(Instance id, XPATH)를 리턴 한다.<br/>
   * XHTML 모드에서만 사용 가능하다.
   * @return Request Instance Reference Array
   * @type Array
   */
  this.getRefs = null;
  /**
   * Request Instance Reference를 추가한다.
   * @param {String} psId instance id
   * @param {String} psPath instance xpath
   * @return void
   * @type void
   */
  this.addRef = null;
  /**
   * HttpRequest Header
   * (K : String, V : String)
   * @type eXria.data.ArrayMap
   * @private
   */
  this.headers = null;
  /**
   * HttpRequest Header 값을 리턴한다.
   * @param {String} psName Header Name
   * @return Header Value
   * @type String
   */
  this.getHeader = null;
  /**
   * HttpRequest Header를 추가한다.
   * @param {String} psName String Header Name
   * @param {String} psValue String Header Value
   * @return void
   * @type void
   */
  this.setHeader = null;
  /**
   * HttpRequest Header를 삭제한다.
   * XHTML 모드에서만 사용 가능
   * @param {String} psName Header Name
   * @return header Value
   * @type String
   */
  this.removeHeader = null;
  /**
   * HttpRequest Parameter
   * @type eXria.data.ArrayMap
   * @private
   */
  this.parameters = null;
  /**
   * HttpRequest에 Parameter를 추가한다.
   * @param {String} psName parameter Name
   * @param {String} psValue parameter Value
   * @return void
   * @type void
   */
  this.addParameter = null;
  /**
   * submission에 데이타셋 CRUD 문자열 정보를 추가시켜 주는 메소드
   * XHTML 사용시 Protocol은 urlencoded 일때만 사용 가능.
   * @param {String} psString 서브미션 전송 시 추가로 보내고자 하는 CRUD 데이터
   * @return void
   * @type void
   */
  this.addCRUDString = null;
  /**
   * HttpRequest에 DataSet을 추가한다.(Plugin Mode에서만 사용 가능)
   * @param {String} psId DataSet Id
   * @return void
   * @type void
   */
  this.addDataSetId = null;
  /**
   * HttpRequest에 설정된 DataSet을 삭제한다.(Plugin Mode에서만 사용 가능)
   * @param {String} psId DataSet Id
   * @return void
   * @type void
   */
  this.removeDataSetId = null;
  /**
   * HttpRequest Parameter를 조회한다.</br>
   * 값이 여럿일 경우 가장 첫번째 값을 리턴
   * @param {String} psName Parameter Name
   * @return Parameter Values
   * @type Array
   */
  this.getParameter = null;
  /**
   * HttpRequest Parameter를 삭제한다.
   * @param {String} psName Parameter Name
   * @return void
   * @type void
   */
  this.removeParameter = null;
  /**
   * HttpRequest Parameter를 모두 삭제한다.
   * @return void
   * @type void
   */
  this.clearParameter = null;
  // from document
  /**
   * Submit Request CharacterSet Encoding Type
   * @type String
   * @private
   */
  this.reqCharset = null;
  /**
   * Submit Response CharacterSet Encoding Type
   * @type String
   * @private
   */
  this.resCharset = null;
  /**
   * Submit Request CharacterSet Encoding Type을 설정한다.
   * @param {String} psCharset request charset
   * @return void
   * @type void
   */
  this.setReqCharset = null;
  /**
   * Submit Response CharacterSet Encoding Type을 설정한다.
   * @param {String} psCharset response Character Set
   * @return void
   * @type void
   */
  this.setResCharset = null;
  /**
   * Response Data Instance XPath
   * @type Array
   * @private
   */
  this.resRefs = null;
  /**
   * Submission 완료 후 서버로 부터 받은 결과를 붙일 Instance를 추가한다.
   * </br>plugin 사용시 Arguement와 상관 없이 Replace : True로 동작.<br/>
   * @param {String} psId instance id
   * @param {String} psPath instance path
   * @param {Boolean} pbReplace instance replace 여부 (Plugin 모드 사용시 생략 가능)
   * @return void
   * @type void
   */
  this.addResRef = null;
  /**
   * Response Ref의 Instance Path를 리턴한다.<br/>
   * XHTML 모드에서만 사용가능하다.
   * @return Instance Path
   * @type Array
   */
  this.getResRefs = null;
  /**
   * Submission Send
   * @return Proxy
   * @type Object
   */
  this.send = null;
  /**
   * Request Reference를 모두 삭제.
   * @return void
   * @type void
   */
  this.clearRef = null;
  /**
   * Server 통신 후 반환 된 HTTP Error Code를 반환
   * <br/>Plugin Mode에서만 동작
   * @return Number Type의 오류 코드 숫자값
   * @type Number
   */
  this.getResultCode = null;
  /**
   * Server로 MultiPart 데이터를 전송할때 파일을 설정하는 함수로 클라이언트 파일의 절대 경로를 설정
   * <br/>Plugin Mode에서만 동작
   * @param {String} psFilePath Upload 대상 FilePath
   * @return void
   * @type void
   */
  this.setUpLoadFileNames = null;
  /**
   * request protocol을 셋팅한다.<br/>
   * @param {String} psReqProtocol request protocol
   * @return void
   * @type void
   */
  this.setReqProtocol = null;
  /**
   * response protocol을 셋팅한다.<br/>
   * @param {String} psResProtocol response protocol
   * @return void
   * @type void
   */
  this.setResProtocol = null;
  /**
   * request protocol을 리턴한다.
   * @type {String}
   * @return request protocol
   */
  this.getReqProtocol = null;
  /**
   * response protocol을 리턴한다.
   * @type {String}
   * @return request protocol
   */
  this.getResProtocol = null;
  /**
   * Header Attribute 값을 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psAttrName 리턴 받을 Attribute Name
   * @return Attribute Value
   * @type String
   * @return Attribute Value
   */
  this.getAttrStr = null;
  /**
   * Header Attribute 값을 설정한다. 만약 해당 Attribute가 있다면 해당 값으로 덮어씌운다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psAttrName 설정 Attribute Name
   * @param {String} psValue 설정할 Attribute 값
   * @type void
   * @return void
   */
  this.setAttrStr = null;
  /**
   * Header의 Content-type을 재설정한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @type void
   * @return void
   */
  this.initReqType = null;
  /**
   * Submission에서 서버로 보낼 데이터를 리턴한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @return Submission Send 시 서버로 보낼 데이터 문자열
   * @type String
   */
  this.getSubmitData = null;
  /**
   * 파라미터로 넘어온 문자열을 Submission의 Response Ref에 지정한 Node에 바인딩 한다.<br/>(Plugin Mode 에서만 사용 가능)
   * @param {String} psData 바인딩하고자 하는 데이터 문자열
   * @type void
   * @return void
   */
  this.bindUserData = null;
  /**
   * 파라미터로 넘어온 데이터를 서버로 보낸다.<br/>
   * 해당 메소드를 사용할 경우 Submission에 바인딩 된 Request 데이터는 모두 무시 되며<br/>
   * 오로지 파라미터로 넘긴 문자열에 대해서만 처리한다.<br/>
   * 또한 서버로부터 내려온 데이터는 인스턴스에 바인딩 되지 않으며 문자열로 리턴 된다.<br/>
   * (Plugin Mode 에서만 사용 가능)
   * @param psData 서버로 보낼 데이터 문자열
   * @type String
   * @return 서버로부터 내려온 데이터 문자열
   */
  this.sendUserData = null;
  /**
   * Response Reference를 String 형태로 리턴한다.<br/>
   * (ex. instaceId:XPath;instanceId2:XPath;)
   * @type String
   * @return Response Reference 문자열
   */
  this.getResponseRefString = null;
  /**
   * Request Reference를 String 형태로 리턴한다.<br/>
   * (ex. instaceId:XPath;instanceId2:XPath;)
   * @type String
   * @return Request Reference 문자열
   */
  this.getRequestRefString = null;
  /**
   * Request Parameter의 Key를 String 형태로 리턴한다.<br/>
   * (ex. ParamKey1,ParamKey2,ParamKey3)
   * @type String
   * @return Request Parameter Key 문자열
   */
  this.getParameterKeyString = null;
  /**
   * Request CharSet을 리턴한다.<br/>
   * @type String
   * @return Request CharSet
   */
  this.getReqCharSet = null;
  /**
   * Response CharSet을 리턴한다.<br/>
   * @type String
   * @return Request CharSet
   */
  this.getResCharSet = null;
  /**
   * Request DataSet의 ID를 String 형태로 리턴한다.<br/>
   * (ex. dst1,dst2,dst3)
   * @type String
   * @return Request DataSet의 ID 문자열
   */
  this.getDataSetIdString = null;
  /**
   * Request Protocol Type을 String 형태로 리턴한다.<br/>
   * (ex. zip;base64)
   * @type String
   * @return  Request Protocol Type에 해당하는 문자열
   */
  this.getReqType = null;
  /**
   * Response Protocol Type을 String 형태로 리턴한다.<br/>
   * (ex. zip;base64)
   * @type String
   * @return  Response Protocol Type에 해당하는 문자열
   */
  this.getResType = null;
  /**
   * Request Protocol Type을 지정한다.<br/>
   * (ex. zip;base64)
   * @param {String} psResType Request Protocol Type
   * @type void
   * @return void
   */
  this.setReqType = null;
  /**
   * Response Protocol Type을 지정한다.<br/>
   * (ex. zip;base64)
   * @param {String} psResType Response Protocol Type
   * @type void
   * @return void
   */
  this.setResType = null;
  /**
   * wait cursor 사용 유무를 리턴한다.
   * @return wait cusor 사용 유무
   * @type Boolean
   */
  this.isWaitCursor = null;
};