﻿/**
 * @fileoverview
 * URLEncodingBuilder
 */
/**
 * URLEncodingBuilder
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.RequestBuilder
 * @constructor
 * @private
 */
eXria.protocols.URLEncodingBuilder = function(poSubmission) {
  eXria.protocols.RequestBuilder.call(this, poSubmission);

  this.build = function() {
    //request data 생성
    var voData = new eXria.lang.StringBuilder();
    var vaValue;
    for(var vsName in this.submission.parameters.entries) {
      vaValue = this.submission.getParameter(vsName);
      for(var i = 0; i < vaValue.length; i++) {
        voData.append(encodeURIComponent(vsName));     //encode
        voData.append("=");
        voData.append(encodeURIComponent(vaValue[i])); //encode
        voData.append("&");
      }
    }

    //requestRef
    var voRefs = this.submission.getRefs();
    var voRef;
    for(var i = 0; i < voRefs.length; i++) {
      voRef = voRefs[i];
      var viInstance = this.submission.model.getInstance(voRef.getId());
      if(viInstance) {
        voData.append(this.buildInstance2Param(viInstance, voRef.getPath()));
      }
    }

    //encoding setting
    //AJAX는 utf-8로 통신한다.
    this.submission.encoding = "utf-8";
    //submit
    this.submission.sendAction(voData.toString());
  };

  this.buildInstance2Param = function(poInstance, psPath) {
    var voNodeList = poInstance.selectNodes(psPath);
    var vsRootNodeName = psPath;
    if(vsRootNodeName.substring(vsRootNodeName.length - 1) == "/") {
      vsRootNodeName = vsRootNodeName.substring(0, vsRootNodeName.length - 1);
    }
    if(vsRootNodeName.indexOf("/") > -1) {
      vsRootNodeName = vsRootNodeName.substring(vsRootNodeName.lastIndexOf("/") + 1);
    }
    if(voNodeList && voNodeList.getLength() > 0) {
      var voParam = new eXria.lang.StringBuilder();
      var vnNodeSize = voNodeList.getLength();
      var voNode;
      for(var i = 0; i < vnNodeSize; i++) {
        voNode = voNodeList.item(i);
        if(voNode.getNodeType() == 1) {
          voParam.append(this.buildElement2Param(voNode)); //TODO
        } else if(voNode.getNodeType() == 3 || voNode.getNodeType() == 4) { //TEXT or CDATA Section
          voParam.append(vsRootNodeName);
          voParam.append("=");
          voParam.append(encodeURIComponent(voNode.getNodeValue())); //encode
          voParam.append("&");
        }
      }
      return voParam.toString();
    } else {
      return "";
    }
  };

  this.buildElement2Param = function(poNode) {
    var voParam = new eXria.lang.StringBuilder();
    var voNode = poNode;
    var voWhiteSpace = /\S/;

    var voNodeList = poNode.getChildNodes();
    if(voNodeList && voNodeList.getLength() > 0) {
      for(var i = 0; i < voNodeList.getLength(); i++) {
        voNode = voNodeList.item(i);
        if(voNode.getNodeType() == 1) {
          voParam.append(this.buildElement2Param(voNode)); //TODO
        } else if((voNode.getNodeType() == 3 || voNode.getNodeType() == 4) && voWhiteSpace.test(voNode.getNodeValue())) { //TEXT or CDATA Section
          voParam.append(poNode.getNodeName());
          voParam.append("=");
          voParam.append(encodeURIComponent(voNode.getNodeValue())); //encode
          voParam.append("&");
        }
      }
    } else {
      voParam.append(poNode.getNodeName());
      voParam.append("=");
      voParam.append("&");
    }

    return voParam.toString();
  };
};