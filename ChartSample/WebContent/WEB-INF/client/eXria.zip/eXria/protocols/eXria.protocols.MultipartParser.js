/**
 * @fileoverview
 * MultipartParser
 */
/**
 * MultipartParser
 * @author Choe, hyeon jong
 * @version 1.0
 * @param {eXria.protocols.Submission} poSubmission Submission Object
 * @base eXria.protocols.ResponseParser
 * @constructor
 * @private
 */
eXria.protocols.MultipartParser = function(poSubmission) {
  eXria.protocols.ResponseParser.call(this, poSubmission);
  this.complete = false;
  
  this.textParse = function(psText) {
	var voResponseParser = eXria.protocols.ProtocolParserFactory.getResponseParser(this.submission, this.submission.resProtocol);
	try {
	  var voResult = voResponseParser.textParse(psText);
	  if(voResponseParser.bind) {
		this.submission.bindInstance(voResult);
	  }
	  if(this.submission.onSubmitDone) {
		this.submission.onSubmitDone(this.submission);
	  }
	} catch(e) {
	  if(this.submission.onSubmitError) {
		this.submission.onSubmitError(voResult);
	  }
	}
  };
  this.parse = function(poFrame) {
	var vsResult = null;
	var voReadyState = poFrame.readyState;
	if(voReadyState) {
	  if(voReadyState == "complete" && !this.complete) {
		this.complete = true;
		vsResult = this.submission.model.page.window.document.frames[poFrame.id].document.body;
    if(vsResult != null) vsResult = vsResult.innerText;
		this.textParse(vsResult);
	  }
	} else {
	  try {
		vsResult = poFrame.contentWindow.document.body.firstChild.firstChild.nodeValue;
	  } catch(e) {
		vsResult = "complete";
	  }
	  this.textParse(vsResult);
	}
  };
};