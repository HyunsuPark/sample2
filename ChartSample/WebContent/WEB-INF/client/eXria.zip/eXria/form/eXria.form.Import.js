/**
 * @fileoverview
 * Page에 Import 되는 Page를 관리하는 Class.</br>
 * 실질적으로 Import 되는 Page는 서버측에서 부모 페이지에 포함시키므로 해당 메서드는 Run Time 시 사용 불가.
 */
/**
 * Page에 Import 되는 Page를 관리하는 Class.</br>
 * 실질적으로 Import 되는 Page는 서버측에서 부모 페이지에 포함시키므로 해당 메서드는 Run Time 시 사용 불가.
 * @version 1.0 
 * @param {String} psId 컨트롤 식별자
 * @param {Number} pnLeft 컨트롤 좌상단 점의 x좌표
 * @param {Number} pnTop 컨트롤 좌상단 점의 y좌표
 * @param {Number} pnWidth 컨트롤의 가로 길이
 * @param {Number} pnHeight 컨트롤의 세로 길이
 * @constructor
 */
eXria.form.Import = function(psId, pnLeft, pnTop, pnWidth, pnHeight, poCanvas) {
  /**
   * base
   * @type eXria.form.Import
   * @private
   */
  var base = this;
  /**
   * Import Page Id
   * @type String
   */
  this.id = psId;
  /**
   * Import Page left
   * @type Number
   */
  this.left = pnLeft;
  /**
   * Import Page top
   * @type Number
   */
  this.top = pnTop;
  /**
   * Import Page width
   * @type Number
   */
  this.width = pnWidth;
  /**
   * Import Page height
   * @type Number
   */
  this.height = pnHeight;
  /**
   * Import 되는 Page의 Canvas Object 
   * @type eXria.form.Canvas
   */
  this.pageCanvas = poCanvas;
  /**
   * Import 될 Page에 부쳐넣어질 Group Object</br>
   * Import 될 페이지는 해당 Group에 포함되어 Import 될 페이지에 생성
   * @type eXria.controls.Control
   * @see eXria.controls.Control
   */
  this.ctrl = this.pageCanvas.createControl("group", psId, pnLeft, pnTop, pnWidth, pnHeight); //group control

  var voImp = eXria.controls.xhtml.Default.Import;
  this.ctrl.disabled = voImp["disabled"];
  this.ctrl.movable = voImp["movable"];
  this.ctrl.showFocusLine = voImp["showFocusLine"];
  this.ctrl.tooltip = voImp["tooltip"];
  this.ctrl.tooltipDisplay = voImp["tooltipDisplay"];
  this.ctrl.tooltipLangKey = voImp["tooltipLangKey"];
  this.ctrl.userAttr = voImp["userAttr"];
  this.ctrl.visible = voImp["visible"];
  this.ctrl.focusBorderColor = voImp["focusBorderColor"];
  this.ctrl.focusBorderStyle = voImp["focusBorderStyle"];
  this.ctrl.focusBorderWidth = voImp["focusBorderWidth"];
  this.ctrl.focusDisplay = voImp["focusDisplay"];  

  this.ctrl.className = "Default_Import_Class";
  this.ctrl.outerClassName = "Default_Import_OuterClass";
  
  /**
   * 현재 Import되는 페이지를 Import 될 페이지에서 보여질지를 결정하는 속성
   * @type String
   * @private
   */
  if(eXria.controls.xhtml.Default.Import["overflow"]) this.ctrl.overflow = eXria.controls.xhtml.Default.Import["overflow"];
  else this.ctrl.overflow = "visible"; //overflow visible 20081016
  /**
   * 현재 Import 될 Page가 존재할 Group의 Focus 속성
   * @type Boolean
   * @private
   */
  this.ctrl.focusDisplay = false;
  /**
   * Import 될 페이지의 Canvas
   * @type
   */
  this.canvas = {};
  /**
   * Canvas Width
   * @type Number
   */
  this.canvas.width = null;
  /**
   * Canvas height
   * @type Number
   */
  this.canvas.height = null;
  /**
   * Canvas refresh
   * @private
   */
  this.canvas.refresh = function() {
    //TODO 검토
  };
  
  /**
   * Import 될 페이지의 subcontrol을 생성하는 function
   * @param {String} psType type
   * @param {String} psId id
   * @param {Number} pnLeft Left
   * @param {Number} pnTop Top
   * @param {Number} pnWidth Width
   * @param {Number} pnHeight Height
   * @return 생성된 Control Object
   * @type eXria.controls.Control
   */
  this.canvas.createControl = function(psType, psId, pnLeft, pnTop, pnWidth, pnHeight) {
    return base.pageCanvas.createControl(psType, psId, pnLeft, pnTop, pnWidth, pnHeight);
  };
  
  /**
   * Import될 페이지가 존재할 Group에 Control을 ADD 한다.
   * @param {eXria.controls.Control} poCtl 컨트롤 Object
   * @return void
   * @type void
   */
  this.canvas.appendControl = function(poCtl) {
    base.ctrl.addChild(poCtl);
  };
  /**
   * Import될 페이지를 Import 할 페이지에 set
   * @return void
   * @type void
   * @private
   */
  this.setImport = function(poCtl) {        
    //this.pageCanvas.appendControl(this.ctrl);
    
    if(!poCtl){ this.pageCanvas.appendControl(this.ctrl);}
    else{
     if('Tab_TabPages' === poCtl.toString() ||
        'SlidePage' === poCtl.toString()){          
      this.pageCanvas.appendControl(this.ctrl);
     }else{
      poCtl.addChild(this.ctrl);
     }      
    }            
  };
};
