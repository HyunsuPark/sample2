/**
 * @fileoverview
 * Plugin Mode 사용시 생성되는 Model Object Class
 */

/**
 * Plugin Mode 사용시 생성되는 Model Object Class
 * @version 1.0
 * @param {String} psId Model Id
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 * @base eXria.form.Model
 */
eXria.form.plugin.Model = function(psId, poPage) {
	/**
	 * dataset을 저장하는 map
	 * @type eXria.data.ArrayMap
	 */
	this.datasetMap = new eXria.data.ArrayMap();
	/**
	 * wrapping 된 서브미션을 저장하는 Map
	 * @type eXria.data.ArrayMap
	 * @private
	 */
	this.submissionsMap = new eXria.data.ArrayMap();
	/**
	 * connection을 저장하는 map
	 * @type eXria.data.ArrayMap
	 * @private
	 */
	this.connectionCmdMap = new eXria.data.ArrayMap();
	/**
	 * inherit
	 */
	eXria.form.Model.call(this, psId, poPage);

	/**
	 * plugin
	 * @type Object
	 * @private
	 */
	this.plugin = null;
	//this.isFireFox = false;
	
	/**
	 * global main frame window
	 * @type Object
	 * @private
	 */
	this.globalWindow = null;

	/**
	 * Progress Image Path 리턴 메소드
	 * @type String
	 * @return Progress Image Path
	 * @private
	 */
	this.getProgressImgPath = function() {
		var vsImagePath = null;
		var vsProgressPath = eXria.protocols.Default.Submission.waitcursorImage;

		var vsResourceBaseUrl = this.page.metadata.resourceBaseUrl;

		if (vsResourceBaseUrl == "/" || vsResourceBaseUrl == ""
				|| !vsResourceBaseUrl) {
			var host = page.window.location.host;
			var vsUrl = "http://" + host;
			vsImagePath = vsUrl + vsProgressPath;
		} else if (vsProgressPath != null) {
			var vsHref = this.page.metadata.url;
			var vsUrl = null;
			if (vsProgressPath.indexOf(vsResourceBaseUrl) > -1) {
				vsUrl = vsHref.substring(0, vsHref.indexOf(vsResourceBaseUrl));
			} else {
				vsUrl = vsHref.substring(0, vsHref.lastIndexOf("/") + 1);
			}
			vsImagePath = vsUrl + vsProgressPath;
		} else {
			var voLocation = this.page.window.location;
			var vsAddr = voLocation.host + vsResourceBaseUrl;

			vsImagePath = "http://" + vsAddr + "eXria/resource/images/progress.gif";
		}
		return vsImagePath;
	};

	/**
	 * 모델 생성
	 * @return void
	 * @type void
	 * @private
	 */
 this.create = function() {
      var voDoc = this.page.window.document;
      var voModel = voDoc.getElementById(this.id);
      var voPlugin = null;
      var voGlobalFrm = "not established";
      var vbIsJREAlive = false;
    
      if (!voModel || voModel == null) {
       var vnModelType = poPage.metadata.modelType;
       var voModelType = eXria.form.ModelType;
    
       if (vnModelType == voModelType.PLUGIN) {
        if (this.plugin == null) {
         var voBrowser = this.page.metadata.browser;
         if (voBrowser.ie > 0) {
          //IE
          voDoc.write("<OBJECT id='" + this.id + "' classid='CLSID:88ADED8D-376C-4d6f-B48D-B336E140294B' ");
          voDoc.write("style='position:absolute;left:-1000px;top:-1000px' width='0' height='0'></OBJECT>");
         } else {
          //Firefox
          voDoc.write("<embed id='" + this.id + "' type='application/npETBClient' width='0' height='0' hidden='true'>");
         }
        }
       } else {
         if(this.page.metadata.libScope == "global") {
           var voWindow = this.page.window;
  
           try {
             voGlobalFrm = voWindow.document.getElementById("$LibFrameName");
           } catch(e) {}
          
           if(voGlobalFrm == null) {
             var voParent = voWindow.parent;
            
             while(voParent != voWindow) {
               voWindow = voParent;
  
               try {
                 voGlobalFrm = voWindow.document.getElementById("$LibFrameName");
               } catch(e) {}
                
               if(voGlobalFrm != null) break;
  
               voParent = voWindow.parent;
             }
           }
  
           if(voGlobalFrm == null) {
             var voOpener = voWindow.opener;
             var voDialogArg = voWindow.dialogArguments;
             var voParent = null;
  
             while (voOpener || voDialogArg) {
               voWindow = voOpener ? voOpener : voDialogArg.window;
  
               voParent = voWindow.parent;
              
               while(voParent != voWindow) {
                 voWindow = voParent;
  
                 try {
                   voGlobalFrm = voWindow.document.getElementById("$LibFrameName");
                 } catch(e) {}
  
                 if(voGlobalFrm != null) break;
  
                 voParent = voWindow.parent;
               }
  
               if(voGlobalFrm != null) break;
  
               voOpener = voWindow.opener;
               voDialogArg = voWindow.dialogArguments;
             }
           }
  
           var voPluginObject;
  
           try {
             this.globalWindow = voGlobalFrm.contentWindow;
             this.id = this.id + this.globalWindow.getSeq();
             voPluginObject = this.globalWindow.document.getElementById("jreFrameApplet");
             voPluginObject.getVersion();
             vbIsJREAlive = true;
           } catch (e) {
             vbIsJREAlive = false;
           }
         } else {
           vbIsJREAlive = false;
         }

				if(!vbIsJREAlive) {
					voGlobalFrm = null;
					var voMetaData = this.page.metadata;
					var voJreConf = voMetaData.jre;
	
					var vsAppPath = (voJreConf.appletPath == "") ? null : voJreConf.appletPath;
					var vsJreVer = (voJreConf.version == "") ? null : voJreConf.version;
					var vsJvmArg = (voJreConf.jvmArgument == "") ? null : voJreConf.jvmArgument;
					var vsInitHeap = (voJreConf.initHeapSize == "") ? null : voJreConf.initHeapSize;
					var vsMaxHeap = (voJreConf.maxHeapSize == "") ? null : voJreConf.maxHeapSize;
					var voJreProp = (voJreConf.properties == "") ? null : voJreConf.properties;
					var vbSupportChunked = (voJreConf.supportChunkedStream == "") ? null : voJreConf.supportChunkedStream;
	
					var vsCodeBase = null;
					if (vsAppPath) {
						vsCodeBase = vsAppPath;
					} else {
						var voLocation = this.page.window.location;
						var vsAddr = voLocation.host + voMetaData.resourceBaseUrl;
						vsCodeBase = voLocation.protocol + "//" + vsAddr + "eXria/applet/";
					}
	
					var attributes = {
						id : this.id,
						name : this.id,
						codebase : vsCodeBase,
						code : 'org.exria.plugin.main.PluginMain',
						archive : "ExriaPlugin.jar",
						style : "position:absolute; width:1px; height:1px; float:left; left:-10000000px; top:-10000000px;"
					};

					var voBrowser = this.page.metadata.browser;
					var vsBrowserType ;

					if(voBrowser.ie != 0){
						vsBrowserType = "MSIE";
					}else if(voBrowser.chrome != 0){
						vsBrowserType = "CHROME";
					}else if(voBrowser.gecko != 0){
						vsBrowserType = "GECKO";
					}else if(voBrowser.opera != 0){
						vsBrowserType = "OPERA";
					}else if(voBrowser.webkit != 0){
						vsBrowserType = "APPLEWEBKIT";
					}else {
						vsBrowserType = "";
					}
					
					var parameters = {
						mayscript : true,
						id : this.id,
						cache_archive : "ExriaPlugin.jar",
						log_level : voMetaData.logLevel,
						browserType : vsBrowserType,
            supportChunkedStream : vbSupportChunked
					};
	
					if (vsJreVer) {
						parameters.java_version = vsJreVer;
					} else {
						parameters.java_version = "1.6+";
					}
	
					var vsJavaArgs = "";
					vsJavaArgs = vsJavaArgs + ((vsJvmArg) ? vsJvmArg + " " : "");
					vsJavaArgs = vsJavaArgs + ((vsInitHeap) ? vsInitHeap + " " : "");
					vsJavaArgs = vsJavaArgs + ((vsMaxHeap) ? vsMaxHeap + " " : "");
	
					for ( var member in voJreProp) {
						vsJavaArgs = vsJavaArgs + "-D" + member + "=" + voJreProp[member]	+ " ";
					}
	
					if (vsJavaArgs != "") {
						parameters.java_arguments = vsJavaArgs;
					}
	
					deployJava.htmlDoc = voDoc;
					deployJava.metadata = voMetaData;
					var javaPlugin = voDoc.getElementById("deployJavaPlugin");
					if (!javaPlugin) {
						deployJava.do_initialize();
					}
					deployJava.runApplet(attributes, parameters, '1.6');
//					this.plugin = deployJava.runApplet(attributes, parameters, '1.6');
				} else {
					this.globalWindow.createPlugin(this.id, page.window.location.href, this.page.window);
				}
			}
		}
	};
	/**
	 * load plugin object
	 * @return null;
	 * @type null
	 * @private
	 */
	this.setPlugin = function() {
		var voDoc = this.page.window.document;
		var voMetaData = this.page.metadata;
		if (voMetaData.modelType == eXria.form.ModelType.JRE) {
			if(this.globalWindow != null) {
				this.plugin = this.globalWindow.getPlugin(this.id);
			} else {
				this.plugin = voDoc.getElementById(this.id);
			}
		} else {
			if (voMetaData.browser.ie > 0) {
				this.plugin = voDoc.getElementById(this.id);
			} else {
				this.plugin = voDoc.getElementById(this.id).nsIETBClientFox;
			}
		}
	};
	/**
	 * set default progress image
	 * @type null
	 * @return null
	 * @private
	 */
	this.setDefaultProgressImg = function() {
		this.plugin.setProgressImg(this.getProgressImgPath());
	};

	/**
	 * model url
	 * @type String
	 * @private
	 */
	this.modelURL = null;
	/**
	 * viewObj
	 * @type Object
	 * @private
	 */
	this.viewObj = null;

	/**
	 * 모델 초기화
	 * @return void
	 * @type void
	 * @private
	 */
	this.init = function() {
		this.plugin.setSubmitBaseUrl(this.page.metadata.submitBaseUrl);
		this.plugin.setResourceUrl(this.page.metadata.resourceBaseUrl);

		if (this.modelURL) {
			this.modelURL = this.modelURL.substring(
					this.page.metadata.resourceBaseUrl.length - 1, this.modelURL.length);
			this.plugin.loadURL(this.modelURL, false);
		}
		if (this.page.metadata.loadingProgressEnabled) {
			this.progressAction(true);
			this.page.load(this.viewObj);
		} else {
			this.page.load(this.viewObj);
		}
	};

	/**
	 * 요청 URL중 문제가 생길 수 있는 URL에 대해 수정하여 리턴
	 * ex) /a.xrf -> a.xrf로 수정
	 * @param {String} psUrl 수정할 url
	 * @return 수정된 url
	 * @type String
	 * @private
	 */
	this.modifyURL = function(psUrl) {
		var vsBaseUrl = this.page.metadata.submitBaseUrl;
		var vnBaseUrlLen = vsBaseUrl.length;

		var vsStartUrl = psUrl.substring(0, vnBaseUrlLen);
		if ((vsBaseUrl != vsStartUrl) && psUrl.substring(0, 1) == '/')
			psUrl = psUrl.substring(1, psUrl.length);

		return psUrl;
	};

	/**
	 * 서버로 부터 Submission 및 Instance Load
	 * @param {String} psUrl server url (synchronization)
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.loadURL = function(psUrl, pnAppend) {
		if (pnAppend && pnAppend == 1) {
			pnAppend = true;
		} else {
			pnAppend = false;
		}
		this.plugin.loadURL(psUrl, pnAppend);
	};
	/**
	 * 넘겨받은 XMLElement를 Node에 Append한다.
	 * @param {XMLNode} poXML XML Node
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.loadXML = function(poXML) {
		this.plugin.loadXML(poXML, 0);
	};
	/**
	 * 넘겨받은 Text를 Parsing하여 Node에 Append한다.
	 * @param {String} psTXT XML Text
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.loadTXT = function(psTXT) {
		this.plugin.loadTXT(psTXT, 0);
	};
	/**
	 * 모델을 로드한다.
	 * @param {String} psUrl model의 URL
	 * @param {Object} poView UI Object
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.loadModel = function(psUrl, poView) {
		//this.modelURL = psUrl;
		this.modelURL = this.modifyURL(psUrl);
		this.viewObj = poView;

		this.init();
	};
	/**
	 * 인스턴스 생성
	 * @param {String} psId Instance ID
	 * @return 생성된 Instance 객체
	 * @type eXria.data.Instance
	 * @see eXria.data.Instance
	 * @ignore
	 */
	this.createInstance = function(psId) {
		var voPlugin = this.plugin;
		voPlugin.createInstance(psId);
		var voPluginInstance = voPlugin.getInstance(psId);
		return new eXria.data.plugin.Instance(voPluginInstance, psId, this);
	};
	/**
	 * 넘어온 ID와 일치하는 인스턴스를 리턴한다.
	 * @return 넘어온 ID와 일치하는 인스턴스
	 * @type eXria.data.Instance
	 * @see eXria.data.Instance
	 * @ignore
	 */
	this.getInstance = function(psId) {
		var voPluginInstance = this.plugin.getInstance(psId);
		if (voPluginInstance && voPluginInstance != null) {
			return new eXria.data.plugin.Instance(voPluginInstance, psId, this);
		} else {
			return null;
		}
	};
	/**
	 * 넘어온 ID와 일치하는 인스턴스를 삭제한다.
	 * @param {String} psId instance ID
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.removeInstance = function(psId) {
		this.plugin.removeInstance(psId);
	};
	/**
	 * submission을 생성한다.
	 * @param {String} psId Submission ID
	 * @type eXria.protocols.Submission
	 * @see eXria.protocols.Submission
	 * @ignore
	 */
	this.createSubmission = function(psId) { /* pnType=Submission Type */
		return this.plugin.createSubmission(psId);
	};
	/**
	 * 넘어온 ID와 일치하는 서브미션을 리턴.
	 * @param {String} psId Submission ID
	 * @return 넘어온 ID와 일치하는 Submission을 리턴한다.
	 * @type eXria.protocls.plugin.Submission
	 * @see eXria.protocls.plugin.Submission
	 * @ignore
	 */
	this.getSubmission = function(psId) {
		var voSubmission = this.submissionsMap.get(psId);
		if (voSubmission == null) {
			voSubmission = new eXria.protocols.plugin.Submission(psId, this,
					this.plugin.getSubmission(psId));
			this.submissionsMap.put(psId, voSubmission);
		}
		return voSubmission;
	};
	/**
	 * 넘어온 ID와 일치하는 Submission을 삭제한다.
	 * @param {String} psId Submission ID
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.removeSubmission = function(psId) {
		this.plugin.removeSubmission(psId);
		this.submissionsMap.remove(psId);
	};
	/**
	 * extension method
	 * @param {String} psDBName DB Name
	 * @return 넘어온 이름과 동일한 DB를 가져온다.
	 * @type Object
	 */
	this.getDB = function(psDBName) { //TODO
		return this.plugin.getDB(psDBName);
	};
	/**
	 * getDataSet
	 * 넘어온 ID와 일치하는 DataSet을 리턴한다.
	 * @param {String} psId DataSet Id
	 * @return DataSet 객체
	 * @type eXria.data.plugin.DataSetCmd
	 * @ignore
	 */
	this.getDataSet = function(psId) {
		var voDs = null;
		if (this.page.metadata.browser.ie > 0) {
			voDs = new eXria.data.plugin.DataSetCmd(psId, this);
		} else {
			voDs = this.datasetMap.get(psId);
			if (voDs == null) {
				voDs = new eXria.data.plugin.DataSetCmd(psId, this); //id, model
				this.datasetMap.put(psId, voDs);
			}
		}
		return voDs;
	};
	/**
	 * 커넥션 객체를 리턴한다.
	 * @return connection 객체
	 * @type eXria.data.plugin.DBConnectionCmd
	 * @see eXria.data.plugin.DBConnectionCmd
	 */
	this.getConnection = function(psId, pnTypeSrc, psSrcConn, pnTarget,
			psTargetName, psTargerConn) {
		var voConnection = null;
		var voConnection = this.connectionCmdMap.get(psId);
		if (voConnection == null) {
			//		voConnection = new eXria.data.plugin.DBConnectionCmd(this, psId,
			//			  this.plugin.getConnection(psId, pnTypeSrc, psSrcConn, pnTarget, psTargetName, psTargerConn));
			voConnection = new eXria.data.plugin.DBConnectionCmd(this, psId, pnTypeSrc, psSrcConn, pnTarget, psTargetName, psTargerConn);
			this.connectionCmdMap.put(psId, voConnection);
		}
		return voConnection;
	};
	/**
	 * getFileSystemObject
	 * 파일시스템 객체를 리턴한다.
	 * @return 파일시스템 객체
	 * @type eXria.data.plugin.FsoCmd
	 */
	this.getFileSystemObject = function() {
		return new eXria.data.plugin.FsoCmd(this.plugin.getFileSystemObject(), this);
	};
	/**
	 * DataSet을 생성한다.
	 * @param {String} psDataSetId 생성할 ID
	 * @param {Number} pnTypeSource source type
	 * @param {String} psConnectionInfo 연결 부가정보
	 * @param {String} psSourceQuery source의 query 정보
	 * @param {Boolean} pbSourceSync source와의 동기화 유무
	 * @param {Boolean} pbKeepOriginValue Keep Origin Value 유무
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.createDataSet = function(psDataSetId, pnTypeSource, psConnectionInfo, psSourceQuery, pbSourceSync, pbKeepOriginValue) {
		if (pbKeepOriginValue == null || pbKeepOriginValue == "") {
			pbKeepOriginValue = true;
		}
		this.plugin.createDataSet(psDataSetId, pnTypeSource, psConnectionInfo,
				psSourceQuery, pbSourceSync, pbKeepOriginValue);
	};
	/**
	 * DataSet을 제거한다.
	 * @param {String} psDataSetId 제거할 dataset ID
	 * @return void
	 * @type void
	 */
	this.removeDataSet = function(psDataSetId) {
		this.plugin.removeDataSet(psDataSetId);
		this.datasetMap.remove(psDataSetId);
	};
	/**
	 * Client의 IP를 구한다.
	 * @return Client의 IP
	 * @type String
	 */
	this.getClientIP = function() {
		return this.plugin.getClientIP();
	};
	/**
	 * Host Name을 구한다.
	 * @return host name
	 * @type String
	 */
	this.getHostName = function() {
		return this.plugin.getHostName();
	};
	/**
	 * 사용자 PC의 시간을 구한다.
	 * @return 사용자 PC의 시간 문자열
	 * @type String
	 */
	this.getSystemTime = function() {
		return this.plugin.getSystemTime();
	};
	/**
	 * 현재 이 플러그인의 버전을 확인한다.
	 * @return 현재 플러그인 버전 정보
	 * @type String
	 */
	this.getVersion = function() {
		return this.plugin.getVersion();
	};
	/**
	 * 플러그인 내부에서 표시하는 메시지를 다른 나라 언어로 표시하고자 할때
	 * 문자열 정의파일(XML형식)을 지정할 수 있다.
	 * @param {String} psUrl 외국어 문자열 정의파일을 지정하는 URL
	 * @return void
	 * @type void
	 */
	this.setMsgFile = function(psUrl) {
		this.plugin.setMsgFile(psUrl);
	};
	/**
	 * Resource Url을 설정한다.
	 * @param {String} psResourceUrl Resource Url
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.setResourceUrl = function(psResourceUrl) {
		this.plugin.setResourceUrl(psResourceUrl);
	};
	/**
	 * Submit Base Url을 설정한다.
	 * @param {String} psBaseUrl
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.setSubmitBaseUrl = function(psBaseUrl) {
		this.plugin.setSubmitBaseUrl(psBaseUrl);
	};
	/**
	 * 사용자 PC의 시간을 설정한다.
	 * @param {Number} pnYear 연도 4자리
	 * @param {Number} pnMonth 월 2자리
	 * @param {Number} pnDay 일 2자리
	 * @param {Number} pnHour 시 2자리
	 * @param {Number} pnMinute 분 2자리
	 * @param {Number} pnSecond 초 2자리
	 * @return void
	 * @type void
	 */
	this.setSystemTime = function(pnYear, pnMonth, pnDay, pnHour, pnMinute, pnSecond) {
		this.plugin.setSystemTime(pnYear, pnMonth, pnDay, pnHour, pnMinute, pnSecond);
	};
	/**
	 * Logger 인터페이스를 얻는다.
	 * @type eXria.form.plugin.Logger
	 * @return Logger Object
	 */
	this.getLogger = function() {
		return new eXria.form.plugin.Logger(this.plugin);
	};
	/**
	 * close
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.close = function() {
		//this.plugin.close();

		if (this.page.metadata.modelType == eXria.form.ModelType.JRE && this.globalWindow != null) {
			this.globalWindow.removeWindow(this.id);
		}
		delete this.plugin;
	};
	/**
	 * 콤보구분 인스턴스 ID 리스트 문자열을 반환하는 메소드.
	 * @type String
	 * @return 인스턴스 ID 리스트 (ex. instance,instance1)
	 */
	this.getInstanceIdList = function() {
		return this.plugin.getInstanceIDListStr();
	};
	/**
	 * 콤보구분 DataSet ID 리스트 문자열을 반환하는 메소드.
	 * @type String
	 * @return DataSet ID 리스트 (ex. dst1,dst2,dst3)
	 */
	this.getDataSetIdList = function() {
		return this.plugin.getDataSetIDListStr();
	};
	/**
	 * Server Error Message를 반환한다.
	 * @param {Boolean} pbCode 에러 코드 리턴 유무
	 * @param {Boolean} pbMsg 에러 메세지 리턴 유무
	 * @param {Boolean} pbSrc 에러 소스 리턴 유무
	 * @type eXria.data.ArrayCollection
	 * @return Error String을 담고 있는 Array 객체
	 * @ignore
	 */
	this.getErrorMessage = function(pbCode, pbMsg, pbSrc) {
		if (pbCode != false)
			pbCode = true;
		if (pbMsg != false)
			pbMsg = true;
		if (pbSrc != false)
			pbSrc = true;

		var vnDefInstId = this.plugin.getDefInstanceID();
		if (!vnDefInstId)
			throw new Error("Default Instance ID is null.");
		var voMapNode = this.getInstance(vnDefInstId).getMapNode("/root/EXRIAERRMSG");
		if (voMapNode.size() == 0)
			return null;

		var vsErrFullStr = "", vsErrCode = "", vsErrMsg = "", vsErrSrc = "";
		if (pbCode)
			vsErrCode = voMapNode.get("ERRCODE");
		if (pbMsg)
			vsErrMsg = voMapNode.get("ERRMSG");
		if (pbSrc)
			vsErrSrc = voMapNode.get("ERRSRC");

		vsErrFullStr = vsErrCode + vsErrMsg + vsErrSrc;

		return vsErrFullStr.replace(/\\n/ig, "\n");
	};
	/**
	 * Server Error Message를 전부 삭제한다.
	 * @type void
	 * @return void
	 * @ignore
	 */
	this.clearErrorMessage = function() {
		var vnDefInstId = this.plugin.getDefInstanceID();
		if (!vnDefInstId)
			throw new Error("Default Instance ID is null.");
		var voNode = this.getInstance(vnDefInstId).selectSingleNode("/root/EXRIAERRMSG");
		while (voNode.childNodes.length) {
			voNode.removeChild(voNode.childNodes[0]);
		}
	};
	/**
	 * 화면 loading 시 progress bar 출력
	 * @param {Boolean} pbShow boolean : true - progress bar 출력, false - progress bar 종료
	 * @return void
	 * @type void
	 * @ignore
	 */
	this.progressAction = function(pbShow, psImage) {
		if (pbShow) {
			if (psImage == null || psImage == "") {
				this.plugin.progressAction(pbShow, this.getProgressImgPath());
			} else {
				this.plugin.progressAction(pbShow, psImage);
			}
		} else {
			this.plugin.progressAction(pbShow, "");
		}
	};
	/**
	 * AES암호화 후 Base64 처리 된 문자열을 복호화 하여 원본 문자열을 리턴한다. 
	 * @param {String} psStr
	 * @type String
	 * @return Base64 decoding 후 복호화 하여 원본 문자열
	 */
	this.decryptStr = function(psStr) {
		if (!psStr)
			return null;
		return this.plugin.decryptStr(psStr);
	};
	/**
	 * plugin 내부 AES 알고리즘으로 입력된 파라미터 문자열을 암호화 하여 Base64 처리 후 리턴한다. 
	 * @param {String} psStr
	 * @type String
	 * @return 암호화와 Base64처리 된 문자열
	 */
	this.encryptStr = function(psStr) {
		if (!psStr)
			return null;
		return this.plugin.encryptStr(psStr);
	};
	/**
	 * 콤보구분 Submission ID 리스트 문자열을 반환하는 메소드.
	 * @type String
	 * @return Submission ID 리스트 (ex. sms1,sms2,sms3)
	 */
	this.getSubmissionIdList = function() {
		return this.plugin.getSubmissionIdListStr();
	};
	/**
	 * 현재 클라이언트 PC의 Mac Address를 리턴
	 * @type String
	 * @return Mac Address
	 */
	this.getMacAddr = function() {
		return this.plugin.getMacAddr();
	};
};
