/**
 * @fileoverview
 * CanvasFactory
 */
 
/**
 * CanvasFactory
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 * @private
 */
eXria.form.CanvasFactory = {
  create : function(pnType, poPage) {
    if (poPage.canvas != null) { throw new Error("Canvas is already created."); }
    var vsId = poPage.id + "_canvas";
    switch (pnType) {
      case eXria.form.CanvasType.XHTML :
        return new eXria.form.xhtml.Canvas(vsId, poPage);
      case eXria.form.CanvasType.FLEX :
        var vsPlugin = eXria.controls.PluginFactory.create(vsId, eXria.controls.PluginType.FLEX, poPage.metadata.browser).toString();
        poPage.window.document.write(vsPlugin);
        return new eXria.form.flex.Canvas(vsId, poPage);
      case eXria.form.CanvasType.SILVERLIGHT :
        var vsPlugin = eXria.controls.PluginFactory.create(vsId, eXria.controls.PluginType.SILVERLIGHT, poPage.metadata.browser).toString();
        poPage.window.document.write(vsPlugin);
        return new eXria.form.silverlight.Canvas(vsId, poPage);
/*
      case eXria.form.CanvasType.XBUILDER : // reserved
        var vsPlugin = eXria.controls.PluginFactory.create(vsId, eXria.controls.PluginType.XBUILDER, poPage.metadata.browser).toString();
        poPage.window.document.write(vsPlugin);
        return new eXria.form.xbuilder.Canvas(vsId, poPage);
*/
      default :
        throw new Error("No such canvas type : " + pnType);
    }
  }
};
