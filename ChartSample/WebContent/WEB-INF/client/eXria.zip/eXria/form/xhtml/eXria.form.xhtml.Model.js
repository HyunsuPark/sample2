/**
 * @fileoverview
 * XHTML Mode 사용시 생성되는 Model Object Class
 */
 
/**
 * XHTML Mode 사용시 생성되는 Model Object Class
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {String} psId Model Id
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 * @base eXria.form.Model
 */
eXria.form.xhtml.Model = function(psId, poPage) {
  /**
   * inherit
   */
  eXria.form.Model.call(this, psId, poPage);
  /**
   * Model Object
   * @type eXria.form.xhtml.Model
   */
  var base = this;

  /**
   * instance
   * @type eXria.data.ArrayMap
   * @private
   */
  this.instances = new eXria.data.ArrayMap();

  /**
   * 서버로 부터 Submission 및 Instance Load
   * @param {String} psUrl server url (synchronization)
   * @return void
   * @type void
   * @ignore
   */
  this.loadURL = function(psUrl, pbAppend) {
	var vsResourceUrl = this.page.metadata.resourceBaseUrl;
	var vnResource = psUrl.indexOf(vsResourceUrl);
	if(vnResource == -1) {
	  psUrl = vsResourceUrl.substring(0, vsResourceUrl.length - 1) + psUrl;
	}
    var voDocument = eXria.data.xhtml.DocumentFactory.createDocument(this.page);
    voDocument.loadURL(psUrl);
    this.parseInitDocument(voDocument, pbAppend);
  };
  /**
   * 넘겨받은 XMLElement를 Node에 Append한다.
   * @param {XMLNode} poXML XML Node
   * @return void
   * @type void
   * @ignore
   */
  this.loadXML = function(poXML, pbAppend) {
    var voDocument = eXria.data.xhtml.DocumentFactory.createDocument(this.page);
    voDocument.loadXML(poXML);
    this.parseInitDocument(voDocument, pbAppend);
  };
  /**
   * 넘겨받은 Text를 Parsing하여 Node에 Append한다.
   * @param {String} psTXT XML Text
   * @return void
   * @type void
   * @ignore
   */
  this.loadTXT = function(psTXT, pbAppend) {
    var voDocument = eXria.data.xhtml.DocumentFactory.createDocument(this.page);
    voDocument.loadTXT(psTXT);
    this.parseInitDocument(voDocument, pbAppend);
  };
  
  /**
   * viewObj
   * @private
   */
  this.viewObj = null;
  /**
   * viewTimer
   * @private
   */
  this.viewTimer = null;
  
  this.defaultInstanceId = null;
  
  /**
   * loadModel
   * @param {String} psUrl server URL
   * @param {Object} poView UI Object
   * @return void
   * @type void
   * @ignore
   */
  this.loadModel = function(psUrl, poView) {
	this.viewObj = poView;
    this.loadURL(psUrl);
    //progress start 20081217
    if(this.page.metadata.loadingProgressEnabled) {
    	this.progressAction(true);
    	this.viewTimer = this.page.window.setTimeout(this.viewRendering, 20);
    } else {
    	this.viewRendering();
    }
  };
  /**
   * viewRendering
   * @return void
   * @type void
   * @ignore
   */
  this.viewRendering = function() {
    if(base.page.model.viewTimer) {
      base.page.window.clearTimeout(base.viewTimer);
    }
    base.page.load(base.viewObj);
    if(base.page.metadata.loadingProgressEnabled) {
      base.progressAction(false);
    }
  };
//progress end 20081217
  /**
   * parseInitDocument
   * @param {Object} poDOM
   * @param {Boolean} pbAppend
   * @return void
   * @type void
   * @ignore
   */
  this.parseInitDocument = function(poDOM, pbAppend) {
    var vnNodeCnt = 0;
    var voNode;
    var vsId;

    if(pbAppend == false) { 
      this.submissions.clear();
      this.instances.clear();
    }

    //1. submission parsing
    {
	  var voSubmissionList = null;
   	  voSubmissionList = poDOM.selectNodes("//*[namespace-uri()='http://www.exria.org/exria' and local-name()='submission']");
      if(!voSubmissionList) {
    	voSubmissionList = poDOM.selectNodes("//xr:submission");
      }
      vnNodeCnt = voSubmissionList.getLength();
      
      var vsReqProtocol, vsResProtocol, vsAsync, vsMethod, vsAction, vsReqCharSet, vaResCharSet;
      var voSubmission = null;
      var voInnerNodeList;
      var voInnerNode;
      
      for(var i = 0; i < vnNodeCnt; i++) {
        voNode = voSubmissionList.item(i); /* nodelist */

        //submission attribute parsing
		var voAttr = voNode.attributes;
        vsId = voAttr.getNamedItem("id").value;
        vsReqProtocol = voAttr.getNamedItem(eXria.protocols.SubmissionType.REQ_PROTOCOL_HEADER).value;
        vsResProtocol = voAttr.getNamedItem(eXria.protocols.SubmissionType.RES_PROTOCOL_HEADER).value;
        vsAsync = voAttr.getNamedItem("async").value;
        vsMethod = voAttr.getNamedItem("method").value;
        vsAction = voAttr.getNamedItem("action").value;
        vsReqCharSet = voAttr.getNamedItem("req-charset").value;
        vaResCharSet = voAttr.getNamedItem("res-charset").value;
        
        voSubmission = new this.page.window.eXria.protocols.xhtml.Submission(vsId, this);
        
        voSubmission.setReqProtocol(vsReqProtocol);
        voSubmission.setResProtocol(vsResProtocol);
        
        voSubmission.setAsync((vsAsync == "false" ? false : true));
        voSubmission.setMethod(vsMethod);
        voSubmission.setAction(vsAction);
        voSubmission.setReqCharset(vsReqCharSet);
        voSubmission.setResCharset(vaResCharSet == null || vaResCharSet == "" ? vsReqCharSet : vaResCharSet); // response-characterset이 없을 경우 request-characterset으로
        
        //submission sub element parsing
        voInnerNodeList = voNode.childNodes;
        for(var j = 0; j < voInnerNodeList.length; j++) {
          voInnerNode = voInnerNodeList.item(j);
          if(voInnerNode.nodeType != 1) {
            continue;
          }
          var vsName = voInnerNode.baseName ? voInnerNode.baseName : voInnerNode.localName;
          switch(vsName) {
            case "listener" :
              var vsEvent   = voInnerNode.attributes.getNamedItem("event").value;
              var vsHandler = voInnerNode.attributes.getNamedItem("handler").value;
              switch(vsEvent) {
                case "onsubmit" :
                  voSubmission.onSubmit = new Function("e", "this.model." + vsHandler + "(e)");
                  break;
                case "onsubmitdone" :
                  voSubmission.onSubmitDone = new Function("e", "this.model." + vsHandler + "(e)");
                  break;
                case "onsubmiterror" :
                  voSubmission.onSubmitError = new Function("e", "this.model." + vsHandler + "(e)");
                  break;
              }
              break;
            case "request-ref" :
              var vsInstanceid = null;
              try {
            	  vsInstanceid   = voInnerNode.attributes.getNamedItem("instanceid");
            	  if(vsInstanceid) vsInstanceid = vsInstanceid.value;
              } catch (e) {
            	  throw new Error("Request-ref is support only Instance.");
              }
              if(vsInstanceid) {
                var vsRef = null;
                vsRef = voInnerNode.attributes.getNamedItem("ref");
                if(vsRef) vsRef = vsRef.value;
                voSubmission.addRef(vsInstanceid, vsRef);
              }
              break;
            case "header" :
              var vsName = voInnerNode.attributes.getNamedItem("name").value;
              var vsValue = voInnerNode.attributes.getNamedItem("value").value;
              voSubmission.setHeader(vsName, vsValue);
              break;
            case "parameter" :
              var vsName = voInnerNode.attributes.getNamedItem("name").value;
			  try {
              	var vsValue = voInnerNode.attributes.getNamedItem("value").value;
			  } catch(e) {
				var vsValue = "";
			  }
              voSubmission.addParameter(vsName, vsValue);
              break;
            case "response-ref" :
              try {
            	  var vsInstanceid   = voInnerNode.attributes.getNamedItem("instanceid").value;
              } catch (e) {
            	  throw new Error("Response-ref is support only Instance.");
              }
              var vsRef   = voInnerNode.attributes.getNamedItem("ref").value;
              var vsAdd   = voInnerNode.attributes.getNamedItem("add").value;
              voSubmission.addResRef(vsInstanceid, vsRef, vsAdd == "true" ? false : true);
              break; 
          }
        }
        this.appendSubmission(voSubmission);
      }
    }

    //2. Instance parsing
    {
      var voInstance;
	  var voInstanceList = null;
      voInstanceList = poDOM.selectNodes("//*[namespace-uri()='http://www.w3.org/2002/xforms' and local-name()='instance']");
      if(!voInstanceList) {
    	voInstanceList = poDOM.selectNodes("//xf:instance");
      }
      vnNodeCnt = voInstanceList.getLength();

      for(var i = 0; i < vnNodeCnt; i++) {
        voNode = voInstanceList.item(i);
        vsId = voNode.attributes.getNamedItem("id").value;
        voInstance = new this.page.window.eXria.data.xhtml.Instance(vsId, this);
		
		var voChildNodes = voNode.childNodes;
		var vnLen = voChildNodes.length;
		var voItem = null;
		var vaNodes = [];

		for(var j = 0 ; j < vnLen ; j++) {
		  voItem = voChildNodes.item(j);
		  if(voItem.nodeType == 1) {
			vaNodes.push(voItem);
		  }
		}
		
		if(vaNodes.length > 0) {
		  voInstance.loadXML(vaNodes[0]);
		  this.appendInstance(voInstance);
		}
//        var voNodeCol = new this.page.window.eXria.data.xhtml.CollectionNode(voNode);
//        if(voNodeCol.size() > 0) {
//          voInstance.loadXML(voNodeCol.get(0));
//
//          this.appendInstance(voInstance);
//        }
      }
	  var voDefaultInstance = null;
      voDefaultInstance = poDOM.selectSingleNode("//*[namespace-uri()='http://www.w3.org/2002/xforms' and local-name()='model']");
      if(!voDefaultInstance) {
    	voDefaultInstance = poDOM.selectSingleNode("//xf:model");
      }
      this.defaultInstanceId = voDefaultInstance.attributes.getNamedItem("defaultinstance").value;
    }
  };
  /**
   * 인스턴스 생성
   * @param {String} psId Instance ID
   * @return 생성된 Instance 리턴
   * @type eXria.data.Instance
   * @return instance Object
   * @type eXria.data.xhtml.Instance
   * @see eXria.data.xhtml.Instance
   * @ignore
   */
  this.createInstance = function(psId) {
    var voInstance = new eXria.data.xhtml.Instance(psId, this);
    var voRootNode = voInstance.createNode("root");
    voInstance.appendNode("/", voRootNode);
    this.appendInstance(voInstance);
    return voInstance;
  };
  /**
   * 넘어온 인스턴스를 instance 객체에 붙인다.
   * @param {eXria.data.Instance} poInstance instance Object
   * @return void
   * @type void
   * @ignore
   */
  this.appendInstance = function(poInstance) {
    this.instances.put(poInstance.id, poInstance);
  };
  /**
   * 넘어온 ID와 일치하는 인스턴스를 찾아 리턴한다.
   * @param {String} psId instance id
   * @return Instance Object
   * @type eXria.data.Instance
   * @ignore
   */
  this.getInstance = function(psId) {
    return this.instances.get(psId);
  };
  /**
   * 넘어온 ID와 일치하는 인스턴스를 찾아 삭제한다.
   * @param {String} psId instance id
   * @return void
   * @type void
   * @ignore
   */
  this.removeInstance = function(psId) {
    var voInstance = this.instances.remove(psId);
    voInstance.clear();
  };

  /**
   * submission
   * @type eXria.data.ArrayMap
   * @private
   */
  this.submissions = new eXria.data.ArrayMap();
  
  /**
   * submission을 생성한다.
   * @param {String} psId submission id
   * @return 생성된 Submission
   * @type eXria.protocols.Submission
   * @ignore
   */
  this.createSubmission = function(psId) { /* pnType=Submission Type */
    return new eXria.protocols.xhtml.Submission(psId, this);
  };
  /**
   * 넘어온 submission 객체를 submission에 추가 시킨다.
   * @param {eXria.protocols.Submission) poSubmission submission object
   * @return void
   * @type void
   * @ignore
   */
  this.appendSubmission = function(poSubmission) {
    this.submissions.put(poSubmission.id, poSubmission);
  };
  /**
   * 넘어온 ID와 일치하는 서브미션을 리턴.
   * @param {String} psId
   * @return Submission Object
   * @type eXria.protocols.Submission
   * @ignore
   */
  this.getSubmission = function(psId) {
    return this.submissions.get(psId);
  };
  /**
   * 넘어온 ID와 일치하는 Submission을 삭제한다.
   * @param {String} psId Submission ID
   * @return void
   * @type void
   * @ignore
   */
  this.removeSubmission = function(psId) {
    var voSubmission = this.submissions.remove(psId);
    voSubmission.clear();
  };

  /**
   * datasets
   * @type eXria.data.ArrayMap
   * @ignore
   */
  this.datasets = new eXria.data.ArrayMap();
  /**
   * 넘어온 dataset을 추가. 동일한 id의 dataset이 존재할 경우 rewrite
   * @param {Object} poDataSet dataset Object
   * @return void
   * @type void
   * @ignore 
   */
  this.appendDataSet = function(poDataSet) {
    this.datasets.put(poDataSet.id, poDataSet);
    this[poDataSet.id] = poDataSet;
  };
  /**
   * 넘어온 id와 일치하는 dataset 리턴
   * @param {String} psId dataset id
   * @return dataset Object
   * @type eXria.data.DataSetCmd
   * @ignore
   */
  this.getDataSet = function(psId) {
	throw new Error("DataSet is support only Plugin Mode.");
  };
  
  /**
   * 넘어온 id와 일치하는 dataset 생성</br>
   * 만약 일치하는 id의 dataset이 존재한다면 기존의 dataset 리턴 아니면 새로생성
   * @param {String} psId dataset Id
   * @return dataset Object
   * @type eXria.data.DataSetCmd
   * @ignore
   */
  this.createDataSet = function(psId){
  	if(this.datasets.get(psId)) {
  		return this.datasets.get(psId);
  	} else {
  		var voDs = new eXria.data.xhtml.DataSet(psId);
  		return voDs;
  	}
  }
  /**
   * 넘어온 Id와 일치하는 dataset 삭제
   * @param {String} psId dataset Id
   * @return void
   * @type void
   * @ignore
   */
  this.removeDataSet = function(psId) {
  	var voDataSet = this.datasets.remove(psId);
  	voDataSet.clear();
    delete this[psId];
  };
  
  /**
   * 화면 loading 시 progress bar 출력
   * @param {Boolean} pbShow boolean : true - progress bar 출력, false - progress bar 종료
   * @return void
   * @type void
   * @ignore
   */
  this.voProgressCtrl = null;
  this.progressAction = function(pbShow) {
	if(pbShow) {
	  if(!this.voProgressCtrl) {
		var voCtrl = this.page.window.document.createElement("div");
		voCtrl.id = "page_progress";
		voCtrl.style.position = "absolute";
		voCtrl.style.overflow = "hidden";
		voCtrl.style.left = "50px";
		voCtrl.style.top = "50px";
		voCtrl.style.height = "44px";
		voCtrl.style.width = "125px";
		voCtrl.innerHTML = "<img src='" + this.page.metadata.resourceBaseUrl + "/eXria/form/xhtml/loading.png" + "' width='125px' height='44px' />";
		this.page.window.document.body.appendChild(voCtrl);
		this.voProgressCtrl = voCtrl;
	  }
	  this.voProgressCtrl.style.visibility = "visible";
	} else {
	  if(this.voProgressCtrl) {
		this.voProgressCtrl.style.visibility = "hidden";
	  }
	}
	  //TODO ... use timer
  };
  
  /**
   * close
   * @ignore
   */
  this.close = function() {
    var voIterator = this.instances.getKeyCollection().iterator();
    while(voIterator.hasNext()) {
      var voInstance = voIterator.next();
      if(voInstance.clear) {
        voInstance.clear();
      }
      delete this[voInstance.id];
    }
    this.instances.clear();
    delete this.instances;

    voIterator = this.submissions.getKeyCollection().iterator();
    while(voIterator.hasNext()) {
      var voSubmission = voIterator.next();
      if(voSubmission.clear) {
        voSubmission.clear();
      }
      delete this[voSubmission.id];
    }
    this.submissions.clear();
    delete this.submissions;
  };
  /**
   * 콤보구분 인스턴스 ID 리스트 문자열을 반환하는 메소드.
   * @type String
   * @return 인스턴스 ID 리스트 (ex. instance,instance1)
   */
  this.getInstanceIdList = function() {
    var vaInstance = this.instances.getKeyCollection().elements;
    return vaInstance.join(",");
  };
  /**
   * 콤보구분 DataSet ID 리스트 문자열을 반환하는 메소드.
   * @type String
   * @return DataSet ID 리스트 (ex. dst1,dst2,dst3)
   */
  this.getDataSetIdList = function() {
    throw new Error("not support method.");
  };
  /**
   * Server Error Message를 반환한다.
   * @param {Boolean} pbCode 에러 코드 리턴 유무
   * @param {Boolean} pbMsg 에러 메세지 리턴 유무
   * @param {Boolean} pbSrc 에러 소스 리턴 유무
   * @type eXria.data.ArrayCollection
   * @return Error String을 담고 있는 Array 객체
   * @ignore
   */
  this.getErrorMessage = function(pbCode, pbMsg, pbSrc) {
	if(pbCode != false) pbCode = true;
	if(pbMsg != false) pbMsg = true;
	if(pbSrc != false) pbSrc = true;
	
	var voNodeCollection = this.instances.get(this.defaultInstanceId).getCollectionNode("/root/EXRIAERRMSG");
	
	var voNode = null;
	var voChild = null;
	var vnNodeChildSize = null;
	var vsErrFullStr = "", vsErrCode = "", vsErrMsg = "", vsErrSrc = "";
	var vnNodeSize = voNodeCollection.size();
	var voErrCollection = new eXria.data.ArrayCollection();

	if(vnNodeSize == 0) return null;

	for(var i = 0 ; i < vnNodeSize ; i++) {
	  voNode = voNodeCollection.get(i);
	  vnNodeChildSize = voNode.childNodes.length;
	  if(voNode.nodeName == "ERRCODE" && pbCode) vsErrCode = "Error Code : \n" + voNode.childNodes[0].nodeValue + "\n";
	  if(voNode.nodeName == "ERRMSG" && pbMsg) vsErrMsg = "Error Message : \n" + voNode.childNodes[0].nodeValue + "\n";
	  if(voNode.nodeName == "ERRSRC" && pbSrc) vsErrSrc = "Error Source : \n" + voNode.childNodes[0].nodeValue + "\n";
	  vsErrFullStr = vsErrCode + vsErrMsg + vsErrSrc;
	  voErrCollection.add(vsErrFullStr.replace(/\\n/ig, "\n"));
	  vsErrCode = "";
	  vsErrMsg = "";
	  vsErrSrc = "";
	  vsErrFullStr = "";
	}
	return voErrCollection;
  };
  
  /**
   * Server Error Message를 전부 삭제한다.
   * @type void
   * @return void
   * @ignore
   */
  this.clearErrorMessage = function() {
	var voNode = this.getInstance(this.defaultInstanceId).selectSingleNode("/root/EXRIAERRMSG");
	while(voNode.childNodes.length) {
	  voNode.removeChild(voNode.childNodes[0]);
	}
  };
  /**
   * AES암호화 후 Base64 처리 된 문자열을 복호화 하여 원본 문자열을 리턴한다. 
   * @param {String} psStr
   * @type String
   * @return Base64 decoding 후 복호화 하여 원본 문자열
   */
  this.decryptStr = function(psStr) {
	return null;
  };
  /**
   * plugin 내부 AES 알고리즘으로 입력된 파라미터 문자열을 암호화 하여 Base64 처리 후 리턴한다. 
   * @param {String} psStr
   * @type String
   * @return 암호화와 Base64처리 된 문자열
   */
  this.encryptStr = function(psStr) {
	return null;
  };
  /**
   * 콤보구분 Submission ID 리스트 문자열을 반환하는 메소드.
   * @type String
   * @return Submission ID 리스트 (ex. sms1,sms2,sms3)
   */
  this.getSubmissionIdList = function() {
    var vaInstance = this.submissions.getKeyCollection().elements;
    return vaInstance.join(",");
  };
  /**
   * 현재 클라이언트 PC의 Mac Address를 리턴
   * @type String
   * @return Mac Address
   */
  this.getMacAddr = function() {
    throw new Error("not support method.");
  };
};
