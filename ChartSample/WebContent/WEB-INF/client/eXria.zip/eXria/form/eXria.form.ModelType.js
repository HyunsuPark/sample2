﻿/**
 * @fileoverview
 * ModelType
 * enum(eXria.form.ModelType.XHTML, eXria.form.ModelType.PLUGIN)
 */
 
/**
 * ModelType
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 * @private
 */
eXria.form.ModelType = {
  XHTML : 0,
  PLUGIN : 1,
  JRE	 : 2,
  SWITCH : 3
};
