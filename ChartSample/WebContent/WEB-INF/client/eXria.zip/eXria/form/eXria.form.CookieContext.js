/**
 * @fileoverview
 * 사용자 Cookie Data를 관리하는 클래스
 */
 
/**
 * 사용자 Cookie Data를 관리하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {eXria.form.Page} poPage Page Object
 * @constructor
 * @base eXria.form.Context
 */
eXria.form.CookieContext = function(poPage) {
  /**
   * inherit
   */
  eXria.form.Context.call(this, poPage);

  /**
   * parameter로 넘어온 name과 일치하는 cookie 값을 찾아 리턴한다.
   * @param {String} psName 찾고자 하는 cookie의 name
   * @return cookie 데이터
   * @type String
   */
  this.getAttribute = function(psName) {
    var voCookies = this.page.window.document.cookie;
    if (voCookies.length > 0) {
      var vnStartIndex = voCookies.indexOf(psName + "=");
      if (vnStartIndex != -1) {
        vnStartIndex = vnStartIndex + psName.length + 1;
        var vnEndIndex = voCookies.indexOf(";", vnStartIndex);
        if (vnEndIndex == -1) { vnEndIndex = voCookies.length; }
        return decodeURIComponent(voCookies.substring(vnStartIndex, vnEndIndex));
      }
    }
    return null;
  };
  
  /**
   * parameter로 넘어온 내용들을 cookie에 저장
   * @param {String} psName name
   * @param {String} psValue value
   * @param {Number} pnExpireDays expire days
   * @return void
   * @type void
   */
  this.setAttribute = function(psName, psValue, pnExpireDays) {
    var vsCookie = psName + "=" + encodeURIComponent(psValue);
    if (pnExpireDays != null) {
      var vdNow = new Date();
      vdNow.setDate(vdNow.getDate() + pnExpireDays);
      vsCookie += ";expires=" + vdNow.toGMTString();
    }
    this.page.window.document.cookie = vsCookie;
  };

  /**
   * parameter로 넘어온 name과 일치하는 cookie 데이터를 삭제한다.
   * @param {String} psName name
   * @return void
   * @type void
   */
  this.removeAttribute = function(psName) {
    var vsValue = this.getAttribute(psName);
    if (vsValue != null) { this.setAttribute(psName, vsValue, -1); }
  };

};
