/**
 * @fileoverview
 * Page Type을 상수 정의한 클래스</br>
 * enum</br>
 * - eXria.form.PageType.MAIN</br>
 * - eXria.form.PageType.POPUP</br>
 * - eXria.form.PageType.FRAME</br>
 * - eXria.form.PageType.IMPORT</br>
 */
 
/**
 * Page Type을 상수 정의한 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */
eXria.form.PageType = {
  MAIN : 0,
  POPUP : 1,
  FRAME : 2,
  IMPORT : 3,
  MODAL : 4
};