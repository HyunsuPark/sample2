﻿/**
 * @fileoverview
 * XML Node를 Collection 형태로 관리할 수 있도록 하는 클래스
 */
/**
 * XML Node를 Collection 형태로 관리할 수 있도록 하는 클래스
 * @author Kim, Min Seok
 * @version 1.0
 * @constructor
 */ 
eXria.data.Collection = function() {
  /**
   * elements
   * @type Object
   * @private
   */
  this.elements = new Array();
  /**
   * 컬렉션 구성 요소 크기를 저장하기 위한 속성
   * @type Number
   * @private
   */
  this.cnt = 0;
  /**
   * Collection에 Parameter로 넘어온 데이터를 추가한다.
   * @param {Object} poValue 컬렉션에 추가될 Value
   * @return void
   * @type void
   */
  this.add = function(poValue) {
    this.elements.push(poValue);
    this.cnt++;
  };
  /**
   * Collection에 현재 존재하는 Item의 갯수를 리턴한다.
   * @return 컬렉션 구성 요소들의 크기[개수]
   * @type Number
   */
  this.size = function() {
	return this.cnt;
  };
  /**
   * Parameter로 넘어온 Index에 해당하는 Collection의 Item을 리턴한다.
   * @param {Number} pnIndex 요소의 인덱스 번호
   * @return 해당 Index를 Index로 하는 요소
   * @type Object
   */
  this.get = function(pnIndex) {
    this.rangeCheck(pnIndex);
    return this.elements[pnIndex];
  };
  /**
   * 주어진 값이 현재 컬렉션 구성 요소의 인덱스 번호로서 적합한 지 여부를 검사하는 메소드
   * @param {Number} pnIndex 검사할 값
   * @return void
   * @type void
   * @private
   */
  this.rangeCheck = function(pnIndex) {
    if (pnIndex < 0 || pnIndex > this.cnt) {
      throw new Error("Index out of range : " + pnIndex);
    }
  };
};
