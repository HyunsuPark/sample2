﻿/**
 * @fileoverview
 * IE의 XML Node를 List로 wrapping 하는 클래스
 */
/**
 * IE의 XML Node를 List로 wrapping 하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {NodeList} XML NodeList Object
 * @base eXria.data.NodeList
 * @constructor
 * @private
 */ 
eXria.data.xhtml.MsieNodeList = function(poResult) {
  /**
   * Inherit
   */
  eXria.data.NodeList.call(this);
  /**
   * XMLNodeList
   * @type XMLNodeList
   * @private
   */
  this.nodeList = poResult;
  /**
   * return item count in NodeList
   * @return item count number
   * @type Number
   */
  this.getLength = function() {
    return this.nodeList.length;
  };
  /**
   * return NodeItem of parameter index
   * @param pnIdx index
   * @return node
   * @type XMLNode
   */
  this.item = function(pnIdx) {
    return this.nodeList.item(pnIdx);
  };
};