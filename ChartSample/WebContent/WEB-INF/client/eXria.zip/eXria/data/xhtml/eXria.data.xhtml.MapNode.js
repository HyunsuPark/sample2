/**
 * @fileoverview
 * XHTML Mode 사용시 Document Node를 Map으로 wrapping 해주는 클래스
 */
/**
 * XHTML Mode 사용시 Document Node를 Map으로 wrapping 해주는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.xhtml.Node
 */
eXria.data.xhtml.MapNode = function(poNode) {
  /**
   * inherit
   */  
  this.node = poNode;
  
  /**
   * ChildNode의 Element 갯수를 리턴한다.
   * @return ChildNode중 Element 갯수
   * @type Number
   */  
  this.size = function() {
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    var vnSize = 0;
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        // Element
        vnSize++;
      }
    }
    return vnSize;
  };
  /**
   * ChildNode중 넘겨받은 Tag명인 첫번째 노드를 리턴한다.
   * @param {String} psName Tag Name
   * @return 조회된 XMLElementNode
   * @type XMLElementNode
   */  
  this.getNode = function(psName) {
    var node = this.node.getElementByTagNameFromChildNodes(psName);
    return node;
  };
  /**
   * ChildNode중 넘겨받은 Tag명인 첫번째 노드의 TextNode값을 리턴한다.
   * @param {String} psKey 조회할 ElementNode의 Tag명
   * @return 조회된 TextNode의 값
   * @type String
   */  
  this.get = function(psKey) {
    if (!psKey || psKey == "") {
      return null;
    }
    var voNode = this.getNode(psKey);
    try {
      var vsRet = String(voNode.getNodeValue());
    } catch (e) {
      return null;
    }
    return vsRet;
  };
  /**
   * ChildNode에 넘겨받은 Key값이 존재할 경우 존재하는 ChildNode의 하위 TextNode로 값을 설정하고,</br>
   * 존재하지 않는 경우 ChileNode에 Append한다.
   * @param {String} psKey 설정할 Element Tag Name
   * @param {String} psValue 설정할 Value
   * @return void
   * @type void
   */  
  this.put = function(psKey, psValue) {
    var voNode = this.getNode(psKey);
    if (psValue == null || psValue == undefined) psValue = "";
    if (voNode != null) {
      var voValue = voNode.getFirstChild();
      if (voValue != null && (voValue.getNodeType() == 3 || voValue.getNodeType() == 4)) {
        // TextNode, CDataNode
        voNode.replaceChild(this.node.createTextNode(psValue), voValue);
        
      } else {
        voNode.appendChild(this.node.createTextNode(psValue));
      }
    } else {
      voNode = this.node.createElement(psKey, psValue);
      this.node.appendChild(voNode);
    }
  };
  /**
   * 넘겨받은 값을 Tag Name으로 가지는 첫번째 Node를 삭제한다.
   * @param {String} psKey 삭제할 Tag명
   * @return void
   * @type void
   */  
  this.remove = function(psKey) {
    var voNode = this.getNode(psKey);
    if (voNode != null) {
      this.node.removeChild(voNode);
    }
  };
  /**
   * 모든 하위 노드를 삭제한다.
   * @return void
   * @type void
   */  
  this.clear = function() {
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(0);
      if (voNode.getNodeType() == 1) {
        this.node.removeChild(voNode);
      }
    }
  };
  /**
   * 하위 Element의 존재 유무 리턴
   * @return 하위 ElementNode가 없을 경우 true, 아니라면 false
   * @type Boolean
   */  
  this.isEmpty = function() {
    return (this.size() == 0);
  };
  /**
   * ChildNode의 Tag명 만으로 구성된 Collection 객체를 리턴한다.
   * @return Tag Name으로 구성된 Collection
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */  
  this.getKeyCollection = function() {
    var voCollection = new eXria.data.ArrayCollection();
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        // Element
        voCollection.add(voNode.getNodeName());
      }
    }
    return voCollection;
  };
  /**
   * ChildNode의 Element 하위 TextNode 및 CDataNode의 값만으로 구성된 Collection 객체를 리턴한다.
   * @return TextNode 및 CDataNode의 값만으로 구성된 Collection 객체를 리턴한다.
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */  
  this.getValueCollection = function() {
    var voCollection = new eXria.data.ArrayCollection();
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        // Element
        voCollection.add(String(voNode.getNodeValue()));
      }
    }
    return voCollection;
  };
  /**
   * ChildNode의 Element, TextNode 및 CDataNode로 구성된 Object Collection 객체를 리턴한다.
   * @return Element, TextNode 및 CDataNode로 구성된 Collection 객체
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */  
  this.getEntryCollection = function() {
    var voCollection = new eXria.data.ArrayCollection();
    var voNodes = this.node.getChildNodes();
    var vnLength = voNodes.getLength();
    var vsKey = null, voValue = null, vsValue = null;
    
    for (var i = 0; i < vnLength; i++) {
      var voNode = voNodes.item(i);
      if (voNode.getNodeType() == 1) {
        voValue = voNode.getFirstChild();
        vsValue = String(voNode.getNodeValue())
        vsKey = voNode.getNodeName();
        
        if (voValue != null && voValue.getNodeType() == 1) {
          voCollection.add({
            key : vsKey, value : voValue.cloneNode(true)
          });
        } else if (vsValue != null) {
          voCollection.add({
            key : vsKey, value : vsValue
          });
        } else {
          voCollection.add({
            key : vsKey, value : null
          });
        }
      }
    }
    return voCollection;
  };
  /**
   * JSON Format String 값으로 리턴한다.
   * @return JSON Format의 xml data
   * @type String
   */  
  this.toString = function() {
    var voBuilder = new eXria.lang.StringBuilder();
    voBuilder.append("{");
    voIterator = this.getKeyCollection().iterator();
    while (voIterator.hasNext()) {
      var vsKey = voIterator.next();
      voBuilder.append(vsKey).append("=").append(this.get(vsKey));
      if (voIterator.isLast() == false) {
        voBuilder.append(", ");
      }
    }
    voBuilder.append("}");
    return voBuilder.toString();
  };
};
