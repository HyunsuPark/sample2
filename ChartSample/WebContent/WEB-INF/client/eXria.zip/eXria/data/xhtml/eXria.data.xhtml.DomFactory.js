/**
 * @fileoverview
 * 사용자의 Browser Type에 따라 DOM을 생성하는 클래스
 */ 
/**
 * 사용자의 Browser Type에 따라 DOM을 생성하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @constructor
 * @private
 */ 
eXria.data.xhtml.DomFactory = {
  /**
   * 사용자의 Browser에 따라 XMLDocument를 생성한다.
   * @return 생성한 브라우저 종속적인 Document
   * @type XMLDocument
   * @private
   */
  createDom : function() {
    var voDom = null;
    if (window.ActiveXObject) {
      try {
        voDom = new ActiveXObject("Microsoft.XMLDOM");
      } catch (e) {}
      voDom.setProperty("SelectionLanguage", "XPath");
    } else if (window.document.implementation && window.document.implementation.createDocument) {
      try {
        voDom = window.document.implementation.createDocument("", "", null);
      } catch (e) {}
    }
    if (voDom == null) { throw new Error("Can not create Document."); }
    return voDom;
  }
};
