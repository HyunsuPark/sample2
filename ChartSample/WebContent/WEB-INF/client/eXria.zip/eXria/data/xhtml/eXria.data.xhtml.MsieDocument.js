/**
 * @fileoverview
 * IE Document를 생성하는 클래스
 */
/**
 * IE Document를 생성하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @base eXria.data.xhtml.Document
 * @constructor
 * @private
 */ 
eXria.data.xhtml.MsieDocument = function(poPage, psId) {
  /**
   * inherit
   */
  eXria.data.xhtml.Document.call(this);
  /**
   * dom Object
   * @type Object
   * @private
   */
  this.dom = eXria.data.DomDocumentFactory.getDomDocument(poPage, psId);

  if (this.dom == null) { throw new Error("Can not create Document."); }
  this.dom.setProperty("SelectionLanguage", "XPath");

  /**
   * 넘겨받은 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 XML Element
   * @type XMLElementNode
   */
  this.selectSingleNode = function(psXpath) {
	try {
	  return this.dom.selectSingleNode(psXpath);
	} catch(e) {
	  return null;
	}
  };
  /**
   * 넘겨받은 XPath에 해당하는 Node들을 조회하여 NodeList로 리턴한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 NodeList를 Wrapping한 NodeList 객체
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodes = function(psXpath) {
	try {
	  var voNodeList = this.dom.selectNodes(psXpath);
	  return new eXria.data.xhtml.MsieNodeList(voNodeList);
	} catch(e) {
	  return null;
	}
  };
  /**
   * 넘겨받은 XMLElement를 Node에 Append한다.
   * @param {XMLNode} poXML XML Node
   * @return void
   * @type void
   */
  this.loadXML = function(poXML) {
    if(this.dom.documentElement) {
      this.dom.replaceChild(poXML, this.dom.documentElement);
    } else {
//      this.dom.appendChild(poXML);
	  eXria.util.DomUtil.appendNodeElement(this.dom, poXML, this);
    }
  };
  /**
   * 넘겨받은 Text를 Parsing하여 Node에 Append한다.
   * @param {String} psTXT XML Text
   * @return void
   * @type void
   */
  this.loadTXT = function(psTXT) {
    this.dom.loadXML(psTXT);
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 alert으로 출력
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return void
   * @type void
   */
  this.print = function(poNode) {
	if(poNode == null && poNode == undefined) {
	  throw new Error("Node is null.");
	} else {
	  alert(poNode.xml);
	}
  };
  /**
   * 넘겨받은 XPath에 해당하는 Element를 Browser Type에 맞춰 문자열로 반환
   * @param {String} psXpath 찾아올 Element의 XPath
   * @return xml 노드를 문자열화한 객체
   * @type String
   */  
  this.nodeToStr = function(poNode) {
	if(poNode == null && poNode == undefined) {
	  throw new Error("Node is null.");
	} else {
	  return poNode.xml;
	}
  };
};
