/**
 * @fileoverview
 * XHTML Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 */
/**
 * XHTML Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 * @author Choe, hyeon jong.
 * @version 2.0
 * @param {NodeList} XHTML NodeList Object
 * @constructor
 * @base eXria.data.NodeList
 */ 
eXria.data.xhtml.NodeList = function(poResult) {
  /**
   * Inherit
   */
  eXria.data.NodeList.call(this);
  /**
   * PLUGINNodeList
   * @type PLUGINNodeList
   * @private
   */
  this.nodeList = poResult;
  /**
   * return item cound in NodeList
   * @return item count number
   * @type Number
   */
  this.getLength = function() {
//    var voNodeList = this.nodeList;
//    var vnLength = 0;
//	var voTmp = null;
//	var vnLen = (voNodeList.length != null) ? voNodeList.length : voNodeList.getLength();
//	for(var i = 0 ; i < vnLen ; i++) {
//	  voTmp = voNodeList.item(i)
//	  if(voTmp.nodeType == 1) { vnLength++; } 
//	}
//    return vnLength;
	return (this.nodeList.length != null) ? this.nodeList.length : this.nodeList.getLength();
  };
  /**
   * return NodeItem of parameter index
   * @param {Number} pnIdx
   * @return Node
   * @type Node
   */
  this.item = function(pnIdx) {
//	var voNode = null;
//	var vnLen = (this.nodeList.length != null) ? this.nodeList.length : this.nodeList.getLength();
//	for(var i = 0, vnIdx = 0 ; i < vnLen ; i++) {
//	  voNode = this.nodeList.item(i);
//	  if(voNode.nodeType == 1 && vnIdx == pnIdx) { 
//		break;
//	  } else {
//		if(voNode.nodeType == 1) { vnIdx++; } 
//	  }
//	}
//	if(voNode == null) return null;
	var voNode = this.nodeList.item(pnIdx);
    if(voNode == null) return null;
	else return new eXria.data.xhtml.Node(voNode);
  };
};