﻿/**
 * @fileoverview
 * XHTML Mode 사용시 Document를 관리하는 클래스
 */
/**
 * XHTML Mode 사용시 Document를 관리하는 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @param {eXria.data.Instance} poInstance Model Instance
 * @constructor
 * @base eXria.data.Document
 */ 
eXria.data.xhtml.Document = function(poInstance) {
  /**
   * inherit
   */
  eXria.data.Document.call(this);
  /**
   * XMLDocument
   * @type XMLDocument
   * @private
   */
  this.dom = null;
  /**
   * 파라미터로 넘겨받은 URL에 존재하는 XML을 로드하여 바인딩
   * @param {String} psUrl 로딩할 XML이 존재하는 URL
   * @return void
   * @type void
   * @private
   */
  this.loadURL = function(psUrl) {
    var voRequest = eXria.form.xhtml.HttpRequestFactory.create();

    voRequest.open("GET", psUrl, false);
    voRequest.send(null);

    if(voRequest.status == 200) {
      delete this.dom;
      this.dom = voRequest.responseXML;
    }
  };
  /**
   * 넘겨받은 Tag Name의 Element Node를 생성하여 리턴한다.
   * @param {String} psName 생성할 Element Tag Name
   * @return 생성된 XML Element Node
   * @type XMLElementNode
   */
  this.createNode = function(psName) {
    return this.dom.createElement(psName);
  };
  /**
   * 넘겨받은 XPath의 Node를 삭제한다.
   * @param {String} 삭제할 XPath
   * @return void
   * @type void
   */
  this.removeNode = function(psXpath) {
    var voNode = this.selectSingleNode(psXpath);
//    if (voNode == null) { throw new Error("Can not find the node : " + psXpath); }
    if (voNode == null) return null;
    return voNode.parentNode.removeChild(voNode);
  };
};


