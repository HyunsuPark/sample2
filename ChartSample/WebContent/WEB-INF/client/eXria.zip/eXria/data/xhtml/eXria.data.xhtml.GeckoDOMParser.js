﻿/**
 * @fileoverview
 * FireFox, Safari, Chrome, Opera Browser의 Dom Parser 클래스
 */
/**
 * FireFox, Safari, Chrome, Opera Browser의 Dom Parser 클래스
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 2.0
 * @base eXria.data.DOMParser
 * @constructor
 * @private
 */ 
eXria.data.xhtml.GeckoDOMParser = function() {
  eXria.data.DOMParser.call(this);
  /**
   * Gecko DOM Parser
   * @type DOMParser
   * @private
   */
  this.parser = new DOMParser();
  /**
   * XML Text 값을 XMLDocument로 Parsing한다.
   * @param {String} psData XML Test
   * @return Parsing된 XMLDocument
   * @type XMLDocument
   */
  this.parse = function(psData) {
    return this.parser.parseFromString(psData, "text/xml");
  };
};