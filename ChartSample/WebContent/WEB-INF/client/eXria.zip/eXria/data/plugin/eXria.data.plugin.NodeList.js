﻿/**
 * @fileoverview
 * Plugin Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 */
/**
 * Plugin Mode 사용시 Document내부의 Node를 List로써 관리하는 클래스
 * @author Youngjin Cho (yjcho@tomatosystem.co.kr)
 * @version 1.0
 * @param {NodeList} PLUGIN NodeList Object
 * @constructor
 * @base eXria.data.NodeList
 */ 
eXria.data.plugin.NodeList = function(poResult) {
  /**
   * Inherit
   */
  eXria.data.NodeList.call(this);
  /**
   * PLUGINNodeList
   * @type PLUGINNodeList
   * @private
   */
  this.nodeList = poResult;
  /**
   * return item cound in NodeList
   * @return item count number
   * @type Number
   */
  this.getLength = function() {
    var voNodeList = this.nodeList;
    var vnLength = -1;
    if(voNodeList.getLength) vnLength = voNodeList.getLength();
    else vnLength = voNodeList.length;
    return vnLength;
  };
  /**
   * return NodeItem of parameter index
   * @param {Number} pnIdx
   * @return Node
   * @type Node
   */
  this.item = function(pnIdx) {
    return this.nodeList.item(pnIdx);
  };
};