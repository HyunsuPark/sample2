﻿/**
 * @fileoverview
 * Document Node Object Class
 */
/**
 * plugin.NativeNode
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {eXria.data.Node} poNode Node Object
 * @constructor
 * @base eXria.data.Node
 */ 
eXria.data.plugin.NativeNode = function(poNode) {
  if (poNode == null) {
    throw new Error("Node is null.");
  }
  /**
   * inherit
   */
  eXria.data.Node.call(this, poNode);
  /**
   * eXria.data.Node
   * @type eXria.data.Node
   * @private
   */
  this.node = poNode;
  /**
   * XMLNode Tag Name
   * @type String
   * @private
   */
  this.name = this.node.nodeName;
  /**
   * 파라미터로 넘어온 Node를 자식 Node의 마지막에 추가한다.
   * @param {eXria.data.Node} poNode 추가할 Node Object
   * @type void
   * @return void
   */
  this.appendChild = function(poNode) {
	if(!poNode) return;
	this.node.appendChild(poNode.node);
  };
  /**
   * 현재 Node와 동일한 Node를 복사하여 리턴한다.
   * @param {Boolean} pbDeep deep copy 유무를 지정한다. (true | false)
   * @return 복사된 Node Object
   * @type eXria.data.Node
   */
  this.cloneNode = function(pbDeep) {
	if(pbDeep != true) pbDeep = false;
	return new eXria.data.plugin.NativeNode(this.node.cloneNode(pbDeep));
  };
  /**
   * 현재 Node의 자식 Node들을 NodeList 형식으로 리턴한다.
   * @type eXria.data.NodeList
   * @return 생성된 자식 Node List
   */
  this.getChildNodes = function() {
	var voChildNodes = this.node.childNodes;
	if(!voChildNodes) { return null; }
	return new eXria.data.plugin.NativeNodeList(this.node.childNodes);
  };
  /**
   * 현재 Node의 첫번째 자식 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 첫번째 자식 Node
   */
  this.getFirstChild = function() {
	var voFirstChild = this.node.firstChild;
	if(!voFirstChild) { return null; }
	
	return new eXria.data.plugin.NativeNode(voFirstChild);
  };
  /**
   * 현재 Node의 마지막 자식 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 마지막 자식 Node
   */
  this.getLastChild = function() {
	var voLastChild = this.node.lastChild;
	if(!voLastChild) { return null; }
	
	return new eXria.data.plugin.NativeNode(voLastChild);
  };
  /**
   * 현재 Node의 바로 다음 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 다음 Node
   */
  this.getNextSibling = function() {
	var voNextNode = this.node.nextSibling;
	if(!voNextNode) { return null; }
	
	return new eXria.data.plugin.NativeNode(voNextNode);
  };
  /**
   * 현재 Node의 이름을 리턴한다.
   * @type String
   * @return 현재 Node의 이름
   */
  this.getNodeName = function() {
    return this.name;
  };
  /**
   * 현재 Node의 value를 리턴한다.
   * @type String
   * @return 현재 Node의 Value
   */
  this.getNodeValue = function() {
	var vsValue = null;
	var vnNodeType = this.node.nodeType;
	if(vnNodeType == 1) {
	  var voChildNode = this.node.firstChild;
	  if(!voChildNode) {
		vsValue = "";
	  } else {
	    vsValue = this.node.firstChild.nodeValue;
	  }
	} else if(vnNodeType == 3 || vnNodeType == 4) {
	  vsValue = this.node.nodeValue;
	} else {
	  vsValue = null;
	}
	return vsValue;
  };
  /**
   * 현재 Node의 부모 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 부모 Node
   */
  this.getParentNode = function() {
	var voParentNode = this.node.parentNode;
	if(!voParentNode) { return null; }
    return new eXria.data.plugin.NativeNode(this.node.parentNode);
  };
  /**
   * 현재 Node의 바로 전 Node를 리턴한다.
   * @type eXria.data.Node
   * @return 현재 Node의 바로 전 Node
   */
  this.getPreviousSibling = function() {
	var voPNode = this.node.previousSibling;
	if(!voPNode) { return null; }
	
    return new eXria.data.plugin.NativeNode(voPNode);
  };
  /**
   * Element를 생성하여 리턴한다.
   * @param {String} psTagName 생성할 Element의 Tag Name
   * @param {String} psValue 생성할 Element의 Value [ null을 넘길 경우 TextNode가 생성되지 않은 Element 리턴 ]
   * @type {eXria.data.Node}
   * @return 생성된 Element
   */
  this.createElement = function(psTagName, psValue) {
	var voNode = null;
	try {
	  var voOwnerDocument = this.node.ownerDocument;
	  voNode = new eXria.data.plugin.NativeNode(voOwnerDocument.createElement(psTagName));
	  if(psValue != null) {
		voNode.appendChild(new eXria.data.plugin.NativeNode(voOwnerDocument.createTextNode(psValue)));
	  }
	} catch(e) { voNode = null; }
	return voNode;
  };
  /**
   * TextNode를 생성하여 리턴
   * @param {String} psValue 생성할 Node의 Value값
   * @type {eXria.data.Node}
   * @return 생성된 TextNode
   */
  this.createTextNode = function(psValue) {
	var voNewNode = null;
	try {
	  voNewNode = this.node.ownerDocument.createTextNode(psValue);
	} catch(e) { return null; }
	return new eXria.data.plugin.NativeNode(voNewNode);
  };
  /**
   * 현재 Node의 자식 Node 유무를 리턴한다.
   * @type Boolean
   * @return 자식 Node의 존재 유무
   */
  this.hasChildNodes = function() {
    return this.node.hasChildNodes();
  };
  /**
   * 현재 Node의 자식 Node 중 파라미터로 넘어온 Node와 일치하는 Node를 삭제한다.
   * @param {eXria.data.Node} poNode 삭제할 Node
   * @type eXria.data.Node
   * @return 삭제된 Node
   */
  this.removeChild = function(poNode) {
	if(!poNode) return;
	var voRmChild = this.node.removeChild(poNode.node);
	if(voRmChild) {
	  return poNode;
	} else {
	  return null;
	}
  };
  /**
   * 현재 Node의 Value 파라미터로 넘어온 데이터로 변경한다.
   * @param {String} psValue 변경할 데이터
   * @type void
   * @return void
   */
  this.setNodeValue = function(psValue) {
	try {
	  psValue = (psValue ? psValue : "");
      var voValue = this.node.firstChild;
      if(voValue != null) {
		voValue.nodeValue = psValue;
	  } else {
		this.node.appendChild(this.node.ownerDocument.createTextNode(psValue));
	  }
	} catch(e) { return null; }
  };
  /**
   * 두번째 파라미터로 넘어온 Node와 동일한 Node가 있을 경우 해당 위치에 첫번째 파라미터로 넘어온 Node를 셋팅.
   * @param {eXria.data.Node} poNewNode 추가할 Node
   * @param {eXria.data.Node} poOldNode 덮어 쓸 Node
   * @type eXria.data.Node
   * @return 삭제된 Node
   */
  this.replaceChild = function(poNewNode, poOldNode) {
	var voRepChild = this.node.replaceChild(poNewNode.node, poOldNode.node);
	if(voRepChild) {
	  return poOldNode;
	} else {
	  return null;
	}
  };
  /**
   * 두번째 파라미터로 넘어온 Node의 앞에 첫번째로 넘어온 파라미터 Node를 추가한다.
   * @param {eXria.data.Node} poNewNode 추가할 Node
   * @param {eXria.data.Node} poRefNode 덮어 쓸 Node
   * @type eXria.data.Node
   * @return insert 되기 전 Node
   */
  this.insertBefore = function(poNewNode, poRefNode) {
	var voOldNode = this.node.insertBefore(poNewNode.node, poRefNode.node);
	if(voOldNode) {
	  return poRefNode;
	} else {
	  return null;
	}
  };
  /**
   * node type을 리턴한다.
   * @type Number
   * @return 해당 Node의 node Type
   */
  this.getNodeType = function() {
	return this.node.nodeType;
  };
  /**
   * 현재 클래스의 이름을 반환 한다.
   * @type String
   * @return 현재 클래스 이름
   */
  this.toString = function() {
	return "eXria.data.plugin.NativeNode";
  };
  /**
   * 파라미터로 넘어온 Node와 현재 Node가 같은 Node인지 비교한다.
   * @param {eXria.data.Node} poNode 비교할 Node
   * @return 두개의 Node가 같은 Node인지 유무
   * @type Boolean
   */
  this.equal = function(poNode) {
	return this.node == poNode.node;
  };
  /**
   * C현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Node
   * @return Node Object
   */
  this.getElementByTagName = function(psTagName) {
    var voNodes = this.getElementsByTagName(psTagName);
    if(voNodes.getLength() == 0) {
      return null;
    } else {
      return voNodes.item(0);
    }
  };
  /**
   * 현재 Node 하위의 모든 ChildNode 중 Depth와 상관 없이 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.NodeList
   * @return NodeList Object
   */
  this.getElementsByTagName = function(psTagName) {
	var voNodes = this.node.getElementsByTagName(psTagName);
	if(!voNodes) return null;
	return new eXria.data.plugin.NativeNodeList(voNodes);
  };
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 첫번째 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Node
   * @return NodeList Object
   */
  this.getElementByTagNameFromChildNodes = function(psTagName) {
    var voNodes = this.getChildNodes();
    var voNode = null;
    var voTmpNode = null;
    for(var i = 0, vnLen = voNodes.getLength() ; i < vnLen ; i++) {
      voNode = voNodes.item(i);
      if(voNode.getNodeName() == psTagName) {
        voTmpNode = voNode;
        break;
      }
    }
    return voTmpNode;
  }
  /**
   * 현재 Node의 ChildNode 중 파라미터로 넘어온 Tag Name과 동일한 모든 Element를 리턴한다.
   * @param {String} psTagName
   * @type eXria.data.Collection
   * @return eXria.data.Collection Object
   */
  this.getElementsByTagNameFromChildNodes = function(psTagName) {
   var voNodes = this.node.childNodes;
   var voNodeArr = new eXria.data.ArrayCollection();

   for(var i = 0, vnLen = voNodes.length ; i < vnLen ; i++) {
     var voNode = voNodes.item(i);
     if(voNode.nodeName == psTagName) {
       voNodeArr.add(new eXria.data.plugin.NativeNode(voNode));
     }
   }
   return voNodeArr;
  };
  /**
   * 현재 Node의 XML 스트링을 리턴.
   * @type String
   * @return XML String
   */
  this.getXML = function() {
    if (window.page.metadata.browser.ie > 0) {
      return this.node.xml;
    } else {
      var vSerializer = new XMLSerializer();
      return vSerializer.serializeToString(this.node);
    }
  };
};
