/**
 * @fileoverview
 * Data 및 Source에 대한 Type을 결정하기 위한 상수 정의 클래스</br>
 * enum (Add Type)</br>
 * eXria.data.plugin.AddAndSrcType.DATAADD</br>
 * eXria.data.plugin.AddAndSrcType.DATAREPLACE</br>
 * eXria.data.plugin.AddAndSrcType.FIELDNAMENEW</br>
 * eXria.data.plugin.AddAndSrcType.FIELDMATCH</br>
 * eXria.data.plugin.AddAndSrcType.FIRSTROWFIELD_SRC</br>
 * eXria.data.plugin.AddAndSrcType.FIRSTROWFIELD_TGT</br>
 * eXria.data.plugin.AddAndSrcType.FIRSTROWFIELD_ALL</br>
 * enum (Source Type)</br>
 * eXria.data.plugin.AddAndSrcType.INSTANCESOURCE</br>
 * eXria.data.plugin.AddAndSrcType.DBSOURCE</br>
 * eXria.data.plugin.AddAndSrcType.CSVFILESOURCE</br>
 * eXria.data.plugin.AddAndSrcType.TABFILESOURCE</br>
 * eXria.data.plugin.AddAndSrcType.DATASETSOURCE</br>
 * eXria.data.plugin.AddAndSrcType.EXCELFILESOURCE</br>
 * eXria.data.plugin.AddAndSrcType.DELIMITERSOURCE</br>
 * eXria.data.plugin.AddAndSrcType.BOMFILETYPE</br>
 * eXria.data.plugin.AddAndSrcType.NOBOMFILETYPE</br>
 * eXria.data.plugin.AddAndSrcType.UTF8FILETYPE</br>
 * eXria.data.plugin.AddAndSrcType.UTF16FILETYPE</br>
 * eXria.data.plugin.AddAndSrcType.ADOSOURCE</br>
 */
/**
 * Data 및 Source에 대한 Type을 결정하기 위한 상수 정의 클래스
 * @author Choe, hyeon jong
 * @version 1.0
 * @constructor
 */
eXria.data.plugin.AddAndSrcType = {
	//ADD Type
	DATAADD				: 0X0001, // target에 이미 노드가 있을경우에 뒤에 추가
	DATAREPLACE			: 0X0002, // target에 이미 노드가 있을경우에 지우고 추가
	FIELDNAMENEW		: 0X0004, // 들어온 데이터의 필드명에 맞추어 target에 적용
	FIELDMATCH   		: 0X0008, // target에 있는 field만 생성
	FIRSTROWFIELD_SRC 	: 0X0010, // source에 첫줄을 필드명으로 생성
	FIRSTROWFIELD_TGT	: 0X0020, // target에 첫줄을 필드명으로 생성
	FIRSTROWFIELD_ALL	: 0X0030, // source와 target에 있는 모든 첫줄을 필드명으로 생성
	//Source Type
	INSTANCESOURCE	: 0X001,	//인스턴스소스
	DBSOURCE		: 0X002,	//내장 Sqlite 소스
	CSVFILESOURCE	: 0X004,	//CSV 형식 소스
	TABFILESOURCE	: 0X008,	//탭 구분 문자열 파일 소스
	DATASETSOURCE	: 0X010,	//Plugin DataSet 소스
	EXCELFILESOURCE	: 0X020, 	//엑셀파일 소스
	DELIMITERSOURCE : 0X040,	//사용자 정의 구분자 파일 소스
	BOMFILETYPE		: 0X080,	//유니코드 BOM 문자 형식 소스
	NOBOMFILETYPE	: 0X100,	//유니코드 NOBOM 문자 형식 소스
	UTF8FILETYPE	: 0X200,	//UTF8 형식 파일 소스
	UTF16FILETYPE	: 0X400,	//UTF16 형식 파일 소스
	ADOSOURCE		: 0X800		//ADO(Active Data Object) 형식 파일 소스(IE전용)
};
