/**
 * @fileoverview
 * File Open시 사용되는 Mode에 대한 상수정의 클래스</br>
 * enum list</br>
 * eXria.data.plugin.IOMode.READONLY</br>
 * eXria.data.plugin.IOMode.WRITEONLY</br>
 * eXria.data.plugin.IOMode.READWRITE</br>
 * eXria.data.plugin.IOMode.APPEND</br>
 * eXria.data.plugin.IOMode.BINARY
 */
/**
 * File Open시 사용되는 Mode에 대한 상수정의 클래스</br>
 * @author Choe, Hyeon Jong
 * @version 1.0
 * @constructor
 */
eXria.data.plugin.IOMode = {
	READONLY		:	0X0001,
	WRITEONLY		:	0X0002,
	READWRITE		:	0X0004,
	APPEND			:	0X0008,
	BINARY			:	0X0010,
	TEXT			:	0X0020,
	CREATE			:	0X0040
};