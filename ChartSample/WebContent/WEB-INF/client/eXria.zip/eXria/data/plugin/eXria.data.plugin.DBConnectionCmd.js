/**
 * @fileoverview
 * Plugin Mode 사용시 DB와의 Connection을 관리하는 클래스
 */
/**
 * Plugin Mode 사용시 DB와의 Connection을 관리하는 클래스
 * @author Choe, hyeon jong
 * @version 1.0
 * @param {Object} poConnection connection
 * @constructor
 */
eXria.data.plugin.DBConnectionCmd = function(poModel, psId, pnTypeSrc, psSrcConn, pnTarget, psTargetName, psTargerConn) {
  /**
   * model
   * @type eXria.form.Model
   */
  this.model = poModel;
  /**
   * id
   * @type String
   */
  this.id = psId;
//  /**
//   * connection Object
//   * @type DBConnectionCmd
//   * @private
//   */
//  this.connection = poConnection;
  this.typeSrc = pnTypeSrc;
  this.srcConn = psSrcConn;
  this.target = pnTarget;
  this.targetName = psTargetName;
  this.TargerConn = psTargerConn;
  
  /**
   * dbcommandcmd를 저장하는 map
   * @type eXria.data.ArrayMap
   * @private
   */
  this.dbCommandCmdMap = new eXria.data.ArrayMap();
  /**
   * Transaction start</br>
   * AutoCommit이 false로 되어있을 경우 Transaction을 시작하기 위해</br>
   * 명시적으로 호출 Transaction을 시작한다.</br>
   * AutoCommit이 false일 경우 Transaction을 시작하기 위해서는 반드시 호출해주어야 한다.</br>
   * @return void
   * @type void
   */
  this.begin = function() {
    this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).begin();
  };
  /**
   * Connection Close
   * @return void
   * @type void
   */
  this.close = function() {
    this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).close();
  };
  /**
   * transaction commit
   * @return void
   * @type void
   */
  this.commit = function() {
    this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).commit();
  };
  /**
   * DBCommandCmd 인터페이스를 구함
   * @param {String} psId 
   * @return DBCommandCmd 타입의 인터페이스가 리턴된다.
   * @type eXria.data.plugin.DBCommandCmd
   * @see eXria.data.plugin.DBCommandCmd
   */
  this.getCommand = function(psId) {
    var voCommand = null;
    voCommand = this.dbCommandCmdMap.get(psId);
    
    if(voCommand == null) {
      voCommand = new eXria.data.plugin.DBCommandCmd(psId, this.model, this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).getCommand(psId));
      this.dbCommandCmdMap.put(psId, voCommand);
    }
    return voCommand;
  };
  /**
   * Close 상태 체크
   * @return close 상태이면 true 리턴
   * @type Boolean
   */
  this.isClosed = function() {
    return this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).isClosed();
  };
  /**
   * open 상태 체크
   * @return open 상태이면 true리턴
   * @type Boolean
   */
  this.isOpened = function() {
    return this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).isOpened();
  };
  /**
   * Auto commit 설정
   * @param {Boolean} pbAuto true이면 AutoCommit 설정
   * @return void
   * @type void
   */
  this.setAutoCommit = function(pbAuto) {
    this.model.plugin.getConnection(this.id, this.typeSrc, this.srcConn, this.target, this.targetName, this.targerConn).setAutoCommit();
  };
};