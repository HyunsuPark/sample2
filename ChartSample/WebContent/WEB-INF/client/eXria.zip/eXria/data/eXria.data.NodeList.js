﻿/**
 * @fileoverview
 * Node를 List로 관리하기 위한 Interface
 */
/**
 * Node를 List로 관리하기 위한 Interface
 * @version 1.0
 * @constructor
 */ 
eXria.data.NodeList = function() {
  /**
   * NodeList의 Item 갯수를 리턴한다.
   * @return item count number
   * @type Number
   */
  this.getLength = null;
  /**
   * 해당 index의 Node를 리턴한다.
   * @param {Number} pnIdx index
   * @return Node Object
   * @type eXria.data.Node
   */
  this.item = null;
};