﻿/**
 * @fileoverview
 * Document 클래스의 Interface
 */
/**
 * Document 클래스의 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @constructor
 */ 
eXria.data.Document = function() {
  /**
   * XMLDocument
   * @type XMLDocument
   * @private
   */
  this.dom = null;
  /**
   * 파라미터로 넘겨받은 URL에 존재하는 XML을 로딩한다.
   * @param {String} psUrl 로딩할 XML이 존재하는 URL
   * @return void
   * @type void
   */
  this.loadURL = null;
  /**
   * 넘겨받은 XMLElement를 Node에 Append한다.
   * @param {XMLNode} poXML XML Node
   * @return void
   * @type void
   */
  this.loadXML = null;
  /**
   * 넘겨받은 Text를 Parsing하여 Node에 Append한다.
   * @param {String} psTXT XML Text
   * @return void
   * @type void
   */ 
  this.loadTXT = null;
  /**
   * 넘겨받은 Tag Name의 Element Node를 생성하여 리턴한다.
   * @param {String} psName 생성할 Element Tag Name
   * @return 생성된 XML Element Node
   * @type Node|Element
   */
  this.createNode = null;
  /**
   * 넘겨받은 XPath의 Node를 삭제한다.
   * @param {String} psXpath 삭제할 XPath
   * @return void
   * @type void
   */
  this.removeNode = null;
  /**
   * 넘겨받은 XPath로 단일 Node를 조회한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 XML Element
   * @type Node
   */
  this.selectSingleNode = null;
  /**
   * 넘겨받은 XPath에 해당하는 Node들을 조회하여 NodeList로 리턴한다.
   * @param {String} psXpath 조회할 XPath
   * @return 조회된 NodeList를 Wrapping한 NodeList 객체
   * @type eXria.data.NodeList
   * @see eXria.data.NodeList
   */
  this.selectNodes = null;
};
