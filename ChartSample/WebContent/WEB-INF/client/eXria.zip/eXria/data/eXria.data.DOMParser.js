﻿/**
 * @fileoverview
 * DOM Parser의 Interface
 */
/**
 * DOM Parser의 Interface
 * @version 1.0
 * @implements eXria.data.xhtml.GeckoDOMParser
 * @implements eXria.data.xhtml.MsieDOMParser
 * @constructor
 * @private
 */
eXria.data.DOMParser = function() {
  /**
   * DOM parser
   * @type Object
   * @private
   */
  this.parser = null;
  /**
   * XML Text 값을 XMLDocument로 Parsing한다.
   * @param {String} psData XML Test
   * @return Parsing된 XMLDocument
   * @type XMLDocument
   */
  this.parse = null;
  /**
   * Parser Clear
   * @return void
   * @type void
   */
  this.clear = function() {
    delete this.parser;
  };
};