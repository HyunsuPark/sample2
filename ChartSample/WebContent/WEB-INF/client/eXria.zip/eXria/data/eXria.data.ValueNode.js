﻿/**
 * @fileoverview
 * Node의 Value를 관리하기 위한 클래스의 Interface
 */
/**
 * Node의 Value를 관리하기 위한 클래스의 Interface
 * @author Kim, Kang Seok (drkimks@tomatosystem.co.kr)
 * @version 1.0
 * @param {Node} poNode XML Node
 * @constructor
 * @base eXria.data.Node
 */ 
eXria.data.ValueNode = function(poNode) {
  /**
   * inherit
   */
  eXria.data.Node.call(this, poNode);
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.
   * @return TextNode 값
   * @type String
   */
  this.getValue = null;
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.
   * @param {String} psValue value
   * @return void
   * @type void
   */
  this.setValue = null;
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.<br/>
   * 만약 값이 없을경우 argument의 값을 대신 리턴한다.
   * @param {String} psFix default value
   * @return TextNode의 값 또는 argument의 값
   * @type String
   */
  this.getString = null;
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.<br/>
   * 설정 값이 Null 일경우 두번째 argument의 값을 설정한다.
   * @param {String} psValue value
   * @param {String} psFix alternate value
   * @return void
   * @type void
   */
  this.setString = null;
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.<br/>
   * 만약 값이 없을경우 argument의 값을 대신 리턴한다.
   * @param {Number} pnFix alternate value
   * @return Number로 치환된 TextNode 값
   * @type Number
   */
  this.getNumber = null;
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.<br/>
   * 설정 값이 Null 일경우 두번째 argument의 값을 설정한다.
   * @param {Number} pnValue value
   * @param {Number} pnFix alternate value
   * @return void
   * @type void
   */
  this.setNumber = null;
  /**
   * ValueNode가 참조하고 있는 XML Node의 TextNode 값을 리턴한다.<br/>
   * 만약 값이 없을경우 argument의 값을 대신 리턴한다.
   * @param {Boolean} pbFix alternate value
   * @return boolean으로 치환된 TextNode 값
   * @type Boolean
   */
  this.getBoolean = null;
  /**
   * ValueNode가 참조하고 있는 XML Node에 TextNode 값을 설정한다.
   * 설정 값이 Null 일경우 두번째 argument의 값을 설정한다.
   * @param {Boolean} puValue value
   * @param {Boolean} pbFix alternate value
   * @return void
   * @type void
   */
  this.setBoolean = null;
};
