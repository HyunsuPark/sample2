﻿/**
 * @fileoverview
 * msxml 버전에 맞춰 ActiveXObject를 생성하여 리턴하는 팩토리 클래스
 */
 
/**
 * msxml 버전에 맞춰 ActiveXObject를 생성하여 리턴하는 팩토리 클래스
 * @version 1.0
 * @author Choe, hyeon jong
 * @constructor
 * @private
 */ 

eXria.data.DomDocumentFactory = {
  msxmlNames : 
  [
    "MSXML2.DOMDocument.6.0",
    "MSXML2.DOMDocument.5.0",
    "MSXML2.DOMDocument.4.0",
    "MSXML2.DOMDocument.3.0"
  ]
  ,
  /**
   * msxml 버전에 맞춰 ActiveXObject를 생성
   * @private
   */
  getDomDocument : function(poPage, psId) {
	if(window.ActiveXObject) {
	  var msxmlNamesLen = this.msxmlNames.length;
	  for(var i = 0 ; i < msxmlNamesLen ; i++) {
	    try {
		  this.voDomObj = new ActiveXObject(this.msxmlNames[i]);
	    } catch (e) {}
		if(this.voDomObj != null) {
	      if(this.voDocumentDom == null) {
	    	this.voDocumentDom = this.voDomObj;
	      } else {
	    	if(this.voInstanceDom == null) {
	    	  this.voInstanceDom = new eXria.data.Map();
	    	}
	    	this.voInstanceDom.put(psId, this.voDomObj);
	      }
	      break;
	    }
	  }
	} else {
	  this.voDomObj = poPage.window.document.implementation.createDocument("", "", null);
	  if(this.voDocumentDom == null) {
		this.voDocumentDom = this.voDomObj;
	  } else {
		if(this.voInstanceDom == null) {
		  this.voInstanceDom = new eXria.data.Map();
		}
	    this.voInstanceDom.put(psId, this.voDomObj);
	  }
	}
	return this.voDomObj;
  },
  /**
   * DomDocument return
   * @type eXria.data.Map
   * @return DOM Document Map
   * @private
   */
  getDomDocObj : function() {
	return this.voInstanceDom;
  }
}; 