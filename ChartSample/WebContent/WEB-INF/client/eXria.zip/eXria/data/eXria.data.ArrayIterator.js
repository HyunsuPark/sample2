﻿/**
 * @fileoverview
 * XML Node를 Array Iterator 형태로 wrapping 하는 클래스
 */
/**
 * XML Node를 Array Iterator 형태로 wrapping 하는 클래스
 * @author Kim, Min Seok
 * @version 1.0
 * @param {eXria.data.Collection} poCollection Collection Object
 * @constructor
 * @base eXria.data.Iterator
 */

eXria.data.ArrayIterator = function(poCollection) {
  /**
   * inherit
   */
  eXria.data.Iterator.call(this, poCollection);
  /**
   * Iterator의 현재 포인트가 Iterator의 첫번째인지 아닌지를 확인하여 리턴한다.
   * @return 첫번째 포인트이면 true 아니면 false
   * @type Boolean
   */
  this.isFirst = function() {
      return (this.cursor == 0);
  };
  /**
   * Iterator의 현재 포인트가 Iterator의 마지막인지 아닌지를 확인하여 리턴한다.
   * @return 마지막이면 true 아니면 false
   * @type Boolean
   */
  this.isLast = function() {
	return (this.cursor == this.collection.cnt);
  };
};
