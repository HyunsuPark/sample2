﻿/**
 * @fileoverview
 * Map으로 생성되어있는 XML Node를 Array Map 형태로 wrapping 하거나 새로운 Array Map을 생성하는 클래스
 */
/**
 * Map으로 생성되어있는 XML Node를 Array Map 형태로 wrapping 하거나 새로운 Array Map을 생성하는 클래스
 * @author Kim, Min Seok
 * @version 1.0
 * @param {eXria.data.Map} poMap Map Object
 * @constructor
 * @base eXria.data.Map
 */ 
eXria.data.ArrayMap = function(poMap) {
  /**
   * inherit
   */
  eXria.data.Map.call(this);
  /**
   * key에 순번을 정렬하기 위해 사용되는 배열 객체
   * @type Array(Number)
   * @private
   */
  var maSeq = [];
  /**
   * 순번 저장 배열을 오름차순 정렬하기 위한 메소드
   * 지정된 두 값의 순서를 결정하기 위한 두 값의 차
   * @type Number
   * @private
   */
  var sortNumber = function(a, b) {
    return a - b;
  };
  /**
   * getKeyCollection 메소드에 의해 반환될 key저장 Collection 객체
   * @type eXria.data.ArrayCollection
   * @private
   */
  this.keyCollection = new eXria.data.ArrayCollection();
  /**
   * getValueCollection 메소드에 의해 반환될 key저장 Collection 객체
   * @type eXria.data.ArrayCollection
   * @private
   */
  this.valueCollection = new eXria.data.ArrayCollection();

  if (poMap != null) {
    this.entries = poMap.entries;
    this.keyEntries = poMap.keyEntries;
    this.seqEntries = poMap.seqEntries;
    this.seq = poMap.seq;
  }
  /**
   * Map에 저장된 Item의 갯수를 리턴한다.
   * @return Map에 저장된 데이타 크기[개수]
   * @type Number
   */
  this.size = function() {
    this.syncEntries();
    return this.cnt;
  };
  /**
   * Map에 저장된 데이터 중 Parameter로 넘어온 Key에 해당되는 데이터가 있을 경우 해당 데이터를 삭제한다.
   * @param {String} psKey 삭제하고자 하는 데이타의 키 값
   * @return void
   * @type void
   */
  this.remove = function(psKey) {
    this.isChanged = true;
    delete this.entries[psKey];
  };
  /**
   * 현재 Map 객체의 모든 데이터를 삭제하고 Map을 초기화 한다.
   * @return void
   * @type void
   */
  this.clear = function() {
    this.isChanged = true;
    this.seq = 0;
    this.entries = new Object();
    this.seqEntries = {};
    this.keyEntries = {};
    this.cnt = 0;
  };
  /**
   * 현재 Map에 저장된 Item이 없는지 체크하여 리턴한다.
   * @return Map 내부에 데이터가 없을 경우 TRUE, 있다면 FALSE
   * @type Boolean
   */
  this.isEmpty = function() {
    this.syncEntries();
    return (this.cnt == 0);
  };
  /**
   * Map에 저장된 모든 Key를 ArrayCollection 형태로 변환하여 리턴한다.
   * @return Map에 저장된 데이타들의 키 값을 저장한 컬렉션
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getKeyCollection = function() {
    this.syncEntries();
    return this.keyCollection;
  };
  /**
   * Map에 저장된 모든 Value를 ArrayCollection 형태로 변환하여 리턴한다.
   * @return Map에 저장된 데이타들의 value 값을 저장한 컬렉션
   * @type eXria.data.ArrayCollection
   * @see eXria.data.ArrayCollection
   */
  this.getValueCollection = function() {
    this.syncEntries();
    return this.valueCollection;
  };
  
  /**
   * Map 변경에 의해 동기화 되어야될 속성들 처리를 수행하는 메소드
   */
  this.syncEntries = function() {
    
    if(this.isChanged) {
      var vnCnt = 0;
      maSeq = [];
      var voEntries = this.entries;
      var voSeqEntries = this.seqEntries;
      
      for(var member in voEntries) {
        maSeq.push(voSeqEntries[member]);
        vnCnt++;
      }
      maSeq.sort(sortNumber);
      
      var vnSize = maSeq.length;
      var vnSeq = 0;
      var voKeyEntries = this.keyEntries;
      
      var voKeyCollection = this.keyCollection;
      var voValueCollection = this.valueCollection;
      voKeyCollection.clear();
      voValueCollection.clear();
  
      for(var i = 0; i < vnSize; i++) {
        vnSeq = maSeq[i];
        voKeyCollection.add(voKeyEntries[vnSeq]);
        voValueCollection.add(voEntries[voKeyEntries[vnSeq]]);
      }
      if(vnCnt == 0) {
        this.seq = 0;
        this.seqEntries = {};
        this.keyEntries = {};
      }
      this.cnt = vnCnt;
      this.isChanged = false;
     }
  };
  
  /**
   * Map에 저장된 모든 데이터를 "," 구분자를 사용하여 문자열 형태로 리턴한다.
   * @return Map에 저장된 데이타들의 문자열 형태 표현 값
   * @type String
   */
  this.toString = function() {
    var voBuilder = new eXria.lang.StringBuilder();
    voBuilder.append("{");
    var voIterator = this.getKeyCollection().iterator();
    var vsKey = null;
    while (voIterator.hasNext()) {
      vsKey = voIterator.next();
      voBuilder.append(vsKey).append("=").append(this.get(vsKey));
      if (voIterator.isLast() == false) { voBuilder.append(", "); }
    }
    voBuilder.append("}");
    return voBuilder.toString();
  };
};
