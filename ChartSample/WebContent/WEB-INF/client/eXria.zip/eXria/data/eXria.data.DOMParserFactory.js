﻿/**
 * @fileoverview
 * Browser Type에 맞게 Parser를 리턴해주는 클래스
 */
/**
 * Browser Type에 맞게 Parser를 리턴해주는 클래스
 * @version 1.0
 * @see eXria.data.DOMParser
 * @constructor
 * @private
 */ 
eXria.data.DOMParserFactory = {
  /**
   * DOM을 Browser 타입에 맞춰 생성 후 리턴
   * @private
   */
  getParser : function(poPage) {
    if(window.ActiveXObject) {
      return new eXria.data.xhtml.MsieDOMParser(poPage);
    } else if(window.DOMParser) {
      return new eXria.data.xhtml.GeckoDOMParser(poPage);
    } else {
      return null;
    }
  }
}; 